package com.danga.MemCached;

import java.io.IOException;

public class NestedIOException extends IOException
{
  private static final long serialVersionUID = 305761673292171137L;

  public NestedIOException(Throwable paramThrowable)
  {
    super(paramThrowable.getMessage());
    super.initCause(paramThrowable);
  }

  public NestedIOException(String paramString, Throwable paramThrowable)
  {
    super(paramString);
    initCause(paramThrowable);
  }
}