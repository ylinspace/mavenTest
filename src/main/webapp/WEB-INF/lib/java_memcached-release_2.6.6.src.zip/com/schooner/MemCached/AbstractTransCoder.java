package com.schooner.MemCached;

import java.io.IOException;
import java.io.OutputStream;

public abstract class AbstractTransCoder
  implements TransCoder
{
  public int encode(SockOutputStream paramSockOutputStream, Object paramObject)
    throws IOException
  {
    paramSockOutputStream.resetCount();
    encode(paramSockOutputStream, paramObject);
    return paramSockOutputStream.getCount();
  }

  public abstract void encode(OutputStream paramOutputStream, Object paramObject)
    throws IOException;
}