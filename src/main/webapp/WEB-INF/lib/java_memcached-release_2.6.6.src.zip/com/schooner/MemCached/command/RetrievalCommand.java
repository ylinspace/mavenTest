package com.schooner.MemCached.command;

import com.schooner.MemCached.MemcachedItem;
import com.schooner.MemCached.NativeHandler;
import com.schooner.MemCached.SchoonerSockIO;
import com.schooner.MemCached.TransCoder;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.Arrays;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class RetrievalCommand extends Command
{
  private static Logger log = LoggerFactory.getLogger(RetrievalCommand.class);
  private static final byte[] B_END = "END\r\n".getBytes();
  private static final byte[] B_VALUE = "VALUE ".getBytes();
  private String key;
  private String cmd;

  public RetrievalCommand(String paramString1, String paramString2)
  {
    this.key = paramString2;
    this.cmd = paramString1;
    StringBuilder localStringBuilder = new StringBuilder(paramString1).append(" ").append(paramString2).append("\r\n");
    this.textLine = localStringBuilder.toString().getBytes();
  }

  public MemcachedItem response(SchoonerSockIO paramSchoonerSockIO, TransCoder paramTransCoder, short paramShort)
    throws IOException
  {
    byte[] arrayOfByte = paramSchoonerSockIO.getResponse(paramShort);
    MemcachedItem localMemcachedItem = new MemcachedItem();
    if (arrayOfByte == null)
      return localMemcachedItem;
    ResponseParser localResponseParser = new ResponseParser(this);
    localResponseParser.exec(arrayOfByte);
    if (localResponseParser.retvalue != null)
    {
      Value localValue = localResponseParser.retvalue;
      if (this.cmd.equals("gets"))
        localMemcachedItem.casUnique = localValue.casUnique;
      try
      {
        if (NativeHandler.isHandled(localValue.flags))
          localMemcachedItem.value = NativeHandler.decode(localValue.dataBlock, localValue.flags);
        else if (paramTransCoder != null)
          localMemcachedItem.value = paramTransCoder.decode(new ByteArrayInputStream(localValue.dataBlock));
      }
      catch (IOException localIOException)
      {
        if (log.isErrorEnabled())
          log.error("error happend in decoding the object");
        throw localIOException;
      }
      return localMemcachedItem;
    }
    return localMemcachedItem;
  }

  public class ResponseParser
  {
    public RetrievalCommand.Value retvalue = null;

    public void exec()
      throws IOException
    {
      int i;
      ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(paramArrayOfByte);
      StringBuilder localStringBuilder = new StringBuilder();
      byte[] arrayOfByte = new byte[5];
      int j = 0;
      localByteArrayInputStream.mark(0);
      localByteArrayInputStream.read(arrayOfByte);
      if (Arrays.equals(arrayOfByte, RetrievalCommand.access$000()))
        return;
      localByteArrayInputStream.reset();
      RetrievalCommand.Value localValue = new RetrievalCommand.Value(this.this$0);
      localByteArrayInputStream.skip(RetrievalCommand.access$100().length + RetrievalCommand.access$200(this.this$0).length() + 1);
      j = 0;
      while ((i = (byte)localByteArrayInputStream.read()) != 32)
      {
        ++j;
        localStringBuilder.append((char)i);
      }
      try
      {
        localValue.flags = Integer.valueOf(localStringBuilder.toString()).intValue();
      }
      catch (NumberFormatException localNumberFormatException1)
      {
        this.retvalue = null;
        return;
      }
      localStringBuilder.delete(0, j);
      j = 0;
      while (((i = (byte)localByteArrayInputStream.read()) != 32) && (i != 13))
      {
        ++j;
        localStringBuilder.append((char)i);
      }
      try
      {
        localValue.bytes = Integer.valueOf(localStringBuilder.toString()).intValue();
      }
      catch (NumberFormatException localNumberFormatException2)
      {
        this.retvalue = null;
        return;
      }
      localStringBuilder.delete(0, j);
      if (RetrievalCommand.access$300(this.this$0).equals("gets"))
      {
        j = 0;
        while ((i = (byte)localByteArrayInputStream.read()) != 13)
        {
          ++j;
          localStringBuilder.append((char)i);
        }
        try
        {
          localValue.casUnique = Long.valueOf(localStringBuilder.toString()).longValue();
        }
        catch (NumberFormatException localNumberFormatException3)
        {
          this.retvalue = null;
          return;
        }
        localStringBuilder.delete(0, j);
      }
      localByteArrayInputStream.skip(-6318800746808606719L);
      localValue.dataBlock = new byte[localValue.bytes];
      localByteArrayInputStream.read(localValue.dataBlock);
      localByteArrayInputStream.skip(2L);
      localByteArrayInputStream.mark(0);
      localByteArrayInputStream.read(arrayOfByte);
      if (Arrays.equals(arrayOfByte, RetrievalCommand.access$000()))
        this.retvalue = localValue;
    }
  }

  public class Value
  {
    public int flags;
    public int bytes;
    public long casUnique;
    public byte[] dataBlock;
  }
}