package com.schooner.MemCached;

import java.io.IOException;
import java.io.InputStream;

public abstract interface TransCoder
{
  public abstract Object decode(InputStream paramInputStream)
    throws IOException;

  public abstract int encode(SockOutputStream paramSockOutputStream, Object paramObject)
    throws IOException;
}