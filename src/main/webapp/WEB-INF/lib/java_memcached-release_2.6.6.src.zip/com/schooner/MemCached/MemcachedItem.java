package com.schooner.MemCached;

public final class MemcachedItem
{
  public long casUnique;
  public Object value;

  public long getCasUnique()
  {
    return this.casUnique;
  }

  public Object getValue()
  {
    return this.value;
  }
}