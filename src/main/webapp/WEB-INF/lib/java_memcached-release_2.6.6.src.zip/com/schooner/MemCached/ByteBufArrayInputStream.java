package com.schooner.MemCached;

import com.danga.MemCached.LineInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.util.List;

public final class ByteBufArrayInputStream extends InputStream
  implements LineInputStream
{
  private ByteBuffer[] bufs;
  private int currentBuf;

  public ByteBufArrayInputStream(List<ByteBuffer> paramList)
    throws Exception
  {
    this((ByteBuffer[])paramList.toArray(new ByteBuffer[0]));
  }

  public ByteBufArrayInputStream(ByteBuffer[] paramArrayOfByteBuffer)
    throws Exception
  {
    this.currentBuf = 0;
    if ((paramArrayOfByteBuffer == null) || (paramArrayOfByteBuffer.length == 0))
      throw new Exception("buffer is empty");
    this.bufs = paramArrayOfByteBuffer;
    ByteBuffer[] arrayOfByteBuffer = paramArrayOfByteBuffer;
    int i = arrayOfByteBuffer.length;
    for (int j = 0; j < i; ++j)
    {
      ByteBuffer localByteBuffer = arrayOfByteBuffer[j];
      localByteBuffer.flip();
    }
  }

  public int read()
  {
    do
    {
      if (this.bufs[this.currentBuf].hasRemaining())
        return (this.bufs[this.currentBuf].get() & 0xFF);
      this.currentBuf += 1;
    }
    while (this.currentBuf < this.bufs.length);
    this.currentBuf -= 1;
    return -1;
  }

  public int read(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException
  {
    int i = paramInt1;
    do
    {
      if (this.bufs[this.currentBuf].hasRemaining())
      {
        int j = Math.min(this.bufs[this.currentBuf].remaining(), paramInt2 - i);
        this.bufs[this.currentBuf].get(paramArrayOfByte, i, j);
        i += j;
      }
      this.currentBuf += 1;
    }
    while ((this.currentBuf < this.bufs.length) && (i < paramInt2));
    this.currentBuf -= 1;
    if ((i > 0) || ((i == 0) && (paramInt2 == 0)))
      return (i - paramInt1);
    return -1;
  }

  public String readLine()
    throws IOException
  {
    byte[] arrayOfByte = new byte[1];
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    int i = 0;
    while (read(arrayOfByte, 0, 1) != -1)
    {
      if (arrayOfByte[0] == 13)
      {
        i = 1;
      }
      else if (i != 0)
      {
        if (arrayOfByte[0] == 10)
          break;
        i = 0;
      }
      localByteArrayOutputStream.write(arrayOfByte, 0, 1);
    }
    if ((localByteArrayOutputStream == null) || (localByteArrayOutputStream.size() <= 0))
      throw new IOException("++++ Stream appears to be dead, so closing it down");
    return localByteArrayOutputStream.toString().trim();
  }

  public void clearEOL()
    throws IOException
  {
    byte[] arrayOfByte = new byte[1];
    int i = 0;
    while (true)
    {
      do
        while (true)
        {
          if (read(arrayOfByte, 0, 1) == -1)
            return;
          if (arrayOfByte[0] != 13)
            break;
          i = 1;
        }
      while (i == 0);
      if (arrayOfByte[0] == 10)
        return;
      i = 0;
    }
  }

  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder("ByteBufArrayIS: ");
    localStringBuilder.append(this.bufs.length).append(" bufs of sizes: \n");
    for (int i = 0; i < this.bufs.length; ++i)
      localStringBuilder.append("                                        ").append(i).append(":  ").append(this.bufs[i]).append("\n");
    return localStringBuilder.toString();
  }
}