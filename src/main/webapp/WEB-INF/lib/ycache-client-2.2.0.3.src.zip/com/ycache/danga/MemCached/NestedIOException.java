package com.ycache.danga.MemCached;

import java.io.IOException;

public class NestedIOException extends IOException
{
  public NestedIOException(Throwable paramThrowable)
  {
    super(paramThrowable.getMessage());
    super.initCause(paramThrowable);
  }

  public NestedIOException(String paramString, Throwable paramThrowable)
  {
    super(paramString);
    initCause(paramThrowable);
  }
}