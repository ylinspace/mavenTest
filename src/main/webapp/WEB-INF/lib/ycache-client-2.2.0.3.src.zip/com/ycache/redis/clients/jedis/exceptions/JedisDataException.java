package com.ycache.redis.clients.jedis.exceptions;

public class JedisDataException extends JedisException
{
  private static final long serialVersionUID = 3878126572474819403L;

  public JedisDataException(String paramString)
  {
    super(paramString);
  }

  public JedisDataException(Throwable paramThrowable)
  {
    super(paramThrowable);
  }

  public JedisDataException(String paramString, Throwable paramThrowable)
  {
    super(paramString, paramThrowable);
  }
}