package com.ycache.danga.MemCached.test;

import [B;
import com.ycache.danga.MemCached.MemCachedClient;
import com.ycache.danga.MemCached.SockIOPool;
import java.io.PrintStream;
import java.io.Serializable;
import java.util.Arrays;
import java.util.Date;
import java.util.Map;
import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;

public class UnitTests
{
  private static Logger log;
  public static MemCachedClient mc;

  public static void test1()
  {
    mc.set("foo", Boolean.TRUE);
    Boolean localBoolean = (Boolean)mc.get("foo");
    if ((!($assertionsDisabled)) && (!(localBoolean.booleanValue())))
      throw new AssertionError();
    log.error("+ store/retrieve Boolean type test passed");
  }

  public static void test2()
  {
    mc.set("foo", new Integer(2147483647));
    Integer localInteger = (Integer)mc.get("foo");
    if ((!($assertionsDisabled)) && (localInteger.intValue() != 2147483647))
      throw new AssertionError();
    log.error("+ store/retrieve Integer type test passed");
  }

  public static void test3()
  {
    String str1 = "test of string encoding";
    mc.set("foo", str1);
    String str2 = (String)mc.get("foo");
    if ((!($assertionsDisabled)) && (!(str2.equals(str1))))
      throw new AssertionError();
    log.error("+ store/retrieve String type test passed");
  }

  public static void test4()
  {
    mc.set("foo", new Character('z'));
    Character localCharacter = (Character)mc.get("foo");
    if ((!($assertionsDisabled)) && (localCharacter.charValue() != 'z'))
      throw new AssertionError();
    log.error("+ store/retrieve Character type test passed");
  }

  public static void test5()
  {
    mc.set("foo", new Byte(127));
    Byte localByte = (Byte)mc.get("foo");
    if ((!($assertionsDisabled)) && (localByte.byteValue() != 127))
      throw new AssertionError();
    log.error("+ store/retrieve Byte type test passed");
  }

  public static void test6()
  {
    mc.set("foo", new StringBuffer("hello"));
    StringBuffer localStringBuffer = (StringBuffer)mc.get("foo");
    if ((!($assertionsDisabled)) && (!(localStringBuffer.toString().equals("hello"))))
      throw new AssertionError();
    log.error("+ store/retrieve StringBuffer type test passed");
  }

  public static void test7()
  {
    mc.set("foo", new Short(100));
    Short localShort = (Short)mc.get("foo");
    if ((!($assertionsDisabled)) && (localShort.shortValue() != 100))
      throw new AssertionError();
    log.error("+ store/retrieve Short type test passed");
  }

  public static void test8()
  {
    mc.set("foo", new Long(9223372036854775807L));
    Long localLong = (Long)mc.get("foo");
    if ((!($assertionsDisabled)) && (localLong.longValue() != 9223372036854775807L))
      throw new AssertionError();
    log.error("+ store/retrieve Long type test passed");
  }

  public static void test9()
  {
    mc.set("foo", new Double(1.1000000000000001D));
    Double localDouble = (Double)mc.get("foo");
    if ((!($assertionsDisabled)) && (localDouble.doubleValue() != 1.1000000000000001D))
      throw new AssertionError();
    log.error("+ store/retrieve Double type test passed");
  }

  public static void test10()
  {
    mc.set("foo", new Float(1.1000000238418579F));
    Float localFloat = (Float)mc.get("foo");
    if ((!($assertionsDisabled)) && (localFloat.floatValue() != 1.1000000238418579F))
      throw new AssertionError();
    log.error("+ store/retrieve Float type test passed");
  }

  public static void test11()
  {
    mc.set("foo", new Integer(100), new Date(System.currentTimeMillis()));
    try
    {
      Thread.sleep(1000L);
    }
    catch (Exception localException)
    {
    }
    if ((!($assertionsDisabled)) && (mc.get("foo") != null))
      throw new AssertionError();
    log.error("+ store/retrieve w/ expiration test passed");
  }

  public static void test12()
  {
    long l1 = -6318801983759187968L;
    mc.storeCounter("foo", l1);
    mc.incr("foo");
    mc.incr("foo", 5L);
    long l2 = mc.decr("foo", 2L);
    if ((!($assertionsDisabled)) && (l2 != 4L))
      throw new AssertionError();
    if ((!($assertionsDisabled)) && (l2 != mc.getCounter("foo")))
      throw new AssertionError();
    log.error("+ incr/decr test passed");
  }

  public static void test13()
  {
    Date localDate1 = new Date();
    mc.set("foo", localDate1);
    Date localDate2 = (Date)mc.get("foo");
    if ((!($assertionsDisabled)) && (!(localDate1.equals(localDate2))))
      throw new AssertionError();
    log.error("+ store/retrieve Date type test passed");
  }

  public static void test14()
  {
    if ((!($assertionsDisabled)) && (mc.keyExists("foobar123")))
      throw new AssertionError();
    mc.set("foobar123", new Integer(100000));
    if ((!($assertionsDisabled)) && (!(mc.keyExists("foobar123"))))
      throw new AssertionError();
    log.error("+ store/retrieve test passed");
    if ((!($assertionsDisabled)) && (mc.keyExists("counterTest123")))
      throw new AssertionError();
    mc.storeCounter("counterTest123", -6318801485542981632L);
    if ((!($assertionsDisabled)) && (!(mc.keyExists("counterTest123"))))
      throw new AssertionError();
    log.error("+ counter store test passed");
  }

  public static void test15()
  {
    Map localMap = mc.statsItems();
    if ((!($assertionsDisabled)) && (localMap == null))
      throw new AssertionError();
    localMap = mc.statsSlabs();
    if ((!($assertionsDisabled)) && (localMap == null))
      throw new AssertionError();
    log.error("+ stats test passed");
  }

  public static void test16()
  {
    if ((!($assertionsDisabled)) && (mc.set("foo", null)))
      throw new AssertionError();
    log.error("+ invalid data store [null] test passed");
  }

  public static void test17()
  {
    mc.set("foo bar", Boolean.TRUE);
    Boolean localBoolean = (Boolean)mc.get("foo bar");
    if ((!($assertionsDisabled)) && (!(localBoolean.booleanValue())))
      throw new AssertionError();
    log.error("+ store/retrieve Boolean type test passed");
  }

  public static void test18()
  {
    long l1 = -6318801983759187968L;
    mc.addOrIncr("foo");
    mc.incr("foo");
    mc.incr("foo", 5L);
    mc.addOrIncr("foo");
    long l2 = mc.decr("foo", 3L);
    if ((!($assertionsDisabled)) && (l2 != 4L))
      throw new AssertionError();
    if ((!($assertionsDisabled)) && (l2 != mc.getCounter("foo")))
      throw new AssertionError();
    log.error("+ incr/decr test passed");
  }

  public static void test19()
  {
    int i = 100;
    String[] arrayOfString = new String[i];
    for (int j = 0; j < i; ++j)
    {
      arrayOfString[j] = Integer.toString(j);
      mc.set(arrayOfString[j], new StringBuilder().append("value").append(j).toString());
    }
    Map localMap = mc.getMulti(arrayOfString);
    for (int k = 0; k < i; ++k)
      if ((!($assertionsDisabled)) && (!(localMap.get(arrayOfString[k]).equals(new StringBuilder().append("value").append(k).toString()))))
        throw new AssertionError();
    log.error("+ getMulti test passed");
  }

  public static void test20(int paramInt1, int paramInt2, int paramInt3)
  {
    log.warn(String.format("test 20 starting with start=%5d skip=%5d max=%7d", new Object[] { Integer.valueOf(paramInt3), Integer.valueOf(paramInt2), Integer.valueOf(paramInt1) }));
    int i = paramInt1 / paramInt2 + 1;
    String[] arrayOfString = new String[i];
    [B[] arrayOf[B = new byte[i][];
    int j = paramInt3;
    for (int k = 0; k < i; ++k)
    {
      arrayOfString[k] = Integer.toString(j);
      arrayOf[B[k] = new byte[j + 1];
      for (l = 0; l < j + 1; ++l)
        arrayOf[B[k][l] = (byte)l;
      mc.set(arrayOfString[k], arrayOf[B[k]);
      j += paramInt2;
    }
    Map localMap = mc.getMulti(arrayOfString);
    for (int l = 0; l < i; ++l)
      if ((!($assertionsDisabled)) && (!(Arrays.equals((byte[])(byte[])localMap.get(arrayOfString[l]), arrayOf[B[l]))))
        throw new AssertionError();
    log.warn(String.format("test 20 finished with start=%5d skip=%5d max=%7d", new Object[] { Integer.valueOf(paramInt3), Integer.valueOf(paramInt2), Integer.valueOf(paramInt1) }));
  }

  public static void test21()
  {
    mc.set("foo", new StringBuilder("hello"));
    StringBuilder localStringBuilder = (StringBuilder)mc.get("foo");
    if ((!($assertionsDisabled)) && (!(localStringBuilder.toString().equals("hello"))))
      throw new AssertionError();
    log.error("+ store/retrieve StringBuilder type test passed");
  }

  public static void test22()
  {
    byte[] arrayOfByte = new byte[10];
    for (int i = 0; i < 10; ++i)
      arrayOfByte[i] = (byte)i;
    mc.set("foo", arrayOfByte);
    if ((!($assertionsDisabled)) && (!(Arrays.equals((byte[])(byte[])mc.get("foo"), arrayOfByte))))
      throw new AssertionError();
    log.error("+ store/retrieve byte[] type test passed");
  }

  public static void test23()
  {
    TestClass localTestClass = new TestClass("foo", "bar", new Integer(32));
    mc.set("foo", localTestClass);
    if ((!($assertionsDisabled)) && (!(localTestClass.equals((TestClass)mc.get("foo")))))
      throw new AssertionError();
    log.error("+ store/retrieve serialized object test passed");
  }

  public static void test24()
  {
    String[] arrayOfString1 = { "key1", "key2", "key3", "key4", "key5", "key6", "key7" };
    String[] arrayOfString2 = { "key1", "key3", "key5", "key7" };
    Object localObject = arrayOfString2;
    int i = localObject.length;
    for (int j = 0; j < i; ++j)
    {
      String str1 = localObject[j];
      mc.set(str1, str1);
    }
    localObject = mc.getMulti(arrayOfString1);
    if ((!($assertionsDisabled)) && (arrayOfString1.length != ((Map)localObject).size()))
      throw new AssertionError();
    String[] arrayOfString3 = arrayOfString2;
    j = arrayOfString3.length;
    for (int k = 0; k < j; ++k)
    {
      String str2 = arrayOfString3[k];
      String str3 = (String)((Map)localObject).get(str2);
      if ((!($assertionsDisabled)) && (!(str2.equals(str3))))
        throw new AssertionError();
    }
    log.error("+ getMulti w/ keys that don't exist test passed");
  }

  public static void runAlTests(MemCachedClient paramMemCachedClient)
  {
    test14();
    for (int i = 0; i < 2; ++i)
    {
      paramMemCachedClient.setCompressEnable((i & 0x1) == 1);
      test1();
      test2();
      test3();
      test4();
      test5();
      test6();
      test7();
      test8();
      test9();
      test10();
      test11();
      test12();
      test13();
      test15();
      test16();
      test17();
      test21();
      test22();
      test23();
      test24();
      for (int j = 0; j < 3; ++j)
        test19();
      test20(8191, 1, 0);
      test20(8192, 1, 0);
      test20(8193, 1, 0);
      test20(16384, 100, 0);
      test20(17000, 128, 0);
      test20(131072, 1023, 0);
      test20(131072, 1023, 1);
      test20(131072, 1024, 0);
      test20(131072, 1024, 1);
      test20(131072, 1023, 0);
      test20(131072, 1023, 1);
      test20(131072, 1024, 0);
      test20(131072, 1024, 1);
      test20(921600, 32768, 0);
      test20(921600, 32768, 1);
    }
  }

  public static void main(String[] paramArrayOfString)
  {
    BasicConfigurator.configure();
    Logger.getRootLogger().setLevel(Level.WARN);
    if (!(UnitTests.class.desiredAssertionStatus()))
    {
      System.err.println("WARNING: assertions are disabled!");
      try
      {
        Thread.sleep(3000L);
      }
      catch (InterruptedException localInterruptedException)
      {
      }
    }
    String[] arrayOfString = { "192.168.1.50:1620", "192.168.1.50:1621", "192.168.1.50:1622", "192.168.1.50:1623", "192.168.1.50:1624", "192.168.1.50:1625", "192.168.1.50:1626", "192.168.1.50:1627", "192.168.1.50:1628", "192.168.1.50:1629" };
    Integer[] arrayOfInteger = { Integer.valueOf(1), Integer.valueOf(1), Integer.valueOf(1), Integer.valueOf(1), Integer.valueOf(10), Integer.valueOf(5), Integer.valueOf(1), Integer.valueOf(1), Integer.valueOf(1), Integer.valueOf(3) };
    if (paramArrayOfString.length > 0)
      arrayOfString = paramArrayOfString;
    SockIOPool localSockIOPool = SockIOPool.getInstance("test");
    localSockIOPool.setServers(arrayOfString);
    localSockIOPool.setWeights(arrayOfInteger);
    localSockIOPool.setMaxConn(250);
    localSockIOPool.setNagle(false);
    localSockIOPool.setHashingAlg(3);
    localSockIOPool.initialize();
    mc = new MemCachedClient("test");
    runAlTests(mc);
  }

  static
  {
    log = Logger.getLogger(UnitTests.class.getName());
    mc = null;
  }

  public static final class TestClass
  implements Serializable
  {
    private String field1;
    private String field2;
    private Integer field3;

    public TestClass(String paramString1, String paramString2, Integer paramInteger)
    {
      this.field1 = paramString1;
      this.field2 = paramString2;
      this.field3 = paramInteger;
    }

    public String getField1()
    {
      return this.field1;
    }

    public String getField2()
    {
      return this.field2;
    }

    public Integer getField3()
    {
      return this.field3;
    }

    public boolean equals(Object paramObject)
    {
      if (this == paramObject)
        return true;
      if (!(paramObject instanceof TestClass))
        return false;
      TestClass localTestClass = (TestClass)paramObject;
      return ((((this.field1 == localTestClass.getField1()) || ((this.field1 != null) && (this.field1.equals(localTestClass.getField1()))))) && (((this.field2 == localTestClass.getField2()) || ((this.field2 != null) && (this.field2.equals(localTestClass.getField2()))))) && (((this.field3 == localTestClass.getField3()) || ((this.field3 != null) && (this.field3.equals(localTestClass.getField3()))))));
    }
  }
}