package com.ycache.redis.clients.jedis;

import com.ycache.redis.clients.util.Hashing;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

public class ShardedJedis extends BinaryShardedJedis
  implements JedisCommands
{
  public ShardedJedis(List<JedisShardInfo> paramList)
  {
    super(paramList);
  }

  public ShardedJedis(List<JedisShardInfo> paramList, Hashing paramHashing)
  {
    super(paramList, paramHashing);
  }

  public ShardedJedis(List<JedisShardInfo> paramList, Pattern paramPattern)
  {
    super(paramList, paramPattern);
  }

  public ShardedJedis(List<JedisShardInfo> paramList, Hashing paramHashing, Pattern paramPattern)
  {
    super(paramList, paramHashing, paramPattern);
  }

  public String set(String paramString1, String paramString2)
  {
    Jedis localJedis = (Jedis)getShard(paramString1);
    return localJedis.set(paramString1, paramString2);
  }

  public String get(String paramString)
  {
    Jedis localJedis = (Jedis)getShard(paramString);
    return localJedis.get(paramString);
  }

  public String echo(String paramString)
  {
    Jedis localJedis = (Jedis)getShard(paramString);
    return localJedis.echo(paramString);
  }

  public Boolean exists(String paramString)
  {
    Jedis localJedis = (Jedis)getShard(paramString);
    return localJedis.exists(paramString);
  }

  public String type(String paramString)
  {
    Jedis localJedis = (Jedis)getShard(paramString);
    return localJedis.type(paramString);
  }

  public Long expire(String paramString, int paramInt)
  {
    Jedis localJedis = (Jedis)getShard(paramString);
    return localJedis.expire(paramString, paramInt);
  }

  public Long expireAt(String paramString, long paramLong)
  {
    Jedis localJedis = (Jedis)getShard(paramString);
    return localJedis.expireAt(paramString, paramLong);
  }

  public Long ttl(String paramString)
  {
    Jedis localJedis = (Jedis)getShard(paramString);
    return localJedis.ttl(paramString);
  }

  public Boolean setbit(String paramString, long paramLong, boolean paramBoolean)
  {
    Jedis localJedis = (Jedis)getShard(paramString);
    return localJedis.setbit(paramString, paramLong, paramBoolean);
  }

  public Boolean setbit(String paramString1, long paramLong, String paramString2)
  {
    Jedis localJedis = (Jedis)getShard(paramString1);
    return localJedis.setbit(paramString1, paramLong, paramString2);
  }

  public Boolean getbit(String paramString, long paramLong)
  {
    Jedis localJedis = (Jedis)getShard(paramString);
    return localJedis.getbit(paramString, paramLong);
  }

  public Long setrange(String paramString1, long paramLong, String paramString2)
  {
    Jedis localJedis = (Jedis)getShard(paramString1);
    return localJedis.setrange(paramString1, paramLong, paramString2);
  }

  public String getrange(String paramString, long paramLong1, long paramLong2)
  {
    Jedis localJedis = (Jedis)getShard(paramString);
    return localJedis.getrange(paramString, paramLong1, paramLong2);
  }

  public String getSet(String paramString1, String paramString2)
  {
    Jedis localJedis = (Jedis)getShard(paramString1);
    return localJedis.getSet(paramString1, paramString2);
  }

  public Long setnx(String paramString1, String paramString2)
  {
    Jedis localJedis = (Jedis)getShard(paramString1);
    return localJedis.setnx(paramString1, paramString2);
  }

  public String setex(String paramString1, int paramInt, String paramString2)
  {
    Jedis localJedis = (Jedis)getShard(paramString1);
    return localJedis.setex(paramString1, paramInt, paramString2);
  }

  public List<String> blpop(String paramString)
  {
    Jedis localJedis = (Jedis)getShard(paramString);
    return localJedis.blpop(paramString);
  }

  public List<String> brpop(String paramString)
  {
    Jedis localJedis = (Jedis)getShard(paramString);
    return localJedis.brpop(paramString);
  }

  public Long decrBy(String paramString, long paramLong)
  {
    Jedis localJedis = (Jedis)getShard(paramString);
    return localJedis.decrBy(paramString, paramLong);
  }

  public Long decr(String paramString)
  {
    Jedis localJedis = (Jedis)getShard(paramString);
    return localJedis.decr(paramString);
  }

  public Long incrBy(String paramString, long paramLong)
  {
    Jedis localJedis = (Jedis)getShard(paramString);
    return localJedis.incrBy(paramString, paramLong);
  }

  public Long incr(String paramString)
  {
    Jedis localJedis = (Jedis)getShard(paramString);
    return localJedis.incr(paramString);
  }

  public Long append(String paramString1, String paramString2)
  {
    Jedis localJedis = (Jedis)getShard(paramString1);
    return localJedis.append(paramString1, paramString2);
  }

  public String substr(String paramString, int paramInt1, int paramInt2)
  {
    Jedis localJedis = (Jedis)getShard(paramString);
    return localJedis.substr(paramString, paramInt1, paramInt2);
  }

  public Long hset(String paramString1, String paramString2, String paramString3)
  {
    Jedis localJedis = (Jedis)getShard(paramString1);
    return localJedis.hset(paramString1, paramString2, paramString3);
  }

  public String hget(String paramString1, String paramString2)
  {
    Jedis localJedis = (Jedis)getShard(paramString1);
    return localJedis.hget(paramString1, paramString2);
  }

  public Long hsetnx(String paramString1, String paramString2, String paramString3)
  {
    Jedis localJedis = (Jedis)getShard(paramString1);
    return localJedis.hsetnx(paramString1, paramString2, paramString3);
  }

  public String hmset(String paramString, Map<String, String> paramMap)
  {
    Jedis localJedis = (Jedis)getShard(paramString);
    return localJedis.hmset(paramString, paramMap);
  }

  public List<String> hmget(String paramString, String[] paramArrayOfString)
  {
    Jedis localJedis = (Jedis)getShard(paramString);
    return localJedis.hmget(paramString, paramArrayOfString);
  }

  public Long hincrBy(String paramString1, String paramString2, long paramLong)
  {
    Jedis localJedis = (Jedis)getShard(paramString1);
    return localJedis.hincrBy(paramString1, paramString2, paramLong);
  }

  public Boolean hexists(String paramString1, String paramString2)
  {
    Jedis localJedis = (Jedis)getShard(paramString1);
    return localJedis.hexists(paramString1, paramString2);
  }

  public Long del(String paramString)
  {
    Jedis localJedis = (Jedis)getShard(paramString);
    return localJedis.del(paramString);
  }

  public Long hdel(String paramString, String[] paramArrayOfString)
  {
    Jedis localJedis = (Jedis)getShard(paramString);
    return localJedis.hdel(paramString, paramArrayOfString);
  }

  public Long hlen(String paramString)
  {
    Jedis localJedis = (Jedis)getShard(paramString);
    return localJedis.hlen(paramString);
  }

  public Set<String> hkeys(String paramString)
  {
    Jedis localJedis = (Jedis)getShard(paramString);
    return localJedis.hkeys(paramString);
  }

  public List<String> hvals(String paramString)
  {
    Jedis localJedis = (Jedis)getShard(paramString);
    return localJedis.hvals(paramString);
  }

  public Map<String, String> hgetAll(String paramString)
  {
    Jedis localJedis = (Jedis)getShard(paramString);
    return localJedis.hgetAll(paramString);
  }

  public Long rpush(String paramString, String[] paramArrayOfString)
  {
    Jedis localJedis = (Jedis)getShard(paramString);
    return localJedis.rpush(paramString, paramArrayOfString);
  }

  public Long lpush(String paramString, String[] paramArrayOfString)
  {
    Jedis localJedis = (Jedis)getShard(paramString);
    return localJedis.lpush(paramString, paramArrayOfString);
  }

  public Long lpushx(String paramString, String[] paramArrayOfString)
  {
    Jedis localJedis = (Jedis)getShard(paramString);
    return localJedis.lpushx(paramString, paramArrayOfString);
  }

  public Long strlen(String paramString)
  {
    Jedis localJedis = (Jedis)getShard(paramString);
    return localJedis.strlen(paramString);
  }

  public Long move(String paramString, int paramInt)
  {
    Jedis localJedis = (Jedis)getShard(paramString);
    return localJedis.move(paramString, paramInt);
  }

  public Long rpushx(String paramString, String[] paramArrayOfString)
  {
    Jedis localJedis = (Jedis)getShard(paramString);
    return localJedis.rpushx(paramString, paramArrayOfString);
  }

  public Long persist(String paramString)
  {
    Jedis localJedis = (Jedis)getShard(paramString);
    return localJedis.persist(paramString);
  }

  public Long llen(String paramString)
  {
    Jedis localJedis = (Jedis)getShard(paramString);
    return localJedis.llen(paramString);
  }

  public List<String> lrange(String paramString, long paramLong1, long paramLong2)
  {
    Jedis localJedis = (Jedis)getShard(paramString);
    return localJedis.lrange(paramString, paramLong1, paramLong2);
  }

  public String ltrim(String paramString, long paramLong1, long paramLong2)
  {
    Jedis localJedis = (Jedis)getShard(paramString);
    return localJedis.ltrim(paramString, paramLong1, paramLong2);
  }

  public String lindex(String paramString, long paramLong)
  {
    Jedis localJedis = (Jedis)getShard(paramString);
    return localJedis.lindex(paramString, paramLong);
  }

  public String lset(String paramString1, long paramLong, String paramString2)
  {
    Jedis localJedis = (Jedis)getShard(paramString1);
    return localJedis.lset(paramString1, paramLong, paramString2);
  }

  public Long lrem(String paramString1, long paramLong, String paramString2)
  {
    Jedis localJedis = (Jedis)getShard(paramString1);
    return localJedis.lrem(paramString1, paramLong, paramString2);
  }

  public String lpop(String paramString)
  {
    Jedis localJedis = (Jedis)getShard(paramString);
    return localJedis.lpop(paramString);
  }

  public String rpop(String paramString)
  {
    Jedis localJedis = (Jedis)getShard(paramString);
    return localJedis.rpop(paramString);
  }

  public Long sadd(String paramString, String[] paramArrayOfString)
  {
    Jedis localJedis = (Jedis)getShard(paramString);
    return localJedis.sadd(paramString, paramArrayOfString);
  }

  public Set<String> smembers(String paramString)
  {
    Jedis localJedis = (Jedis)getShard(paramString);
    return localJedis.smembers(paramString);
  }

  public Long srem(String paramString, String[] paramArrayOfString)
  {
    Jedis localJedis = (Jedis)getShard(paramString);
    return localJedis.srem(paramString, paramArrayOfString);
  }

  public String spop(String paramString)
  {
    Jedis localJedis = (Jedis)getShard(paramString);
    return localJedis.spop(paramString);
  }

  public Long scard(String paramString)
  {
    Jedis localJedis = (Jedis)getShard(paramString);
    return localJedis.scard(paramString);
  }

  public Boolean sismember(String paramString1, String paramString2)
  {
    Jedis localJedis = (Jedis)getShard(paramString1);
    return localJedis.sismember(paramString1, paramString2);
  }

  public String srandmember(String paramString)
  {
    Jedis localJedis = (Jedis)getShard(paramString);
    return localJedis.srandmember(paramString);
  }

  public Long zadd(String paramString1, double paramDouble, String paramString2)
  {
    Jedis localJedis = (Jedis)getShard(paramString1);
    return localJedis.zadd(paramString1, paramDouble, paramString2);
  }

  public Long zadd(String paramString, Map<Double, String> paramMap)
  {
    Jedis localJedis = (Jedis)getShard(paramString);
    return localJedis.zadd(paramString, paramMap);
  }

  public Set<String> zrange(String paramString, long paramLong1, long paramLong2)
  {
    Jedis localJedis = (Jedis)getShard(paramString);
    return localJedis.zrange(paramString, paramLong1, paramLong2);
  }

  public Long zrem(String paramString, String[] paramArrayOfString)
  {
    Jedis localJedis = (Jedis)getShard(paramString);
    return localJedis.zrem(paramString, paramArrayOfString);
  }

  public Double zincrby(String paramString1, double paramDouble, String paramString2)
  {
    Jedis localJedis = (Jedis)getShard(paramString1);
    return localJedis.zincrby(paramString1, paramDouble, paramString2);
  }

  public Long zrank(String paramString1, String paramString2)
  {
    Jedis localJedis = (Jedis)getShard(paramString1);
    return localJedis.zrank(paramString1, paramString2);
  }

  public Long zrevrank(String paramString1, String paramString2)
  {
    Jedis localJedis = (Jedis)getShard(paramString1);
    return localJedis.zrevrank(paramString1, paramString2);
  }

  public Set<String> zrevrange(String paramString, long paramLong1, long paramLong2)
  {
    Jedis localJedis = (Jedis)getShard(paramString);
    return localJedis.zrevrange(paramString, paramLong1, paramLong2);
  }

  public Set<Tuple> zrangeWithScores(String paramString, long paramLong1, long paramLong2)
  {
    Jedis localJedis = (Jedis)getShard(paramString);
    return localJedis.zrangeWithScores(paramString, paramLong1, paramLong2);
  }

  public Set<Tuple> zrevrangeWithScores(String paramString, long paramLong1, long paramLong2)
  {
    Jedis localJedis = (Jedis)getShard(paramString);
    return localJedis.zrevrangeWithScores(paramString, paramLong1, paramLong2);
  }

  public Long zcard(String paramString)
  {
    Jedis localJedis = (Jedis)getShard(paramString);
    return localJedis.zcard(paramString);
  }

  public Double zscore(String paramString1, String paramString2)
  {
    Jedis localJedis = (Jedis)getShard(paramString1);
    return localJedis.zscore(paramString1, paramString2);
  }

  public List<String> sort(String paramString)
  {
    Jedis localJedis = (Jedis)getShard(paramString);
    return localJedis.sort(paramString);
  }

  public List<String> sort(String paramString, SortingParams paramSortingParams)
  {
    Jedis localJedis = (Jedis)getShard(paramString);
    return localJedis.sort(paramString, paramSortingParams);
  }

  public Long zcount(String paramString, double paramDouble1, double paramDouble2)
  {
    Jedis localJedis = (Jedis)getShard(paramString);
    return localJedis.zcount(paramString, paramDouble1, paramDouble2);
  }

  public Long zcount(String paramString1, String paramString2, String paramString3)
  {
    Jedis localJedis = (Jedis)getShard(paramString1);
    return localJedis.zcount(paramString1, paramString2, paramString3);
  }

  public Set<String> zrangeByScore(String paramString, double paramDouble1, double paramDouble2)
  {
    Jedis localJedis = (Jedis)getShard(paramString);
    return localJedis.zrangeByScore(paramString, paramDouble1, paramDouble2);
  }

  public Set<String> zrevrangeByScore(String paramString, double paramDouble1, double paramDouble2)
  {
    Jedis localJedis = (Jedis)getShard(paramString);
    return localJedis.zrevrangeByScore(paramString, paramDouble1, paramDouble2);
  }

  public Set<String> zrangeByScore(String paramString, double paramDouble1, double paramDouble2, int paramInt1, int paramInt2)
  {
    Jedis localJedis = (Jedis)getShard(paramString);
    return localJedis.zrangeByScore(paramString, paramDouble1, paramDouble2, paramInt1, paramInt2);
  }

  public Set<String> zrevrangeByScore(String paramString, double paramDouble1, double paramDouble2, int paramInt1, int paramInt2)
  {
    Jedis localJedis = (Jedis)getShard(paramString);
    return localJedis.zrevrangeByScore(paramString, paramDouble1, paramDouble2, paramInt1, paramInt2);
  }

  public Set<Tuple> zrangeByScoreWithScores(String paramString, double paramDouble1, double paramDouble2)
  {
    Jedis localJedis = (Jedis)getShard(paramString);
    return localJedis.zrangeByScoreWithScores(paramString, paramDouble1, paramDouble2);
  }

  public Set<Tuple> zrevrangeByScoreWithScores(String paramString, double paramDouble1, double paramDouble2)
  {
    Jedis localJedis = (Jedis)getShard(paramString);
    return localJedis.zrevrangeByScoreWithScores(paramString, paramDouble1, paramDouble2);
  }

  public Set<Tuple> zrangeByScoreWithScores(String paramString, double paramDouble1, double paramDouble2, int paramInt1, int paramInt2)
  {
    Jedis localJedis = (Jedis)getShard(paramString);
    return localJedis.zrangeByScoreWithScores(paramString, paramDouble1, paramDouble2, paramInt1, paramInt2);
  }

  public Set<Tuple> zrevrangeByScoreWithScores(String paramString, double paramDouble1, double paramDouble2, int paramInt1, int paramInt2)
  {
    Jedis localJedis = (Jedis)getShard(paramString);
    return localJedis.zrevrangeByScoreWithScores(paramString, paramDouble1, paramDouble2, paramInt1, paramInt2);
  }

  public Set<String> zrangeByScore(String paramString1, String paramString2, String paramString3)
  {
    Jedis localJedis = (Jedis)getShard(paramString1);
    return localJedis.zrangeByScore(paramString1, paramString2, paramString3);
  }

  public Set<String> zrevrangeByScore(String paramString1, String paramString2, String paramString3)
  {
    Jedis localJedis = (Jedis)getShard(paramString1);
    return localJedis.zrevrangeByScore(paramString1, paramString2, paramString3);
  }

  public Set<String> zrangeByScore(String paramString1, String paramString2, String paramString3, int paramInt1, int paramInt2)
  {
    Jedis localJedis = (Jedis)getShard(paramString1);
    return localJedis.zrangeByScore(paramString1, paramString2, paramString3, paramInt1, paramInt2);
  }

  public Set<String> zrevrangeByScore(String paramString1, String paramString2, String paramString3, int paramInt1, int paramInt2)
  {
    Jedis localJedis = (Jedis)getShard(paramString1);
    return localJedis.zrevrangeByScore(paramString1, paramString2, paramString3, paramInt1, paramInt2);
  }

  public Set<Tuple> zrangeByScoreWithScores(String paramString1, String paramString2, String paramString3)
  {
    Jedis localJedis = (Jedis)getShard(paramString1);
    return localJedis.zrangeByScoreWithScores(paramString1, paramString2, paramString3);
  }

  public Set<Tuple> zrevrangeByScoreWithScores(String paramString1, String paramString2, String paramString3)
  {
    Jedis localJedis = (Jedis)getShard(paramString1);
    return localJedis.zrevrangeByScoreWithScores(paramString1, paramString2, paramString3);
  }

  public Set<Tuple> zrangeByScoreWithScores(String paramString1, String paramString2, String paramString3, int paramInt1, int paramInt2)
  {
    Jedis localJedis = (Jedis)getShard(paramString1);
    return localJedis.zrangeByScoreWithScores(paramString1, paramString2, paramString3, paramInt1, paramInt2);
  }

  public Set<Tuple> zrevrangeByScoreWithScores(String paramString1, String paramString2, String paramString3, int paramInt1, int paramInt2)
  {
    Jedis localJedis = (Jedis)getShard(paramString1);
    return localJedis.zrevrangeByScoreWithScores(paramString1, paramString2, paramString3, paramInt1, paramInt2);
  }

  public Long zremrangeByRank(String paramString, long paramLong1, long paramLong2)
  {
    Jedis localJedis = (Jedis)getShard(paramString);
    return localJedis.zremrangeByRank(paramString, paramLong1, paramLong2);
  }

  public Long zremrangeByScore(String paramString, double paramDouble1, double paramDouble2)
  {
    Jedis localJedis = (Jedis)getShard(paramString);
    return localJedis.zremrangeByScore(paramString, paramDouble1, paramDouble2);
  }

  public Long zremrangeByScore(String paramString1, String paramString2, String paramString3)
  {
    Jedis localJedis = (Jedis)getShard(paramString1);
    return localJedis.zremrangeByScore(paramString1, paramString2, paramString3);
  }

  public Long linsert(String paramString1, BinaryClient.LIST_POSITION paramLIST_POSITION, String paramString2, String paramString3)
  {
    Jedis localJedis = (Jedis)getShard(paramString1);
    return localJedis.linsert(paramString1, paramLIST_POSITION, paramString2, paramString3);
  }

  public Long bitcount(String paramString)
  {
    Jedis localJedis = (Jedis)getShard(paramString);
    return localJedis.bitcount(paramString);
  }

  public Long bitcount(String paramString, long paramLong1, long paramLong2)
  {
    Jedis localJedis = (Jedis)getShard(paramString);
    return localJedis.bitcount(paramString, paramLong1, paramLong2);
  }
}