package com.ycache.redis.clients.jedis;

import [B;
import java.util.List;
import java.util.Map;
import java.util.Set;

abstract class PipelineBase extends Queable
  implements BinaryRedisPipeline, RedisPipeline
{
  protected abstract Client getClient(String paramString);

  protected abstract Client getClient(byte[] paramArrayOfByte);

  public Response<Long> append(String paramString1, String paramString2)
  {
    getClient(paramString1).append(paramString1, paramString2);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> append(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    getClient(paramArrayOfByte1).append(paramArrayOfByte1, paramArrayOfByte2);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<List<String>> blpop(String paramString)
  {
    String[] arrayOfString = new String[1];
    arrayOfString[0] = paramString;
    getClient(paramString).blpop(arrayOfString);
    return getResponse(BuilderFactory.STRING_LIST);
  }

  public Response<List<String>> brpop(String paramString)
  {
    String[] arrayOfString = new String[1];
    arrayOfString[0] = paramString;
    getClient(paramString).brpop(arrayOfString);
    return getResponse(BuilderFactory.STRING_LIST);
  }

  public Response<List<byte[]>> blpop(byte[] paramArrayOfByte)
  {
    [B[] arrayOf[B = new byte[1][];
    arrayOf[B[0] = paramArrayOfByte;
    getClient(paramArrayOfByte).blpop(arrayOf[B);
    return getResponse(BuilderFactory.BYTE_ARRAY_LIST);
  }

  public Response<List<byte[]>> brpop(byte[] paramArrayOfByte)
  {
    [B[] arrayOf[B = new byte[1][];
    arrayOf[B[0] = paramArrayOfByte;
    getClient(paramArrayOfByte).brpop(arrayOf[B);
    return getResponse(BuilderFactory.BYTE_ARRAY_LIST);
  }

  public Response<Long> decr(String paramString)
  {
    getClient(paramString).decr(paramString);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> decr(byte[] paramArrayOfByte)
  {
    getClient(paramArrayOfByte).decr(paramArrayOfByte);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> decrBy(String paramString, long paramLong)
  {
    getClient(paramString).decrBy(paramString, paramLong);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> decrBy(byte[] paramArrayOfByte, long paramLong)
  {
    getClient(paramArrayOfByte).decrBy(paramArrayOfByte, paramLong);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> del(String paramString)
  {
    getClient(paramString).del(new String[] { paramString });
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> del(byte[] paramArrayOfByte)
  {
    getClient(paramArrayOfByte).del(new byte[][] { paramArrayOfByte });
    return getResponse(BuilderFactory.LONG);
  }

  public Response<String> echo(String paramString)
  {
    getClient(paramString).echo(paramString);
    return getResponse(BuilderFactory.STRING);
  }

  public Response<byte[]> echo(byte[] paramArrayOfByte)
  {
    getClient(paramArrayOfByte).echo(paramArrayOfByte);
    return getResponse(BuilderFactory.BYTE_ARRAY);
  }

  public Response<Boolean> exists(String paramString)
  {
    getClient(paramString).exists(paramString);
    return getResponse(BuilderFactory.BOOLEAN);
  }

  public Response<Boolean> exists(byte[] paramArrayOfByte)
  {
    getClient(paramArrayOfByte).exists(paramArrayOfByte);
    return getResponse(BuilderFactory.BOOLEAN);
  }

  public Response<Long> expire(String paramString, int paramInt)
  {
    getClient(paramString).expire(paramString, paramInt);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> expire(byte[] paramArrayOfByte, int paramInt)
  {
    getClient(paramArrayOfByte).expire(paramArrayOfByte, paramInt);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> expireAt(String paramString, long paramLong)
  {
    getClient(paramString).expireAt(paramString, paramLong);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> expireAt(byte[] paramArrayOfByte, long paramLong)
  {
    getClient(paramArrayOfByte).expireAt(paramArrayOfByte, paramLong);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<String> get(String paramString)
  {
    getClient(paramString).get(paramString);
    return getResponse(BuilderFactory.STRING);
  }

  public Response<byte[]> get(byte[] paramArrayOfByte)
  {
    getClient(paramArrayOfByte).get(paramArrayOfByte);
    return getResponse(BuilderFactory.BYTE_ARRAY);
  }

  public Response<Boolean> getbit(String paramString, long paramLong)
  {
    getClient(paramString).getbit(paramString, paramLong);
    return getResponse(BuilderFactory.BOOLEAN);
  }

  public Response<Boolean> getbit(byte[] paramArrayOfByte, long paramLong)
  {
    getClient(paramArrayOfByte).getbit(paramArrayOfByte, paramLong);
    return getResponse(BuilderFactory.BOOLEAN);
  }

  public Response<String> getrange(String paramString, long paramLong1, long paramLong2)
  {
    getClient(paramString).getrange(paramString, paramLong1, paramLong2);
    return getResponse(BuilderFactory.STRING);
  }

  public Response<String> getSet(String paramString1, String paramString2)
  {
    getClient(paramString1).getSet(paramString1, paramString2);
    return getResponse(BuilderFactory.STRING);
  }

  public Response<byte[]> getSet(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    getClient(paramArrayOfByte1).getSet(paramArrayOfByte1, paramArrayOfByte2);
    return getResponse(BuilderFactory.BYTE_ARRAY);
  }

  public Response<Long> getrange(byte[] paramArrayOfByte, long paramLong1, long paramLong2)
  {
    getClient(paramArrayOfByte).getrange(paramArrayOfByte, paramLong1, paramLong2);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> hdel(String paramString, String[] paramArrayOfString)
  {
    getClient(paramString).hdel(paramString, paramArrayOfString);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> hdel(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1)
  {
    getClient(paramArrayOfByte).hdel(paramArrayOfByte, paramArrayOfByte1);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Boolean> hexists(String paramString1, String paramString2)
  {
    getClient(paramString1).hexists(paramString1, paramString2);
    return getResponse(BuilderFactory.BOOLEAN);
  }

  public Response<Boolean> hexists(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    getClient(paramArrayOfByte1).hexists(paramArrayOfByte1, paramArrayOfByte2);
    return getResponse(BuilderFactory.BOOLEAN);
  }

  public Response<String> hget(String paramString1, String paramString2)
  {
    getClient(paramString1).hget(paramString1, paramString2);
    return getResponse(BuilderFactory.STRING);
  }

  public Response<byte[]> hget(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    getClient(paramArrayOfByte1).hget(paramArrayOfByte1, paramArrayOfByte2);
    return getResponse(BuilderFactory.BYTE_ARRAY);
  }

  public Response<Map<String, String>> hgetAll(String paramString)
  {
    getClient(paramString).hgetAll(paramString);
    return getResponse(BuilderFactory.STRING_MAP);
  }

  public Response<Map<byte[], byte[]>> hgetAll(byte[] paramArrayOfByte)
  {
    getClient(paramArrayOfByte).hgetAll(paramArrayOfByte);
    return getResponse(BuilderFactory.BYTE_ARRAY_MAP);
  }

  public Response<Long> hincrBy(String paramString1, String paramString2, long paramLong)
  {
    getClient(paramString1).hincrBy(paramString1, paramString2, paramLong);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> hincrBy(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, long paramLong)
  {
    getClient(paramArrayOfByte1).hincrBy(paramArrayOfByte1, paramArrayOfByte2, paramLong);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Set<String>> hkeys(String paramString)
  {
    getClient(paramString).hkeys(paramString);
    return getResponse(BuilderFactory.STRING_SET);
  }

  public Response<Set<byte[]>> hkeys(byte[] paramArrayOfByte)
  {
    getClient(paramArrayOfByte).hkeys(paramArrayOfByte);
    return getResponse(BuilderFactory.BYTE_ARRAY_ZSET);
  }

  public Response<Long> hlen(String paramString)
  {
    getClient(paramString).hlen(paramString);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> hlen(byte[] paramArrayOfByte)
  {
    getClient(paramArrayOfByte).hlen(paramArrayOfByte);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<List<String>> hmget(String paramString, String[] paramArrayOfString)
  {
    getClient(paramString).hmget(paramString, paramArrayOfString);
    return getResponse(BuilderFactory.STRING_LIST);
  }

  public Response<List<byte[]>> hmget(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1)
  {
    getClient(paramArrayOfByte).hmget(paramArrayOfByte, paramArrayOfByte1);
    return getResponse(BuilderFactory.BYTE_ARRAY_LIST);
  }

  public Response<String> hmset(String paramString, Map<String, String> paramMap)
  {
    getClient(paramString).hmset(paramString, paramMap);
    return getResponse(BuilderFactory.STRING);
  }

  public Response<String> hmset(byte[] paramArrayOfByte, Map<byte[], byte[]> paramMap)
  {
    getClient(paramArrayOfByte).hmset(paramArrayOfByte, paramMap);
    return getResponse(BuilderFactory.STRING);
  }

  public Response<Long> hset(String paramString1, String paramString2, String paramString3)
  {
    getClient(paramString1).hset(paramString1, paramString2, paramString3);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> hset(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
  {
    getClient(paramArrayOfByte1).hset(paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> hsetnx(String paramString1, String paramString2, String paramString3)
  {
    getClient(paramString1).hsetnx(paramString1, paramString2, paramString3);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> hsetnx(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
  {
    getClient(paramArrayOfByte1).hsetnx(paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<List<String>> hvals(String paramString)
  {
    getClient(paramString).hvals(paramString);
    return getResponse(BuilderFactory.STRING_LIST);
  }

  public Response<List<byte[]>> hvals(byte[] paramArrayOfByte)
  {
    getClient(paramArrayOfByte).hvals(paramArrayOfByte);
    return getResponse(BuilderFactory.BYTE_ARRAY_LIST);
  }

  public Response<Long> incr(String paramString)
  {
    getClient(paramString).incr(paramString);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> incr(byte[] paramArrayOfByte)
  {
    getClient(paramArrayOfByte).incr(paramArrayOfByte);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> incrBy(String paramString, long paramLong)
  {
    getClient(paramString).incrBy(paramString, paramLong);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> incrBy(byte[] paramArrayOfByte, long paramLong)
  {
    getClient(paramArrayOfByte).incrBy(paramArrayOfByte, paramLong);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<String> lindex(String paramString, long paramLong)
  {
    getClient(paramString).lindex(paramString, paramLong);
    return getResponse(BuilderFactory.STRING);
  }

  public Response<byte[]> lindex(byte[] paramArrayOfByte, long paramLong)
  {
    getClient(paramArrayOfByte).lindex(paramArrayOfByte, paramLong);
    return getResponse(BuilderFactory.BYTE_ARRAY);
  }

  public Response<Long> linsert(String paramString1, BinaryClient.LIST_POSITION paramLIST_POSITION, String paramString2, String paramString3)
  {
    getClient(paramString1).linsert(paramString1, paramLIST_POSITION, paramString2, paramString3);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> linsert(byte[] paramArrayOfByte1, BinaryClient.LIST_POSITION paramLIST_POSITION, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
  {
    getClient(paramArrayOfByte1).linsert(paramArrayOfByte1, paramLIST_POSITION, paramArrayOfByte2, paramArrayOfByte3);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> llen(String paramString)
  {
    getClient(paramString).llen(paramString);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> llen(byte[] paramArrayOfByte)
  {
    getClient(paramArrayOfByte).llen(paramArrayOfByte);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<String> lpop(String paramString)
  {
    getClient(paramString).lpop(paramString);
    return getResponse(BuilderFactory.STRING);
  }

  public Response<byte[]> lpop(byte[] paramArrayOfByte)
  {
    getClient(paramArrayOfByte).lpop(paramArrayOfByte);
    return getResponse(BuilderFactory.BYTE_ARRAY);
  }

  public Response<Long> lpush(String paramString, String[] paramArrayOfString)
  {
    getClient(paramString).lpush(paramString, paramArrayOfString);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> lpush(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1)
  {
    getClient(paramArrayOfByte).lpush(paramArrayOfByte, paramArrayOfByte1);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> lpushx(String paramString, String[] paramArrayOfString)
  {
    getClient(paramString).lpushx(paramString, paramArrayOfString);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> lpushx(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1)
  {
    getClient(paramArrayOfByte).lpushx(paramArrayOfByte, paramArrayOfByte1);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<List<String>> lrange(String paramString, long paramLong1, long paramLong2)
  {
    getClient(paramString).lrange(paramString, paramLong1, paramLong2);
    return getResponse(BuilderFactory.STRING_LIST);
  }

  public Response<List<byte[]>> lrange(byte[] paramArrayOfByte, long paramLong1, long paramLong2)
  {
    getClient(paramArrayOfByte).lrange(paramArrayOfByte, paramLong1, paramLong2);
    return getResponse(BuilderFactory.BYTE_ARRAY_LIST);
  }

  public Response<Long> lrem(String paramString1, long paramLong, String paramString2)
  {
    getClient(paramString1).lrem(paramString1, paramLong, paramString2);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> lrem(byte[] paramArrayOfByte1, long paramLong, byte[] paramArrayOfByte2)
  {
    getClient(paramArrayOfByte1).lrem(paramArrayOfByte1, paramLong, paramArrayOfByte2);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<String> lset(String paramString1, long paramLong, String paramString2)
  {
    getClient(paramString1).lset(paramString1, paramLong, paramString2);
    return getResponse(BuilderFactory.STRING);
  }

  public Response<String> lset(byte[] paramArrayOfByte1, long paramLong, byte[] paramArrayOfByte2)
  {
    getClient(paramArrayOfByte1).lset(paramArrayOfByte1, paramLong, paramArrayOfByte2);
    return getResponse(BuilderFactory.STRING);
  }

  public Response<String> ltrim(String paramString, long paramLong1, long paramLong2)
  {
    getClient(paramString).ltrim(paramString, paramLong1, paramLong2);
    return getResponse(BuilderFactory.STRING);
  }

  public Response<String> ltrim(byte[] paramArrayOfByte, long paramLong1, long paramLong2)
  {
    getClient(paramArrayOfByte).ltrim(paramArrayOfByte, paramLong1, paramLong2);
    return getResponse(BuilderFactory.STRING);
  }

  public Response<Long> move(String paramString, int paramInt)
  {
    getClient(paramString).move(paramString, paramInt);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> move(byte[] paramArrayOfByte, int paramInt)
  {
    getClient(paramArrayOfByte).move(paramArrayOfByte, paramInt);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> persist(String paramString)
  {
    getClient(paramString).persist(paramString);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> persist(byte[] paramArrayOfByte)
  {
    getClient(paramArrayOfByte).persist(paramArrayOfByte);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<String> rpop(String paramString)
  {
    getClient(paramString).rpop(paramString);
    return getResponse(BuilderFactory.STRING);
  }

  public Response<byte[]> rpop(byte[] paramArrayOfByte)
  {
    getClient(paramArrayOfByte).rpop(paramArrayOfByte);
    return getResponse(BuilderFactory.BYTE_ARRAY);
  }

  public Response<Long> rpush(String paramString, String[] paramArrayOfString)
  {
    getClient(paramString).rpush(paramString, paramArrayOfString);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> rpush(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1)
  {
    getClient(paramArrayOfByte).rpush(paramArrayOfByte, paramArrayOfByte1);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> rpushx(String paramString, String[] paramArrayOfString)
  {
    getClient(paramString).rpushx(paramString, paramArrayOfString);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> rpushx(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1)
  {
    getClient(paramArrayOfByte).rpushx(paramArrayOfByte, paramArrayOfByte1);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> sadd(String paramString, String[] paramArrayOfString)
  {
    getClient(paramString).sadd(paramString, paramArrayOfString);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> sadd(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1)
  {
    getClient(paramArrayOfByte).sadd(paramArrayOfByte, paramArrayOfByte1);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> scard(String paramString)
  {
    getClient(paramString).scard(paramString);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> scard(byte[] paramArrayOfByte)
  {
    getClient(paramArrayOfByte).scard(paramArrayOfByte);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<String> set(String paramString1, String paramString2)
  {
    getClient(paramString1).set(paramString1, paramString2);
    return getResponse(BuilderFactory.STRING);
  }

  public Response<String> set(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    getClient(paramArrayOfByte1).set(paramArrayOfByte1, paramArrayOfByte2);
    return getResponse(BuilderFactory.STRING);
  }

  public Response<Boolean> setbit(String paramString, long paramLong, boolean paramBoolean)
  {
    getClient(paramString).setbit(paramString, paramLong, paramBoolean);
    return getResponse(BuilderFactory.BOOLEAN);
  }

  public Response<Boolean> setbit(byte[] paramArrayOfByte1, long paramLong, byte[] paramArrayOfByte2)
  {
    getClient(paramArrayOfByte1).setbit(paramArrayOfByte1, paramLong, paramArrayOfByte2);
    return getResponse(BuilderFactory.BOOLEAN);
  }

  public Response<String> setex(String paramString1, int paramInt, String paramString2)
  {
    getClient(paramString1).setex(paramString1, paramInt, paramString2);
    return getResponse(BuilderFactory.STRING);
  }

  public Response<String> setex(byte[] paramArrayOfByte1, int paramInt, byte[] paramArrayOfByte2)
  {
    getClient(paramArrayOfByte1).setex(paramArrayOfByte1, paramInt, paramArrayOfByte2);
    return getResponse(BuilderFactory.STRING);
  }

  public Response<Long> setnx(String paramString1, String paramString2)
  {
    getClient(paramString1).setnx(paramString1, paramString2);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> setnx(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    getClient(paramArrayOfByte1).setnx(paramArrayOfByte1, paramArrayOfByte2);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> setrange(String paramString1, long paramLong, String paramString2)
  {
    getClient(paramString1).setrange(paramString1, paramLong, paramString2);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> setrange(byte[] paramArrayOfByte1, long paramLong, byte[] paramArrayOfByte2)
  {
    getClient(paramArrayOfByte1).setrange(paramArrayOfByte1, paramLong, paramArrayOfByte2);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Boolean> sismember(String paramString1, String paramString2)
  {
    getClient(paramString1).sismember(paramString1, paramString2);
    return getResponse(BuilderFactory.BOOLEAN);
  }

  public Response<Boolean> sismember(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    getClient(paramArrayOfByte1).sismember(paramArrayOfByte1, paramArrayOfByte2);
    return getResponse(BuilderFactory.BOOLEAN);
  }

  public Response<Set<String>> smembers(String paramString)
  {
    getClient(paramString).smembers(paramString);
    return getResponse(BuilderFactory.STRING_SET);
  }

  public Response<Set<byte[]>> smembers(byte[] paramArrayOfByte)
  {
    getClient(paramArrayOfByte).smembers(paramArrayOfByte);
    return getResponse(BuilderFactory.BYTE_ARRAY_ZSET);
  }

  public Response<List<String>> sort(String paramString)
  {
    getClient(paramString).sort(paramString);
    return getResponse(BuilderFactory.STRING_LIST);
  }

  public Response<List<byte[]>> sort(byte[] paramArrayOfByte)
  {
    getClient(paramArrayOfByte).sort(paramArrayOfByte);
    return getResponse(BuilderFactory.BYTE_ARRAY_LIST);
  }

  public Response<List<String>> sort(String paramString, SortingParams paramSortingParams)
  {
    getClient(paramString).sort(paramString, paramSortingParams);
    return getResponse(BuilderFactory.STRING_LIST);
  }

  public Response<List<byte[]>> sort(byte[] paramArrayOfByte, SortingParams paramSortingParams)
  {
    getClient(paramArrayOfByte).sort(paramArrayOfByte, paramSortingParams);
    return getResponse(BuilderFactory.BYTE_ARRAY_LIST);
  }

  public Response<String> spop(String paramString)
  {
    getClient(paramString).spop(paramString);
    return getResponse(BuilderFactory.STRING);
  }

  public Response<byte[]> spop(byte[] paramArrayOfByte)
  {
    getClient(paramArrayOfByte).spop(paramArrayOfByte);
    return getResponse(BuilderFactory.BYTE_ARRAY);
  }

  public Response<String> srandmember(String paramString)
  {
    getClient(paramString).srandmember(paramString);
    return getResponse(BuilderFactory.STRING);
  }

  public Response<List<String>> srandmember(String paramString, int paramInt)
  {
    getClient(paramString).srandmember(paramString, paramInt);
    return getResponse(BuilderFactory.STRING_LIST);
  }

  public Response<byte[]> srandmember(byte[] paramArrayOfByte)
  {
    getClient(paramArrayOfByte).srandmember(paramArrayOfByte);
    return getResponse(BuilderFactory.BYTE_ARRAY);
  }

  public Response<List<byte[]>> srandmember(byte[] paramArrayOfByte, int paramInt)
  {
    getClient(paramArrayOfByte).srandmember(paramArrayOfByte, paramInt);
    return getResponse(BuilderFactory.BYTE_ARRAY_LIST);
  }

  public Response<Long> srem(String paramString, String[] paramArrayOfString)
  {
    getClient(paramString).srem(paramString, paramArrayOfString);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> srem(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1)
  {
    getClient(paramArrayOfByte).srem(paramArrayOfByte, paramArrayOfByte1);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> strlen(String paramString)
  {
    getClient(paramString).strlen(paramString);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> strlen(byte[] paramArrayOfByte)
  {
    getClient(paramArrayOfByte).strlen(paramArrayOfByte);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<String> substr(String paramString, int paramInt1, int paramInt2)
  {
    getClient(paramString).substr(paramString, paramInt1, paramInt2);
    return getResponse(BuilderFactory.STRING);
  }

  public Response<String> substr(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    getClient(paramArrayOfByte).substr(paramArrayOfByte, paramInt1, paramInt2);
    return getResponse(BuilderFactory.STRING);
  }

  public Response<Long> ttl(String paramString)
  {
    getClient(paramString).ttl(paramString);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> ttl(byte[] paramArrayOfByte)
  {
    getClient(paramArrayOfByte).ttl(paramArrayOfByte);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<String> type(String paramString)
  {
    getClient(paramString).type(paramString);
    return getResponse(BuilderFactory.STRING);
  }

  public Response<String> type(byte[] paramArrayOfByte)
  {
    getClient(paramArrayOfByte).type(paramArrayOfByte);
    return getResponse(BuilderFactory.STRING);
  }

  public Response<Long> zadd(String paramString1, double paramDouble, String paramString2)
  {
    getClient(paramString1).zadd(paramString1, paramDouble, paramString2);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> zadd(String paramString, Map<Double, String> paramMap)
  {
    getClient(paramString).zadd(paramString, paramMap);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> zadd(byte[] paramArrayOfByte1, double paramDouble, byte[] paramArrayOfByte2)
  {
    getClient(paramArrayOfByte1).zadd(paramArrayOfByte1, paramDouble, paramArrayOfByte2);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> zcard(String paramString)
  {
    getClient(paramString).zcard(paramString);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> zcard(byte[] paramArrayOfByte)
  {
    getClient(paramArrayOfByte).zcard(paramArrayOfByte);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> zcount(String paramString, double paramDouble1, double paramDouble2)
  {
    getClient(paramString).zcount(paramString, paramDouble1, paramDouble2);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> zcount(String paramString1, String paramString2, String paramString3)
  {
    getClient(paramString1).zcount(paramString1, paramString2, paramString3);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> zcount(byte[] paramArrayOfByte, double paramDouble1, double paramDouble2)
  {
    getClient(paramArrayOfByte).zcount(paramArrayOfByte, Protocol.toByteArray(paramDouble1), Protocol.toByteArray(paramDouble2));
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Double> zincrby(String paramString1, double paramDouble, String paramString2)
  {
    getClient(paramString1).zincrby(paramString1, paramDouble, paramString2);
    return getResponse(BuilderFactory.DOUBLE);
  }

  public Response<Double> zincrby(byte[] paramArrayOfByte1, double paramDouble, byte[] paramArrayOfByte2)
  {
    getClient(paramArrayOfByte1).zincrby(paramArrayOfByte1, paramDouble, paramArrayOfByte2);
    return getResponse(BuilderFactory.DOUBLE);
  }

  public Response<Set<String>> zrange(String paramString, long paramLong1, long paramLong2)
  {
    getClient(paramString).zrange(paramString, paramLong1, paramLong2);
    return getResponse(BuilderFactory.STRING_ZSET);
  }

  public Response<Set<byte[]>> zrange(byte[] paramArrayOfByte, long paramLong1, long paramLong2)
  {
    getClient(paramArrayOfByte).zrange(paramArrayOfByte, paramLong1, paramLong2);
    return getResponse(BuilderFactory.BYTE_ARRAY_ZSET);
  }

  public Response<Set<String>> zrangeByScore(String paramString, double paramDouble1, double paramDouble2)
  {
    getClient(paramString).zrangeByScore(paramString, paramDouble1, paramDouble2);
    return getResponse(BuilderFactory.STRING_ZSET);
  }

  public Response<Set<byte[]>> zrangeByScore(byte[] paramArrayOfByte, double paramDouble1, double paramDouble2)
  {
    return zrangeByScore(paramArrayOfByte, Protocol.toByteArray(paramDouble1), Protocol.toByteArray(paramDouble2));
  }

  public Response<Set<String>> zrangeByScore(String paramString1, String paramString2, String paramString3)
  {
    getClient(paramString1).zrangeByScore(paramString1, paramString2, paramString3);
    return getResponse(BuilderFactory.STRING_ZSET);
  }

  public Response<Set<byte[]>> zrangeByScore(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
  {
    getClient(paramArrayOfByte1).zrangeByScore(paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3);
    return getResponse(BuilderFactory.BYTE_ARRAY_ZSET);
  }

  public Response<Set<String>> zrangeByScore(String paramString, double paramDouble1, double paramDouble2, int paramInt1, int paramInt2)
  {
    getClient(paramString).zrangeByScore(paramString, paramDouble1, paramDouble2, paramInt1, paramInt2);
    return getResponse(BuilderFactory.STRING_ZSET);
  }

  public Response<Set<String>> zrangeByScore(String paramString1, String paramString2, String paramString3, int paramInt1, int paramInt2)
  {
    getClient(paramString1).zrangeByScore(paramString1, paramString2, paramString3, paramInt1, paramInt2);
    return getResponse(BuilderFactory.STRING_ZSET);
  }

  public Response<Set<byte[]>> zrangeByScore(byte[] paramArrayOfByte, double paramDouble1, double paramDouble2, int paramInt1, int paramInt2)
  {
    return zrangeByScore(paramArrayOfByte, Protocol.toByteArray(paramDouble1), Protocol.toByteArray(paramDouble2), paramInt1, paramInt2);
  }

  public Response<Set<byte[]>> zrangeByScore(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3, int paramInt1, int paramInt2)
  {
    getClient(paramArrayOfByte1).zrangeByScore(paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3, paramInt1, paramInt2);
    return getResponse(BuilderFactory.BYTE_ARRAY_ZSET);
  }

  public Response<Set<Tuple>> zrangeByScoreWithScores(String paramString, double paramDouble1, double paramDouble2)
  {
    getClient(paramString).zrangeByScoreWithScores(paramString, paramDouble1, paramDouble2);
    return getResponse(BuilderFactory.TUPLE_ZSET);
  }

  public Response<Set<Tuple>> zrangeByScoreWithScores(String paramString1, String paramString2, String paramString3)
  {
    getClient(paramString1).zrangeByScoreWithScores(paramString1, paramString2, paramString3);
    return getResponse(BuilderFactory.TUPLE_ZSET);
  }

  public Response<Set<Tuple>> zrangeByScoreWithScores(byte[] paramArrayOfByte, double paramDouble1, double paramDouble2)
  {
    return zrangeByScoreWithScores(paramArrayOfByte, Protocol.toByteArray(paramDouble1), Protocol.toByteArray(paramDouble2));
  }

  public Response<Set<Tuple>> zrangeByScoreWithScores(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
  {
    getClient(paramArrayOfByte1).zrangeByScoreWithScores(paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3);
    return getResponse(BuilderFactory.TUPLE_ZSET_BINARY);
  }

  public Response<Set<Tuple>> zrangeByScoreWithScores(String paramString, double paramDouble1, double paramDouble2, int paramInt1, int paramInt2)
  {
    getClient(paramString).zrangeByScoreWithScores(paramString, paramDouble1, paramDouble2, paramInt1, paramInt2);
    return getResponse(BuilderFactory.TUPLE_ZSET);
  }

  public Response<Set<Tuple>> zrangeByScoreWithScores(String paramString1, String paramString2, String paramString3, int paramInt1, int paramInt2)
  {
    getClient(paramString1).zrangeByScoreWithScores(paramString1, paramString2, paramString3, paramInt1, paramInt2);
    return getResponse(BuilderFactory.TUPLE_ZSET);
  }

  public Response<Set<Tuple>> zrangeByScoreWithScores(byte[] paramArrayOfByte, double paramDouble1, double paramDouble2, int paramInt1, int paramInt2)
  {
    getClient(paramArrayOfByte).zrangeByScoreWithScores(paramArrayOfByte, Protocol.toByteArray(paramDouble1), Protocol.toByteArray(paramDouble2), paramInt1, paramInt2);
    return getResponse(BuilderFactory.TUPLE_ZSET_BINARY);
  }

  public Response<Set<Tuple>> zrangeByScoreWithScores(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3, int paramInt1, int paramInt2)
  {
    getClient(paramArrayOfByte1).zrangeByScoreWithScores(paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3, paramInt1, paramInt2);
    return getResponse(BuilderFactory.TUPLE_ZSET_BINARY);
  }

  public Response<Set<String>> zrevrangeByScore(String paramString, double paramDouble1, double paramDouble2)
  {
    getClient(paramString).zrevrangeByScore(paramString, paramDouble1, paramDouble2);
    return getResponse(BuilderFactory.STRING_ZSET);
  }

  public Response<Set<byte[]>> zrevrangeByScore(byte[] paramArrayOfByte, double paramDouble1, double paramDouble2)
  {
    getClient(paramArrayOfByte).zrevrangeByScore(paramArrayOfByte, Protocol.toByteArray(paramDouble1), Protocol.toByteArray(paramDouble2));
    return getResponse(BuilderFactory.BYTE_ARRAY_ZSET);
  }

  public Response<Set<String>> zrevrangeByScore(String paramString1, String paramString2, String paramString3)
  {
    getClient(paramString1).zrevrangeByScore(paramString1, paramString2, paramString3);
    return getResponse(BuilderFactory.STRING_ZSET);
  }

  public Response<Set<byte[]>> zrevrangeByScore(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
  {
    getClient(paramArrayOfByte1).zrevrangeByScore(paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3);
    return getResponse(BuilderFactory.BYTE_ARRAY_ZSET);
  }

  public Response<Set<String>> zrevrangeByScore(String paramString, double paramDouble1, double paramDouble2, int paramInt1, int paramInt2)
  {
    getClient(paramString).zrevrangeByScore(paramString, paramDouble1, paramDouble2, paramInt1, paramInt2);
    return getResponse(BuilderFactory.STRING_ZSET);
  }

  public Response<Set<String>> zrevrangeByScore(String paramString1, String paramString2, String paramString3, int paramInt1, int paramInt2)
  {
    getClient(paramString1).zrevrangeByScore(paramString1, paramString2, paramString3, paramInt1, paramInt2);
    return getResponse(BuilderFactory.STRING_ZSET);
  }

  public Response<Set<byte[]>> zrevrangeByScore(byte[] paramArrayOfByte, double paramDouble1, double paramDouble2, int paramInt1, int paramInt2)
  {
    getClient(paramArrayOfByte).zrevrangeByScore(paramArrayOfByte, Protocol.toByteArray(paramDouble1), Protocol.toByteArray(paramDouble2), paramInt1, paramInt2);
    return getResponse(BuilderFactory.BYTE_ARRAY_ZSET);
  }

  public Response<Set<byte[]>> zrevrangeByScore(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3, int paramInt1, int paramInt2)
  {
    getClient(paramArrayOfByte1).zrevrangeByScore(paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3, paramInt1, paramInt2);
    return getResponse(BuilderFactory.BYTE_ARRAY_ZSET);
  }

  public Response<Set<Tuple>> zrevrangeByScoreWithScores(String paramString, double paramDouble1, double paramDouble2)
  {
    getClient(paramString).zrevrangeByScoreWithScores(paramString, paramDouble1, paramDouble2);
    return getResponse(BuilderFactory.TUPLE_ZSET);
  }

  public Response<Set<Tuple>> zrevrangeByScoreWithScores(String paramString1, String paramString2, String paramString3)
  {
    getClient(paramString1).zrevrangeByScoreWithScores(paramString1, paramString2, paramString3);
    return getResponse(BuilderFactory.TUPLE_ZSET);
  }

  public Response<Set<Tuple>> zrevrangeByScoreWithScores(byte[] paramArrayOfByte, double paramDouble1, double paramDouble2)
  {
    getClient(paramArrayOfByte).zrevrangeByScoreWithScores(paramArrayOfByte, Protocol.toByteArray(paramDouble1), Protocol.toByteArray(paramDouble2));
    return getResponse(BuilderFactory.TUPLE_ZSET_BINARY);
  }

  public Response<Set<Tuple>> zrevrangeByScoreWithScores(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
  {
    getClient(paramArrayOfByte1).zrevrangeByScoreWithScores(paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3);
    return getResponse(BuilderFactory.TUPLE_ZSET_BINARY);
  }

  public Response<Set<Tuple>> zrevrangeByScoreWithScores(String paramString, double paramDouble1, double paramDouble2, int paramInt1, int paramInt2)
  {
    getClient(paramString).zrevrangeByScoreWithScores(paramString, paramDouble1, paramDouble2, paramInt1, paramInt2);
    return getResponse(BuilderFactory.TUPLE_ZSET);
  }

  public Response<Set<Tuple>> zrevrangeByScoreWithScores(String paramString1, String paramString2, String paramString3, int paramInt1, int paramInt2)
  {
    getClient(paramString1).zrevrangeByScoreWithScores(paramString1, paramString2, paramString3, paramInt1, paramInt2);
    return getResponse(BuilderFactory.TUPLE_ZSET);
  }

  public Response<Set<Tuple>> zrevrangeByScoreWithScores(byte[] paramArrayOfByte, double paramDouble1, double paramDouble2, int paramInt1, int paramInt2)
  {
    getClient(paramArrayOfByte).zrevrangeByScoreWithScores(paramArrayOfByte, Protocol.toByteArray(paramDouble1), Protocol.toByteArray(paramDouble2), paramInt1, paramInt2);
    return getResponse(BuilderFactory.TUPLE_ZSET_BINARY);
  }

  public Response<Set<Tuple>> zrevrangeByScoreWithScores(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3, int paramInt1, int paramInt2)
  {
    getClient(paramArrayOfByte1).zrevrangeByScoreWithScores(paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3, paramInt1, paramInt2);
    return getResponse(BuilderFactory.TUPLE_ZSET_BINARY);
  }

  public Response<Set<Tuple>> zrangeWithScores(String paramString, long paramLong1, long paramLong2)
  {
    getClient(paramString).zrangeWithScores(paramString, paramLong1, paramLong2);
    return getResponse(BuilderFactory.TUPLE_ZSET);
  }

  public Response<Set<Tuple>> zrangeWithScores(byte[] paramArrayOfByte, long paramLong1, long paramLong2)
  {
    getClient(paramArrayOfByte).zrangeWithScores(paramArrayOfByte, paramLong1, paramLong2);
    return getResponse(BuilderFactory.TUPLE_ZSET_BINARY);
  }

  public Response<Long> zrank(String paramString1, String paramString2)
  {
    getClient(paramString1).zrank(paramString1, paramString2);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> zrank(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    getClient(paramArrayOfByte1).zrank(paramArrayOfByte1, paramArrayOfByte2);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> zrem(String paramString, String[] paramArrayOfString)
  {
    getClient(paramString).zrem(paramString, paramArrayOfString);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> zrem(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1)
  {
    getClient(paramArrayOfByte).zrem(paramArrayOfByte, paramArrayOfByte1);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> zremrangeByRank(String paramString, long paramLong1, long paramLong2)
  {
    getClient(paramString).zremrangeByRank(paramString, paramLong1, paramLong2);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> zremrangeByRank(byte[] paramArrayOfByte, long paramLong1, long paramLong2)
  {
    getClient(paramArrayOfByte).zremrangeByRank(paramArrayOfByte, paramLong1, paramLong2);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> zremrangeByScore(String paramString, double paramDouble1, double paramDouble2)
  {
    getClient(paramString).zremrangeByScore(paramString, paramDouble1, paramDouble2);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> zremrangeByScore(String paramString1, String paramString2, String paramString3)
  {
    getClient(paramString1).zremrangeByScore(paramString1, paramString2, paramString3);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> zremrangeByScore(byte[] paramArrayOfByte, double paramDouble1, double paramDouble2)
  {
    getClient(paramArrayOfByte).zremrangeByScore(paramArrayOfByte, Protocol.toByteArray(paramDouble1), Protocol.toByteArray(paramDouble2));
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> zremrangeByScore(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
  {
    getClient(paramArrayOfByte1).zremrangeByScore(paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Set<String>> zrevrange(String paramString, long paramLong1, long paramLong2)
  {
    getClient(paramString).zrevrange(paramString, paramLong1, paramLong2);
    return getResponse(BuilderFactory.STRING_ZSET);
  }

  public Response<Set<byte[]>> zrevrange(byte[] paramArrayOfByte, long paramLong1, long paramLong2)
  {
    getClient(paramArrayOfByte).zrevrange(paramArrayOfByte, paramLong1, paramLong2);
    return getResponse(BuilderFactory.BYTE_ARRAY_ZSET);
  }

  public Response<Set<Tuple>> zrevrangeWithScores(String paramString, long paramLong1, long paramLong2)
  {
    getClient(paramString).zrevrangeWithScores(paramString, paramLong1, paramLong2);
    return getResponse(BuilderFactory.TUPLE_ZSET);
  }

  public Response<Set<Tuple>> zrevrangeWithScores(byte[] paramArrayOfByte, long paramLong1, long paramLong2)
  {
    getClient(paramArrayOfByte).zrevrangeWithScores(paramArrayOfByte, paramLong1, paramLong2);
    return getResponse(BuilderFactory.TUPLE_ZSET);
  }

  public Response<Long> zrevrank(String paramString1, String paramString2)
  {
    getClient(paramString1).zrevrank(paramString1, paramString2);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> zrevrank(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    getClient(paramArrayOfByte1).zrevrank(paramArrayOfByte1, paramArrayOfByte2);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Double> zscore(String paramString1, String paramString2)
  {
    getClient(paramString1).zscore(paramString1, paramString2);
    return getResponse(BuilderFactory.DOUBLE);
  }

  public Response<Double> zscore(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    getClient(paramArrayOfByte1).zscore(paramArrayOfByte1, paramArrayOfByte2);
    return getResponse(BuilderFactory.DOUBLE);
  }

  public Response<Long> bitcount(String paramString)
  {
    getClient(paramString).bitcount(paramString);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> bitcount(String paramString, long paramLong1, long paramLong2)
  {
    getClient(paramString).bitcount(paramString, paramLong1, paramLong2);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> bitcount(byte[] paramArrayOfByte)
  {
    getClient(paramArrayOfByte).bitcount(paramArrayOfByte);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> bitcount(byte[] paramArrayOfByte, long paramLong1, long paramLong2)
  {
    getClient(paramArrayOfByte).bitcount(paramArrayOfByte, paramLong1, paramLong2);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<byte[]> dump(String paramString)
  {
    getClient(paramString).dump(paramString);
    return getResponse(BuilderFactory.BYTE_ARRAY);
  }

  public Response<byte[]> dump(byte[] paramArrayOfByte)
  {
    getClient(paramArrayOfByte).dump(paramArrayOfByte);
    return getResponse(BuilderFactory.BYTE_ARRAY);
  }

  public Response<String> migrate(String paramString1, int paramInt1, String paramString2, int paramInt2, int paramInt3)
  {
    getClient(paramString2).migrate(paramString1, paramInt1, paramString2, paramInt2, paramInt3);
    return getResponse(BuilderFactory.STRING);
  }

  public Response<String> migrate(byte[] paramArrayOfByte1, int paramInt1, byte[] paramArrayOfByte2, int paramInt2, int paramInt3)
  {
    getClient(paramArrayOfByte2).migrate(paramArrayOfByte1, paramInt1, paramArrayOfByte2, paramInt2, paramInt3);
    return getResponse(BuilderFactory.STRING);
  }

  public Response<Long> objectRefcount(String paramString)
  {
    getClient(paramString).objectRefcount(paramString);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> objectRefcount(byte[] paramArrayOfByte)
  {
    getClient(paramArrayOfByte).objectRefcount(paramArrayOfByte);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<String> objectEncoding(String paramString)
  {
    getClient(paramString).objectEncoding(paramString);
    return getResponse(BuilderFactory.STRING);
  }

  public Response<byte[]> objectEncoding(byte[] paramArrayOfByte)
  {
    getClient(paramArrayOfByte).objectEncoding(paramArrayOfByte);
    return getResponse(BuilderFactory.BYTE_ARRAY);
  }

  public Response<Long> objectIdletime(String paramString)
  {
    getClient(paramString).objectIdletime(paramString);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> objectIdletime(byte[] paramArrayOfByte)
  {
    getClient(paramArrayOfByte).objectIdletime(paramArrayOfByte);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> pexpire(String paramString, int paramInt)
  {
    getClient(paramString).pexpire(paramString, paramInt);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> pexpire(byte[] paramArrayOfByte, int paramInt)
  {
    getClient(paramArrayOfByte).pexpire(paramArrayOfByte, paramInt);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> pexpireAt(String paramString, long paramLong)
  {
    getClient(paramString).pexpireAt(paramString, paramLong);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> pexpireAt(byte[] paramArrayOfByte, long paramLong)
  {
    getClient(paramArrayOfByte).pexpireAt(paramArrayOfByte, paramLong);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> pttl(String paramString)
  {
    getClient(paramString).pttl(paramString);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> pttl(byte[] paramArrayOfByte)
  {
    getClient(paramArrayOfByte).pttl(paramArrayOfByte);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<String> restore(String paramString, int paramInt, byte[] paramArrayOfByte)
  {
    getClient(paramString).restore(paramString, paramInt, paramArrayOfByte);
    return getResponse(BuilderFactory.STRING);
  }

  public Response<String> restore(byte[] paramArrayOfByte1, int paramInt, byte[] paramArrayOfByte2)
  {
    getClient(paramArrayOfByte1).restore(paramArrayOfByte1, paramInt, paramArrayOfByte2);
    return getResponse(BuilderFactory.STRING);
  }

  public Response<Double> incrByFloat(String paramString, double paramDouble)
  {
    getClient(paramString).incrByFloat(paramString, paramDouble);
    return getResponse(BuilderFactory.DOUBLE);
  }

  public Response<Double> incrByFloat(byte[] paramArrayOfByte, double paramDouble)
  {
    getClient(paramArrayOfByte).incrByFloat(paramArrayOfByte, paramDouble);
    return getResponse(BuilderFactory.DOUBLE);
  }

  public Response<String> psetex(String paramString1, int paramInt, String paramString2)
  {
    getClient(paramString1).psetex(paramString1, paramInt, paramString2);
    return getResponse(BuilderFactory.STRING);
  }

  public Response<String> psetex(byte[] paramArrayOfByte1, int paramInt, byte[] paramArrayOfByte2)
  {
    getClient(paramArrayOfByte1).psetex(paramArrayOfByte1, paramInt, paramArrayOfByte2);
    return getResponse(BuilderFactory.STRING);
  }

  public Response<String> set(String paramString1, String paramString2, String paramString3)
  {
    getClient(paramString1).set(paramString1, paramString2, paramString3);
    return getResponse(BuilderFactory.STRING);
  }

  public Response<String> set(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
  {
    getClient(paramArrayOfByte1).set(paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3);
    return getResponse(BuilderFactory.STRING);
  }

  public Response<String> set(String paramString1, String paramString2, String paramString3, String paramString4, int paramInt)
  {
    getClient(paramString1).set(paramString1, paramString2, paramString3, paramString4, paramInt);
    return getResponse(BuilderFactory.STRING);
  }

  public Response<String> set(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3, byte[] paramArrayOfByte4, int paramInt)
  {
    getClient(paramArrayOfByte1).set(paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3, paramArrayOfByte4, paramInt);
    return getResponse(BuilderFactory.STRING);
  }

  public Response<Double> hincrByFloat(String paramString1, String paramString2, double paramDouble)
  {
    getClient(paramString1).hincrByFloat(paramString1, paramString2, paramDouble);
    return getResponse(BuilderFactory.DOUBLE);
  }

  public Response<Double> hincrByFloat(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, double paramDouble)
  {
    getClient(paramArrayOfByte1).hincrByFloat(paramArrayOfByte1, paramArrayOfByte2, paramDouble);
    return getResponse(BuilderFactory.DOUBLE);
  }

  public Response<String> eval(String paramString)
  {
    return eval(paramString, 0, new String[0]);
  }

  public Response<String> eval(String paramString, List<String> paramList1, List<String> paramList2)
  {
    String[] arrayOfString = Jedis.getParams(paramList1, paramList2);
    return eval(paramString, paramList1.size(), arrayOfString);
  }

  public Response<String> eval(String paramString, int paramInt, String[] paramArrayOfString)
  {
    getClient(paramString).eval(paramString, paramInt, paramArrayOfString);
    return getResponse(BuilderFactory.STRING);
  }

  public Response<String> evalsha(String paramString)
  {
    return evalsha(paramString, 0, new String[0]);
  }

  public Response<String> evalsha(String paramString, List<String> paramList1, List<String> paramList2)
  {
    String[] arrayOfString = Jedis.getParams(paramList1, paramList2);
    return evalsha(paramString, paramList1.size(), arrayOfString);
  }

  public Response<String> evalsha(String paramString, int paramInt, String[] paramArrayOfString)
  {
    getClient(paramString).evalsha(paramString, paramInt, paramArrayOfString);
    return getResponse(BuilderFactory.STRING);
  }
}