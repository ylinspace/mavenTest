package com.ycache.redis.clients.jedis;

import com.ycache.redis.clients.util.SafeEncoder;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

public class SortingParams
{
  private List<byte[]> params = new ArrayList();

  public SortingParams by(String paramString)
  {
    return by(SafeEncoder.encode(paramString));
  }

  public SortingParams by(byte[] paramArrayOfByte)
  {
    this.params.add(Protocol.Keyword.BY.raw);
    this.params.add(paramArrayOfByte);
    return this;
  }

  public SortingParams nosort()
  {
    this.params.add(Protocol.Keyword.BY.raw);
    this.params.add(Protocol.Keyword.NOSORT.raw);
    return this;
  }

  public Collection<byte[]> getParams()
  {
    return Collections.unmodifiableCollection(this.params);
  }

  public SortingParams desc()
  {
    this.params.add(Protocol.Keyword.DESC.raw);
    return this;
  }

  public SortingParams asc()
  {
    this.params.add(Protocol.Keyword.ASC.raw);
    return this;
  }

  public SortingParams limit(int paramInt1, int paramInt2)
  {
    this.params.add(Protocol.Keyword.LIMIT.raw);
    this.params.add(Protocol.toByteArray(paramInt1));
    this.params.add(Protocol.toByteArray(paramInt2));
    return this;
  }

  public SortingParams alpha()
  {
    this.params.add(Protocol.Keyword.ALPHA.raw);
    return this;
  }

  public SortingParams get(String[] paramArrayOfString)
  {
    String[] arrayOfString = paramArrayOfString;
    int i = arrayOfString.length;
    for (int j = 0; j < i; ++j)
    {
      String str = arrayOfString[j];
      this.params.add(Protocol.Keyword.GET.raw);
      this.params.add(SafeEncoder.encode(str));
    }
    return this;
  }

  public SortingParams get(byte[][] paramArrayOfByte)
  {
    byte[][] arrayOfByte = paramArrayOfByte;
    int i = arrayOfByte.length;
    for (int j = 0; j < i; ++j)
    {
      byte[] arrayOfByte1 = arrayOfByte[j];
      this.params.add(Protocol.Keyword.GET.raw);
      this.params.add(arrayOfByte1);
    }
    return this;
  }
}