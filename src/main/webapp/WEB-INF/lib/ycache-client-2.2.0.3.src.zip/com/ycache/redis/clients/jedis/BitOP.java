package com.ycache.redis.clients.jedis;

public enum BitOP
{
  AND, OR, XOR, NOT;
}