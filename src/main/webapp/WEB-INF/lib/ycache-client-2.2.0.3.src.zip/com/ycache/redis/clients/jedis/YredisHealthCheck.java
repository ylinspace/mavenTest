package com.ycache.redis.clients.jedis;

import com.yihaodian.common.yredis.RedisProxy;
import com.yihaodian.configcentre.client.utils.YccGlobalPropertyConfigurer;
import com.yihaodian.configcentre.utils.AppUtils;
import com.yihaodian.dto.CheckResult;
import com.yihaodian.dto.DetailResult;
import com.yihaodian.dto.HealthState;
import com.yihaodian.healthcheck.HealthCheckType;
import com.yihaodian.healthcheck.HealthCheckUtil;
import com.yihaodian.healthcheck.HealthCheckable;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class YredisHealthCheck
  implements HealthCheckable
{
  private Map<String, RedisProxy> redisMap = new HashMap();
  private static YredisHealthCheck instance = null;

  public static synchronized YredisHealthCheck getInstance()
  {
    if (instance == null)
    {
      instance = new YredisHealthCheck();
      instance.register();
    }
    return instance;
  }

  public void register()
  {
    HealthCheckUtil.register(this);
  }

  public CheckResult getRealTimeInfo()
  {
    CheckResult localCheckResult = new CheckResult();
    String str1 = "testKey";
    String str2 = "testValue";
    String str3 = AppUtils.getHostAddress();
    String str4 = YccGlobalPropertyConfigurer.getMainPoolId();
    localCheckResult.setAppHost(str3);
    Iterator localIterator = this.redisMap.entrySet().iterator();
    while (localIterator.hasNext())
    {
      Map.Entry localEntry = (Map.Entry)localIterator.next();
      DetailResult localDetailResult = new DetailResult();
      localCheckResult.addDetailResult(localDetailResult);
      RedisProxy localRedisProxy = (RedisProxy)localEntry.getValue();
      String str5 = (String)localEntry.getKey();
      try
      {
        localRedisProxy.set(str1, str2);
        String str6 = "";
        if ((localRedisProxy.get(str1) != null) && (!(localRedisProxy.get(str1).toString().equalsIgnoreCase(""))))
          str6 = localRedisProxy.get(str1).toString();
        if ((str6 == null) || (str6.equalsIgnoreCase("")))
        {
          localDetailResult.setDetailState(HealthState.FAILED.getCode());
          localDetailResult.setResource(str5);
          localDetailResult.setErrorInfo(((String)localEntry.getKey()) + " set or get key: " + str1 + "; value:" + str2 + " --failed");
        }
        else
        {
          localDetailResult.setDetailState(HealthState.SUCCESS.getCode());
          localDetailResult.setResource(str5);
          localDetailResult.setMemo(((String)localEntry.getKey()) + " set or get key: " + str1 + "; value:" + str2 + " --success");
        }
        localRedisProxy.del(str1);
      }
      catch (Exception localException)
      {
        localDetailResult.setDetailState(HealthState.FAILED.getCode());
        localDetailResult.setResource(str5);
        localDetailResult.setErrorInfo(localException.getMessage());
      }
    }
    localCheckResult.setAppCode(str4);
    return localCheckResult;
  }

  public Map<String, RedisProxy> getRedisMap()
  {
    return this.redisMap;
  }

  public void setRedisMap(Map<String, RedisProxy> paramMap)
  {
    this.redisMap = paramMap;
  }

  public String getType()
  {
    return HealthCheckType.YCACHE.getCode();
  }
}