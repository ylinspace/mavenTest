package com.ycache.redis.clients.util;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public class MurmurHash
  implements Hashing
{
  public static int hash(byte[] paramArrayOfByte, int paramInt)
  {
    return hash(ByteBuffer.wrap(paramArrayOfByte), paramInt);
  }

  public static int hash(byte[] paramArrayOfByte, int paramInt1, int paramInt2, int paramInt3)
  {
    return hash(ByteBuffer.wrap(paramArrayOfByte, paramInt1, paramInt2), paramInt3);
  }

  public static int hash(ByteBuffer paramByteBuffer, int paramInt)
  {
    ByteOrder localByteOrder = paramByteBuffer.order();
    paramByteBuffer.order(ByteOrder.LITTLE_ENDIAN);
    int i = 1540483477;
    int j = 24;
    int k = paramInt ^ paramByteBuffer.remaining();
    while (paramByteBuffer.remaining() >= 4)
    {
      int l = paramByteBuffer.getInt();
      l *= i;
      l ^= l >>> j;
      l *= i;
      k *= i;
      k ^= l;
    }
    if (paramByteBuffer.remaining() > 0)
    {
      ByteBuffer localByteBuffer = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN);
      localByteBuffer.put(paramByteBuffer).rewind();
      k ^= localByteBuffer.getInt();
      k *= i;
    }
    k ^= k >>> 13;
    k *= i;
    k ^= k >>> 15;
    paramByteBuffer.order(localByteOrder);
    return k;
  }

  public static long hash64A(byte[] paramArrayOfByte, int paramInt)
  {
    return hash64A(ByteBuffer.wrap(paramArrayOfByte), paramInt);
  }

  public static long hash64A(byte[] paramArrayOfByte, int paramInt1, int paramInt2, int paramInt3)
  {
    return hash64A(ByteBuffer.wrap(paramArrayOfByte, paramInt1, paramInt2), paramInt3);
  }

  public static long hash64A(ByteBuffer paramByteBuffer, int paramInt)
  {
    ByteOrder localByteOrder = paramByteBuffer.order();
    paramByteBuffer.order(ByteOrder.LITTLE_ENDIAN);
    long l1 = -4132994306676758123L;
    int i = 47;
    long l2 = paramInt ^ paramByteBuffer.remaining() * l1;
    while (paramByteBuffer.remaining() >= 8)
    {
      long l3 = paramByteBuffer.getLong();
      l3 *= l1;
      l3 ^= l3 >>> i;
      l3 *= l1;
      l2 ^= l3;
      l2 *= l1;
    }
    if (paramByteBuffer.remaining() > 0)
    {
      ByteBuffer localByteBuffer = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN);
      localByteBuffer.put(paramByteBuffer).rewind();
      l2 ^= localByteBuffer.getLong();
      l2 *= l1;
    }
    l2 ^= l2 >>> i;
    l2 *= l1;
    l2 ^= l2 >>> i;
    paramByteBuffer.order(localByteOrder);
    return l2;
  }

  public long hash(byte[] paramArrayOfByte)
  {
    return hash64A(paramArrayOfByte, 305441741);
  }

  public long hash(String paramString)
  {
    return hash(SafeEncoder.encode(paramString));
  }
}