package com.ycache.redis.clients.jedis;

import com.ycache.redis.clients.jedis.exceptions.JedisException;
import java.util.Arrays;
import java.util.List;

public abstract class BinaryJedisPubSub
{
  private int subscribedChannels = 0;
  private Client client;

  public abstract void onMessage(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);

  public abstract void onPMessage(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3);

  public abstract void onSubscribe(byte[] paramArrayOfByte, int paramInt);

  public abstract void onUnsubscribe(byte[] paramArrayOfByte, int paramInt);

  public abstract void onPUnsubscribe(byte[] paramArrayOfByte, int paramInt);

  public abstract void onPSubscribe(byte[] paramArrayOfByte, int paramInt);

  public void unsubscribe()
  {
    this.client.unsubscribe();
    this.client.flush();
  }

  public void unsubscribe(byte[][] paramArrayOfByte)
  {
    this.client.unsubscribe(paramArrayOfByte);
    this.client.flush();
  }

  public void subscribe(byte[][] paramArrayOfByte)
  {
    this.client.subscribe(paramArrayOfByte);
    this.client.flush();
  }

  public void psubscribe(byte[][] paramArrayOfByte)
  {
    this.client.psubscribe(paramArrayOfByte);
    this.client.flush();
  }

  public void punsubscribe()
  {
    this.client.punsubscribe();
    this.client.flush();
  }

  public void punsubscribe(byte[][] paramArrayOfByte)
  {
    this.client.punsubscribe(paramArrayOfByte);
    this.client.flush();
  }

  public boolean isSubscribed()
  {
    return (this.subscribedChannels > 0);
  }

  public void proceedWithPatterns(Client paramClient, byte[][] paramArrayOfByte)
  {
    this.client = paramClient;
    paramClient.psubscribe(paramArrayOfByte);
    process(paramClient);
  }

  public void proceed(Client paramClient, byte[][] paramArrayOfByte)
  {
    this.client = paramClient;
    paramClient.subscribe(paramArrayOfByte);
    process(paramClient);
  }

  private void process(Client paramClient)
  {
    do
    {
      byte[] arrayOfByte2;
      List localList = paramClient.getObjectMultiBulkReply();
      Object localObject = localList.get(0);
      if (!(localObject instanceof byte[]))
        throw new JedisException("Unknown message type: " + localObject);
      byte[] arrayOfByte1 = (byte[])(byte[])localObject;
      if (Arrays.equals(Protocol.Keyword.SUBSCRIBE.raw, arrayOfByte1))
      {
        this.subscribedChannels = ((Long)localList.get(2)).intValue();
        arrayOfByte2 = (byte[])(byte[])localList.get(1);
        onSubscribe(arrayOfByte2, this.subscribedChannels);
      }
      else if (Arrays.equals(Protocol.Keyword.UNSUBSCRIBE.raw, arrayOfByte1))
      {
        this.subscribedChannels = ((Long)localList.get(2)).intValue();
        arrayOfByte2 = (byte[])(byte[])localList.get(1);
        onUnsubscribe(arrayOfByte2, this.subscribedChannels);
      }
      else
      {
        byte[] arrayOfByte3;
        if (Arrays.equals(Protocol.Keyword.MESSAGE.raw, arrayOfByte1))
        {
          arrayOfByte2 = (byte[])(byte[])localList.get(1);
          arrayOfByte3 = (byte[])(byte[])localList.get(2);
          onMessage(arrayOfByte2, arrayOfByte3);
        }
        else if (Arrays.equals(Protocol.Keyword.PMESSAGE.raw, arrayOfByte1))
        {
          arrayOfByte2 = (byte[])(byte[])localList.get(1);
          arrayOfByte3 = (byte[])(byte[])localList.get(2);
          byte[] arrayOfByte4 = (byte[])(byte[])localList.get(3);
          onPMessage(arrayOfByte2, arrayOfByte3, arrayOfByte4);
        }
        else if (Arrays.equals(Protocol.Keyword.PSUBSCRIBE.raw, arrayOfByte1))
        {
          this.subscribedChannels = ((Long)localList.get(2)).intValue();
          arrayOfByte2 = (byte[])(byte[])localList.get(1);
          onPSubscribe(arrayOfByte2, this.subscribedChannels);
        }
        else if (Arrays.equals(Protocol.Keyword.PUNSUBSCRIBE.raw, arrayOfByte1))
        {
          this.subscribedChannels = ((Long)localList.get(2)).intValue();
          arrayOfByte2 = (byte[])(byte[])localList.get(1);
          onPUnsubscribe(arrayOfByte2, this.subscribedChannels);
        }
        else
        {
          throw new JedisException("Unknown message type: " + localObject);
        }
      }
    }
    while (isSubscribed());
  }

  public int getSubscribedChannels()
  {
    return this.subscribedChannels;
  }
}