package com.ycache.danga.MemCached;

import com.yihaodian.common.ycache.CacheProxy;
import com.yihaodian.configcentre.client.utils.YccGlobalPropertyConfigurer;
import com.yihaodian.configcentre.utils.AppUtils;
import com.yihaodian.dto.CheckResult;
import com.yihaodian.dto.DetailResult;
import com.yihaodian.dto.HealthState;
import com.yihaodian.healthcheck.HealthCheckType;
import com.yihaodian.healthcheck.HealthCheckUtil;
import com.yihaodian.healthcheck.HealthCheckable;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class YcacheHealthCheck
  implements HealthCheckable
{
  private Map<String, CacheProxy> cacheMap = new HashMap();
  private static YcacheHealthCheck instance = null;

  public static synchronized YcacheHealthCheck getInstance()
  {
    if (instance == null)
    {
      instance = new YcacheHealthCheck();
      instance.register();
    }
    return instance;
  }

  public void register()
  {
    HealthCheckUtil.register(this);
  }

  public CheckResult getRealTimeInfo()
  {
    CheckResult localCheckResult = new CheckResult();
    String str1 = "testKey";
    String str2 = "testValue";
    String str3 = AppUtils.getHostAddress();
    String str4 = YccGlobalPropertyConfigurer.getMainPoolId();
    localCheckResult.setAppHost(str3);
    Iterator localIterator = this.cacheMap.entrySet().iterator();
    while (localIterator.hasNext())
    {
      Map.Entry localEntry = (Map.Entry)localIterator.next();
      DetailResult localDetailResult = new DetailResult();
      localCheckResult.addDetailResult(localDetailResult);
      CacheProxy localCacheProxy = (CacheProxy)localEntry.getValue();
      String str5 = (String)localEntry.getKey();
      try
      {
        localCacheProxy.put(str1, str2);
        String str6 = "";
        if ((localCacheProxy.get(str1) != null) && (!(localCacheProxy.get(str1).toString().equalsIgnoreCase(""))))
          str6 = localCacheProxy.get(str1).toString();
        if ((str6 == null) || (str6.equalsIgnoreCase("")))
        {
          localDetailResult.setDetailState(HealthState.FAILED.getCode());
          localDetailResult.setResource(str5);
          localDetailResult.setErrorInfo(((String)localEntry.getKey()) + " set or get key: " + str1 + "; value:" + str2 + " --failed");
        }
        else
        {
          localDetailResult.setDetailState(HealthState.SUCCESS.getCode());
          localDetailResult.setResource(str5);
          localDetailResult.setMemo(((String)localEntry.getKey()) + " set or get key: " + str1 + "; value:" + str2 + " --success");
        }
        localCacheProxy.remove(str1);
      }
      catch (Exception localException)
      {
        localDetailResult.setDetailState(HealthState.FAILED.getCode());
        localDetailResult.setResource(str5);
        localDetailResult.setErrorInfo(localException.getMessage());
      }
    }
    localCheckResult.setAppCode(str4);
    return localCheckResult;
  }

  public Map<String, CacheProxy> getCacheMap()
  {
    return this.cacheMap;
  }

  public void setCacheMap(Map<String, CacheProxy> paramMap)
  {
    this.cacheMap = paramMap;
  }

  public String getType()
  {
    return HealthCheckType.YCACHE.getCode();
  }
}