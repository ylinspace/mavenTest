package com.ycache.redis.clients.jedis;

import com.ycache.redis.clients.util.Pool;
import java.net.URI;
import org.apache.commons.pool.impl.GenericObjectPool;
import org.apache.commons.pool.impl.GenericObjectPool.Config;

public class JedisPool extends Pool<Jedis>
{
  public JedisPool(GenericObjectPool.Config paramConfig, String paramString)
  {
    this(paramConfig, paramString, 6379, 2000, null, 0);
  }

  public JedisPool(String paramString, int paramInt)
  {
    this(new GenericObjectPool.Config(), paramString, paramInt, 2000, null, 0);
  }

  public JedisPool(String paramString)
  {
    URI localURI = URI.create(paramString);
    if ((localURI.getScheme() != null) && (localURI.getScheme().equals("redis")))
    {
      String str1 = localURI.getHost();
      int i = localURI.getPort();
      String str2 = localURI.getUserInfo().split(":", 2)[1];
      int j = Integer.parseInt(localURI.getPath().split("/", 2)[1]);
      this.internalPool = new GenericObjectPool(new JedisFactory(str1, i, 2000, str2, j), new GenericObjectPool.Config());
    }
    else
    {
      this.internalPool = new GenericObjectPool(new JedisFactory(paramString, 6379, 2000, null, 0), new GenericObjectPool.Config());
    }
  }

  public JedisPool(URI paramURI)
  {
    String str1 = paramURI.getHost();
    int i = paramURI.getPort();
    String str2 = paramURI.getUserInfo().split(":", 2)[1];
    int j = Integer.parseInt(paramURI.getPath().split("/", 2)[1]);
    this.internalPool = new GenericObjectPool(new JedisFactory(str1, i, 2000, str2, j), new GenericObjectPool.Config());
  }

  public JedisPool(GenericObjectPool.Config paramConfig, String paramString1, int paramInt1, int paramInt2, String paramString2)
  {
    this(paramConfig, paramString1, paramInt1, paramInt2, paramString2, 0);
  }

  public JedisPool(GenericObjectPool.Config paramConfig, String paramString, int paramInt)
  {
    this(paramConfig, paramString, paramInt, 2000, null, 0);
  }

  public JedisPool(GenericObjectPool.Config paramConfig, String paramString, int paramInt1, int paramInt2)
  {
    this(paramConfig, paramString, paramInt1, paramInt2, null, 0);
  }

  public JedisPool(GenericObjectPool.Config paramConfig, String paramString1, int paramInt1, int paramInt2, String paramString2, int paramInt3)
  {
    super(paramConfig, new JedisFactory(paramString1, paramInt1, paramInt2, paramString2, paramInt3));
  }

  public void returnBrokenResource(BinaryJedis paramBinaryJedis)
  {
    returnBrokenResourceObject(paramBinaryJedis);
  }

  public void returnResource(BinaryJedis paramBinaryJedis)
  {
    returnResourceObject(paramBinaryJedis);
  }
}