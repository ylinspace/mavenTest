package com.ycache.danga.MemCached;

import com.yihaodian.architecture.hedwig.common.hessian.HedwigHessianInput;
import com.yihaodian.architecture.hedwig.common.hessian.HedwigHessianOutput;
import com.yihaodian.common.ycache.stats.StatsLocalCache;
import com.yihaodian.common.ycache.stats.StatsLocalCacheManager;
import com.yihaodian.configcentre.client.utils.YccGlobalPropertyConfigurer;
import com.yihaodian.configcentre.utils.AppUtils;
import com.yihaodian.monitor.dto.YcacheAnalyse;
import com.yihaodian.monitor.util.MonitorJmsSendUtil;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InvalidClassException;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.Socket;
import java.net.URLEncoder;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.SocketChannel;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map<Ljava.lang.String;Ljava.lang.Object;>;
import java.util.Set;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;
import org.apache.log4j.Logger;

public class MemCachedClient
{
  private static Logger log = Logger.getLogger(MemCachedClient.class.getName());
  private static final String VALUE = "VALUE";
  private static final String STATS = "STAT";
  private static final String ITEM = "ITEM";
  private static final String DELETED = "DELETED";
  private static final String NOTFOUND = "NOT_FOUND";
  private static final String STORED = "STORED";
  private static final String NOTSTORED = "NOT_STORED";
  private static final String OK = "OK";
  private static final String END = "END";
  private static final String ERROR = "ERROR";
  private static final String CLIENT_ERROR = "CLIENT_ERROR";
  private static final String SERVER_ERROR = "SERVER_ERROR";
  private static final byte[] B_END = "END\r\n".getBytes();
  private static final byte[] B_NOTFOUND = "NOT_FOUND\r\n".getBytes();
  private static final byte[] B_DELETED = "DELETED\r\r".getBytes();
  private static final byte[] B_STORED = "STORED\r\r".getBytes();
  private static final long exp = 86400L;
  private static final int COMPRESS_THRESH = 30720;
  private static final int SENDEMAIL_INTERVAL = 10;
  public static final int MARKER_BYTE = 1;
  public static final int MARKER_BOOLEAN = 8192;
  public static final int MARKER_INTEGER = 4;
  public static final int MARKER_LONG = 16384;
  public static final int MARKER_CHARACTER = 16;
  public static final int MARKER_STRING = 32;
  public static final int MARKER_STRINGBUFFER = 64;
  public static final int MARKER_FLOAT = 128;
  public static final int MARKER_SHORT = 256;
  public static final int MARKER_DOUBLE = 512;
  public static final int MARKER_DATE = 1024;
  public static final int MARKER_STRINGBUILDER = 2048;
  public static final int MARKER_BYTEARR = 4096;
  public static final int F_COMPRESSED = 2;
  public static final int F_SERIALIZED = 8;
  public static final int F_SERIALIZED_JDK = 32768;
  private boolean sanitizeKeys;
  private boolean primitiveAsString;
  private boolean compressEnable;
  private boolean JDK;
  private long compressThreshold;
  private String defaultEncoding;
  private int sendEmailInterval;
  private SockIOPool pool;
  private String poolName;
  private ClassLoader classLoader;
  private ErrorHandler errorHandler;
  public static final int MEMCACHE_CONTENT_LIMIT_SIZE = 1048576;
  public static final int DEFATUL_MAX_KEY_SIZE = 10240;
  public static final int DEFAULT_MAX_VALUE_SIZE = 1048576;
  private int maxKeySize = 10240;
  private int maxValueSize = 1048576;
  private static final String JUMPER_TOPIC_NAME = "ycachequeue";
  private static final String appHost = AppUtils.getHostAddress();
  private static final String appCode = YccGlobalPropertyConfigurer.getMainPoolId();

  public MemCachedClient()
  {
    init();
  }

  public MemCachedClient(String paramString)
  {
    this.poolName = paramString;
    init();
  }

  public MemCachedClient(ClassLoader paramClassLoader)
  {
    this.classLoader = paramClassLoader;
    init();
  }

  public MemCachedClient(ClassLoader paramClassLoader, ErrorHandler paramErrorHandler)
  {
    this.classLoader = paramClassLoader;
    this.errorHandler = paramErrorHandler;
    init();
  }

  public MemCachedClient(ClassLoader paramClassLoader, ErrorHandler paramErrorHandler, String paramString)
  {
    this.classLoader = paramClassLoader;
    this.errorHandler = paramErrorHandler;
    this.poolName = paramString;
    init();
  }

  private void init()
  {
    this.sanitizeKeys = true;
    this.primitiveAsString = false;
    this.compressEnable = true;
    this.JDK = false;
    this.compressThreshold = 30720L;
    this.sendEmailInterval = 10;
    this.defaultEncoding = "UTF-8";
    this.poolName = ((this.poolName == null) ? "default" : this.poolName);
    this.pool = SockIOPool.getInstance(this.poolName);
  }

  public void setClassLoader(ClassLoader paramClassLoader)
  {
    this.classLoader = paramClassLoader;
  }

  public void setErrorHandler(ErrorHandler paramErrorHandler)
  {
    this.errorHandler = paramErrorHandler;
  }

  public void setSanitizeKeys(boolean paramBoolean)
  {
    this.sanitizeKeys = paramBoolean;
  }

  public void setPrimitiveAsString(boolean paramBoolean)
  {
    this.primitiveAsString = paramBoolean;
  }

  public void setMaxKeySize(int paramInt)
  {
    this.maxKeySize = paramInt;
  }

  public void setMaxValueSize(int paramInt)
  {
    this.maxValueSize = paramInt;
  }

  public void setSendEmailInterval(int paramInt)
  {
    this.sendEmailInterval = paramInt;
  }

  public void setDefaultEncoding(String paramString)
  {
    this.defaultEncoding = paramString;
  }

  public void setCompressEnable(boolean paramBoolean)
  {
    this.compressEnable = paramBoolean;
  }

  public void setJDK(boolean paramBoolean)
  {
    this.JDK = paramBoolean;
  }

  public void setCompressThreshold(long paramLong)
  {
    this.compressThreshold = paramLong;
  }

  public boolean keyExists(String paramString)
  {
    return (get(paramString, null, true) != null);
  }

  public boolean delete(String paramString)
  {
    return delete(paramString, null, null);
  }

  public boolean delete(String paramString, Date paramDate)
  {
    return delete(paramString, null, paramDate);
  }

  public boolean delete(String paramString, Integer paramInteger, Date paramDate)
  {
    if (paramString == null)
    {
      log.error("null value for key passed to delete()");
      return false;
    }
    try
    {
      paramString = sanitizeKey(paramString);
    }
    catch (UnsupportedEncodingException localUnsupportedEncodingException)
    {
      if (this.errorHandler != null)
        this.errorHandler.handleErrorOnDelete(this, localUnsupportedEncodingException, paramString);
      log.error("failed to sanitize your key!", localUnsupportedEncodingException);
      return false;
    }
    SockIOPool.SockIO localSockIO = this.pool.getSock(paramString, paramInteger);
    if (localSockIO == null)
    {
      if (this.errorHandler != null)
        this.errorHandler.handleErrorOnDelete(this, new IOException("no socket to server available"), paramString);
      return false;
    }
    StringBuilder localStringBuilder = new StringBuilder("delete ").append(paramString);
    if (paramDate != null)
      localStringBuilder.append(new StringBuilder().append(" ").append(paramDate.getTime() / 1000L).toString());
    if (this.pool.getNoreply())
      localStringBuilder.append(" noreply");
    localStringBuilder.append("\r\n");
    try
    {
      localSockIO.write(localStringBuilder.toString().getBytes());
      localSockIO.flush();
      if (!(this.pool.getNoreply()))
      {
        String str = localSockIO.readLine();
        if ("DELETED".equals(str))
        {
          if (log.isInfoEnabled())
            log.info(new StringBuilder().append("++++ deletion of key: ").append(paramString).append(" from cache was a success").toString());
          localSockIO.close();
          localSockIO = null;
          return true;
        }
        if ("NOT_FOUND".equals(str))
        {
          if (log.isInfoEnabled())
            log.info(new StringBuilder().append("++++ deletion of key: ").append(paramString).append(" from cache failed as the key was not found").toString());
        }
        else
        {
          log.error(new StringBuilder().append("++++ error deleting key: ").append(paramString).toString());
          log.error(new StringBuilder().append("++++ server response: ").append(str).toString());
          try
          {
            Object localObject1 = getObject(cacheInRequestKey(this.poolName, "deleteFailTimes"));
            if (localObject1 == null)
            {
              setObject(cacheInRequestKey(this.poolName, "deleteFailTimes"), java.lang.Long.valueOf(-6318798324447051775L), 86400L);
              setObject(cacheInRequestKey(this.poolName, "deleteFailDate"), new Date(), 86400L);
              sendToDetector(localSockIO.getHost(), str, new StringBuilder().append("poolName :").append(this.poolName).append("   ++++ error deleting key: ").append(paramString).toString());
            }
            else
            {
              incrNumber(cacheInRequestKey(this.poolName, "deleteFailTimes"), -6318799114721034239L);
              Object localObject2 = getObject(cacheInRequestKey(this.poolName, "deleteFailTimes"));
              long l1 = ((java.lang.Long)localObject2).longValue();
              Object localObject3 = getObject(cacheInRequestKey(this.poolName, "deleteFailDate"));
              long l2 = ((Date)localObject3).getTime();
              if ((l1 > 10000L) || (new Date().getTime() - l2 > this.sendEmailInterval * 60 * 1000))
              {
                sendToDetector(localSockIO.getHost(), str, new StringBuilder().append("poolName :").append(this.poolName).append("   ++++ error deleting  times = ").append(l1).append(" in ").append(this.sendEmailInterval).append("min or less than ").append(this.sendEmailInterval).append("min and recent key: ").append(paramString).toString());
                setObject(cacheInRequestKey(this.poolName, "deleteFailTimes"), java.lang.Long.valueOf(-6318797723151630335L), 86400L);
                setObject(cacheInRequestKey(this.poolName, "deleteFailDate"), new Date(), 86400L);
              }
            }
          }
          catch (Exception localException)
          {
            log.error(new StringBuilder().append("++++ delete cache error: ").append(localException.getMessage()).toString(), localException);
          }
        }
      }
      else
      {
        log.info(new StringBuilder().append("++++ deletion use noreply for key: ").append(paramString).toString());
        localSockIO.discardInput();
        localSockIO.close();
        localSockIO = null;
        return true;
      }
    }
    catch (IOException localIOException1)
    {
      if (this.errorHandler != null)
        this.errorHandler.handleErrorOnDelete(this, localIOException1, paramString);
      log.error(new StringBuilder().append("++++ exception thrown while writing bytes to server on delete; host:").append(localSockIO.getHost()).toString());
      log.error(localIOException1.getMessage(), localIOException1);
      try
      {
        localSockIO.trueClose();
      }
      catch (IOException localIOException2)
      {
        log.error(new StringBuilder().append("++++ failed to close socket : ").append(localSockIO.toString()).toString());
      }
      localSockIO = null;
    }
    if (localSockIO != null)
    {
      localSockIO.close();
      localSockIO = null;
    }
    return false;
  }

  private void printSocketPool()
  {
    String[] arrayOfString = this.pool.getServers();
    int i = arrayOfString.length;
    for (int j = 0; j < i; ++j)
    {
      String str = arrayOfString[j];
      log.debug(new StringBuilder().append("server ip and port:").append(str).toString());
    }
  }

  public boolean set(String paramString, Object paramObject)
  {
    return set("set", paramString, paramObject, null, null, this.primitiveAsString);
  }

  public boolean set(String paramString, Object paramObject, Integer paramInteger)
  {
    return set("set", paramString, paramObject, null, paramInteger, this.primitiveAsString);
  }

  public boolean set(String paramString, Object paramObject, Date paramDate)
  {
    if (log.isDebugEnabled())
      printSocketPool();
    return set("set", paramString, paramObject, paramDate, null, this.primitiveAsString);
  }

  public boolean set(String paramString, Object paramObject, Date paramDate, Integer paramInteger)
  {
    return set("set", paramString, paramObject, paramDate, paramInteger, this.primitiveAsString);
  }

  public boolean add(String paramString, Object paramObject)
  {
    return set("add", paramString, paramObject, null, null, this.primitiveAsString);
  }

  public boolean add(String paramString, Object paramObject, Integer paramInteger)
  {
    return set("add", paramString, paramObject, null, paramInteger, this.primitiveAsString);
  }

  public boolean add(String paramString, Object paramObject, Date paramDate)
  {
    return set("add", paramString, paramObject, paramDate, null, this.primitiveAsString);
  }

  public boolean add(String paramString, Object paramObject, Date paramDate, Integer paramInteger)
  {
    return set("add", paramString, paramObject, paramDate, paramInteger, this.primitiveAsString);
  }

  public boolean replace(String paramString, Object paramObject)
  {
    return set("replace", paramString, paramObject, null, null, this.primitiveAsString);
  }

  public boolean replace(String paramString, Object paramObject, Integer paramInteger)
  {
    return set("replace", paramString, paramObject, null, paramInteger, this.primitiveAsString);
  }

  public boolean replace(String paramString, Object paramObject, Date paramDate)
  {
    return set("replace", paramString, paramObject, paramDate, null, this.primitiveAsString);
  }

  public boolean replace(String paramString, Object paramObject, Date paramDate, Integer paramInteger)
  {
    return set("replace", paramString, paramObject, paramDate, paramInteger, this.primitiveAsString);
  }

  private boolean set(String paramString1, String paramString2, Object paramObject, Date paramDate, Integer paramInteger, boolean paramBoolean)
  {
    byte[] arrayOfByte;
    Object localObject1;
    Object localObject2;
    if ((paramString1 == null) || (paramString1.trim().equals("")) || (paramString2 == null))
    {
      log.error("key is null or cmd is null/empty for set()");
      return false;
    }
    try
    {
      paramString2 = sanitizeKey(paramString2);
    }
    catch (UnsupportedEncodingException localUnsupportedEncodingException1)
    {
      if (this.errorHandler != null)
        this.errorHandler.handleErrorOnSet(this, localUnsupportedEncodingException1, paramString2);
      log.error("failed to sanitize your key!", localUnsupportedEncodingException1);
      return false;
    }
    if (paramObject == null)
    {
      log.error("trying to store a null value to cache");
      return false;
    }
    SockIOPool.SockIO localSockIO = this.pool.getSock(paramString2, paramInteger);
    if (localSockIO == null)
    {
      if (this.errorHandler != null)
        this.errorHandler.handleErrorOnSet(this, new IOException("no socket to server available"), paramString2);
      return false;
    }
    if (paramDate == null)
      paramDate = new Date(-6318800901427429376L);
    if ((paramDate.getTime() / 1000L > 2592000L) && (paramDate.getTime() < System.currentTimeMillis() - 3600000L))
      paramDate = new Date(-1702967296L);
    int i = 0;
    int j = 0;
    if (NativeHandler.isHandled(paramObject))
    {
      if (paramBoolean)
        try
        {
          if (log.isInfoEnabled())
            log.info(new StringBuilder().append("++++ storing data as a string for key: ").append(paramString2).append(" for class: ").append(paramObject.getClass().getName()).toString());
          arrayOfByte = paramObject.toString().getBytes(this.defaultEncoding);
        }
        catch (UnsupportedEncodingException localUnsupportedEncodingException2)
        {
          if (this.errorHandler != null)
            this.errorHandler.handleErrorOnSet(this, localUnsupportedEncodingException2, paramString2);
          log.error(new StringBuilder().append("invalid encoding type used: ").append(this.defaultEncoding).toString(), localUnsupportedEncodingException2);
          localSockIO.close();
          localSockIO = null;
          return false;
        }
      try
      {
        if (log.isInfoEnabled())
          log.info("Storing with native handler...");
        i |= NativeHandler.getMarkerFlag(paramObject);
        arrayOfByte = NativeHandler.encode(paramObject);
      }
      catch (Exception localException1)
      {
        if (this.errorHandler != null)
          this.errorHandler.handleErrorOnSet(this, localException1, paramString2);
        log.error("Failed to native handle obj", localException1);
        localSockIO.close();
        localSockIO = null;
        return false;
      }
      j = arrayOfByte.length;
    }
    else
    {
      localObject1 = null;
      localObject2 = null;
      try
      {
        if (log.isInfoEnabled())
          log.info(new StringBuilder().append("++++ serializing for key: ").append(paramString2).append(" for class: ").append(paramObject.getClass().getName()).toString());
        localObject1 = new ByteArrayOutputStream();
        if (this.JDK)
        {
          new ObjectOutputStream((OutputStream)localObject1).writeObject(paramObject);
          i |= 32768;
        }
        else
        {
          localObject2 = new HedwigHessianOutput((OutputStream)localObject1);
          ((HedwigHessianOutput)localObject2).writeObject(paramObject);
          ((HedwigHessianOutput)localObject2).close();
        }
        arrayOfByte = ((ByteArrayOutputStream)localObject1).toByteArray();
        j = arrayOfByte.length;
        i |= 8;
        localObject2 = null;
      }
      catch (IOException localIOException4)
      {
        if (this.errorHandler != null)
          this.errorHandler.handleErrorOnSet(this, localIOException4, paramString2);
        log.error(new StringBuilder().append("failed to serialize obj; host:").append(localSockIO.getHost()).toString(), localIOException4);
        log.error(paramObject.toString());
        localSockIO.close();
        localSockIO = null;
        int k = 0;
        return k;
      }
      finally
      {
        try
        {
          if (localObject1 != null)
          {
            ((ByteArrayOutputStream)localObject1).close();
            localObject1 = null;
          }
          if (localObject2 != null)
          {
            ((HedwigHessianOutput)localObject2).close();
            localObject2 = null;
          }
        }
        catch (IOException localIOException9)
        {
          localIOException9.printStackTrace();
        }
      }
    }
    if ((this.compressEnable) && (arrayOfByte.length > this.compressThreshold))
    {
      localObject1 = null;
      localObject2 = null;
      try
      {
        if (log.isInfoEnabled())
          log.info("++++ trying to compress data");
        log.info(new StringBuilder().append("++++ size prior to compression: ").append(arrayOfByte.length).toString());
        localObject2 = new ByteArrayOutputStream(arrayOfByte.length);
        localObject1 = new GZIPOutputStream((OutputStream)localObject2);
        ((GZIPOutputStream)localObject1).write(arrayOfByte, 0, arrayOfByte.length);
        ((GZIPOutputStream)localObject1).finish();
        arrayOfByte = ((ByteArrayOutputStream)localObject2).toByteArray();
        i |= 2;
        j = arrayOfByte.length;
        if (log.isInfoEnabled())
          log.info(new StringBuilder().append("++++ compression succeeded, size after: ").append(arrayOfByte.length).toString());
      }
      catch (IOException localIOException7)
      {
        if (this.errorHandler != null)
          this.errorHandler.handleErrorOnSet(this, localIOException6, paramString2);
        log.error(new StringBuilder().append("IOException while compressing stream: ").append(localIOException6.getMessage()).toString());
        log.error("storing data uncompressed");
      }
      finally
      {
        try
        {
          if (localObject2 != null)
          {
            ((ByteArrayOutputStream)localObject2).close();
            localObject2 = null;
          }
          if (localObject1 != null)
          {
            ((GZIPOutputStream)localObject1).close();
            localObject1 = null;
          }
        }
        catch (IOException localIOException10)
        {
          localIOException10.printStackTrace();
        }
      }
    }
    if (j > this.maxValueSize)
      log.error("value too long, key: " + paramString2 + " length:" + j);
    try
    {
      localObject1 = new String("");
      localObject2 = String.format("%s %s %d %d %d%s\r\n", new Object[] { paramString1, paramString2, Integer.valueOf(i), java.lang.Long.valueOf(paramDate.getTime() / 1000L), Integer.valueOf(arrayOfByte.length), localObject1 });
      localSockIO.write(((String)localObject2).getBytes());
      localSockIO.write(arrayOfByte);
      localSockIO.write("\r\n".getBytes());
      localSockIO.flush();
      if (!(this.pool.getNoreply()))
      {
        String str = localSockIO.readLine();
        if (log.isInfoEnabled())
          log.info(new StringBuilder().append("++++ memcache cmd (result code): ").append((String)localObject2).append(" (").append(str).append(")").toString());
        if ("STORED".equals(str))
        {
          if (log.isInfoEnabled())
            log.info(new StringBuilder().append("++++ data successfully stored for key: ").append(paramString2).toString());
          localSockIO.close();
          localSockIO = null;
          return true;
        }
        if ("NOT_STORED".equals(str))
        {
          if (log.isInfoEnabled())
            log.info(new StringBuilder().append("++++ data not stored in cache for key: ").append(paramString2).toString());
        }
        else
        {
          log.error(new StringBuilder().append("++++ error storing data in cache for key: ").append(paramString2).append(" -- length: ").append(arrayOfByte.length).toString());
          log.error(new StringBuilder().append("++++ server response: ").append(str).toString());
          try
          {
            Object localObject3 = getObject(cacheInRequestKey(this.poolName, "putFailTimes"));
            if (localObject3 == null)
            {
              setObject(cacheInRequestKey(this.poolName, "putFailTimes"), java.lang.Long.valueOf(-6318798324447051775L), 86400L);
              setObject(cacheInRequestKey(this.poolName, "putFailDate"), new Date(), 86400L);
              sendToDetector(localSockIO.getHost(), str, new StringBuilder().append("poolName :").append(this.poolName).append("   ++++ error storing data in cache key: ").append(paramString2).append(" -- length: ").append(arrayOfByte.length).toString());
            }
            else
            {
              incrNumber(cacheInRequestKey(this.poolName, "putFailTimes"), -6318799114721034239L);
              Object localObject4 = getObject(cacheInRequestKey(this.poolName, "putFailTimes"));
              long l1 = ((java.lang.Long)localObject4).longValue();
              Object localObject7 = getObject(cacheInRequestKey(this.poolName, "putFailDate"));
              long l2 = ((Date)localObject7).getTime();
              if ((l1 > 10000L) || (new Date().getTime() - l2 > this.sendEmailInterval * 60 * 1000))
              {
                sendToDetector(localSockIO.getHost(), str, new StringBuilder().append("poolName :").append(this.poolName).append("   ++++ storing data times = ").append(l1).append(" in ").append(this.sendEmailInterval).append("min or less than ").append(this.sendEmailInterval).append("min and recent key: ").append(paramString2).append(" -- length: ").append(arrayOfByte.length).toString());
                setObject(cacheInRequestKey(this.poolName, "putFailTimes"), java.lang.Long.valueOf(-6318797723151630335L), 86400L);
                setObject(cacheInRequestKey(this.poolName, "putFailDate"), new Date(), 86400L);
              }
            }
          }
          catch (Exception localException2)
          {
            log.error(new StringBuilder().append("++++ put cache error: ").append(localException2.getMessage()).toString(), localException2);
          }
        }
      }
      else
      {
        log.info(new StringBuilder().append("++++ use noreply to set for key: ").append(paramString2).toString());
        localSockIO.discardInput();
        localSockIO.close();
        localSockIO = null;
        return true;
      }
    }
    catch (IOException localIOException1)
    {
      if (this.errorHandler != null)
        this.errorHandler.handleErrorOnSet(this, localIOException1, paramString2);
      log.error(new StringBuilder().append("++++ exception thrown while writing bytes to server on set; host:").append(localSockIO.getHost()).toString());
      log.error(localIOException1.getMessage(), localIOException1);
      try
      {
        localSockIO.trueClose();
      }
      catch (IOException localIOException2)
      {
        log.error(new StringBuilder().append("++++ failed to close socket : ").append(localSockIO.toString()).toString());
      }
      localSockIO = null;
    }
    if (localSockIO != null)
    {
      localSockIO.close();
      localSockIO = null;
    }
    return false;
  }

  public boolean storeCounter(String paramString, long paramLong, Date paramDate)
  {
    return set("set", paramString, new java.lang.Long(paramLong), paramDate, null, true);
  }

  public boolean storeCounter(String paramString, long paramLong)
  {
    return set("set", paramString, new java.lang.Long(paramLong), null, null, true);
  }

  public boolean storeCounter(String paramString, java.lang.Long paramLong)
  {
    return set("set", paramString, paramLong, null, null, true);
  }

  public boolean storeCounter(String paramString, java.lang.Long paramLong, Integer paramInteger)
  {
    return set("set", paramString, paramLong, null, paramInteger, true);
  }

  public long getCounter(String paramString)
  {
    return getCounter(paramString, null);
  }

  public long getCounter(String paramString, Integer paramInteger)
  {
    if (paramString == null)
    {
      log.error("null key for getCounter()");
      return -1L;
    }
    long l = -1L;
    try
    {
      l = java.lang.Long.parseLong(((String)get(paramString, paramInteger, true)).trim());
    }
    catch (Exception localException)
    {
      if (this.errorHandler != null)
        this.errorHandler.handleErrorOnGet(this, localException, paramString);
      if (log.isInfoEnabled())
        log.info(String.format("Failed to parse Long value for key: %s", new Object[] { paramString }));
    }
    return l;
  }

  public long addOrIncr(String paramString)
  {
    return addOrIncr(paramString, -6318801485542981632L, null);
  }

  public long addOrIncr(String paramString, long paramLong)
  {
    return addOrIncr(paramString, paramLong, null);
  }

  public long addOrIncr(String paramString, long paramLong, Integer paramInteger)
  {
    boolean bool = set("add", paramString, new java.lang.Long(paramLong), null, paramInteger, true);
    if (bool)
      return paramLong;
    return incrdecr("incr", paramString, paramLong, paramInteger);
  }

  public long addOrDecr(String paramString)
  {
    return addOrDecr(paramString, -6318801485542981632L, null);
  }

  public long addOrDecr(String paramString, long paramLong)
  {
    return addOrDecr(paramString, paramLong, null);
  }

  public long addOrDecr(String paramString, long paramLong, Integer paramInteger)
  {
    boolean bool = set("add", paramString, new java.lang.Long(paramLong), null, paramInteger, true);
    if (bool)
      return paramLong;
    return incrdecr("decr", paramString, paramLong, paramInteger);
  }

  public long incr(String paramString)
  {
    return incrdecr("incr", paramString, -6318801485542981631L, null);
  }

  public long incr(String paramString, long paramLong)
  {
    return incrdecr("incr", paramString, paramLong, null);
  }

  public long incr(String paramString, long paramLong, Integer paramInteger)
  {
    return incrdecr("incr", paramString, paramLong, paramInteger);
  }

  public long decr(String paramString)
  {
    return incrdecr("decr", paramString, -6318801485542981631L, null);
  }

  public long decr(String paramString, long paramLong)
  {
    return incrdecr("decr", paramString, paramLong, null);
  }

  public long decr(String paramString, long paramLong, Integer paramInteger)
  {
    return incrdecr("decr", paramString, paramLong, paramInteger);
  }

  // ERROR //
  private long incrdecr(String paramString1, String paramString2, long paramLong, Integer paramInteger)
  {
    // Byte code:
    //   0: aload_2
    //   1: ifnonnull +15 -> 16
    //   4: getstatic 5	com/ycache/danga/MemCached/MemCachedClient:log	Lorg/apache/log4j/Logger;
    //   7: ldc 203
    //   9: invokevirtual 28	org/apache/log4j/Logger:error	(Ljava/lang/Object;)V
    //   12: ldc2_w 193
    //   15: lreturn
    //   16: aload_0
    //   17: aload_2
    //   18: invokespecial 29	com/ycache/danga/MemCached/MemCachedClient:sanitizeKey	(Ljava/lang/String;)Ljava/lang/String;
    //   21: astore_2
    //   22: goto +39 -> 61
    //   25: astore 6
    //   27: aload_0
    //   28: getfield 2	com/ycache/danga/MemCached/MemCachedClient:errorHandler	Lcom/ycache/danga/MemCached/ErrorHandler;
    //   31: ifnull +16 -> 47
    //   34: aload_0
    //   35: getfield 2	com/ycache/danga/MemCached/MemCachedClient:errorHandler	Lcom/ycache/danga/MemCached/ErrorHandler;
    //   38: aload_0
    //   39: aload 6
    //   41: aload_2
    //   42: invokeinterface 196 4 0
    //   47: getstatic 5	com/ycache/danga/MemCached/MemCachedClient:log	Lorg/apache/log4j/Logger;
    //   50: ldc 32
    //   52: aload 6
    //   54: invokevirtual 33	org/apache/log4j/Logger:error	(Ljava/lang/Object;Ljava/lang/Throwable;)V
    //   57: ldc2_w 193
    //   60: lreturn
    //   61: aload_0
    //   62: getfield 3	com/ycache/danga/MemCached/MemCachedClient:pool	Lcom/ycache/danga/MemCached/SockIOPool;
    //   65: aload_2
    //   66: aload 5
    //   68: invokevirtual 34	com/ycache/danga/MemCached/SockIOPool:getSock	(Ljava/lang/String;Ljava/lang/Integer;)Lcom/ycache/danga/MemCached/SockIOPool$SockIO;
    //   71: astore 6
    //   73: aload 6
    //   75: ifnonnull +34 -> 109
    //   78: aload_0
    //   79: getfield 2	com/ycache/danga/MemCached/MemCachedClient:errorHandler	Lcom/ycache/danga/MemCached/ErrorHandler;
    //   82: ifnull +23 -> 105
    //   85: aload_0
    //   86: getfield 2	com/ycache/danga/MemCached/MemCachedClient:errorHandler	Lcom/ycache/danga/MemCached/ErrorHandler;
    //   89: aload_0
    //   90: new 35	java/io/IOException
    //   93: dup
    //   94: ldc 36
    //   96: invokespecial 37	java/io/IOException:<init>	(Ljava/lang/String;)V
    //   99: aload_2
    //   100: invokeinterface 113 4 0
    //   105: ldc2_w 193
    //   108: lreturn
    //   109: aload_0
    //   110: getfield 3	com/ycache/danga/MemCached/MemCachedClient:pool	Lcom/ycache/danga/MemCached/SockIOPool;
    //   113: invokevirtual 49	com/ycache/danga/MemCached/SockIOPool:getNoreply	()Z
    //   116: ifeq +15 -> 131
    //   119: new 168	java/lang/String
    //   122: dup
    //   123: ldc 50
    //   125: invokespecial 169	java/lang/String:<init>	(Ljava/lang/String;)V
    //   128: goto +12 -> 140
    //   131: new 168	java/lang/String
    //   134: dup
    //   135: ldc 111
    //   137: invokespecial 169	java/lang/String:<init>	(Ljava/lang/String;)V
    //   140: astore 7
    //   142: ldc 204
    //   144: iconst_4
    //   145: anewarray 171	java/lang/Object
    //   148: dup
    //   149: iconst_0
    //   150: aload_1
    //   151: aastore
    //   152: dup
    //   153: iconst_1
    //   154: aload_2
    //   155: aastore
    //   156: dup
    //   157: iconst_2
    //   158: lload_3
    //   159: invokestatic 70	java/lang/Long:valueOf	(J)Ljava/lang/Long;
    //   162: aastore
    //   163: dup
    //   164: iconst_3
    //   165: aload 7
    //   167: aastore
    //   168: invokestatic 173	java/lang/String:format	(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   171: astore 8
    //   173: getstatic 5	com/ycache/danga/MemCached/MemCachedClient:log	Lorg/apache/log4j/Logger;
    //   176: invokevirtual 106	org/apache/log4j/Logger:isDebugEnabled	()Z
    //   179: ifeq +29 -> 208
    //   182: getstatic 5	com/ycache/danga/MemCached/MemCachedClient:log	Lorg/apache/log4j/Logger;
    //   185: new 38	java/lang/StringBuilder
    //   188: dup
    //   189: invokespecial 42	java/lang/StringBuilder:<init>	()V
    //   192: ldc 205
    //   194: invokevirtual 41	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   197: aload 8
    //   199: invokevirtual 41	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   202: invokevirtual 48	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   205: invokevirtual 103	org/apache/log4j/Logger:debug	(Ljava/lang/Object;)V
    //   208: aload 6
    //   210: aload 8
    //   212: invokevirtual 52	java/lang/String:getBytes	()[B
    //   215: invokevirtual 53	com/ycache/danga/MemCached/SockIOPool$SockIO:write	([B)V
    //   218: aload 6
    //   220: invokevirtual 54	com/ycache/danga/MemCached/SockIOPool$SockIO:flush	()V
    //   223: aload 6
    //   225: invokevirtual 55	com/ycache/danga/MemCached/SockIOPool$SockIO:readLine	()Ljava/lang/String;
    //   228: astore 9
    //   230: aload 9
    //   232: ldc 206
    //   234: invokevirtual 207	java/lang/String:matches	(Ljava/lang/String;)Z
    //   237: ifeq +58 -> 295
    //   240: aload 6
    //   242: invokevirtual 62	com/ycache/danga/MemCached/SockIOPool$SockIO:close	()V
    //   245: aload 9
    //   247: invokestatic 195	java/lang/Long:parseLong	(Ljava/lang/String;)J
    //   250: lreturn
    //   251: astore 10
    //   253: aload_0
    //   254: getfield 2	com/ycache/danga/MemCached/MemCachedClient:errorHandler	Lcom/ycache/danga/MemCached/ErrorHandler;
    //   257: ifnull +16 -> 273
    //   260: aload_0
    //   261: getfield 2	com/ycache/danga/MemCached/MemCachedClient:errorHandler	Lcom/ycache/danga/MemCached/ErrorHandler;
    //   264: aload_0
    //   265: aload 10
    //   267: aload_2
    //   268: invokeinterface 196 4 0
    //   273: getstatic 5	com/ycache/danga/MemCached/MemCachedClient:log	Lorg/apache/log4j/Logger;
    //   276: ldc 197
    //   278: iconst_1
    //   279: anewarray 171	java/lang/Object
    //   282: dup
    //   283: iconst_0
    //   284: aload_2
    //   285: aastore
    //   286: invokestatic 173	java/lang/String:format	(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   289: invokevirtual 28	org/apache/log4j/Logger:error	(Ljava/lang/Object;)V
    //   292: goto +474 -> 766
    //   295: ldc 63
    //   297: aload 9
    //   299: invokevirtual 57	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   302: ifeq +40 -> 342
    //   305: getstatic 5	com/ycache/danga/MemCached/MemCachedClient:log	Lorg/apache/log4j/Logger;
    //   308: invokevirtual 58	org/apache/log4j/Logger:isInfoEnabled	()Z
    //   311: ifeq +455 -> 766
    //   314: getstatic 5	com/ycache/danga/MemCached/MemCachedClient:log	Lorg/apache/log4j/Logger;
    //   317: new 38	java/lang/StringBuilder
    //   320: dup
    //   321: invokespecial 42	java/lang/StringBuilder:<init>	()V
    //   324: ldc 208
    //   326: invokevirtual 41	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   329: aload_2
    //   330: invokevirtual 41	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   333: invokevirtual 48	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   336: invokevirtual 61	org/apache/log4j/Logger:info	(Ljava/lang/Object;)V
    //   339: goto +427 -> 766
    //   342: getstatic 5	com/ycache/danga/MemCached/MemCachedClient:log	Lorg/apache/log4j/Logger;
    //   345: new 38	java/lang/StringBuilder
    //   348: dup
    //   349: invokespecial 42	java/lang/StringBuilder:<init>	()V
    //   352: ldc 209
    //   354: invokevirtual 41	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   357: aload_2
    //   358: invokevirtual 41	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   361: invokevirtual 48	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   364: invokevirtual 28	org/apache/log4j/Logger:error	(Ljava/lang/Object;)V
    //   367: getstatic 5	com/ycache/danga/MemCached/MemCachedClient:log	Lorg/apache/log4j/Logger;
    //   370: new 38	java/lang/StringBuilder
    //   373: dup
    //   374: invokespecial 42	java/lang/StringBuilder:<init>	()V
    //   377: ldc 66
    //   379: invokevirtual 41	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   382: aload 9
    //   384: invokevirtual 41	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   387: invokevirtual 48	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   390: invokevirtual 28	org/apache/log4j/Logger:error	(Ljava/lang/Object;)V
    //   393: aload_0
    //   394: aload_0
    //   395: aload_0
    //   396: getfield 11	com/ycache/danga/MemCached/MemCachedClient:poolName	Ljava/lang/String;
    //   399: ldc 210
    //   401: invokespecial 68	com/ycache/danga/MemCached/MemCachedClient:cacheInRequestKey	(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   404: invokevirtual 69	com/ycache/danga/MemCached/MemCachedClient:getObject	(Ljava/lang/String;)Ljava/lang/Object;
    //   407: astore 10
    //   409: aload 10
    //   411: ifnonnull +93 -> 504
    //   414: aload_0
    //   415: aload_0
    //   416: aload_0
    //   417: getfield 11	com/ycache/danga/MemCached/MemCachedClient:poolName	Ljava/lang/String;
    //   420: ldc 210
    //   422: invokespecial 68	com/ycache/danga/MemCached/MemCachedClient:cacheInRequestKey	(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   425: lconst_1
    //   426: invokestatic 70	java/lang/Long:valueOf	(J)Ljava/lang/Long;
    //   429: ldc2_w 71
    //   432: invokevirtual 73	com/ycache/danga/MemCached/MemCachedClient:setObject	(Ljava/lang/String;Ljava/lang/Object;J)V
    //   435: aload_0
    //   436: aload_0
    //   437: aload_0
    //   438: getfield 11	com/ycache/danga/MemCached/MemCachedClient:poolName	Ljava/lang/String;
    //   441: ldc 211
    //   443: invokespecial 68	com/ycache/danga/MemCached/MemCachedClient:cacheInRequestKey	(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   446: new 75	java/util/Date
    //   449: dup
    //   450: invokespecial 76	java/util/Date:<init>	()V
    //   453: ldc2_w 71
    //   456: invokevirtual 73	com/ycache/danga/MemCached/MemCachedClient:setObject	(Ljava/lang/String;Ljava/lang/Object;J)V
    //   459: aload_0
    //   460: aload 6
    //   462: invokevirtual 77	com/ycache/danga/MemCached/SockIOPool$SockIO:getHost	()Ljava/lang/String;
    //   465: aload 9
    //   467: new 38	java/lang/StringBuilder
    //   470: dup
    //   471: invokespecial 42	java/lang/StringBuilder:<init>	()V
    //   474: ldc 78
    //   476: invokevirtual 41	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   479: aload_0
    //   480: getfield 11	com/ycache/danga/MemCached/MemCachedClient:poolName	Ljava/lang/String;
    //   483: invokevirtual 41	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   486: ldc 212
    //   488: invokevirtual 41	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   491: aload_2
    //   492: invokevirtual 41	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   495: invokevirtual 48	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   498: invokevirtual 80	com/ycache/danga/MemCached/MemCachedClient:sendToDetector	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    //   501: goto +229 -> 730
    //   504: aload_0
    //   505: aload_0
    //   506: aload_0
    //   507: getfield 11	com/ycache/danga/MemCached/MemCachedClient:poolName	Ljava/lang/String;
    //   510: ldc 210
    //   512: invokespecial 68	com/ycache/danga/MemCached/MemCachedClient:cacheInRequestKey	(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   515: lconst_1
    //   516: invokevirtual 81	com/ycache/danga/MemCached/MemCachedClient:incrNumber	(Ljava/lang/String;J)V
    //   519: aload_0
    //   520: aload_0
    //   521: aload_0
    //   522: getfield 11	com/ycache/danga/MemCached/MemCachedClient:poolName	Ljava/lang/String;
    //   525: ldc 210
    //   527: invokespecial 68	com/ycache/danga/MemCached/MemCachedClient:cacheInRequestKey	(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   530: invokevirtual 69	com/ycache/danga/MemCached/MemCachedClient:getObject	(Ljava/lang/String;)Ljava/lang/Object;
    //   533: astore 11
    //   535: aload 11
    //   537: checkcast 82	java/lang/Long
    //   540: invokevirtual 83	java/lang/Long:longValue	()J
    //   543: lstore 12
    //   545: aload_0
    //   546: aload_0
    //   547: aload_0
    //   548: getfield 11	com/ycache/danga/MemCached/MemCachedClient:poolName	Ljava/lang/String;
    //   551: ldc 211
    //   553: invokespecial 68	com/ycache/danga/MemCached/MemCachedClient:cacheInRequestKey	(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   556: invokevirtual 69	com/ycache/danga/MemCached/MemCachedClient:getObject	(Ljava/lang/String;)Ljava/lang/Object;
    //   559: astore 14
    //   561: aload 14
    //   563: checkcast 75	java/util/Date
    //   566: invokevirtual 44	java/util/Date:getTime	()J
    //   569: lstore 15
    //   571: lload 12
    //   573: ldc2_w 84
    //   576: lcmp
    //   577: ifgt +32 -> 609
    //   580: new 75	java/util/Date
    //   583: dup
    //   584: invokespecial 76	java/util/Date:<init>	()V
    //   587: invokevirtual 44	java/util/Date:getTime	()J
    //   590: lload 15
    //   592: lsub
    //   593: aload_0
    //   594: getfield 20	com/ycache/danga/MemCached/MemCachedClient:sendEmailInterval	I
    //   597: bipush 60
    //   599: imul
    //   600: sipush 1000
    //   603: imul
    //   604: i2l
    //   605: lcmp
    //   606: ifle +124 -> 730
    //   609: aload_0
    //   610: aload 6
    //   612: invokevirtual 77	com/ycache/danga/MemCached/SockIOPool$SockIO:getHost	()Ljava/lang/String;
    //   615: aload 9
    //   617: new 38	java/lang/StringBuilder
    //   620: dup
    //   621: invokespecial 42	java/lang/StringBuilder:<init>	()V
    //   624: ldc 78
    //   626: invokevirtual 41	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   629: aload_0
    //   630: getfield 11	com/ycache/danga/MemCached/MemCachedClient:poolName	Ljava/lang/String;
    //   633: invokevirtual 41	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   636: ldc 213
    //   638: invokevirtual 41	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   641: lload 12
    //   643: invokevirtual 47	java/lang/StringBuilder:append	(J)Ljava/lang/StringBuilder;
    //   646: ldc 87
    //   648: invokevirtual 41	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   651: aload_0
    //   652: getfield 20	com/ycache/danga/MemCached/MemCachedClient:sendEmailInterval	I
    //   655: invokevirtual 88	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   658: ldc 89
    //   660: invokevirtual 41	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   663: aload_0
    //   664: getfield 20	com/ycache/danga/MemCached/MemCachedClient:sendEmailInterval	I
    //   667: invokevirtual 88	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   670: ldc 90
    //   672: invokevirtual 41	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   675: aload_2
    //   676: invokevirtual 41	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   679: invokevirtual 48	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   682: invokevirtual 80	com/ycache/danga/MemCached/MemCachedClient:sendToDetector	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    //   685: aload_0
    //   686: aload_0
    //   687: aload_0
    //   688: getfield 11	com/ycache/danga/MemCached/MemCachedClient:poolName	Ljava/lang/String;
    //   691: ldc 210
    //   693: invokespecial 68	com/ycache/danga/MemCached/MemCachedClient:cacheInRequestKey	(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   696: lconst_1
    //   697: invokestatic 70	java/lang/Long:valueOf	(J)Ljava/lang/Long;
    //   700: ldc2_w 71
    //   703: invokevirtual 73	com/ycache/danga/MemCached/MemCachedClient:setObject	(Ljava/lang/String;Ljava/lang/Object;J)V
    //   706: aload_0
    //   707: aload_0
    //   708: aload_0
    //   709: getfield 11	com/ycache/danga/MemCached/MemCachedClient:poolName	Ljava/lang/String;
    //   712: ldc 211
    //   714: invokespecial 68	com/ycache/danga/MemCached/MemCachedClient:cacheInRequestKey	(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   717: new 75	java/util/Date
    //   720: dup
    //   721: invokespecial 76	java/util/Date:<init>	()V
    //   724: ldc2_w 71
    //   727: invokevirtual 73	com/ycache/danga/MemCached/MemCachedClient:setObject	(Ljava/lang/String;Ljava/lang/Object;J)V
    //   730: goto +36 -> 766
    //   733: astore 10
    //   735: getstatic 5	com/ycache/danga/MemCached/MemCachedClient:log	Lorg/apache/log4j/Logger;
    //   738: new 38	java/lang/StringBuilder
    //   741: dup
    //   742: invokespecial 42	java/lang/StringBuilder:<init>	()V
    //   745: ldc 214
    //   747: invokevirtual 41	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   750: aload 10
    //   752: invokevirtual 93	java/lang/Exception:getMessage	()Ljava/lang/String;
    //   755: invokevirtual 41	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   758: invokevirtual 48	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   761: aload 10
    //   763: invokevirtual 33	org/apache/log4j/Logger:error	(Ljava/lang/Object;Ljava/lang/Throwable;)V
    //   766: goto +109 -> 875
    //   769: astore 7
    //   771: aload_0
    //   772: getfield 2	com/ycache/danga/MemCached/MemCachedClient:errorHandler	Lcom/ycache/danga/MemCached/ErrorHandler;
    //   775: ifnull +16 -> 791
    //   778: aload_0
    //   779: getfield 2	com/ycache/danga/MemCached/MemCachedClient:errorHandler	Lcom/ycache/danga/MemCached/ErrorHandler;
    //   782: aload_0
    //   783: aload 7
    //   785: aload_2
    //   786: invokeinterface 196 4 0
    //   791: getstatic 5	com/ycache/danga/MemCached/MemCachedClient:log	Lorg/apache/log4j/Logger;
    //   794: new 38	java/lang/StringBuilder
    //   797: dup
    //   798: invokespecial 42	java/lang/StringBuilder:<init>	()V
    //   801: ldc 215
    //   803: invokevirtual 41	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   806: aload 6
    //   808: invokevirtual 77	com/ycache/danga/MemCached/SockIOPool$SockIO:getHost	()Ljava/lang/String;
    //   811: invokevirtual 41	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   814: invokevirtual 48	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   817: invokevirtual 28	org/apache/log4j/Logger:error	(Ljava/lang/Object;)V
    //   820: getstatic 5	com/ycache/danga/MemCached/MemCachedClient:log	Lorg/apache/log4j/Logger;
    //   823: aload 7
    //   825: invokevirtual 97	java/io/IOException:getMessage	()Ljava/lang/String;
    //   828: aload 7
    //   830: invokevirtual 33	org/apache/log4j/Logger:error	(Ljava/lang/Object;Ljava/lang/Throwable;)V
    //   833: aload 6
    //   835: invokevirtual 98	com/ycache/danga/MemCached/SockIOPool$SockIO:trueClose	()V
    //   838: goto +34 -> 872
    //   841: astore 8
    //   843: getstatic 5	com/ycache/danga/MemCached/MemCachedClient:log	Lorg/apache/log4j/Logger;
    //   846: new 38	java/lang/StringBuilder
    //   849: dup
    //   850: invokespecial 42	java/lang/StringBuilder:<init>	()V
    //   853: ldc 99
    //   855: invokevirtual 41	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   858: aload 6
    //   860: invokevirtual 100	com/ycache/danga/MemCached/SockIOPool$SockIO:toString	()Ljava/lang/String;
    //   863: invokevirtual 41	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   866: invokevirtual 48	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   869: invokevirtual 28	org/apache/log4j/Logger:error	(Ljava/lang/Object;)V
    //   872: aconst_null
    //   873: astore 6
    //   875: aload 6
    //   877: ifnull +11 -> 888
    //   880: aload 6
    //   882: invokevirtual 62	com/ycache/danga/MemCached/SockIOPool$SockIO:close	()V
    //   885: aconst_null
    //   886: astore 6
    //   888: ldc2_w 193
    //   891: lreturn
    //
    // Exception table:
    //   from	to	target	type
    //   16	22	25	java/io/UnsupportedEncodingException
    //   245	250	251	java/lang/Exception
    //   393	730	733	java/lang/Exception
    //   109	250	769	java/io/IOException
    //   251	766	769	java/io/IOException
    //   833	838	841	java/io/IOException
  }

  public Object get(String paramString)
  {
    if (log.isDebugEnabled())
      printSocketPool();
    return get(paramString, null, false);
  }

  public Object get(String paramString, Integer paramInteger)
  {
    return get(paramString, paramInteger, false);
  }

  public Object get(String paramString, Integer paramInteger, boolean paramBoolean)
  {
    if (paramString == null)
    {
      log.error("key is null for get()");
      return null;
    }
    try
    {
      paramString = sanitizeKey(paramString);
    }
    catch (UnsupportedEncodingException localUnsupportedEncodingException)
    {
      if (this.errorHandler != null)
        this.errorHandler.handleErrorOnGet(this, localUnsupportedEncodingException, paramString);
      log.error("failed to sanitize your key!", localUnsupportedEncodingException);
      return null;
    }
    SockIOPool.SockIO localSockIO = this.pool.getSock(paramString, paramInteger);
    if (localSockIO == null)
    {
      if (this.errorHandler != null)
        this.errorHandler.handleErrorOnGet(this, new IOException("no socket to server available"), paramString);
      return null;
    }
    try
    {
      String str1 = new StringBuilder().append("get ").append(paramString).append("\r\n").toString();
      if (log.isDebugEnabled())
        log.debug(new StringBuilder().append("++++ memcache get command: ").append(str1).toString());
      localSockIO.write(str1.getBytes());
      localSockIO.flush();
      Object localObject1 = null;
      while (true)
      {
        String str2 = localSockIO.readLine();
        if (log.isDebugEnabled())
          log.debug(new StringBuilder().append("++++ line: ").append(str2).toString());
        if (str2.startsWith("VALUE"))
        {
          Object localObject3;
          String[] arrayOfString = str2.split(" ");
          int i = Integer.parseInt(arrayOfString[2]);
          int j = Integer.parseInt(arrayOfString[3]);
          if (log.isDebugEnabled())
          {
            log.debug(new StringBuilder().append("++++ key: ").append(paramString).toString());
            log.debug(new StringBuilder().append("++++ flags: ").append(i).toString());
            log.debug(new StringBuilder().append("++++ length: ").append(j).toString());
          }
          byte[] arrayOfByte1 = new byte[j];
          localSockIO.read(arrayOfByte1);
          localSockIO.clearEOL();
          if ((i & 0x2) == 2)
            try
            {
              GZIPInputStream localGZIPInputStream = new GZIPInputStream(new ByteArrayInputStream(arrayOfByte1));
              localObject3 = new ByteArrayOutputStream(arrayOfByte1.length);
              byte[] arrayOfByte2 = new byte[2048];
              while ((k = localGZIPInputStream.read(arrayOfByte2)) != -1)
              {
                int k;
                ((ByteArrayOutputStream)localObject3).write(arrayOfByte2, 0, k);
              }
              arrayOfByte1 = ((ByteArrayOutputStream)localObject3).toByteArray();
              localGZIPInputStream.close();
              localGZIPInputStream = null;
            }
            catch (IOException localIOException3)
            {
              if (this.errorHandler != null)
                this.errorHandler.handleErrorOnGet(this, localIOException3, paramString);
              log.error(new StringBuilder().append("++++ IOException thrown while trying to uncompress input stream for key: ").append(paramString).append(" -- ").append(localIOException3.getMessage()).toString());
              throw new NestedIOException(new StringBuilder().append("++++ IOException thrown while trying to uncompress input stream for key: ").append(paramString).toString(), localIOException3);
            }
          if ((i & 0x8) != 8)
          {
            if ((this.primitiveAsString) || (paramBoolean))
            {
              if (log.isInfoEnabled())
                log.info("++++ retrieving object and stuffing into a string.");
              localObject1 = new String(arrayOfByte1, this.defaultEncoding);
              break label851:
            }
            try
            {
              localObject1 = NativeHandler.decode(arrayOfByte1, i);
            }
            catch (Exception localException1)
            {
              if (this.errorHandler != null)
                this.errorHandler.handleErrorOnGet(this, localException1, paramString);
              log.error(new StringBuilder().append("++++ Exception thrown while trying to deserialize for key: ").append(paramString).toString(), localException1);
              throw new NestedIOException(localException1);
            }
          }
          try
          {
            Object localObject2;
            if ((i & 0x8000) == 32768)
            {
              localObject2 = new ContextObjectInputStream(new ByteArrayInputStream(arrayOfByte1), this.classLoader);
              localObject1 = ((ContextObjectInputStream)localObject2).readObject();
            }
            else
            {
              localObject2 = new ByteArrayInputStream(arrayOfByte1);
              localObject3 = new HedwigHessianInput((InputStream)localObject2);
              localObject1 = ((HedwigHessianInput)localObject3).readObject();
              ((HedwigHessianInput)localObject3).close();
            }
            label851: if (log.isInfoEnabled())
              log.info(new StringBuilder().append("++++ deserializing ").append(((Object)localObject1).getClass()).toString());
          }
          catch (Exception localException2)
          {
            if (this.errorHandler != null)
              this.errorHandler.handleErrorOnGet(this, localException2, paramString);
            localObject1 = null;
            log.error(new StringBuilder().append("++++ Exception thrown while trying to deserialize for key: ").append(paramString).append(" -- ").append(localException2.getMessage()).toString());
          }
        }
        else if ("END".equals(str2))
        {
          if (!(log.isDebugEnabled()))
            break;
          log.debug("++++ finished reading from cache server");
          break;
        }
      }
      localSockIO.close();
      localSockIO = null;
      return localObject1;
    }
    catch (IOException localIOException1)
    {
      if (this.errorHandler != null)
        this.errorHandler.handleErrorOnGet(this, localIOException1, paramString);
      log.error(new StringBuilder().append("++++ exception thrown while trying to get object from cache for key: ").append(paramString).append("; host:").append(localSockIO.getHost()).append(" -- ").append(localIOException1.getMessage()).toString(), localIOException1);
      try
      {
        localSockIO.trueClose();
      }
      catch (IOException localIOException2)
      {
        log.error(new StringBuilder().append("++++ failed to close socket : ").append(localSockIO.toString()).toString());
      }
      localSockIO = null;
      if (localSockIO != null)
        localSockIO.close();
    }
    return null;
  }

  public Object[] getMultiArray(String[] paramArrayOfString)
  {
    return getMultiArray(paramArrayOfString, null, false);
  }

  public Object[] getMultiArray(String[] paramArrayOfString, Integer[] paramArrayOfInteger)
  {
    return getMultiArray(paramArrayOfString, paramArrayOfInteger, false);
  }

  public Object[] getMultiArray(String[] paramArrayOfString, Integer[] paramArrayOfInteger, boolean paramBoolean)
  {
    java.util.Map localMap = getMulti(paramArrayOfString, paramArrayOfInteger, paramBoolean);
    if (localMap == null)
      return null;
    Object[] arrayOfObject = new Object[paramArrayOfString.length];
    for (int i = 0; i < paramArrayOfString.length; ++i)
      arrayOfObject[i] = localMap.get(paramArrayOfString[i]);
    return arrayOfObject;
  }

  public java.util.Map<String, Object> getMulti(String[] paramArrayOfString)
  {
    return getMulti(paramArrayOfString, null, false);
  }

  public java.util.Map<String, Object> getMulti(String[] paramArrayOfString, Integer[] paramArrayOfInteger)
  {
    return getMulti(paramArrayOfString, paramArrayOfInteger, false);
  }

  public java.util.Map<String, Object> getMulti(String[] paramArrayOfString, Integer[] paramArrayOfInteger, boolean paramBoolean)
  {
    SockIOPool.SockIO localSockIO;
    if ((paramArrayOfString == null) || (paramArrayOfString.length == 0))
    {
      log.error("missing keys for getMulti()");
      return null;
    }
    HashMap localHashMap1 = new HashMap();
    for (int i = 0; i < paramArrayOfString.length; ++i)
    {
      localObject1 = paramArrayOfString[i];
      if (localObject1 == null)
      {
        log.error("null key, so skipping");
      }
      else
      {
        Integer localInteger = null;
        if ((paramArrayOfInteger != null) && (paramArrayOfInteger.length > i))
          localInteger = paramArrayOfInteger[i];
        Object localObject2 = localObject1;
        try
        {
          localObject2 = sanitizeKey((String)localObject1);
        }
        catch (UnsupportedEncodingException localUnsupportedEncodingException1)
        {
          if (this.errorHandler != null)
            this.errorHandler.handleErrorOnGet(this, localUnsupportedEncodingException1, (String)localObject1);
          log.error("failed to sanitize your key!", localUnsupportedEncodingException1);
          break label267:
        }
        localSockIO = this.pool.getSock((String)localObject2, localInteger);
        if (localSockIO == null)
        {
          if (this.errorHandler != null)
            this.errorHandler.handleErrorOnGet(this, new IOException("no socket to server available"), (String)localObject1);
        }
        else
        {
          if (!(localHashMap1.containsKey(localSockIO.getHost())))
            localHashMap1.put(localSockIO.getHost(), new StringBuilder("get"));
          ((StringBuilder)localHashMap1.get(localSockIO.getHost())).append(new StringBuilder().append(" ").append((String)localObject2).toString());
          localSockIO.close();
          label267: localSockIO = null;
        }
      }
    }
    if (log.isInfoEnabled())
      log.info(new StringBuilder().append("multi get socket count : ").append(localHashMap1.size()).toString());
    HashMap localHashMap2 = new HashMap(paramArrayOfString.length);
    new NIOLoader(this, this).doMulti(paramBoolean, localHashMap1, paramArrayOfString, localHashMap2);
    Object localObject1 = paramArrayOfString;
    int j = localObject1.length;
    for (int k = 0; k < j; ++k)
    {
      localSockIO = localObject1[k];
      Object localObject3 = localSockIO;
      try
      {
        localObject3 = sanitizeKey(localSockIO);
      }
      catch (UnsupportedEncodingException localUnsupportedEncodingException2)
      {
        if (this.errorHandler != null)
          this.errorHandler.handleErrorOnGet(this, localUnsupportedEncodingException2, localSockIO);
        log.error("failed to sanitize your key!", localUnsupportedEncodingException2);
        break label493:
      }
      if ((!(localSockIO.equals(localObject3))) && (localHashMap2.containsKey(localObject3)))
      {
        localHashMap2.put(localSockIO, localHashMap2.get(localObject3));
        localHashMap2.remove(localObject3);
      }
      label493: if (!(localHashMap2.containsKey(localSockIO)))
        localHashMap2.put(localSockIO, null);
    }
    if (log.isDebugEnabled())
      log.debug(new StringBuilder().append("++++ memcache: got back ").append(localHashMap2.size()).append(" results").toString());
    return ((java.util.Map<String, Object>)(java.util.Map<String, Object>)(java.util.Map<String, Object>)localHashMap2);
  }

  private void loadMulti(LineInputStream paramLineInputStream, java.util.Map<String, Object> paramMap, boolean paramBoolean)
    throws IOException
  {
    while (true)
    {
      String str1 = paramLineInputStream.readLine();
      if (log.isDebugEnabled())
        log.debug(new StringBuilder().append("++++ line: ").append(str1).toString());
      if (str1.startsWith("VALUE"))
      {
        Object localObject1;
        Object localObject3;
        String[] arrayOfString = str1.split(" ");
        String str2 = arrayOfString[1];
        int i = Integer.parseInt(arrayOfString[2]);
        int j = Integer.parseInt(arrayOfString[3]);
        if (log.isDebugEnabled())
        {
          log.debug(new StringBuilder().append("++++ key: ").append(str2).toString());
          log.debug(new StringBuilder().append("++++ flags: ").append(i).toString());
          log.debug(new StringBuilder().append("++++ length: ").append(j).toString());
        }
        byte[] arrayOfByte1 = new byte[j];
        paramLineInputStream.read(arrayOfByte1);
        paramLineInputStream.clearEOL();
        if ((i & 0x2) == 2)
          try
          {
            GZIPInputStream localGZIPInputStream = new GZIPInputStream(new ByteArrayInputStream(arrayOfByte1));
            localObject3 = new ByteArrayOutputStream(arrayOfByte1.length);
            byte[] arrayOfByte2 = new byte[2048];
            while ((k = localGZIPInputStream.read(arrayOfByte2)) != -1)
            {
              int k;
              ((ByteArrayOutputStream)localObject3).write(arrayOfByte2, 0, k);
            }
            arrayOfByte1 = ((ByteArrayOutputStream)localObject3).toByteArray();
            localGZIPInputStream.close();
            localGZIPInputStream = null;
          }
          catch (IOException localIOException)
          {
            if (this.errorHandler != null)
              this.errorHandler.handleErrorOnGet(this, localIOException, str2);
            log.error(new StringBuilder().append("++++ IOException thrown while trying to uncompress input stream for key: ").append(str2).append(" -- ").append(localIOException.getMessage()).toString());
            throw new NestedIOException(new StringBuilder().append("++++ IOException thrown while trying to uncompress input stream for key: ").append(str2).toString(), localIOException);
          }
        if ((i & 0x8) != 8)
        {
          if ((this.primitiveAsString) || (paramBoolean))
          {
            if (log.isInfoEnabled())
              log.info("++++ retrieving object and stuffing into a string.");
            localObject1 = new String(arrayOfByte1, this.defaultEncoding);
            break label768:
          }
          try
          {
            localObject1 = NativeHandler.decode(arrayOfByte1, i);
          }
          catch (Exception localException)
          {
            if (this.errorHandler != null)
              this.errorHandler.handleErrorOnGet(this, localException, str2);
            log.error(new StringBuilder().append("++++ Exception thrown while trying to deserialize for key: ").append(str2).append(" -- ").append(localException.getMessage()).toString());
            throw new NestedIOException(localException);
          }
        }
        try
        {
          Object localObject2;
          if ((i & 0x8000) == 32768)
          {
            localObject2 = new ContextObjectInputStream(new ByteArrayInputStream(arrayOfByte1), this.classLoader);
            localObject1 = ((ContextObjectInputStream)localObject2).readObject();
          }
          else
          {
            localObject2 = new ByteArrayInputStream(arrayOfByte1);
            localObject3 = new HedwigHessianInput((InputStream)localObject2);
            localObject1 = ((HedwigHessianInput)localObject3).readObject();
            ((HedwigHessianInput)localObject3).close();
          }
          if (log.isInfoEnabled())
            log.info(new StringBuilder().append("++++ deserializing ").append(((Object)localObject1).getClass()).toString());
        }
        catch (InvalidClassException localInvalidClassException)
        {
          if (this.errorHandler != null)
            this.errorHandler.handleErrorOnGet(this, localInvalidClassException, str2);
          localObject1 = null;
          log.error(new StringBuilder().append("++++ InvalidClassException thrown while trying to deserialize for key: ").append(str2).append(" -- ").append(localInvalidClassException.getMessage()).toString());
        }
        catch (ClassNotFoundException localClassNotFoundException)
        {
          if (this.errorHandler != null)
            this.errorHandler.handleErrorOnGet(this, localClassNotFoundException, str2);
          localObject1 = null;
          log.error(new StringBuilder().append("++++ ClassNotFoundException thrown while trying to deserialize for key: ").append(str2).append(" -- ").append(localClassNotFoundException.getMessage()).toString());
        }
        if (localObject1 != null)
          label768: paramMap.put(str2, localObject1);
      }
      else if ("END".equals(str1))
      {
        if (!(log.isDebugEnabled()))
          return;
        log.debug("++++ finished reading from cache server");
        return;
      }
    }
  }

  private String sanitizeKey(String paramString)
    throws UnsupportedEncodingException
  {
    return ((this.sanitizeKeys) ? URLEncoder.encode(paramString, "UTF-8") : paramString);
  }

  public boolean flushAll()
  {
    return flushAll(null);
  }

  public boolean flushAll(String[] paramArrayOfString)
  {
    if (this.pool == null)
    {
      log.error("++++ unable to get SockIOPool instance");
      return false;
    }
    paramArrayOfString = (paramArrayOfString == null) ? this.pool.getServers() : paramArrayOfString;
    if ((paramArrayOfString == null) || (paramArrayOfString.length <= 0))
    {
      log.error("++++ no servers to flush");
      return false;
    }
    int i = 1;
    for (int j = 0; j < paramArrayOfString.length; ++j)
    {
      SockIOPool.SockIO localSockIO = this.pool.getConnection(paramArrayOfString[j]);
      if (localSockIO == null)
      {
        log.error(new StringBuilder().append("++++ unable to get connection to : ").append(paramArrayOfString[j]).toString());
        i = 0;
        if (this.errorHandler != null)
          this.errorHandler.handleErrorOnFlush(this, new IOException("no socket to server available"));
      }
      else
      {
        String str1 = "flush_all\r\n";
        try
        {
          localSockIO.write(str1.getBytes());
          localSockIO.flush();
          String str2 = localSockIO.readLine();
          i = ("OK".equals(str2)) ? 0 : (i != 0) ? 1 : 0;
        }
        catch (IOException localIOException1)
        {
          if (this.errorHandler != null)
            this.errorHandler.handleErrorOnFlush(this, localIOException1);
          log.error(new StringBuilder().append("++++ exception thrown while writing bytes to server on flushAll; host:").append(localSockIO.getHost()).toString());
          log.error(localIOException1.getMessage(), localIOException1);
          try
          {
            localSockIO.trueClose();
          }
          catch (IOException localIOException2)
          {
            log.error(new StringBuilder().append("++++ failed to close socket : ").append(localSockIO.toString()).toString());
          }
          i = 0;
          localSockIO = null;
        }
        if (localSockIO != null)
        {
          localSockIO.close();
          localSockIO = null;
        }
      }
    }
    return i;
  }

  public java.util.Map stats()
  {
    return stats(null);
  }

  public java.util.Map stats(String[] paramArrayOfString)
  {
    return stats(paramArrayOfString, "stats\r\n", "STAT");
  }

  public java.util.Map statsItems()
  {
    return statsItems(null);
  }

  public java.util.Map statsItems(String[] paramArrayOfString)
  {
    return stats(paramArrayOfString, "stats items\r\n", "STAT");
  }

  public java.util.Map statsSlabs()
  {
    return statsSlabs(null);
  }

  public java.util.Map statsSlabs(String[] paramArrayOfString)
  {
    return stats(paramArrayOfString, "stats slabs\r\n", "STAT");
  }

  public java.util.Map statsCacheDump(int paramInt1, int paramInt2)
  {
    return statsCacheDump(null, paramInt1, paramInt2);
  }

  public java.util.Map statsCacheDump(String[] paramArrayOfString, int paramInt1, int paramInt2)
  {
    return stats(paramArrayOfString, String.format("stats cachedump %d %d\r\n", new Object[] { Integer.valueOf(paramInt1), Integer.valueOf(paramInt2) }), "ITEM");
  }

  private java.util.Map stats(String[] paramArrayOfString, String paramString1, String paramString2)
  {
    if ((paramString1 == null) || (paramString1.trim().equals("")))
    {
      log.error("++++ invalid / missing command for stats()");
      return null;
    }
    paramArrayOfString = (paramArrayOfString == null) ? this.pool.getServers() : paramArrayOfString;
    if ((paramArrayOfString == null) || (paramArrayOfString.length <= 0))
    {
      log.error("++++ no servers to check stats");
      return null;
    }
    HashMap localHashMap1 = new HashMap();
    for (int i = 0; i < paramArrayOfString.length; ++i)
    {
      SockIOPool.SockIO localSockIO = this.pool.getConnection(paramArrayOfString[i]);
      if (localSockIO == null)
      {
        log.error(new StringBuilder().append("++++ unable to get connection to : ").append(paramArrayOfString[i]).toString());
        if (this.errorHandler != null)
          this.errorHandler.handleErrorOnStats(this, new IOException("no socket to server available"));
      }
      else
      {
        try
        {
          localSockIO.write(paramString1.getBytes());
          localSockIO.flush();
          HashMap localHashMap2 = new HashMap();
          while (true)
          {
            Object localObject1;
            Object localObject2;
            String str1 = localSockIO.readLine();
            if (log.isDebugEnabled())
              log.debug(new StringBuilder().append("++++ line: ").append(str1).toString());
            if (str1.startsWith(paramString2))
            {
              localObject1 = str1.split(" ", 3);
              localObject2 = localObject1[1];
              String str2 = localObject1[2];
              if (log.isDebugEnabled())
              {
                log.debug(new StringBuilder().append("++++ key  : ").append((String)localObject2).toString());
                log.debug(new StringBuilder().append("++++ value: ").append(str2).toString());
              }
              localHashMap2.put(localObject2, str2);
            }
            else
            {
              if ("END".equals(str1))
              {
                if (!(log.isDebugEnabled()))
                  break;
                log.debug("++++ finished reading from cache server");
                break;
              }
              if ((str1.startsWith("ERROR")) || (str1.startsWith("CLIENT_ERROR")) || (str1.startsWith("SERVER_ERROR")))
              {
                log.error("++++ failed to query stats");
                log.error(new StringBuilder().append("++++ server response: ").append(str1).toString());
                try
                {
                  localObject1 = getObject(cacheInRequestKey(this.poolName, "statFailTimes"));
                  if (localObject1 == null)
                  {
                    setObject(cacheInRequestKey(this.poolName, "statFailTimes"), java.lang.Long.valueOf(-6318796915697778687L), 86400L);
                    setObject(cacheInRequestKey(this.poolName, "statFailDate"), new Date(), 86400L);
                    sendToDetector(localSockIO.getHost(), str1, new StringBuilder().append("poolName :").append(this.poolName).append("   ++++ failed to query stats").toString());
                  }
                  else
                  {
                    incrNumber(cacheInRequestKey(this.poolName, "statFailTimes"), -6318797705971761151L);
                    localObject2 = getObject(cacheInRequestKey(this.poolName, "statFailTimes"));
                    long l1 = ((java.lang.Long)localObject2).longValue();
                    Object localObject3 = getObject(cacheInRequestKey(this.poolName, "statFailDate"));
                    long l2 = ((Date)localObject3).getTime();
                    if ((l1 > 10000L) || (new Date().getTime() - l2 > this.sendEmailInterval * 60 * 1000))
                    {
                      sendToDetector(localSockIO.getHost(), str1, new StringBuilder().append("poolName :").append(this.poolName).append("   ++++ failed to query stats times = ").append(l1).append(" in ").append(this.sendEmailInterval).append("min or less than ").append(this.sendEmailInterval).append("min").toString());
                      setObject(cacheInRequestKey(this.poolName, "statFailTimes"), java.lang.Long.valueOf(-6318813906588401663L), 86400L);
                      setObject(cacheInRequestKey(this.poolName, "statFailDate"), new Date(), 86400L);
                    }
                  }
                }
                catch (Exception localException)
                {
                  log.error(new StringBuilder().append("++++ stat cache error: ").append(localException.getMessage()).toString(), localException);
                }
                break;
              }
            }
            localHashMap1.put(paramArrayOfString[i], localHashMap2);
          }
        }
        catch (IOException localIOException1)
        {
          if (this.errorHandler != null)
            this.errorHandler.handleErrorOnStats(this, localIOException1);
          log.error(new StringBuilder().append("++++ exception thrown while writing bytes to server on stats; host:").append(localSockIO.getHost()).toString());
          log.error(localIOException1.getMessage(), localIOException1);
          try
          {
            localSockIO.trueClose();
          }
          catch (IOException localIOException2)
          {
            log.error(new StringBuilder().append("++++ failed to close socket : ").append(localSockIO.toString()).toString());
          }
          localSockIO = null;
        }
        if (localSockIO != null)
        {
          localSockIO.close();
          localSockIO = null;
        }
      }
    }
    return ((java.util.Map)(java.util.Map)localHashMap1);
  }

  public void sendToDetector(String paramString1, String paramString2, String paramString3)
  {
    YcacheAnalyse localYcacheAnalyse = new YcacheAnalyse();
    if ((paramString1 != null) && (paramString1.split(":").length > 0))
    {
      localYcacheAnalyse.setCacheHost(paramString1.split(":")[0]);
      localYcacheAnalyse.setCachePort(Integer.valueOf(Integer.parseInt(paramString1.split(":")[1])));
    }
    else
    {
      localYcacheAnalyse.setCacheHost("no sock host");
      localYcacheAnalyse.setCachePort(Integer.valueOf(0));
    }
    localYcacheAnalyse.setCacheGroup(this.poolName);
    localYcacheAnalyse.setMemo(paramString2);
    localYcacheAnalyse.setExtInfo(paramString3);
    localYcacheAnalyse.setAppCode(appCode);
    localYcacheAnalyse.setAppHost(appHost);
    localYcacheAnalyse.setIntervalTime(Integer.valueOf(60));
    Date localDate = new Date();
    localYcacheAnalyse.setGmtCreate(localDate);
    localYcacheAnalyse.setEndTime(localDate);
    localYcacheAnalyse.setStartTime(localDate);
    MonitorJmsSendUtil.sendMessageAwait(localYcacheAnalyse, "ycachequeue");
  }

  private String cacheInRequestKey(String paramString1, String paramString2)
  {
    return new StringBuilder().append(paramString1).append("_").append(paramString2).toString();
  }

  public synchronized void incrNumber(String paramString, long paramLong)
  {
    StatsLocalCache localStatsLocalCache = StatsLocalCacheManager.getContent(paramString);
    if (localStatsLocalCache != null)
    {
      java.lang.Long localLong = (java.lang.Long)localStatsLocalCache.getValue();
      localLong = java.lang.Long.valueOf(localLong.longValue() + paramLong);
      localStatsLocalCache.setValue(localLong);
    }
  }

  public synchronized Object getObject(String paramString)
    throws Exception
  {
    StatsLocalCache localStatsLocalCache = StatsLocalCacheManager.getContent(paramString);
    if (localStatsLocalCache != null)
      return localStatsLocalCache.getValue();
    return null;
  }

  public synchronized void setObject(String paramString, Object paramObject, long paramLong)
    throws Exception
  {
    StatsLocalCacheManager.putContent(paramString, paramObject, paramLong * 1000L);
  }

  protected final class NIOLoader
  {
    protected Selector selector;
    protected int numConns = 0;
    protected MemCachedClient mc;
    protected Connection[] conns;

    public NIOLoader(, MemCachedClient paramMemCachedClient2)
    {
      this.mc = paramMemCachedClient2;
    }

    public void doMulti(, java.util.Map<String, StringBuilder> paramMap, String[] paramArrayOfString, java.util.Map<String, Object> paramMap1)
    {
      Object localObject1;
      long l1 = -6318801451183243264L;
      try
      {
        int i2;
        Iterator localIterator2;
        this.selector = Selector.open();
        this.conns = new Connection[paramMap.keySet().size()];
        this.numConns = 0;
        Iterator localIterator1 = paramMap.keySet().iterator();
        while (localIterator1.hasNext())
        {
          String str = (String)localIterator1.next();
          SockIOPool.SockIO localSockIO = MemCachedClient.access$200(this.this$0).getConnection(str);
          if (localSockIO == null)
          {
            if (MemCachedClient.access$300(this.this$0) != null)
              MemCachedClient.access$000().error("get connection error. host=" + str);
            MemCachedClient.access$300(this.this$0).handleErrorOnGet(this.mc, new IOException("no socket to server available"), paramArrayOfString);
            return;
          }
          this.conns[(this.numConns++)] = new Connection(this, localSockIO, (StringBuilder)paramMap.get(str));
        }
        long l2 = System.currentTimeMillis();
        long l3 = Math.min(MemCachedClient.access$200(this.this$0).getMaxBusy(), 5000L);
        l1 = l3;
        int i1 = this.numConns;
        while ((this.numConns > 0) && (l1 > -6318801227844943872L))
        {
          i2 = this.selector.select(l1);
          if (i2 > 0)
          {
            localIterator2 = this.selector.selectedKeys().iterator();
            while (localIterator2.hasNext())
            {
              SelectionKey localSelectionKey = (SelectionKey)localIterator2.next();
              localIterator2.remove();
              handleKey(localSelectionKey);
            }
          }
          else
          {
            MemCachedClient.access$000().error("selector return 0, maybe timeout. maxConns=" + i1 + " curConns=" + this.numConns + " startTime=" + l2 + " curTime=" + System.currentTimeMillis() + " timeout=" + l3);
          }
          l1 = l3 - System.currentTimeMillis() - l2;
        }
      }
      catch (IOException localIOException2)
      {
        Connection[] arrayOfConnection1;
        int i;
        Connection[] arrayOfConnection3;
        int l;
        Connection localConnection2;
        handleError(localIOException2, paramArrayOfString);
        return;
      }
      finally
      {
        if (MemCachedClient.access$000().isDebugEnabled())
          MemCachedClient.access$000().debug("Disconnecting; numConns=" + this.numConns + "  timeRemaining=" + l1);
        try
        {
          if (this.selector != null)
            this.selector.close();
        }
        catch (IOException localIOException5)
        {
        }
        Connection[] arrayOfConnection4 = this.conns;
        int i3 = arrayOfConnection4.length;
        for (int i4 = 0; i4 < i3; ++i4)
        {
          Connection localConnection3 = arrayOfConnection4[i4];
          if (localConnection3 != null)
            localConnection3.close();
        }
      }
      Connection[] arrayOfConnection2 = this.conns;
      int j = arrayOfConnection2.length;
      for (int k = 0; k < j; ++k)
      {
        Connection localConnection1 = arrayOfConnection2[k];
        try
        {
          if ((localConnection1.incoming.size() > 0) && (localConnection1.isDone()))
            MemCachedClient.access$400(this.this$0, new ByteBufArrayInputStream(localConnection1.incoming), paramMap1, paramBoolean);
        }
        catch (Exception localException)
        {
          MemCachedClient.access$000().warn("Caught the aforementioned exception on " + localConnection1);
        }
      }
    }

    private void handleError(, String[] paramArrayOfString)
    {
      if (MemCachedClient.access$300(this.this$0) != null)
        MemCachedClient.access$300(this.this$0).handleErrorOnGet(this.this$0, paramThrowable, paramArrayOfString);
      MemCachedClient.access$000().error("++++ exception thrown while getting from cache on getMulti");
      MemCachedClient.access$000().error(paramThrowable.getMessage());
    }

    private void handleKey()
      throws IOException
    {
      if (MemCachedClient.access$000().isDebugEnabled())
        MemCachedClient.access$000().debug("handling selector op " + paramSelectionKey.readyOps() + " for key " + paramSelectionKey);
      if (paramSelectionKey.isReadable())
        readResponse(paramSelectionKey);
      else if (paramSelectionKey.isWritable())
        writeRequest(paramSelectionKey);
    }

    public void writeRequest()
      throws IOException
    {
      ByteBuffer localByteBuffer = ((Connection)paramSelectionKey.attachment()).outgoing;
      SocketChannel localSocketChannel = (SocketChannel)paramSelectionKey.channel();
      if (localByteBuffer.hasRemaining())
      {
        if (MemCachedClient.access$000().isDebugEnabled())
          MemCachedClient.access$000().debug("writing " + localByteBuffer.remaining() + "B to " + ((SocketChannel)paramSelectionKey.channel()).socket().getInetAddress());
        localSocketChannel.write(localByteBuffer);
      }
      if (!(localByteBuffer.hasRemaining()))
      {
        if (MemCachedClient.access$000().isDebugEnabled())
          MemCachedClient.access$000().debug("switching to read mode for server " + ((SocketChannel)paramSelectionKey.channel()).socket().getInetAddress());
        paramSelectionKey.interestOps(1);
      }
    }

    public void readResponse()
      throws IOException
    {
      Connection localConnection = (Connection)paramSelectionKey.attachment();
      ByteBuffer localByteBuffer = localConnection.getBuffer();
      int i = localConnection.channel.read(localByteBuffer);
      if (i > 0)
      {
        if (MemCachedClient.access$000().isDebugEnabled())
          MemCachedClient.access$000().debug("read  " + i + " from " + localConnection.channel.socket().getInetAddress());
        if (localConnection.isDone())
        {
          if (MemCachedClient.access$000().isDebugEnabled())
            MemCachedClient.access$000().debug("connection done to  " + localConnection.channel.socket().getInetAddress());
          paramSelectionKey.cancel();
          this.numConns -= 1;
          return;
        }
      }
    }

    private final class Connection
    {
      public List<ByteBuffer> incoming = new ArrayList();
      public ByteBuffer outgoing;
      public SockIOPool.SockIO sock;
      public SocketChannel channel;
      private boolean isDone = false;

      public Connection(, SockIOPool.SockIO paramSockIO, StringBuilder paramStringBuilder)
        throws IOException
      {
        if (MemCachedClient.access$000().isDebugEnabled())
          MemCachedClient.access$000().debug(new StringBuilder().append("setting up connection to ").append(paramSockIO.getHost()).toString());
        this.sock = paramSockIO;
        this.outgoing = ByteBuffer.wrap(paramStringBuilder.append("\r\n").toString().getBytes());
        this.channel = paramSockIO.getChannel();
        if (this.channel == null)
          throw new IOException(new StringBuilder().append("dead connection to: ").append(paramSockIO.getHost()).toString());
        this.channel.configureBlocking(false);
        this.channel.register(paramNIOLoader.selector, 4, this);
      }

      public void close()
      {
        try
        {
          if (this.isDone)
          {
            if (MemCachedClient.access$000().isDebugEnabled())
              MemCachedClient.access$000().debug(new StringBuilder().append("++++ gracefully closing connection to ").append(this.sock.getHost()).toString());
            this.channel.configureBlocking(true);
            this.sock.close();
            return;
          }
        }
        catch (IOException localIOException1)
        {
          MemCachedClient.access$000().warn("++++ memcache: unexpected error closing normally");
        }
        try
        {
          if (MemCachedClient.access$000().isDebugEnabled())
            MemCachedClient.access$000().debug(new StringBuilder().append("forcefully closing connection to ").append(this.sock.getHost()).toString());
          this.channel.close();
          this.sock.trueClose();
        }
        catch (IOException localIOException2)
        {
        }
      }

      public boolean isDone()
      {
        if (this.isDone)
          return true;
        int i = MemCachedClient.access$100().length - 1;
        for (int j = this.incoming.size() - 1; (j >= 0) && (i >= 0); --j)
        {
          ByteBuffer localByteBuffer = (ByteBuffer)this.incoming.get(j);
          int k = localByteBuffer.position() - 1;
          do
            if ((k < 0) || (i < 0))
              break label89;
          while (localByteBuffer.get(k--) == MemCachedClient.access$100()[(i--)]);
          label89: return false;
        }
        this.isDone = (i < 0);
        return this.isDone;
      }

      public ByteBuffer getBuffer()
      {
        int i = this.incoming.size() - 1;
        if ((i >= 0) && (((ByteBuffer)this.incoming.get(i)).hasRemaining()))
          return ((ByteBuffer)this.incoming.get(i));
        ByteBuffer localByteBuffer = ByteBuffer.allocate(8192);
        this.incoming.add(localByteBuffer);
        return localByteBuffer;
      }

      public String toString()
      {
        return new StringBuilder().append("Connection to ").append(this.sock.getHost()).append(" with ").append(this.incoming.size()).append(" bufs; done is ").append(this.isDone).toString();
      }
    }
  }
}