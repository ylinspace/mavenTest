package com.ycache.redis.clients.util;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class JedisByteHashMap
  implements Map<byte[], byte[]>, Cloneable, Serializable
{
  private static final long serialVersionUID = -6971431362627219416L;
  private Map<ByteArrayWrapper, byte[]> internalMap = new HashMap();

  public void clear()
  {
    this.internalMap.clear();
  }

  public boolean containsKey(Object paramObject)
  {
    if (paramObject instanceof byte[])
      return this.internalMap.containsKey(new ByteArrayWrapper((byte[])(byte[])paramObject));
    return this.internalMap.containsKey(paramObject);
  }

  public boolean containsValue(Object paramObject)
  {
    return this.internalMap.containsValue(paramObject);
  }

  public Set<Map.Entry<byte[], byte[]>> entrySet()
  {
    Iterator localIterator = this.internalMap.entrySet().iterator();
    HashSet localHashSet = new HashSet();
    while (localIterator.hasNext())
    {
      Map.Entry localEntry = (Map.Entry)localIterator.next();
      localHashSet.add(new JedisByteEntry(ByteArrayWrapper.access$000((ByteArrayWrapper)localEntry.getKey()), (byte[])localEntry.getValue()));
    }
    return localHashSet;
  }

  public byte[] get(Object paramObject)
  {
    if (paramObject instanceof byte[])
      return ((byte[])this.internalMap.get(new ByteArrayWrapper((byte[])(byte[])paramObject)));
    return ((byte[])this.internalMap.get(paramObject));
  }

  public boolean isEmpty()
  {
    return this.internalMap.isEmpty();
  }

  public Set<byte[]> keySet()
  {
    HashSet localHashSet = new HashSet();
    Iterator localIterator = this.internalMap.keySet().iterator();
    while (localIterator.hasNext())
      localHashSet.add(ByteArrayWrapper.access$000((ByteArrayWrapper)localIterator.next()));
    return localHashSet;
  }

  public byte[] put(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    return ((byte[])this.internalMap.put(new ByteArrayWrapper(paramArrayOfByte1), paramArrayOfByte2));
  }

  public void putAll(Map<? extends byte[], ? extends byte[]> paramMap)
  {
    Iterator localIterator = paramMap.entrySet().iterator();
    while (localIterator.hasNext())
    {
      Map.Entry localEntry = (Map.Entry)localIterator.next();
      this.internalMap.put(new ByteArrayWrapper((byte[])localEntry.getKey()), localEntry.getValue());
    }
  }

  public byte[] remove(Object paramObject)
  {
    if (paramObject instanceof byte[])
      return ((byte[])this.internalMap.remove(new ByteArrayWrapper((byte[])(byte[])paramObject)));
    return ((byte[])this.internalMap.remove(paramObject));
  }

  public int size()
  {
    return this.internalMap.size();
  }

  public Collection<byte[]> values()
  {
    return this.internalMap.values();
  }

  private static final class JedisByteEntry
  implements Map.Entry<byte[], byte[]>
  {
    private byte[] value;
    private byte[] key;

    public JedisByteEntry(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
    {
      this.key = paramArrayOfByte1;
      this.value = paramArrayOfByte2;
    }

    public byte[] getKey()
    {
      return this.key;
    }

    public byte[] getValue()
    {
      return this.value;
    }

    public byte[] setValue(byte[] paramArrayOfByte)
    {
      this.value = paramArrayOfByte;
      return paramArrayOfByte;
    }
  }

  private static final class ByteArrayWrapper
  {
    private final byte[] data;

    public ByteArrayWrapper(byte[] paramArrayOfByte)
    {
      if (paramArrayOfByte == null)
        throw new NullPointerException();
      this.data = paramArrayOfByte;
    }

    public boolean equals(Object paramObject)
    {
      if (!(paramObject instanceof ByteArrayWrapper))
        return false;
      return Arrays.equals(this.data, ((ByteArrayWrapper)paramObject).data);
    }

    public int hashCode()
    {
      return Arrays.hashCode(this.data);
    }
  }
}