package com.ycache.redis.clients.util;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Slowlog
{
  private final long id;
  private final long timeStamp;
  private final long executionTime;
  private final List<String> args;

  public static List<Slowlog> from(List<Object> paramList)
  {
    ArrayList localArrayList = new ArrayList(paramList.size());
    Iterator localIterator = paramList.iterator();
    while (localIterator.hasNext())
    {
      Object localObject = localIterator.next();
      List localList = (List)localObject;
      localArrayList.add(new Slowlog(localList));
    }
    return localArrayList;
  }

  private Slowlog(List<Object> paramList)
  {
    this.id = ((Long)paramList.get(0)).longValue();
    this.timeStamp = ((Long)paramList.get(1)).longValue();
    this.executionTime = ((Long)paramList.get(2)).longValue();
    List localList = (List)paramList.get(3);
    this.args = new ArrayList(localList.size());
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      byte[] arrayOfByte = (byte[])localIterator.next();
      this.args.add(SafeEncoder.encode(arrayOfByte));
    }
  }

  public long getId()
  {
    return this.id;
  }

  public long getTimeStamp()
  {
    return this.timeStamp;
  }

  public long getExecutionTime()
  {
    return this.executionTime;
  }

  public List<String> getArgs()
  {
    return this.args;
  }
}