package com.ycache.redis.clients.jedis;

import java.util.List;
import java.util.Set;

public abstract interface MultiKeyCommands
{
  public abstract Long del(String[] paramArrayOfString);

  public abstract List<String> blpop(int paramInt, String[] paramArrayOfString);

  public abstract List<String> brpop(int paramInt, String[] paramArrayOfString);

  public abstract List<String> blpop(String[] paramArrayOfString);

  public abstract List<String> brpop(String[] paramArrayOfString);

  public abstract Set<String> keys(String paramString);

  public abstract List<String> mget(String[] paramArrayOfString);

  public abstract String mset(String[] paramArrayOfString);

  public abstract Long msetnx(String[] paramArrayOfString);

  public abstract String rename(String paramString1, String paramString2);

  public abstract Long renamenx(String paramString1, String paramString2);

  public abstract String rpoplpush(String paramString1, String paramString2);

  public abstract Set<String> sdiff(String[] paramArrayOfString);

  public abstract Long sdiffstore(String paramString, String[] paramArrayOfString);

  public abstract Set<String> sinter(String[] paramArrayOfString);

  public abstract Long sinterstore(String paramString, String[] paramArrayOfString);

  public abstract Long smove(String paramString1, String paramString2, String paramString3);

  public abstract Long sort(String paramString1, SortingParams paramSortingParams, String paramString2);

  public abstract Long sort(String paramString1, String paramString2);

  public abstract Set<String> sunion(String[] paramArrayOfString);

  public abstract Long sunionstore(String paramString, String[] paramArrayOfString);

  public abstract String watch(String[] paramArrayOfString);

  public abstract String unwatch();

  public abstract Long zinterstore(String paramString, String[] paramArrayOfString);

  public abstract Long zinterstore(String paramString, ZParams paramZParams, String[] paramArrayOfString);

  public abstract Long zunionstore(String paramString, String[] paramArrayOfString);

  public abstract Long zunionstore(String paramString, ZParams paramZParams, String[] paramArrayOfString);

  public abstract String brpoplpush(String paramString1, String paramString2, int paramInt);

  public abstract Long publish(String paramString1, String paramString2);

  public abstract void subscribe(JedisPubSub paramJedisPubSub, String[] paramArrayOfString);

  public abstract void psubscribe(JedisPubSub paramJedisPubSub, String[] paramArrayOfString);

  public abstract String randomKey();

  public abstract Long bitop(BitOP paramBitOP, String paramString, String[] paramArrayOfString);
}