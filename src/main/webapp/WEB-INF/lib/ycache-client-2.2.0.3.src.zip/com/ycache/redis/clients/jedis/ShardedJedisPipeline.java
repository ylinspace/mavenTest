package com.ycache.redis.clients.jedis;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

public class ShardedJedisPipeline extends PipelineBase
{
  private BinaryShardedJedis jedis;
  private List<FutureResult> results = new ArrayList();
  private Queue<Client> clients = new LinkedList();

  public void setShardedJedis(BinaryShardedJedis paramBinaryShardedJedis)
  {
    this.jedis = paramBinaryShardedJedis;
  }

  public List<Object> getResults()
  {
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator = this.results.iterator();
    while (localIterator.hasNext())
    {
      FutureResult localFutureResult = (FutureResult)localIterator.next();
      localArrayList.add(localFutureResult.get());
    }
    return localArrayList;
  }

  public void sync()
  {
    Iterator localIterator = this.clients.iterator();
    while (localIterator.hasNext())
    {
      Client localClient = (Client)localIterator.next();
      generateResponse(localClient.getOne());
    }
  }

  public List<Object> syncAndReturnAll()
  {
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator = this.clients.iterator();
    while (localIterator.hasNext())
    {
      Client localClient = (Client)localIterator.next();
      localArrayList.add(generateResponse(localClient.getOne()).get());
    }
    return localArrayList;
  }

  @Deprecated
  public void execute()
  {
  }

  protected Client getClient(String paramString)
  {
    Client localClient = ((Jedis)this.jedis.getShard(paramString)).getClient();
    this.clients.add(localClient);
    this.results.add(new FutureResult(localClient));
    return localClient;
  }

  protected Client getClient(byte[] paramArrayOfByte)
  {
    Client localClient = ((Jedis)this.jedis.getShard(paramArrayOfByte)).getClient();
    this.clients.add(localClient);
    this.results.add(new FutureResult(localClient));
    return localClient;
  }

  private static class FutureResult
  {
    private Client client;

    public FutureResult(Client paramClient)
    {
      this.client = paramClient;
    }

    public Object get()
    {
      return this.client.getOne();
    }
  }
}