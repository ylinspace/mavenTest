package com.ycache.redis.clients.jedis;

public abstract class JedisMonitor
{
  protected Client client;

  public void proceed(Client paramClient)
  {
    this.client = paramClient;
    this.client.setTimeoutInfinite();
    do
    {
      String str = paramClient.getBulkReply();
      onCommand(str);
    }
    while (paramClient.isConnected());
  }

  public abstract void onCommand(String paramString);
}