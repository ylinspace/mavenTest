package com.ycache.redis.clients.jedis;

import [B;
import com.ycache.redis.clients.jedis.exceptions.JedisDataException;
import com.ycache.redis.clients.jedis.exceptions.JedisException;
import com.ycache.redis.clients.util.JedisByteHashMap;
import com.ycache.redis.clients.util.SafeEncoder;
import java.net.URI;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.List<[B>;
import java.util.Map;
import java.util.Set;

public class BinaryJedis
  implements BasicCommands, BinaryJedisCommands, MultiKeyBinaryCommands, AdvancedBinaryJedisCommands, BinaryScriptingCommands
{
  protected Client client = null;

  public BinaryJedis(String paramString)
  {
    URI localURI = URI.create(paramString);
    if ((localURI.getScheme() != null) && (localURI.getScheme().equals("redis")))
    {
      this.client = new Client(localURI.getHost(), localURI.getPort());
      this.client.auth(localURI.getUserInfo().split(":", 2)[1]);
      this.client.getStatusCodeReply();
      this.client.select(Integer.parseInt(localURI.getPath().split("/", 2)[1]));
      this.client.getStatusCodeReply();
    }
    else
    {
      this.client = new Client(paramString);
    }
  }

  public BinaryJedis(String paramString, int paramInt)
  {
    this.client = new Client(paramString, paramInt);
  }

  public BinaryJedis(String paramString, int paramInt1, int paramInt2)
  {
    this.client = new Client(paramString, paramInt1);
    this.client.setTimeout(paramInt2);
  }

  public BinaryJedis(JedisShardInfo paramJedisShardInfo)
  {
    this.client = new Client(paramJedisShardInfo.getHost(), paramJedisShardInfo.getPort());
    this.client.setTimeout(paramJedisShardInfo.getTimeout());
    this.client.setPassword(paramJedisShardInfo.getPassword());
  }

  public BinaryJedis(URI paramURI)
  {
    this.client = new Client(paramURI.getHost(), paramURI.getPort());
    this.client.auth(paramURI.getUserInfo().split(":", 2)[1]);
    this.client.getStatusCodeReply();
    this.client.select(Integer.parseInt(paramURI.getPath().split("/", 2)[1]));
    this.client.getStatusCodeReply();
  }

  public String ping()
  {
    checkIsInMulti();
    this.client.ping();
    return this.client.getStatusCodeReply();
  }

  public String set(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    checkIsInMulti();
    this.client.set(paramArrayOfByte1, paramArrayOfByte2);
    return this.client.getStatusCodeReply();
  }

  public String set(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3, byte[] paramArrayOfByte4, long paramLong)
  {
    checkIsInMulti();
    this.client.set(paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3, paramArrayOfByte4, paramLong);
    return this.client.getStatusCodeReply();
  }

  public byte[] get(byte[] paramArrayOfByte)
  {
    checkIsInMulti();
    this.client.get(paramArrayOfByte);
    return this.client.getBinaryBulkReply();
  }

  public String quit()
  {
    checkIsInMulti();
    this.client.quit();
    return this.client.getStatusCodeReply();
  }

  public Boolean exists(byte[] paramArrayOfByte)
  {
    checkIsInMulti();
    this.client.exists(paramArrayOfByte);
    return Boolean.valueOf(this.client.getIntegerReply().longValue() == -6318801176305336319L);
  }

  public Long del(byte[][] paramArrayOfByte)
  {
    checkIsInMulti();
    this.client.del(paramArrayOfByte);
    return this.client.getIntegerReply();
  }

  public Long del(byte[] paramArrayOfByte)
  {
    checkIsInMulti();
    this.client.del(new byte[][] { paramArrayOfByte });
    return this.client.getIntegerReply();
  }

  public String type(byte[] paramArrayOfByte)
  {
    checkIsInMulti();
    this.client.type(paramArrayOfByte);
    return this.client.getStatusCodeReply();
  }

  public String flushDB()
  {
    checkIsInMulti();
    this.client.flushDB();
    return this.client.getStatusCodeReply();
  }

  public Set<byte[]> keys(byte[] paramArrayOfByte)
  {
    checkIsInMulti();
    this.client.keys(paramArrayOfByte);
    HashSet localHashSet = new HashSet(this.client.getBinaryMultiBulkReply());
    return localHashSet;
  }

  public byte[] randomBinaryKey()
  {
    checkIsInMulti();
    this.client.randomKey();
    return this.client.getBinaryBulkReply();
  }

  public String rename(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    checkIsInMulti();
    this.client.rename(paramArrayOfByte1, paramArrayOfByte2);
    return this.client.getStatusCodeReply();
  }

  public Long renamenx(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    checkIsInMulti();
    this.client.renamenx(paramArrayOfByte1, paramArrayOfByte2);
    return this.client.getIntegerReply();
  }

  public Long dbSize()
  {
    checkIsInMulti();
    this.client.dbSize();
    return this.client.getIntegerReply();
  }

  public Long expire(byte[] paramArrayOfByte, int paramInt)
  {
    checkIsInMulti();
    this.client.expire(paramArrayOfByte, paramInt);
    return this.client.getIntegerReply();
  }

  public Long expireAt(byte[] paramArrayOfByte, long paramLong)
  {
    checkIsInMulti();
    this.client.expireAt(paramArrayOfByte, paramLong);
    return this.client.getIntegerReply();
  }

  public Long ttl(byte[] paramArrayOfByte)
  {
    checkIsInMulti();
    this.client.ttl(paramArrayOfByte);
    return this.client.getIntegerReply();
  }

  public String select(int paramInt)
  {
    checkIsInMulti();
    this.client.select(paramInt);
    return this.client.getStatusCodeReply();
  }

  public Long move(byte[] paramArrayOfByte, int paramInt)
  {
    checkIsInMulti();
    this.client.move(paramArrayOfByte, paramInt);
    return this.client.getIntegerReply();
  }

  public String flushAll()
  {
    checkIsInMulti();
    this.client.flushAll();
    return this.client.getStatusCodeReply();
  }

  public byte[] getSet(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    checkIsInMulti();
    this.client.getSet(paramArrayOfByte1, paramArrayOfByte2);
    return this.client.getBinaryBulkReply();
  }

  public List<byte[]> mget(byte[][] paramArrayOfByte)
  {
    checkIsInMulti();
    this.client.mget(paramArrayOfByte);
    return this.client.getBinaryMultiBulkReply();
  }

  public Long setnx(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    checkIsInMulti();
    this.client.setnx(paramArrayOfByte1, paramArrayOfByte2);
    return this.client.getIntegerReply();
  }

  public String setex(byte[] paramArrayOfByte1, int paramInt, byte[] paramArrayOfByte2)
  {
    checkIsInMulti();
    this.client.setex(paramArrayOfByte1, paramInt, paramArrayOfByte2);
    return this.client.getStatusCodeReply();
  }

  public String mset(byte[][] paramArrayOfByte)
  {
    checkIsInMulti();
    this.client.mset(paramArrayOfByte);
    return this.client.getStatusCodeReply();
  }

  public Long msetnx(byte[][] paramArrayOfByte)
  {
    checkIsInMulti();
    this.client.msetnx(paramArrayOfByte);
    return this.client.getIntegerReply();
  }

  public Long decrBy(byte[] paramArrayOfByte, long paramLong)
  {
    checkIsInMulti();
    this.client.decrBy(paramArrayOfByte, paramLong);
    return this.client.getIntegerReply();
  }

  public Long decr(byte[] paramArrayOfByte)
  {
    checkIsInMulti();
    this.client.decr(paramArrayOfByte);
    return this.client.getIntegerReply();
  }

  public Long incrBy(byte[] paramArrayOfByte, long paramLong)
  {
    checkIsInMulti();
    this.client.incrBy(paramArrayOfByte, paramLong);
    return this.client.getIntegerReply();
  }

  public Long incr(byte[] paramArrayOfByte)
  {
    checkIsInMulti();
    this.client.incr(paramArrayOfByte);
    return this.client.getIntegerReply();
  }

  public Long append(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    checkIsInMulti();
    this.client.append(paramArrayOfByte1, paramArrayOfByte2);
    return this.client.getIntegerReply();
  }

  public byte[] substr(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    checkIsInMulti();
    this.client.substr(paramArrayOfByte, paramInt1, paramInt2);
    return this.client.getBinaryBulkReply();
  }

  public Long hset(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
  {
    checkIsInMulti();
    this.client.hset(paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3);
    return this.client.getIntegerReply();
  }

  public byte[] hget(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    checkIsInMulti();
    this.client.hget(paramArrayOfByte1, paramArrayOfByte2);
    return this.client.getBinaryBulkReply();
  }

  public Long hsetnx(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
  {
    checkIsInMulti();
    this.client.hsetnx(paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3);
    return this.client.getIntegerReply();
  }

  public String hmset(byte[] paramArrayOfByte, Map<byte[], byte[]> paramMap)
  {
    checkIsInMulti();
    this.client.hmset(paramArrayOfByte, paramMap);
    return this.client.getStatusCodeReply();
  }

  public List<byte[]> hmget(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1)
  {
    checkIsInMulti();
    this.client.hmget(paramArrayOfByte, paramArrayOfByte1);
    return this.client.getBinaryMultiBulkReply();
  }

  public Long hincrBy(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, long paramLong)
  {
    checkIsInMulti();
    this.client.hincrBy(paramArrayOfByte1, paramArrayOfByte2, paramLong);
    return this.client.getIntegerReply();
  }

  public Boolean hexists(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    checkIsInMulti();
    this.client.hexists(paramArrayOfByte1, paramArrayOfByte2);
    return Boolean.valueOf(this.client.getIntegerReply().longValue() == -6318801176305336319L);
  }

  public Long hdel(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1)
  {
    checkIsInMulti();
    this.client.hdel(paramArrayOfByte, paramArrayOfByte1);
    return this.client.getIntegerReply();
  }

  public Long hlen(byte[] paramArrayOfByte)
  {
    checkIsInMulti();
    this.client.hlen(paramArrayOfByte);
    return this.client.getIntegerReply();
  }

  public Set<byte[]> hkeys(byte[] paramArrayOfByte)
  {
    checkIsInMulti();
    this.client.hkeys(paramArrayOfByte);
    List localList = this.client.getBinaryMultiBulkReply();
    return new HashSet(localList);
  }

  public List<byte[]> hvals(byte[] paramArrayOfByte)
  {
    checkIsInMulti();
    this.client.hvals(paramArrayOfByte);
    List localList = this.client.getBinaryMultiBulkReply();
    return localList;
  }

  public Map<byte[], byte[]> hgetAll(byte[] paramArrayOfByte)
  {
    checkIsInMulti();
    this.client.hgetAll(paramArrayOfByte);
    List localList = this.client.getBinaryMultiBulkReply();
    JedisByteHashMap localJedisByteHashMap = new JedisByteHashMap();
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
      localJedisByteHashMap.put(localIterator.next(), localIterator.next());
    return localJedisByteHashMap;
  }

  public Long rpush(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1)
  {
    checkIsInMulti();
    this.client.rpush(paramArrayOfByte, paramArrayOfByte1);
    return this.client.getIntegerReply();
  }

  public Long lpush(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1)
  {
    checkIsInMulti();
    this.client.lpush(paramArrayOfByte, paramArrayOfByte1);
    return this.client.getIntegerReply();
  }

  public Long llen(byte[] paramArrayOfByte)
  {
    checkIsInMulti();
    this.client.llen(paramArrayOfByte);
    return this.client.getIntegerReply();
  }

  public List<byte[]> lrange(byte[] paramArrayOfByte, long paramLong1, long paramLong2)
  {
    checkIsInMulti();
    this.client.lrange(paramArrayOfByte, paramLong1, paramLong2);
    return this.client.getBinaryMultiBulkReply();
  }

  public String ltrim(byte[] paramArrayOfByte, long paramLong1, long paramLong2)
  {
    checkIsInMulti();
    this.client.ltrim(paramArrayOfByte, paramLong1, paramLong2);
    return this.client.getStatusCodeReply();
  }

  public byte[] lindex(byte[] paramArrayOfByte, long paramLong)
  {
    checkIsInMulti();
    this.client.lindex(paramArrayOfByte, paramLong);
    return this.client.getBinaryBulkReply();
  }

  public String lset(byte[] paramArrayOfByte1, long paramLong, byte[] paramArrayOfByte2)
  {
    checkIsInMulti();
    this.client.lset(paramArrayOfByte1, paramLong, paramArrayOfByte2);
    return this.client.getStatusCodeReply();
  }

  public Long lrem(byte[] paramArrayOfByte1, long paramLong, byte[] paramArrayOfByte2)
  {
    checkIsInMulti();
    this.client.lrem(paramArrayOfByte1, paramLong, paramArrayOfByte2);
    return this.client.getIntegerReply();
  }

  public byte[] lpop(byte[] paramArrayOfByte)
  {
    checkIsInMulti();
    this.client.lpop(paramArrayOfByte);
    return this.client.getBinaryBulkReply();
  }

  public byte[] rpop(byte[] paramArrayOfByte)
  {
    checkIsInMulti();
    this.client.rpop(paramArrayOfByte);
    return this.client.getBinaryBulkReply();
  }

  public byte[] rpoplpush(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    checkIsInMulti();
    this.client.rpoplpush(paramArrayOfByte1, paramArrayOfByte2);
    return this.client.getBinaryBulkReply();
  }

  public Long sadd(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1)
  {
    checkIsInMulti();
    this.client.sadd(paramArrayOfByte, paramArrayOfByte1);
    return this.client.getIntegerReply();
  }

  public Set<byte[]> smembers(byte[] paramArrayOfByte)
  {
    checkIsInMulti();
    this.client.smembers(paramArrayOfByte);
    List localList = this.client.getBinaryMultiBulkReply();
    return new HashSet(localList);
  }

  public Long srem(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1)
  {
    checkIsInMulti();
    this.client.srem(paramArrayOfByte, paramArrayOfByte1);
    return this.client.getIntegerReply();
  }

  public byte[] spop(byte[] paramArrayOfByte)
  {
    checkIsInMulti();
    this.client.spop(paramArrayOfByte);
    return this.client.getBinaryBulkReply();
  }

  public Long smove(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
  {
    checkIsInMulti();
    this.client.smove(paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3);
    return this.client.getIntegerReply();
  }

  public Long scard(byte[] paramArrayOfByte)
  {
    checkIsInMulti();
    this.client.scard(paramArrayOfByte);
    return this.client.getIntegerReply();
  }

  public Boolean sismember(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    checkIsInMulti();
    this.client.sismember(paramArrayOfByte1, paramArrayOfByte2);
    return Boolean.valueOf(this.client.getIntegerReply().longValue() == -6318801176305336319L);
  }

  public Set<byte[]> sinter(byte[][] paramArrayOfByte)
  {
    checkIsInMulti();
    this.client.sinter(paramArrayOfByte);
    List localList = this.client.getBinaryMultiBulkReply();
    return new HashSet(localList);
  }

  public Long sinterstore(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1)
  {
    checkIsInMulti();
    this.client.sinterstore(paramArrayOfByte, paramArrayOfByte1);
    return this.client.getIntegerReply();
  }

  public Set<byte[]> sunion(byte[][] paramArrayOfByte)
  {
    checkIsInMulti();
    this.client.sunion(paramArrayOfByte);
    List localList = this.client.getBinaryMultiBulkReply();
    return new HashSet(localList);
  }

  public Long sunionstore(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1)
  {
    checkIsInMulti();
    this.client.sunionstore(paramArrayOfByte, paramArrayOfByte1);
    return this.client.getIntegerReply();
  }

  public Set<byte[]> sdiff(byte[][] paramArrayOfByte)
  {
    checkIsInMulti();
    this.client.sdiff(paramArrayOfByte);
    List localList = this.client.getBinaryMultiBulkReply();
    return new HashSet(localList);
  }

  public Long sdiffstore(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1)
  {
    checkIsInMulti();
    this.client.sdiffstore(paramArrayOfByte, paramArrayOfByte1);
    return this.client.getIntegerReply();
  }

  public byte[] srandmember(byte[] paramArrayOfByte)
  {
    checkIsInMulti();
    this.client.srandmember(paramArrayOfByte);
    return this.client.getBinaryBulkReply();
  }

  public List<byte[]> srandmember(byte[] paramArrayOfByte, int paramInt)
  {
    checkIsInMulti();
    this.client.srandmember(paramArrayOfByte, paramInt);
    return this.client.getBinaryMultiBulkReply();
  }

  public Long zadd(byte[] paramArrayOfByte1, double paramDouble, byte[] paramArrayOfByte2)
  {
    checkIsInMulti();
    this.client.zadd(paramArrayOfByte1, paramDouble, paramArrayOfByte2);
    return this.client.getIntegerReply();
  }

  public Long zadd(byte[] paramArrayOfByte, Map<Double, byte[]> paramMap)
  {
    checkIsInMulti();
    this.client.zaddBinary(paramArrayOfByte, paramMap);
    return this.client.getIntegerReply();
  }

  public Set<byte[]> zrange(byte[] paramArrayOfByte, long paramLong1, long paramLong2)
  {
    checkIsInMulti();
    this.client.zrange(paramArrayOfByte, paramLong1, paramLong2);
    List localList = this.client.getBinaryMultiBulkReply();
    return new LinkedHashSet(localList);
  }

  public Long zrem(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1)
  {
    checkIsInMulti();
    this.client.zrem(paramArrayOfByte, paramArrayOfByte1);
    return this.client.getIntegerReply();
  }

  public Double zincrby(byte[] paramArrayOfByte1, double paramDouble, byte[] paramArrayOfByte2)
  {
    checkIsInMulti();
    this.client.zincrby(paramArrayOfByte1, paramDouble, paramArrayOfByte2);
    String str = this.client.getBulkReply();
    return Double.valueOf(str);
  }

  public Long zrank(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    checkIsInMulti();
    this.client.zrank(paramArrayOfByte1, paramArrayOfByte2);
    return this.client.getIntegerReply();
  }

  public Long zrevrank(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    checkIsInMulti();
    this.client.zrevrank(paramArrayOfByte1, paramArrayOfByte2);
    return this.client.getIntegerReply();
  }

  public Set<byte[]> zrevrange(byte[] paramArrayOfByte, long paramLong1, long paramLong2)
  {
    checkIsInMulti();
    this.client.zrevrange(paramArrayOfByte, paramLong1, paramLong2);
    List localList = this.client.getBinaryMultiBulkReply();
    return new LinkedHashSet(localList);
  }

  public Set<Tuple> zrangeWithScores(byte[] paramArrayOfByte, long paramLong1, long paramLong2)
  {
    checkIsInMulti();
    this.client.zrangeWithScores(paramArrayOfByte, paramLong1, paramLong2);
    Set localSet = getBinaryTupledSet();
    return localSet;
  }

  public Set<Tuple> zrevrangeWithScores(byte[] paramArrayOfByte, long paramLong1, long paramLong2)
  {
    checkIsInMulti();
    this.client.zrevrangeWithScores(paramArrayOfByte, paramLong1, paramLong2);
    Set localSet = getBinaryTupledSet();
    return localSet;
  }

  public Long zcard(byte[] paramArrayOfByte)
  {
    checkIsInMulti();
    this.client.zcard(paramArrayOfByte);
    return this.client.getIntegerReply();
  }

  public Double zscore(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    checkIsInMulti();
    this.client.zscore(paramArrayOfByte1, paramArrayOfByte2);
    String str = this.client.getBulkReply();
    return ((str != null) ? new Double(str) : null);
  }

  public Transaction multi()
  {
    this.client.multi();
    return new Transaction(this.client);
  }

  public List<Object> multi(TransactionBlock paramTransactionBlock)
  {
    List localList = null;
    paramTransactionBlock.setClient(this.client);
    try
    {
      this.client.multi();
      paramTransactionBlock.execute();
      localList = paramTransactionBlock.exec();
    }
    catch (Exception localException)
    {
      paramTransactionBlock.discard();
    }
    return localList;
  }

  protected void checkIsInMulti()
  {
    if (this.client.isInMulti())
      throw new JedisDataException("Cannot use Jedis when in Multi. Please use JedisTransaction instead.");
  }

  public void connect()
  {
    this.client.connect();
  }

  public void disconnect()
  {
    this.client.disconnect();
  }

  public String watch(byte[][] paramArrayOfByte)
  {
    this.client.watch(paramArrayOfByte);
    return this.client.getStatusCodeReply();
  }

  public String unwatch()
  {
    this.client.unwatch();
    return this.client.getStatusCodeReply();
  }

  public List<byte[]> sort(byte[] paramArrayOfByte)
  {
    checkIsInMulti();
    this.client.sort(paramArrayOfByte);
    return this.client.getBinaryMultiBulkReply();
  }

  public List<byte[]> sort(byte[] paramArrayOfByte, SortingParams paramSortingParams)
  {
    checkIsInMulti();
    this.client.sort(paramArrayOfByte, paramSortingParams);
    return this.client.getBinaryMultiBulkReply();
  }

  public List<byte[]> blpop(int paramInt, byte[][] paramArrayOfByte)
  {
    checkIsInMulti();
    ArrayList localArrayList = new ArrayList();
    Object localObject1 = paramArrayOfByte;
    int i = localObject1.length;
    for (int j = 0; j < i; ++j)
    {
      Object localObject2 = localObject1[j];
      localArrayList.add(localObject2);
    }
    localArrayList.add(Protocol.toByteArray(paramInt));
    this.client.blpop((byte[][])localArrayList.toArray(new byte[localArrayList.size()][]));
    this.client.setTimeoutInfinite();
    localObject1 = this.client.getBinaryMultiBulkReply();
    this.client.rollbackTimeout();
    return ((List<byte[]>)localObject1);
  }

  public Long sort(byte[] paramArrayOfByte1, SortingParams paramSortingParams, byte[] paramArrayOfByte2)
  {
    checkIsInMulti();
    this.client.sort(paramArrayOfByte1, paramSortingParams, paramArrayOfByte2);
    return this.client.getIntegerReply();
  }

  public Long sort(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    checkIsInMulti();
    this.client.sort(paramArrayOfByte1, paramArrayOfByte2);
    return this.client.getIntegerReply();
  }

  public List<byte[]> brpop(int paramInt, byte[][] paramArrayOfByte)
  {
    checkIsInMulti();
    ArrayList localArrayList = new ArrayList();
    Object localObject1 = paramArrayOfByte;
    int i = localObject1.length;
    for (int j = 0; j < i; ++j)
    {
      Object localObject2 = localObject1[j];
      localArrayList.add(localObject2);
    }
    localArrayList.add(Protocol.toByteArray(paramInt));
    this.client.brpop((byte[][])localArrayList.toArray(new byte[localArrayList.size()][]));
    this.client.setTimeoutInfinite();
    localObject1 = this.client.getBinaryMultiBulkReply();
    this.client.rollbackTimeout();
    return ((List<byte[]>)localObject1);
  }

  public List<byte[]> blpop(byte[] paramArrayOfByte)
  {
    checkIsInMulti();
    [B[] arrayOf[B = new byte[1][];
    arrayOf[B[0] = paramArrayOfByte;
    this.client.blpop(arrayOf[B);
    this.client.setTimeoutInfinite();
    List localList = this.client.getBinaryMultiBulkReply();
    this.client.rollbackTimeout();
    return localList;
  }

  public List<byte[]> brpop(byte[] paramArrayOfByte)
  {
    checkIsInMulti();
    [B[] arrayOf[B = new byte[1][];
    arrayOf[B[0] = paramArrayOfByte;
    this.client.brpop(arrayOf[B);
    this.client.setTimeoutInfinite();
    List localList = this.client.getBinaryMultiBulkReply();
    this.client.rollbackTimeout();
    return localList;
  }

  public List<byte[]> blpop(byte[][] paramArrayOfByte)
  {
    checkIsInMulti();
    this.client.blpop(paramArrayOfByte);
    this.client.setTimeoutInfinite();
    List localList = this.client.getBinaryMultiBulkReply();
    this.client.rollbackTimeout();
    return localList;
  }

  public List<byte[]> brpop(byte[][] paramArrayOfByte)
  {
    checkIsInMulti();
    this.client.brpop(paramArrayOfByte);
    this.client.setTimeoutInfinite();
    List localList = this.client.getBinaryMultiBulkReply();
    this.client.rollbackTimeout();
    return localList;
  }

  public String auth(String paramString)
  {
    checkIsInMulti();
    this.client.auth(paramString);
    return this.client.getStatusCodeReply();
  }

  public List<Object> pipelined(PipelineBlock paramPipelineBlock)
  {
    paramPipelineBlock.setClient(this.client);
    paramPipelineBlock.execute();
    return paramPipelineBlock.syncAndReturnAll();
  }

  public Pipeline pipelined()
  {
    Pipeline localPipeline = new Pipeline();
    localPipeline.setClient(this.client);
    return localPipeline;
  }

  public Long zcount(byte[] paramArrayOfByte, double paramDouble1, double paramDouble2)
  {
    return zcount(paramArrayOfByte, Protocol.toByteArray(paramDouble1), Protocol.toByteArray(paramDouble2));
  }

  public Long zcount(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
  {
    checkIsInMulti();
    this.client.zcount(paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3);
    return this.client.getIntegerReply();
  }

  public Set<byte[]> zrangeByScore(byte[] paramArrayOfByte, double paramDouble1, double paramDouble2)
  {
    return zrangeByScore(paramArrayOfByte, Protocol.toByteArray(paramDouble1), Protocol.toByteArray(paramDouble2));
  }

  public Set<byte[]> zrangeByScore(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
  {
    checkIsInMulti();
    this.client.zrangeByScore(paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3);
    return new LinkedHashSet(this.client.getBinaryMultiBulkReply());
  }

  public Set<byte[]> zrangeByScore(byte[] paramArrayOfByte, double paramDouble1, double paramDouble2, int paramInt1, int paramInt2)
  {
    return zrangeByScore(paramArrayOfByte, Protocol.toByteArray(paramDouble1), Protocol.toByteArray(paramDouble2), paramInt1, paramInt2);
  }

  public Set<byte[]> zrangeByScore(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3, int paramInt1, int paramInt2)
  {
    checkIsInMulti();
    this.client.zrangeByScore(paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3, paramInt1, paramInt2);
    return new LinkedHashSet(this.client.getBinaryMultiBulkReply());
  }

  public Set<Tuple> zrangeByScoreWithScores(byte[] paramArrayOfByte, double paramDouble1, double paramDouble2)
  {
    return zrangeByScoreWithScores(paramArrayOfByte, Protocol.toByteArray(paramDouble1), Protocol.toByteArray(paramDouble2));
  }

  public Set<Tuple> zrangeByScoreWithScores(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
  {
    checkIsInMulti();
    this.client.zrangeByScoreWithScores(paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3);
    Set localSet = getBinaryTupledSet();
    return localSet;
  }

  public Set<Tuple> zrangeByScoreWithScores(byte[] paramArrayOfByte, double paramDouble1, double paramDouble2, int paramInt1, int paramInt2)
  {
    return zrangeByScoreWithScores(paramArrayOfByte, Protocol.toByteArray(paramDouble1), Protocol.toByteArray(paramDouble2), paramInt1, paramInt2);
  }

  public Set<Tuple> zrangeByScoreWithScores(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3, int paramInt1, int paramInt2)
  {
    checkIsInMulti();
    this.client.zrangeByScoreWithScores(paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3, paramInt1, paramInt2);
    Set localSet = getBinaryTupledSet();
    return localSet;
  }

  private Set<Tuple> getBinaryTupledSet()
  {
    checkIsInMulti();
    List localList = this.client.getBinaryMultiBulkReply();
    LinkedHashSet localLinkedHashSet = new LinkedHashSet();
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
      localLinkedHashSet.add(new Tuple((byte[])localIterator.next(), Double.valueOf(SafeEncoder.encode((byte[])localIterator.next()))));
    return localLinkedHashSet;
  }

  public Set<byte[]> zrevrangeByScore(byte[] paramArrayOfByte, double paramDouble1, double paramDouble2)
  {
    return zrevrangeByScore(paramArrayOfByte, Protocol.toByteArray(paramDouble1), Protocol.toByteArray(paramDouble2));
  }

  public Set<byte[]> zrevrangeByScore(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
  {
    checkIsInMulti();
    this.client.zrevrangeByScore(paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3);
    return new LinkedHashSet(this.client.getBinaryMultiBulkReply());
  }

  public Set<byte[]> zrevrangeByScore(byte[] paramArrayOfByte, double paramDouble1, double paramDouble2, int paramInt1, int paramInt2)
  {
    return zrevrangeByScore(paramArrayOfByte, Protocol.toByteArray(paramDouble1), Protocol.toByteArray(paramDouble2), paramInt1, paramInt2);
  }

  public Set<byte[]> zrevrangeByScore(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3, int paramInt1, int paramInt2)
  {
    checkIsInMulti();
    this.client.zrevrangeByScore(paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3, paramInt1, paramInt2);
    return new LinkedHashSet(this.client.getBinaryMultiBulkReply());
  }

  public Set<Tuple> zrevrangeByScoreWithScores(byte[] paramArrayOfByte, double paramDouble1, double paramDouble2)
  {
    return zrevrangeByScoreWithScores(paramArrayOfByte, Protocol.toByteArray(paramDouble1), Protocol.toByteArray(paramDouble2));
  }

  public Set<Tuple> zrevrangeByScoreWithScores(byte[] paramArrayOfByte, double paramDouble1, double paramDouble2, int paramInt1, int paramInt2)
  {
    return zrevrangeByScoreWithScores(paramArrayOfByte, Protocol.toByteArray(paramDouble1), Protocol.toByteArray(paramDouble2), paramInt1, paramInt2);
  }

  public Set<Tuple> zrevrangeByScoreWithScores(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
  {
    checkIsInMulti();
    this.client.zrevrangeByScoreWithScores(paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3);
    Set localSet = getBinaryTupledSet();
    return localSet;
  }

  public Set<Tuple> zrevrangeByScoreWithScores(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3, int paramInt1, int paramInt2)
  {
    checkIsInMulti();
    this.client.zrevrangeByScoreWithScores(paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3, paramInt1, paramInt2);
    Set localSet = getBinaryTupledSet();
    return localSet;
  }

  public Long zremrangeByRank(byte[] paramArrayOfByte, long paramLong1, long paramLong2)
  {
    checkIsInMulti();
    this.client.zremrangeByRank(paramArrayOfByte, paramLong1, paramLong2);
    return this.client.getIntegerReply();
  }

  public Long zremrangeByScore(byte[] paramArrayOfByte, double paramDouble1, double paramDouble2)
  {
    return zremrangeByScore(paramArrayOfByte, Protocol.toByteArray(paramDouble1), Protocol.toByteArray(paramDouble2));
  }

  public Long zremrangeByScore(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
  {
    checkIsInMulti();
    this.client.zremrangeByScore(paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3);
    return this.client.getIntegerReply();
  }

  public Long zunionstore(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1)
  {
    checkIsInMulti();
    this.client.zunionstore(paramArrayOfByte, paramArrayOfByte1);
    return this.client.getIntegerReply();
  }

  public Long zunionstore(byte[] paramArrayOfByte, ZParams paramZParams, byte[][] paramArrayOfByte1)
  {
    checkIsInMulti();
    this.client.zunionstore(paramArrayOfByte, paramZParams, paramArrayOfByte1);
    return this.client.getIntegerReply();
  }

  public Long zinterstore(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1)
  {
    checkIsInMulti();
    this.client.zinterstore(paramArrayOfByte, paramArrayOfByte1);
    return this.client.getIntegerReply();
  }

  public Long zinterstore(byte[] paramArrayOfByte, ZParams paramZParams, byte[][] paramArrayOfByte1)
  {
    checkIsInMulti();
    this.client.zinterstore(paramArrayOfByte, paramZParams, paramArrayOfByte1);
    return this.client.getIntegerReply();
  }

  public String save()
  {
    this.client.save();
    return this.client.getStatusCodeReply();
  }

  public String bgsave()
  {
    this.client.bgsave();
    return this.client.getStatusCodeReply();
  }

  public String bgrewriteaof()
  {
    this.client.bgrewriteaof();
    return this.client.getStatusCodeReply();
  }

  public Long lastsave()
  {
    this.client.lastsave();
    return this.client.getIntegerReply();
  }

  public String shutdown()
  {
    this.client.shutdown();
    String str = null;
    try
    {
      str = this.client.getStatusCodeReply();
    }
    catch (JedisException localJedisException)
    {
      str = null;
    }
    return str;
  }

  public String info()
  {
    this.client.info();
    return this.client.getBulkReply();
  }

  public String info(String paramString)
  {
    this.client.info(paramString);
    return this.client.getBulkReply();
  }

  public void monitor(JedisMonitor paramJedisMonitor)
  {
    this.client.monitor();
    paramJedisMonitor.proceed(this.client);
  }

  public String slaveof(String paramString, int paramInt)
  {
    this.client.slaveof(paramString, paramInt);
    return this.client.getStatusCodeReply();
  }

  public String slaveofNoOne()
  {
    this.client.slaveofNoOne();
    return this.client.getStatusCodeReply();
  }

  public List<byte[]> configGet(byte[] paramArrayOfByte)
  {
    this.client.configGet(paramArrayOfByte);
    return this.client.getBinaryMultiBulkReply();
  }

  public String configResetStat()
  {
    this.client.configResetStat();
    return this.client.getStatusCodeReply();
  }

  public byte[] configSet(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    this.client.configSet(paramArrayOfByte1, paramArrayOfByte2);
    return this.client.getBinaryBulkReply();
  }

  public boolean isConnected()
  {
    return this.client.isConnected();
  }

  public Long strlen(byte[] paramArrayOfByte)
  {
    this.client.strlen(paramArrayOfByte);
    return this.client.getIntegerReply();
  }

  public void sync()
  {
    this.client.sync();
  }

  public Long lpushx(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1)
  {
    this.client.lpushx(paramArrayOfByte, paramArrayOfByte1);
    return this.client.getIntegerReply();
  }

  public Long persist(byte[] paramArrayOfByte)
  {
    this.client.persist(paramArrayOfByte);
    return this.client.getIntegerReply();
  }

  public Long rpushx(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1)
  {
    this.client.rpushx(paramArrayOfByte, paramArrayOfByte1);
    return this.client.getIntegerReply();
  }

  public byte[] echo(byte[] paramArrayOfByte)
  {
    this.client.echo(paramArrayOfByte);
    return this.client.getBinaryBulkReply();
  }

  public Long linsert(byte[] paramArrayOfByte1, BinaryClient.LIST_POSITION paramLIST_POSITION, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
  {
    this.client.linsert(paramArrayOfByte1, paramLIST_POSITION, paramArrayOfByte2, paramArrayOfByte3);
    return this.client.getIntegerReply();
  }

  public String debug(DebugParams paramDebugParams)
  {
    this.client.debug(paramDebugParams);
    return this.client.getStatusCodeReply();
  }

  public Client getClient()
  {
    return this.client;
  }

  public byte[] brpoplpush(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, int paramInt)
  {
    this.client.brpoplpush(paramArrayOfByte1, paramArrayOfByte2, paramInt);
    this.client.setTimeoutInfinite();
    byte[] arrayOfByte = this.client.getBinaryBulkReply();
    this.client.rollbackTimeout();
    return arrayOfByte;
  }

  public Boolean setbit(byte[] paramArrayOfByte, long paramLong, boolean paramBoolean)
  {
    this.client.setbit(paramArrayOfByte, paramLong, paramBoolean);
    return Boolean.valueOf(this.client.getIntegerReply().longValue() == -6318801176305336319L);
  }

  public Boolean setbit(byte[] paramArrayOfByte1, long paramLong, byte[] paramArrayOfByte2)
  {
    this.client.setbit(paramArrayOfByte1, paramLong, paramArrayOfByte2);
    return Boolean.valueOf(this.client.getIntegerReply().longValue() == -6318801176305336319L);
  }

  public Boolean getbit(byte[] paramArrayOfByte, long paramLong)
  {
    this.client.getbit(paramArrayOfByte, paramLong);
    return Boolean.valueOf(this.client.getIntegerReply().longValue() == -6318801176305336319L);
  }

  public Long setrange(byte[] paramArrayOfByte1, long paramLong, byte[] paramArrayOfByte2)
  {
    this.client.setrange(paramArrayOfByte1, paramLong, paramArrayOfByte2);
    return this.client.getIntegerReply();
  }

  public byte[] getrange(byte[] paramArrayOfByte, long paramLong1, long paramLong2)
  {
    this.client.getrange(paramArrayOfByte, paramLong1, paramLong2);
    return this.client.getBinaryBulkReply();
  }

  public Long publish(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    this.client.publish(paramArrayOfByte1, paramArrayOfByte2);
    return this.client.getIntegerReply();
  }

  public void subscribe(BinaryJedisPubSub paramBinaryJedisPubSub, byte[][] paramArrayOfByte)
  {
    this.client.setTimeoutInfinite();
    paramBinaryJedisPubSub.proceed(this.client, paramArrayOfByte);
    this.client.rollbackTimeout();
  }

  public void psubscribe(BinaryJedisPubSub paramBinaryJedisPubSub, byte[][] paramArrayOfByte)
  {
    this.client.setTimeoutInfinite();
    paramBinaryJedisPubSub.proceedWithPatterns(this.client, paramArrayOfByte);
    this.client.rollbackTimeout();
  }

  public Long getDB()
  {
    return this.client.getDB();
  }

  public Object eval(byte[] paramArrayOfByte, List<byte[]> paramList1, List<byte[]> paramList2)
  {
    this.client.setTimeoutInfinite();
    this.client.eval(paramArrayOfByte, Protocol.toByteArray(paramList1.size()), getParams(paramList1, paramList2));
    return this.client.getOne();
  }

  private byte[][] getParams(List<byte[]> paramList1, List<byte[]> paramList2)
  {
    int i = paramList1.size();
    [B[] arrayOf[B = new byte[i + paramList2.size()][];
    for (int j = 0; j < i; ++j)
      arrayOf[B[j] = ((byte[])paramList1.get(j));
    for (j = 0; j < paramList1.size(); ++j)
      arrayOf[B[(i + j)] = ((byte[])paramList2.get(j));
    return arrayOf[B;
  }

  public Object eval(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[][] paramArrayOfByte)
  {
    this.client.setTimeoutInfinite();
    this.client.eval(paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte);
    return this.client.getOne();
  }

  public Object eval(byte[] paramArrayOfByte, int paramInt, byte[][] paramArrayOfByte1)
  {
    this.client.setTimeoutInfinite();
    this.client.eval(paramArrayOfByte, SafeEncoder.encode(Integer.toString(paramInt)), paramArrayOfByte1);
    return this.client.getOne();
  }

  public Object eval(byte[] paramArrayOfByte)
  {
    this.client.setTimeoutInfinite();
    this.client.eval(paramArrayOfByte, 0, new byte[0][]);
    return this.client.getOne();
  }

  public Object evalsha(byte[] paramArrayOfByte)
  {
    this.client.setTimeoutInfinite();
    this.client.evalsha(paramArrayOfByte, 0, new byte[0][]);
    return this.client.getOne();
  }

  public Object evalsha(byte[] paramArrayOfByte, List<byte[]> paramList1, List<byte[]> paramList2)
  {
    this.client.setTimeoutInfinite();
    this.client.evalsha(paramArrayOfByte, paramList1.size(), (byte[][])paramList1.toArray(new byte[0][]));
    return this.client.getOne();
  }

  public Object evalsha(byte[] paramArrayOfByte, int paramInt, byte[][] paramArrayOfByte1)
  {
    this.client.setTimeoutInfinite();
    this.client.evalsha(paramArrayOfByte, paramInt, paramArrayOfByte1);
    return this.client.getOne();
  }

  public String scriptFlush()
  {
    this.client.scriptFlush();
    return this.client.getStatusCodeReply();
  }

  public List<Long> scriptExists(byte[][] paramArrayOfByte)
  {
    this.client.scriptExists(paramArrayOfByte);
    return this.client.getIntegerMultiBulkReply();
  }

  public byte[] scriptLoad(byte[] paramArrayOfByte)
  {
    this.client.scriptLoad(paramArrayOfByte);
    return this.client.getBinaryBulkReply();
  }

  public String scriptKill()
  {
    this.client.scriptKill();
    return this.client.getStatusCodeReply();
  }

  public String slowlogReset()
  {
    this.client.slowlogReset();
    return this.client.getBulkReply();
  }

  public Long slowlogLen()
  {
    this.client.slowlogLen();
    return this.client.getIntegerReply();
  }

  public List<byte[]> slowlogGetBinary()
  {
    this.client.slowlogGet();
    return this.client.getBinaryMultiBulkReply();
  }

  public List<byte[]> slowlogGetBinary(long paramLong)
  {
    this.client.slowlogGet(paramLong);
    return this.client.getBinaryMultiBulkReply();
  }

  public Long objectRefcount(byte[] paramArrayOfByte)
  {
    this.client.objectRefcount(paramArrayOfByte);
    return this.client.getIntegerReply();
  }

  public byte[] objectEncoding(byte[] paramArrayOfByte)
  {
    this.client.objectEncoding(paramArrayOfByte);
    return this.client.getBinaryBulkReply();
  }

  public Long objectIdletime(byte[] paramArrayOfByte)
  {
    this.client.objectIdletime(paramArrayOfByte);
    return this.client.getIntegerReply();
  }

  public Long bitcount(byte[] paramArrayOfByte)
  {
    this.client.bitcount(paramArrayOfByte);
    return this.client.getIntegerReply();
  }

  public Long bitcount(byte[] paramArrayOfByte, long paramLong1, long paramLong2)
  {
    this.client.bitcount(paramArrayOfByte, paramLong1, paramLong2);
    return this.client.getIntegerReply();
  }

  public Long bitop(BitOP paramBitOP, byte[] paramArrayOfByte, byte[][] paramArrayOfByte1)
  {
    this.client.bitop(paramBitOP, paramArrayOfByte, paramArrayOfByte1);
    return this.client.getIntegerReply();
  }

  public byte[] dump(byte[] paramArrayOfByte)
  {
    checkIsInMulti();
    this.client.dump(paramArrayOfByte);
    return this.client.getBinaryBulkReply();
  }

  public String restore(byte[] paramArrayOfByte1, int paramInt, byte[] paramArrayOfByte2)
  {
    checkIsInMulti();
    this.client.restore(paramArrayOfByte1, paramInt, paramArrayOfByte2);
    return this.client.getStatusCodeReply();
  }

  public Long pexpire(byte[] paramArrayOfByte, int paramInt)
  {
    checkIsInMulti();
    this.client.pexpire(paramArrayOfByte, paramInt);
    return this.client.getIntegerReply();
  }

  public Long pexpireAt(byte[] paramArrayOfByte, long paramLong)
  {
    checkIsInMulti();
    this.client.pexpireAt(paramArrayOfByte, paramLong);
    return this.client.getIntegerReply();
  }

  public Long pttl(byte[] paramArrayOfByte)
  {
    checkIsInMulti();
    this.client.pttl(paramArrayOfByte);
    return this.client.getIntegerReply();
  }

  public Double incrByFloat(byte[] paramArrayOfByte, double paramDouble)
  {
    checkIsInMulti();
    this.client.incrByFloat(paramArrayOfByte, paramDouble);
    String str = this.client.getBulkReply();
    return ((str != null) ? new Double(str) : null);
  }

  public String psetex(byte[] paramArrayOfByte1, int paramInt, byte[] paramArrayOfByte2)
  {
    checkIsInMulti();
    this.client.psetex(paramArrayOfByte1, paramInt, paramArrayOfByte2);
    return this.client.getStatusCodeReply();
  }

  public String set(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
  {
    checkIsInMulti();
    this.client.set(paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3);
    return this.client.getStatusCodeReply();
  }

  public String set(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3, byte[] paramArrayOfByte4, int paramInt)
  {
    checkIsInMulti();
    this.client.set(paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3, paramArrayOfByte4, paramInt);
    return this.client.getStatusCodeReply();
  }

  public String clientKill(byte[] paramArrayOfByte)
  {
    checkIsInMulti();
    this.client.clientKill(paramArrayOfByte);
    return this.client.getStatusCodeReply();
  }

  public String clientGetname()
  {
    checkIsInMulti();
    this.client.clientGetname();
    return this.client.getBulkReply();
  }

  public String clientList()
  {
    checkIsInMulti();
    this.client.clientList();
    return this.client.getBulkReply();
  }

  public String clientSetname(byte[] paramArrayOfByte)
  {
    checkIsInMulti();
    this.client.clientSetname(paramArrayOfByte);
    return this.client.getBulkReply();
  }

  public List<String> time()
  {
    checkIsInMulti();
    this.client.time();
    return this.client.getMultiBulkReply();
  }

  public String migrate(byte[] paramArrayOfByte1, int paramInt1, byte[] paramArrayOfByte2, int paramInt2, int paramInt3)
  {
    checkIsInMulti();
    this.client.migrate(paramArrayOfByte1, paramInt1, paramArrayOfByte2, paramInt2, paramInt3);
    return this.client.getStatusCodeReply();
  }

  public Double hincrByFloat(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, double paramDouble)
  {
    checkIsInMulti();
    this.client.hincrByFloat(paramArrayOfByte1, paramArrayOfByte2, paramDouble);
    String str = this.client.getBulkReply();
    return ((str != null) ? new Double(str) : null);
  }
}