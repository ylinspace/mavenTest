package com.ycache.redis.clients.jedis;

import com.ycache.redis.clients.jedis.exceptions.JedisException;

public abstract class TransactionBlock extends Transaction
{
  public TransactionBlock(Client paramClient)
  {
    super(paramClient);
  }

  public TransactionBlock()
  {
  }

  public abstract void execute()
    throws JedisException;

  public void setClient(Client paramClient)
  {
    this.client = paramClient;
  }
}