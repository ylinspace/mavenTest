package com.ycache.redis.clients.util;

import com.ycache.redis.clients.jedis.exceptions.JedisConnectionException;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;

public class RedisInputStream extends FilterInputStream
{
  protected final byte[] buf;
  protected int count;
  protected int limit;

  public RedisInputStream(InputStream paramInputStream, int paramInt)
  {
    super(paramInputStream);
    if (paramInt <= 0)
      throw new IllegalArgumentException("Buffer size <= 0");
    this.buf = new byte[paramInt];
  }

  public RedisInputStream(InputStream paramInputStream)
  {
    this(paramInputStream, 8192);
  }

  public byte readByte()
    throws IOException
  {
    if (this.count == this.limit)
      fill();
    return this.buf[(this.count++)];
  }

  public String readLine()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    try
    {
      while (true)
      {
        int i;
        while (true)
        {
          if (this.count == this.limit)
            fill();
          if (this.limit == -1)
            break label143:
          i = this.buf[(this.count++)];
          if (i != 13)
            break;
          if (this.count == this.limit)
            fill();
          if (this.limit == -1)
          {
            localStringBuilder.append((char)i);
            break label143:
          }
          int j = this.buf[(this.count++)];
          if (j == 10)
            break label143:
          localStringBuilder.append((char)i);
          localStringBuilder.append((char)j);
        }
        localStringBuilder.append((char)i);
      }
    }
    catch (IOException localIOException)
    {
      label143: throw new JedisConnectionException(localIOException);
    }
    String str = localStringBuilder.toString();
    if (str.length() == 0)
      throw new JedisConnectionException("It seems like server has closed the connection.");
    return str;
  }

  public int read(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException
  {
    if (this.count == this.limit)
    {
      fill();
      if (this.limit == -1)
        return -1;
    }
    int i = Math.min(this.limit - this.count, paramInt2);
    System.arraycopy(this.buf, this.count, paramArrayOfByte, paramInt1, i);
    this.count += i;
    return i;
  }

  private void fill()
    throws IOException
  {
    this.limit = this.in.read(this.buf);
    this.count = 0;
  }
}