package com.ycache.danga.MemCached.test;

import com.ycache.danga.MemCached.MemCachedClient;
import com.ycache.danga.MemCached.SockIOPool;
import java.io.PrintStream;
import java.util.Hashtable;

public class MemCachedTest
{
  private static Hashtable<Integer, StringBuilder> threadInfo = new Hashtable();

  public static void main(String[] paramArrayOfString)
  {
    String[] arrayOfString1 = { "cache1.int.meetup.com:12345", "cache0.int.meetup.com:12345" };
    SockIOPool localSockIOPool = SockIOPool.getInstance();
    localSockIOPool.setServers(arrayOfString1);
    localSockIOPool.setInitConn(5);
    localSockIOPool.setMinConn(5);
    localSockIOPool.setMaxConn(50);
    localSockIOPool.setMaintSleep(30L);
    localSockIOPool.setNagle(false);
    localSockIOPool.initialize();
    int i = Integer.parseInt(paramArrayOfString[0]);
    int j = Integer.parseInt(paramArrayOfString[1]);
    int k = 1024 * Integer.parseInt(paramArrayOfString[2]);
    int[] arrayOfInt = new int[k];
    for (int l = 0; l < k; ++l)
      arrayOfInt[l] = l;
    String[] arrayOfString2 = new String[k];
    for (int i1 = 0; i1 < k; ++i1)
      arrayOfString2[i1] = "test_key" + i1;
    for (i1 = 0; i1 < i; ++i1)
    {
      bench localbench = new bench(j, i1, arrayOfInt, arrayOfString2);
      localbench.start();
    }
    for (i1 = 0; i1 < i; ++i1)
    {
      if (!(threadInfo.containsKey(new Integer(i1))))
        break;
      System.out.println(threadInfo.get(new Integer(i1)));
    }
    try
    {
      Thread.sleep(1000L);
    }
    catch (InterruptedException localInterruptedException)
    {
      while (true)
        localInterruptedException.printStackTrace();
      localSockIOPool.shutDown();
      System.exit(1);
    }
  }

  private static class bench extends Thread
  {
    private int runs;
    private int threadNum;
    private int[] object;
    private String[] keys;
    private int size;

    public bench(int paramInt1, int paramInt2, int[] paramArrayOfInt, String[] paramArrayOfString)
    {
      this.runs = paramInt1;
      this.threadNum = paramInt2;
      this.object = paramArrayOfInt;
      this.keys = paramArrayOfString;
      this.size = paramArrayOfInt.length;
    }

    public void run()
    {
      StringBuilder localStringBuilder = new StringBuilder();
      MemCachedClient localMemCachedClient = new MemCachedClient();
      localMemCachedClient.setCompressEnable(false);
      localMemCachedClient.setCompressThreshold(-6318801193485205504L);
      long l1 = System.currentTimeMillis();
      for (int i = 0; i < this.runs; ++i)
        localMemCachedClient.delete(this.keys[i]);
      long l2 = System.currentTimeMillis() - l1;
      float f = (float)l2 / this.runs;
      localStringBuilder.append(new StringBuilder().append("\nthread ").append(this.threadNum).append(": runs: ").append(this.runs).append(" deletes of obj ").append(this.size / 1024).append("KB -- avg time per req ").append(f).append(" ms (total: ").append(l2).append(" ms)").toString());
      l1 = System.currentTimeMillis();
      for (int j = 0; j < this.runs; ++j)
        localMemCachedClient.set(this.keys[j], this.object);
      l2 = System.currentTimeMillis() - l1;
      f = (float)l2 / this.runs;
      localStringBuilder.append(new StringBuilder().append("\nthread ").append(this.threadNum).append(": runs: ").append(this.runs).append(" stores of obj ").append(this.size / 1024).append("KB -- avg time per req ").append(f).append(" ms (total: ").append(l2).append(" ms)").toString());
      l1 = System.currentTimeMillis();
      for (j = 0; j < this.runs; ++j)
        localMemCachedClient.get(this.keys[j]);
      l2 = System.currentTimeMillis() - l1;
      f = (float)l2 / this.runs;
      localStringBuilder.append(new StringBuilder().append("\nthread ").append(this.threadNum).append(": runs: ").append(this.runs).append(" gets of obj ").append(this.size / 1024).append("KB -- avg time per req ").append(f).append(" ms (total: ").append(l2).append(" ms)").toString());
      MemCachedTest.access$000().put(new Integer(this.threadNum), localStringBuilder);
    }
  }
}