package com.ycache.redis.clients.jedis;

import com.ycache.redis.clients.jedis.exceptions.JedisConnectionException;
import com.ycache.redis.clients.jedis.exceptions.JedisDataException;
import com.ycache.redis.clients.util.RedisInputStream;
import com.ycache.redis.clients.util.RedisOutputStream;
import com.ycache.redis.clients.util.SafeEncoder;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public final class Protocol
{
  public static final int DEFAULT_PORT = 6379;
  public static final int DEFAULT_SENTINEL_PORT = 26379;
  public static final int DEFAULT_TIMEOUT = 2000;
  public static final int DEFAULT_DATABASE = 0;
  public static final String CHARSET = "UTF-8";
  public static final byte DOLLAR_BYTE = 36;
  public static final byte ASTERISK_BYTE = 42;
  public static final byte PLUS_BYTE = 43;
  public static final byte MINUS_BYTE = 45;
  public static final byte COLON_BYTE = 58;
  public static final String SENTINEL_MASTERS = "masters";
  public static final String SENTINEL_GET_MASTER_ADDR_BY_NAME = "get-master-addr-by-name";
  public static final String SENTINEL_RESET = "reset";
  public static final String SENTINEL_SLAVES = "slaves";
  public static final String SENTINEL_IS_MASTER_DOWN_BY_ADDR = "is-master-down-by-addr";

  public static void sendCommand(RedisOutputStream paramRedisOutputStream, Command paramCommand, byte[][] paramArrayOfByte)
  {
    sendCommand(paramRedisOutputStream, paramCommand.raw, paramArrayOfByte);
  }

  private static void sendCommand(RedisOutputStream paramRedisOutputStream, byte[] paramArrayOfByte, byte[][] paramArrayOfByte1)
  {
    try
    {
      paramRedisOutputStream.write(42);
      paramRedisOutputStream.writeIntCrLf(paramArrayOfByte1.length + 1);
      paramRedisOutputStream.write(36);
      paramRedisOutputStream.writeIntCrLf(paramArrayOfByte.length);
      paramRedisOutputStream.write(paramArrayOfByte);
      paramRedisOutputStream.writeCrLf();
      byte[][] arrayOfByte = paramArrayOfByte1;
      int i = arrayOfByte.length;
      for (int j = 0; j < i; ++j)
      {
        byte[] arrayOfByte1 = arrayOfByte[j];
        paramRedisOutputStream.write(36);
        paramRedisOutputStream.writeIntCrLf(arrayOfByte1.length);
        paramRedisOutputStream.write(arrayOfByte1);
        paramRedisOutputStream.writeCrLf();
      }
    }
    catch (IOException localIOException)
    {
      throw new JedisConnectionException(localIOException);
    }
  }

  private static void processError(RedisInputStream paramRedisInputStream)
  {
    String str = paramRedisInputStream.readLine();
    throw new JedisDataException(str);
  }

  private static Object process(RedisInputStream paramRedisInputStream)
  {
    int i;
    try
    {
      i = paramRedisInputStream.readByte();
      if (i == 45)
      {
        processError(paramRedisInputStream);
      }
      else
      {
        if (i == 42)
          return processMultiBulkReply(paramRedisInputStream);
        if (i == 58)
          return processInteger(paramRedisInputStream);
        if (i == 36)
          return processBulkReply(paramRedisInputStream);
        if (i == 43)
          return processStatusCodeReply(paramRedisInputStream);
        throw new JedisConnectionException("Unknown reply: " + (char)i);
      }
    }
    catch (IOException localIOException)
    {
      throw new JedisConnectionException(localIOException);
    }
    return null;
  }

  private static byte[] processStatusCodeReply(RedisInputStream paramRedisInputStream)
  {
    return SafeEncoder.encode(paramRedisInputStream.readLine());
  }

  private static byte[] processBulkReply(RedisInputStream paramRedisInputStream)
  {
    int i = Integer.parseInt(paramRedisInputStream.readLine());
    if (i == -1)
      return null;
    byte[] arrayOfByte = new byte[i];
    int j = 0;
    try
    {
      while (j < i)
        j += paramRedisInputStream.read(arrayOfByte, j, i - j);
      paramRedisInputStream.readByte();
      paramRedisInputStream.readByte();
    }
    catch (IOException localIOException)
    {
      throw new JedisConnectionException(localIOException);
    }
    return arrayOfByte;
  }

  private static Long processInteger(RedisInputStream paramRedisInputStream)
  {
    String str = paramRedisInputStream.readLine();
    return Long.valueOf(str);
  }

  private static List<Object> processMultiBulkReply(RedisInputStream paramRedisInputStream)
  {
    int i = Integer.parseInt(paramRedisInputStream.readLine());
    if (i == -1)
      return null;
    ArrayList localArrayList = new ArrayList(i);
    for (int j = 0; j < i; ++j)
      try
      {
        localArrayList.add(process(paramRedisInputStream));
      }
      catch (JedisDataException localJedisDataException)
      {
        localArrayList.add(localJedisDataException);
      }
    return localArrayList;
  }

  public static Object read(RedisInputStream paramRedisInputStream)
  {
    return process(paramRedisInputStream);
  }

  public static final byte[] toByteArray(boolean paramBoolean)
  {
    return toByteArray((paramBoolean) ? 1 : 0);
  }

  public static final byte[] toByteArray(int paramInt)
  {
    return SafeEncoder.encode(String.valueOf(paramInt));
  }

  public static final byte[] toByteArray(long paramLong)
  {
    return SafeEncoder.encode(String.valueOf(paramLong));
  }

  public static final byte[] toByteArray(double paramDouble)
  {
    return SafeEncoder.encode(String.valueOf(paramDouble));
  }

  public static enum Keyword
  {
    AGGREGATE, ALPHA, ASC, BY, DESC, GET, LIMIT, MESSAGE, NO, NOSORT, PMESSAGE, PSUBSCRIBE, PUNSUBSCRIBE, OK, ONE, QUEUED, SET, STORE, SUBSCRIBE, UNSUBSCRIBE, WEIGHTS, WITHSCORES, RESETSTAT, RESET, FLUSH, EXISTS, LOAD, KILL, LEN, REFCOUNT, ENCODING, IDLETIME, AND, OR, XOR, NOT, GETNAME, SETNAME, LIST;

    public final byte[] raw = SafeEncoder.encode(name().toLowerCase());
  }

  public static enum Command
  {
    PING, SET, GET, QUIT, EXISTS, DEL, TYPE, FLUSHDB, KEYS, RANDOMKEY, RENAME, RENAMENX, RENAMEX, DBSIZE, EXPIRE, EXPIREAT, TTL, SELECT, MOVE, FLUSHALL, GETSET, MGET, SETNX, SETEX, MSET, MSETNX, DECRBY, DECR, INCRBY, INCR, APPEND, SUBSTR, HSET, HGET, HSETNX, HMSET, HMGET, HINCRBY, HEXISTS, HDEL, HLEN, HKEYS, HVALS, HGETALL, RPUSH, LPUSH, LLEN, LRANGE, LTRIM, LINDEX, LSET, LREM, LPOP, RPOP, RPOPLPUSH, SADD, SMEMBERS, SREM, SPOP, SMOVE, SCARD, SISMEMBER, SINTER, SINTERSTORE, SUNION, SUNIONSTORE, SDIFF, SDIFFSTORE, SRANDMEMBER, ZADD, ZRANGE, ZREM, ZINCRBY, ZRANK, ZREVRANK, ZREVRANGE, ZCARD, ZSCORE, MULTI, DISCARD, EXEC, WATCH, UNWATCH, SORT, BLPOP, BRPOP, AUTH, SUBSCRIBE, PUBLISH, UNSUBSCRIBE, PSUBSCRIBE, PUNSUBSCRIBE, ZCOUNT, ZRANGEBYSCORE, ZREVRANGEBYSCORE, ZREMRANGEBYRANK, ZREMRANGEBYSCORE, ZUNIONSTORE, ZINTERSTORE, SAVE, BGSAVE, BGREWRITEAOF, LASTSAVE, SHUTDOWN, INFO, MONITOR, SLAVEOF, CONFIG, STRLEN, SYNC, LPUSHX, PERSIST, RPUSHX, ECHO, LINSERT, DEBUG, BRPOPLPUSH, SETBIT, GETBIT, SETRANGE, GETRANGE, EVAL, EVALSHA, SCRIPT, SLOWLOG, OBJECT, BITCOUNT, BITOP, SENTINEL, DUMP, RESTORE, PEXPIRE, PEXPIREAT, PTTL, INCRBYFLOAT, PSETEX, CLIENT, TIME, MIGRATE, HINCRBYFLOAT;

    public final byte[] raw = SafeEncoder.encode(name());
  }
}