package com.ycache.redis.clients.jedis;

import com.ycache.redis.clients.util.Hashing;
import com.ycache.redis.clients.util.Sharded;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

public class BinaryShardedJedis extends Sharded<Jedis, JedisShardInfo>
  implements BinaryJedisCommands
{
  public BinaryShardedJedis(List<JedisShardInfo> paramList)
  {
    super(paramList);
  }

  public BinaryShardedJedis(List<JedisShardInfo> paramList, Hashing paramHashing)
  {
    super(paramList, paramHashing);
  }

  public BinaryShardedJedis(List<JedisShardInfo> paramList, Pattern paramPattern)
  {
    super(paramList, paramPattern);
  }

  public BinaryShardedJedis(List<JedisShardInfo> paramList, Hashing paramHashing, Pattern paramPattern)
  {
    super(paramList, paramHashing, paramPattern);
  }

  public void disconnect()
  {
    Iterator localIterator = getAllShards().iterator();
    while (localIterator.hasNext())
    {
      Jedis localJedis = (Jedis)localIterator.next();
      localJedis.quit();
      localJedis.disconnect();
    }
  }

  protected Jedis create(JedisShardInfo paramJedisShardInfo)
  {
    return new Jedis(paramJedisShardInfo);
  }

  public String set(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte1);
    return localJedis.set(paramArrayOfByte1, paramArrayOfByte2);
  }

  public byte[] get(byte[] paramArrayOfByte)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte);
    return localJedis.get(paramArrayOfByte);
  }

  public Boolean exists(byte[] paramArrayOfByte)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte);
    return localJedis.exists(paramArrayOfByte);
  }

  public String type(byte[] paramArrayOfByte)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte);
    return localJedis.type(paramArrayOfByte);
  }

  public Long expire(byte[] paramArrayOfByte, int paramInt)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte);
    return localJedis.expire(paramArrayOfByte, paramInt);
  }

  public Long expireAt(byte[] paramArrayOfByte, long paramLong)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte);
    return localJedis.expireAt(paramArrayOfByte, paramLong);
  }

  public Long ttl(byte[] paramArrayOfByte)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte);
    return localJedis.ttl(paramArrayOfByte);
  }

  public byte[] getSet(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte1);
    return localJedis.getSet(paramArrayOfByte1, paramArrayOfByte2);
  }

  public Long setnx(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte1);
    return localJedis.setnx(paramArrayOfByte1, paramArrayOfByte2);
  }

  public String setex(byte[] paramArrayOfByte1, int paramInt, byte[] paramArrayOfByte2)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte1);
    return localJedis.setex(paramArrayOfByte1, paramInt, paramArrayOfByte2);
  }

  public Long decrBy(byte[] paramArrayOfByte, long paramLong)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte);
    return localJedis.decrBy(paramArrayOfByte, paramLong);
  }

  public Long decr(byte[] paramArrayOfByte)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte);
    return localJedis.decr(paramArrayOfByte);
  }

  public Long del(byte[] paramArrayOfByte)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte);
    return localJedis.del(paramArrayOfByte);
  }

  public Long incrBy(byte[] paramArrayOfByte, long paramLong)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte);
    return localJedis.incrBy(paramArrayOfByte, paramLong);
  }

  public Long incr(byte[] paramArrayOfByte)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte);
    return localJedis.incr(paramArrayOfByte);
  }

  public Long append(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte1);
    return localJedis.append(paramArrayOfByte1, paramArrayOfByte2);
  }

  public byte[] substr(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte);
    return localJedis.substr(paramArrayOfByte, paramInt1, paramInt2);
  }

  public Long hset(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte1);
    return localJedis.hset(paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3);
  }

  public byte[] hget(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte1);
    return localJedis.hget(paramArrayOfByte1, paramArrayOfByte2);
  }

  public Long hsetnx(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte1);
    return localJedis.hsetnx(paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3);
  }

  public String hmset(byte[] paramArrayOfByte, Map<byte[], byte[]> paramMap)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte);
    return localJedis.hmset(paramArrayOfByte, paramMap);
  }

  public List<byte[]> hmget(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte);
    return localJedis.hmget(paramArrayOfByte, paramArrayOfByte1);
  }

  public Long hincrBy(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, long paramLong)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte1);
    return localJedis.hincrBy(paramArrayOfByte1, paramArrayOfByte2, paramLong);
  }

  public Boolean hexists(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte1);
    return localJedis.hexists(paramArrayOfByte1, paramArrayOfByte2);
  }

  public Long hdel(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte);
    return localJedis.hdel(paramArrayOfByte, paramArrayOfByte1);
  }

  public Long hlen(byte[] paramArrayOfByte)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte);
    return localJedis.hlen(paramArrayOfByte);
  }

  public Set<byte[]> hkeys(byte[] paramArrayOfByte)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte);
    return localJedis.hkeys(paramArrayOfByte);
  }

  public Collection<byte[]> hvals(byte[] paramArrayOfByte)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte);
    return localJedis.hvals(paramArrayOfByte);
  }

  public Map<byte[], byte[]> hgetAll(byte[] paramArrayOfByte)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte);
    return localJedis.hgetAll(paramArrayOfByte);
  }

  public Long rpush(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte);
    return localJedis.rpush(paramArrayOfByte, paramArrayOfByte1);
  }

  public Long lpush(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte);
    return localJedis.lpush(paramArrayOfByte, paramArrayOfByte1);
  }

  public Long strlen(byte[] paramArrayOfByte)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte);
    return localJedis.strlen(paramArrayOfByte);
  }

  public Long lpushx(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte);
    return localJedis.lpushx(paramArrayOfByte, paramArrayOfByte1);
  }

  public Long persist(byte[] paramArrayOfByte)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte);
    return localJedis.persist(paramArrayOfByte);
  }

  public Long rpushx(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte);
    return localJedis.rpushx(paramArrayOfByte, paramArrayOfByte1);
  }

  public Long llen(byte[] paramArrayOfByte)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte);
    return localJedis.llen(paramArrayOfByte);
  }

  public List<byte[]> lrange(byte[] paramArrayOfByte, long paramLong1, long paramLong2)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte);
    return localJedis.lrange(paramArrayOfByte, paramLong1, paramLong2);
  }

  public String ltrim(byte[] paramArrayOfByte, long paramLong1, long paramLong2)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte);
    return localJedis.ltrim(paramArrayOfByte, paramLong1, paramLong2);
  }

  public byte[] lindex(byte[] paramArrayOfByte, long paramLong)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte);
    return localJedis.lindex(paramArrayOfByte, paramLong);
  }

  public String lset(byte[] paramArrayOfByte1, long paramLong, byte[] paramArrayOfByte2)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte1);
    return localJedis.lset(paramArrayOfByte1, paramLong, paramArrayOfByte2);
  }

  public Long lrem(byte[] paramArrayOfByte1, long paramLong, byte[] paramArrayOfByte2)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte1);
    return localJedis.lrem(paramArrayOfByte1, paramLong, paramArrayOfByte2);
  }

  public byte[] lpop(byte[] paramArrayOfByte)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte);
    return localJedis.lpop(paramArrayOfByte);
  }

  public byte[] rpop(byte[] paramArrayOfByte)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte);
    return localJedis.rpop(paramArrayOfByte);
  }

  public Long sadd(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte);
    return localJedis.sadd(paramArrayOfByte, paramArrayOfByte1);
  }

  public Set<byte[]> smembers(byte[] paramArrayOfByte)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte);
    return localJedis.smembers(paramArrayOfByte);
  }

  public Long srem(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte);
    return localJedis.srem(paramArrayOfByte, paramArrayOfByte1);
  }

  public byte[] spop(byte[] paramArrayOfByte)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte);
    return localJedis.spop(paramArrayOfByte);
  }

  public Long scard(byte[] paramArrayOfByte)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte);
    return localJedis.scard(paramArrayOfByte);
  }

  public Boolean sismember(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte1);
    return localJedis.sismember(paramArrayOfByte1, paramArrayOfByte2);
  }

  public byte[] srandmember(byte[] paramArrayOfByte)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte);
    return localJedis.srandmember(paramArrayOfByte);
  }

  public Long zadd(byte[] paramArrayOfByte1, double paramDouble, byte[] paramArrayOfByte2)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte1);
    return localJedis.zadd(paramArrayOfByte1, paramDouble, paramArrayOfByte2);
  }

  public Long zadd(byte[] paramArrayOfByte, Map<Double, byte[]> paramMap)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte);
    return localJedis.zadd(paramArrayOfByte, paramMap);
  }

  public Set<byte[]> zrange(byte[] paramArrayOfByte, long paramLong1, long paramLong2)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte);
    return localJedis.zrange(paramArrayOfByte, paramLong1, paramLong2);
  }

  public Long zrem(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte);
    return localJedis.zrem(paramArrayOfByte, paramArrayOfByte1);
  }

  public Double zincrby(byte[] paramArrayOfByte1, double paramDouble, byte[] paramArrayOfByte2)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte1);
    return localJedis.zincrby(paramArrayOfByte1, paramDouble, paramArrayOfByte2);
  }

  public Long zrank(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte1);
    return localJedis.zrank(paramArrayOfByte1, paramArrayOfByte2);
  }

  public Long zrevrank(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte1);
    return localJedis.zrevrank(paramArrayOfByte1, paramArrayOfByte2);
  }

  public Set<byte[]> zrevrange(byte[] paramArrayOfByte, long paramLong1, long paramLong2)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte);
    return localJedis.zrevrange(paramArrayOfByte, paramLong1, paramLong2);
  }

  public Set<Tuple> zrangeWithScores(byte[] paramArrayOfByte, long paramLong1, long paramLong2)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte);
    return localJedis.zrangeWithScores(paramArrayOfByte, paramLong1, paramLong2);
  }

  public Set<Tuple> zrevrangeWithScores(byte[] paramArrayOfByte, long paramLong1, long paramLong2)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte);
    return localJedis.zrevrangeWithScores(paramArrayOfByte, paramLong1, paramLong2);
  }

  public Long zcard(byte[] paramArrayOfByte)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte);
    return localJedis.zcard(paramArrayOfByte);
  }

  public Double zscore(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte1);
    return localJedis.zscore(paramArrayOfByte1, paramArrayOfByte2);
  }

  public List<byte[]> sort(byte[] paramArrayOfByte)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte);
    return localJedis.sort(paramArrayOfByte);
  }

  public List<byte[]> sort(byte[] paramArrayOfByte, SortingParams paramSortingParams)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte);
    return localJedis.sort(paramArrayOfByte, paramSortingParams);
  }

  public Long zcount(byte[] paramArrayOfByte, double paramDouble1, double paramDouble2)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte);
    return localJedis.zcount(paramArrayOfByte, paramDouble1, paramDouble2);
  }

  public Long zcount(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte1);
    return localJedis.zcount(paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3);
  }

  public Set<byte[]> zrangeByScore(byte[] paramArrayOfByte, double paramDouble1, double paramDouble2)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte);
    return localJedis.zrangeByScore(paramArrayOfByte, paramDouble1, paramDouble2);
  }

  public Set<byte[]> zrangeByScore(byte[] paramArrayOfByte, double paramDouble1, double paramDouble2, int paramInt1, int paramInt2)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte);
    return localJedis.zrangeByScore(paramArrayOfByte, paramDouble1, paramDouble2, paramInt1, paramInt2);
  }

  public Set<Tuple> zrangeByScoreWithScores(byte[] paramArrayOfByte, double paramDouble1, double paramDouble2)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte);
    return localJedis.zrangeByScoreWithScores(paramArrayOfByte, paramDouble1, paramDouble2);
  }

  public Set<Tuple> zrangeByScoreWithScores(byte[] paramArrayOfByte, double paramDouble1, double paramDouble2, int paramInt1, int paramInt2)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte);
    return localJedis.zrangeByScoreWithScores(paramArrayOfByte, paramDouble1, paramDouble2, paramInt1, paramInt2);
  }

  public Set<byte[]> zrangeByScore(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte1);
    return localJedis.zrangeByScore(paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3);
  }

  public Set<Tuple> zrangeByScoreWithScores(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte1);
    return localJedis.zrangeByScoreWithScores(paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3);
  }

  public Set<Tuple> zrangeByScoreWithScores(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3, int paramInt1, int paramInt2)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte1);
    return localJedis.zrangeByScoreWithScores(paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3, paramInt1, paramInt2);
  }

  public Set<byte[]> zrangeByScore(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3, int paramInt1, int paramInt2)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte1);
    return localJedis.zrangeByScore(paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3, paramInt1, paramInt2);
  }

  public Set<byte[]> zrevrangeByScore(byte[] paramArrayOfByte, double paramDouble1, double paramDouble2)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte);
    return localJedis.zrevrangeByScore(paramArrayOfByte, paramDouble1, paramDouble2);
  }

  public Set<byte[]> zrevrangeByScore(byte[] paramArrayOfByte, double paramDouble1, double paramDouble2, int paramInt1, int paramInt2)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte);
    return localJedis.zrevrangeByScore(paramArrayOfByte, paramDouble1, paramDouble2, paramInt1, paramInt2);
  }

  public Set<Tuple> zrevrangeByScoreWithScores(byte[] paramArrayOfByte, double paramDouble1, double paramDouble2)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte);
    return localJedis.zrevrangeByScoreWithScores(paramArrayOfByte, paramDouble1, paramDouble2);
  }

  public Set<Tuple> zrevrangeByScoreWithScores(byte[] paramArrayOfByte, double paramDouble1, double paramDouble2, int paramInt1, int paramInt2)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte);
    return localJedis.zrevrangeByScoreWithScores(paramArrayOfByte, paramDouble1, paramDouble2, paramInt1, paramInt2);
  }

  public Set<byte[]> zrevrangeByScore(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte1);
    return localJedis.zrevrangeByScore(paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3);
  }

  public Set<byte[]> zrevrangeByScore(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3, int paramInt1, int paramInt2)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte1);
    return localJedis.zrevrangeByScore(paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3, paramInt1, paramInt2);
  }

  public Set<Tuple> zrevrangeByScoreWithScores(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte1);
    return localJedis.zrevrangeByScoreWithScores(paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3);
  }

  public Set<Tuple> zrevrangeByScoreWithScores(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3, int paramInt1, int paramInt2)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte1);
    return localJedis.zrevrangeByScoreWithScores(paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3, paramInt1, paramInt2);
  }

  public Long zremrangeByRank(byte[] paramArrayOfByte, long paramLong1, long paramLong2)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte);
    return localJedis.zremrangeByRank(paramArrayOfByte, paramLong1, paramLong2);
  }

  public Long zremrangeByScore(byte[] paramArrayOfByte, double paramDouble1, double paramDouble2)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte);
    return localJedis.zremrangeByScore(paramArrayOfByte, paramDouble1, paramDouble2);
  }

  public Long zremrangeByScore(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte1);
    return localJedis.zremrangeByScore(paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3);
  }

  public Long linsert(byte[] paramArrayOfByte1, BinaryClient.LIST_POSITION paramLIST_POSITION, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte1);
    return localJedis.linsert(paramArrayOfByte1, paramLIST_POSITION, paramArrayOfByte2, paramArrayOfByte3);
  }

  @Deprecated
  public List<java.lang.Object> pipelined(ShardedJedisPipeline paramShardedJedisPipeline)
  {
    paramShardedJedisPipeline.setShardedJedis(this);
    paramShardedJedisPipeline.execute();
    return paramShardedJedisPipeline.getResults();
  }

  public ShardedJedisPipeline pipelined()
  {
    ShardedJedisPipeline localShardedJedisPipeline = new ShardedJedisPipeline();
    localShardedJedisPipeline.setShardedJedis(this);
    return localShardedJedisPipeline;
  }

  public Long objectRefcount(byte[] paramArrayOfByte)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte);
    return localJedis.objectRefcount(paramArrayOfByte);
  }

  public byte[] objectEncoding(byte[] paramArrayOfByte)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte);
    return localJedis.objectEncoding(paramArrayOfByte);
  }

  public Long objectIdletime(byte[] paramArrayOfByte)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte);
    return localJedis.objectIdletime(paramArrayOfByte);
  }

  public Boolean setbit(byte[] paramArrayOfByte, long paramLong, boolean paramBoolean)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte);
    return localJedis.setbit(paramArrayOfByte, paramLong, paramBoolean);
  }

  public Boolean setbit(byte[] paramArrayOfByte1, long paramLong, byte[] paramArrayOfByte2)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte1);
    return localJedis.setbit(paramArrayOfByte1, paramLong, paramArrayOfByte2);
  }

  public Boolean getbit(byte[] paramArrayOfByte, long paramLong)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte);
    return localJedis.getbit(paramArrayOfByte, paramLong);
  }

  public Long setrange(byte[] paramArrayOfByte1, long paramLong, byte[] paramArrayOfByte2)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte1);
    return localJedis.setrange(paramArrayOfByte1, paramLong, paramArrayOfByte2);
  }

  public byte[] getrange(byte[] paramArrayOfByte, long paramLong1, long paramLong2)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte);
    return localJedis.getrange(paramArrayOfByte, paramLong1, paramLong2);
  }

  public Long move(byte[] paramArrayOfByte, int paramInt)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte);
    return localJedis.move(paramArrayOfByte, paramInt);
  }

  public byte[] echo(byte[] paramArrayOfByte)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte);
    return localJedis.echo(paramArrayOfByte);
  }

  public List<byte[]> brpop(byte[] paramArrayOfByte)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte);
    return localJedis.brpop(paramArrayOfByte);
  }

  public List<byte[]> blpop(byte[] paramArrayOfByte)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte);
    return localJedis.blpop(paramArrayOfByte);
  }

  public Long bitcount(byte[] paramArrayOfByte)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte);
    return localJedis.bitcount(paramArrayOfByte);
  }

  public Long bitcount(byte[] paramArrayOfByte, long paramLong1, long paramLong2)
  {
    Jedis localJedis = (Jedis)getShard(paramArrayOfByte);
    return localJedis.bitcount(paramArrayOfByte, paramLong1, paramLong2);
  }
}