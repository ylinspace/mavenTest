package com.ycache.redis.clients.jedis;

import [B;
import com.ycache.redis.clients.jedis.exceptions.JedisConnectionException;
import com.ycache.redis.clients.jedis.exceptions.JedisDataException;
import com.ycache.redis.clients.jedis.exceptions.JedisException;
import com.ycache.redis.clients.util.RedisInputStream;
import com.ycache.redis.clients.util.RedisOutputStream;
import com.ycache.redis.clients.util.SafeEncoder;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.List;

public class Connection
{
  private String host;
  private int port = 6379;
  private Socket socket;
  private RedisOutputStream outputStream;
  private RedisInputStream inputStream;
  private int pipelinedCommands = 0;
  private int timeout = 2000;

  public Socket getSocket()
  {
    return this.socket;
  }

  public int getTimeout()
  {
    return this.timeout;
  }

  public void setTimeout(int paramInt)
  {
    this.timeout = paramInt;
  }

  public void setTimeoutInfinite()
  {
    try
    {
      if (!(isConnected()))
        connect();
      this.socket.setKeepAlive(true);
      this.socket.setSoTimeout(0);
    }
    catch (SocketException localSocketException)
    {
      throw new JedisException(localSocketException);
    }
  }

  public void rollbackTimeout()
  {
    try
    {
      this.socket.setSoTimeout(this.timeout);
      this.socket.setKeepAlive(false);
    }
    catch (SocketException localSocketException)
    {
      throw new JedisException(localSocketException);
    }
  }

  public Connection(String paramString)
  {
    this.host = paramString;
  }

  protected void flush()
  {
    try
    {
      this.outputStream.flush();
    }
    catch (IOException localIOException)
    {
      throw new JedisConnectionException(localIOException);
    }
  }

  protected Connection sendCommand(Protocol.Command paramCommand, String[] paramArrayOfString)
  {
    [B[] arrayOf[B = new byte[paramArrayOfString.length][];
    for (int i = 0; i < paramArrayOfString.length; ++i)
      arrayOf[B[i] = SafeEncoder.encode(paramArrayOfString[i]);
    return sendCommand(paramCommand, arrayOf[B);
  }

  protected Connection sendCommand(Protocol.Command paramCommand, byte[][] paramArrayOfByte)
  {
    connect();
    Protocol.sendCommand(this.outputStream, paramCommand, paramArrayOfByte);
    this.pipelinedCommands += 1;
    return this;
  }

  protected Connection sendCommand(Protocol.Command paramCommand)
  {
    connect();
    Protocol.sendCommand(this.outputStream, paramCommand, new byte[0][]);
    this.pipelinedCommands += 1;
    return this;
  }

  public Connection(String paramString, int paramInt)
  {
    this.host = paramString;
    this.port = paramInt;
  }

  public String getHost()
  {
    return this.host;
  }

  public void setHost(String paramString)
  {
    this.host = paramString;
  }

  public int getPort()
  {
    return this.port;
  }

  public void setPort(int paramInt)
  {
    this.port = paramInt;
  }

  public Connection()
  {
  }

  public void connect()
  {
    if (!(isConnected()))
      try
      {
        this.socket = new Socket();
        this.socket.setReuseAddress(true);
        this.socket.setKeepAlive(true);
        this.socket.setTcpNoDelay(true);
        this.socket.setSoLinger(true, 0);
        this.socket.connect(new InetSocketAddress(this.host, this.port), this.timeout);
        this.socket.setSoTimeout(this.timeout);
        this.outputStream = new RedisOutputStream(this.socket.getOutputStream());
        this.inputStream = new RedisInputStream(this.socket.getInputStream());
      }
      catch (IOException localIOException)
      {
        throw new JedisConnectionException(localIOException);
      }
  }

  public void disconnect()
  {
    if (isConnected())
      try
      {
        this.inputStream.close();
        this.outputStream.close();
        if (!(this.socket.isClosed()))
          this.socket.close();
      }
      catch (IOException localIOException)
      {
        throw new JedisConnectionException(localIOException);
      }
  }

  public boolean isConnected()
  {
    return ((this.socket != null) && (this.socket.isBound()) && (!(this.socket.isClosed())) && (this.socket.isConnected()) && (!(this.socket.isInputShutdown())) && (!(this.socket.isOutputShutdown())));
  }

  protected String getStatusCodeReply()
  {
    flush();
    this.pipelinedCommands -= 1;
    byte[] arrayOfByte = (byte[])(byte[])Protocol.read(this.inputStream);
    if (null == arrayOfByte)
      return null;
    return SafeEncoder.encode(arrayOfByte);
  }

  public String getBulkReply()
  {
    byte[] arrayOfByte = getBinaryBulkReply();
    if (null != arrayOfByte)
      return SafeEncoder.encode(arrayOfByte);
    return null;
  }

  public byte[] getBinaryBulkReply()
  {
    flush();
    this.pipelinedCommands -= 1;
    return ((byte[])(byte[])Protocol.read(this.inputStream));
  }

  public Long getIntegerReply()
  {
    flush();
    this.pipelinedCommands -= 1;
    return ((Long)Protocol.read(this.inputStream));
  }

  public List<String> getMultiBulkReply()
  {
    return ((List)BuilderFactory.STRING_LIST.build(getBinaryMultiBulkReply()));
  }

  public List<byte[]> getBinaryMultiBulkReply()
  {
    flush();
    this.pipelinedCommands -= 1;
    return ((List)Protocol.read(this.inputStream));
  }

  public List<Object> getObjectMultiBulkReply()
  {
    flush();
    this.pipelinedCommands -= 1;
    return ((List)Protocol.read(this.inputStream));
  }

  public List<Long> getIntegerMultiBulkReply()
  {
    flush();
    this.pipelinedCommands -= 1;
    return ((List)Protocol.read(this.inputStream));
  }

  public List<Object> getAll()
  {
    return getAll(0);
  }

  public List<Object> getAll(int paramInt)
  {
    ArrayList localArrayList = new ArrayList();
    flush();
    while (this.pipelinedCommands > paramInt)
    {
      try
      {
        localArrayList.add(Protocol.read(this.inputStream));
      }
      catch (JedisDataException localJedisDataException)
      {
        localArrayList.add(localJedisDataException);
      }
      this.pipelinedCommands -= 1;
    }
    return localArrayList;
  }

  public Object getOne()
  {
    flush();
    this.pipelinedCommands -= 1;
    return Protocol.read(this.inputStream);
  }
}