package com.ycache.redis.clients.jedis;

import com.ycache.redis.clients.jedis.exceptions.JedisConnectionException;
import com.ycache.redis.clients.util.Pool;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.logging.Logger;
import org.apache.commons.pool.impl.GenericObjectPool.Config;

public class JedisSentinelPool extends Pool<Jedis>
{
  protected GenericObjectPool.Config poolConfig;
  protected int timeout;
  protected String password;
  protected int database;
  protected Set<MasterListener> masterListeners;
  protected Logger log;
  private volatile HostAndPort currentHostMaster;

  public JedisSentinelPool(String paramString, Set<String> paramSet, GenericObjectPool.Config paramConfig)
  {
    this(paramString, paramSet, paramConfig, 2000, null, 0);
  }

  public JedisSentinelPool(String paramString, Set<String> paramSet)
  {
    this(paramString, paramSet, new GenericObjectPool.Config(), 2000, null, 0);
  }

  public JedisSentinelPool(String paramString1, Set<String> paramSet, String paramString2)
  {
    this(paramString1, paramSet, new GenericObjectPool.Config(), 2000, paramString2);
  }

  public JedisSentinelPool(String paramString1, Set<String> paramSet, GenericObjectPool.Config paramConfig, int paramInt, String paramString2)
  {
    this(paramString1, paramSet, paramConfig, paramInt, paramString2, 0);
  }

  public JedisSentinelPool(String paramString, Set<String> paramSet, GenericObjectPool.Config paramConfig, int paramInt)
  {
    this(paramString, paramSet, paramConfig, paramInt, null, 0);
  }

  public JedisSentinelPool(String paramString1, Set<String> paramSet, GenericObjectPool.Config paramConfig, String paramString2)
  {
    this(paramString1, paramSet, paramConfig, 2000, paramString2);
  }

  public JedisSentinelPool(String paramString1, Set<String> paramSet, GenericObjectPool.Config paramConfig, int paramInt1, String paramString2, int paramInt2)
  {
    this.timeout = 2000;
    this.database = 0;
    this.masterListeners = new HashSet();
    this.log = Logger.getLogger(getClass().getName());
    this.poolConfig = paramConfig;
    this.timeout = paramInt1;
    this.password = paramString2;
    this.database = paramInt2;
    HostAndPort localHostAndPort = initSentinels(paramSet, paramString1);
    initPool(localHostAndPort);
  }

  public void returnBrokenResource(BinaryJedis paramBinaryJedis)
  {
    returnBrokenResourceObject(paramBinaryJedis);
  }

  public void returnResource(BinaryJedis paramBinaryJedis)
  {
    returnResourceObject(paramBinaryJedis);
  }

  public void destroy()
  {
    Iterator localIterator = this.masterListeners.iterator();
    while (localIterator.hasNext())
    {
      MasterListener localMasterListener = (MasterListener)localIterator.next();
      localMasterListener.shutdown();
    }
    super.destroy();
  }

  public HostAndPort getCurrentHostMaster()
  {
    return this.currentHostMaster;
  }

  private void initPool(HostAndPort paramHostAndPort)
  {
    if (!(paramHostAndPort.equals(this.currentHostMaster)))
    {
      this.currentHostMaster = paramHostAndPort;
      this.log.info("Created JedisPool to master at " + paramHostAndPort);
      initPool(this.poolConfig, new JedisFactory(paramHostAndPort.host, paramHostAndPort.port, this.timeout, this.password, this.database));
    }
  }

  private HostAndPort initSentinels(Set<String> paramSet, String paramString)
  {
    String str;
    HostAndPort localHostAndPort2;
    HostAndPort localHostAndPort1 = null;
    int i = 1;
    if (i != 0)
    {
      this.log.info("Trying to find master from available Sentinels...");
      Iterator localIterator1 = paramSet.iterator();
      while (localIterator1.hasNext())
      {
        str = (String)localIterator1.next();
        localHostAndPort2 = toHostAndPort(Arrays.asList(str.split(":")));
        this.log.fine("Connecting to Sentinel " + localHostAndPort2);
        try
        {
          Jedis localJedis = new Jedis(localHostAndPort2.host, localHostAndPort2.port);
          if (localHostAndPort1 == null)
          {
            localHostAndPort1 = toHostAndPort(localJedis.sentinelGetMasterAddrByName(paramString));
            this.log.fine("Found Redis master at " + localHostAndPort1);
            localJedis.disconnect();
            break label250:
          }
        }
        catch (JedisConnectionException localJedisConnectionException)
        {
          this.log.warning("Cannot connect to sentinel running @ " + localHostAndPort2 + ". Trying next one.");
        }
      }
    }
    try
    {
      this.log.severe("All sentinels down, cannot determine where is " + paramString + " master is running... sleeping 1000ms.");
      label250: Thread.sleep(1000L);
    }
    catch (InterruptedException localIterator2)
    {
      while (true)
        localInterruptedException.printStackTrace();
      this.log.info("Redis master running at " + localHostAndPort1 + ", starting Sentinel listeners...");
      Iterator localIterator2 = paramSet.iterator();
      while (localIterator2.hasNext())
      {
        str = (String)localIterator2.next();
        localHostAndPort2 = toHostAndPort(Arrays.asList(str.split(":")));
        MasterListener localMasterListener = new MasterListener(this, paramString, localHostAndPort2.host, localHostAndPort2.port);
        this.masterListeners.add(localMasterListener);
        localMasterListener.start();
      }
    }
    return localHostAndPort1;
  }

  private HostAndPort toHostAndPort(List<String> paramList)
  {
    HostAndPort localHostAndPort = new HostAndPort(this, null);
    localHostAndPort.host = ((String)paramList.get(0));
    localHostAndPort.port = Integer.parseInt((String)paramList.get(1));
    return localHostAndPort;
  }

  protected class MasterListener extends Thread
  {
    protected String masterName;
    protected String host;
    protected int port;
    protected long subscribeRetryWaitTimeMillis;
    protected Jedis j;
    protected AtomicBoolean running;

    protected MasterListener()
    {
      this.subscribeRetryWaitTimeMillis = 5000L;
      this.running = new AtomicBoolean(false);
    }

    public MasterListener(, String paramString1, String paramString2, int paramInt)
    {
      this.subscribeRetryWaitTimeMillis = 5000L;
      this.running = new AtomicBoolean(false);
      this.masterName = paramString1;
      this.host = paramString2;
      this.port = paramInt;
    }

    public MasterListener(, String paramString1, String paramString2, int paramInt, long paramLong)
    {
      this(paramJedisSentinelPool, paramString1, paramString2, paramInt);
      this.subscribeRetryWaitTimeMillis = paramLong;
    }

    public void run()
    {
      this.running.set(true);
      if (this.running.get())
      {
        this.j = new Jedis(this.host, this.port);
        try
        {
          this.j.subscribe(new JedisSentinelPool.JedisPubSubAdapter(this)
          {
            public void onMessage(, String paramString2)
            {
              this.this$1.this$0.log.fine("Sentinel " + this.this$1.host + ":" + this.this$1.port + " published: " + paramString2 + ".");
              String[] arrayOfString = paramString2.split(" ");
              if (arrayOfString.length > 3)
                if (this.this$1.masterName.equals(arrayOfString[0]))
                  JedisSentinelPool.access$200(this.this$1.this$0, JedisSentinelPool.access$100(this.this$1.this$0, Arrays.asList(new String[] { arrayOfString[3], arrayOfString[4] })));
                else
                  this.this$1.this$0.log.fine("Ignoring message on +switch-master for master name " + arrayOfString[0] + ", our master name is " + this.this$1.masterName);
              else
                this.this$1.this$0.log.severe("Invalid message received on Sentinel " + this.this$1.host + ":" + this.this$1.port + " on channel +switch-master: " + paramString2);
            }
          }
          , new String[] { "+switch-master" });
        }
        catch (JedisConnectionException localJedisConnectionException)
        {
          if (this.running.get())
          {
            this.this$0.log.severe("Lost connection to Sentinel at " + this.host + ":" + this.port + ". Sleeping 5000ms and retrying.");
            try
            {
              Thread.sleep(this.subscribeRetryWaitTimeMillis);
            }
            catch (InterruptedException localInterruptedException)
            {
              localInterruptedException.printStackTrace();
            }
          }
          else
          {
            this.this$0.log.fine("Unsubscribing from Sentinel at " + this.host + ":" + this.port);
          }
        }
      }
    }

    public void shutdown()
    {
      try
      {
        this.this$0.log.fine("Shutting down listener on " + this.host + ":" + this.port);
        this.running.set(false);
        this.j.disconnect();
      }
      catch (Exception localException)
      {
        this.this$0.log.severe("Caught exception while shutting down: " + localException.getMessage());
      }
    }
  }

  protected class JedisPubSubAdapter extends JedisPubSub
  {
    public void onMessage(, String paramString2)
    {
    }

    public void onPMessage(, String paramString2, String paramString3)
    {
    }

    public void onPSubscribe(, int paramInt)
    {
    }

    public void onPUnsubscribe(, int paramInt)
    {
    }

    public void onSubscribe(, int paramInt)
    {
    }

    public void onUnsubscribe(, int paramInt)
    {
    }
  }

  private class HostAndPort
  {
    String host;
    int port;

    public boolean equals()
    {
      if (paramObject instanceof HostAndPort)
      {
        HostAndPort localHostAndPort = (HostAndPort)paramObject;
        return ((this.port == localHostAndPort.port) && (this.host.equals(localHostAndPort.host)));
      }
      return false;
    }

    public String toString()
    {
      return this.host + ":" + this.port;
    }
  }
}