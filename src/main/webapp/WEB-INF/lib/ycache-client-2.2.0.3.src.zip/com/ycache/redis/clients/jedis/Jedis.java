package com.ycache.redis.clients.jedis;

import com.ycache.redis.clients.util.SafeEncoder;
import com.ycache.redis.clients.util.Slowlog;
import java.io.Serializable;
import java.net.URI;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.List<Ljava.lang.String;>;
import java.util.Map;
import java.util.Set;

public class Jedis extends BinaryJedis
  implements JedisCommands, MultiKeyCommands, AdvancedJedisCommands, ScriptingCommands
{
  public Jedis(String paramString)
  {
    super(paramString);
  }

  public Jedis(String paramString, int paramInt)
  {
    super(paramString, paramInt);
  }

  public Jedis(String paramString, int paramInt1, int paramInt2)
  {
    super(paramString, paramInt1, paramInt2);
  }

  public Jedis(JedisShardInfo paramJedisShardInfo)
  {
    super(paramJedisShardInfo);
  }

  public Jedis(URI paramURI)
  {
    super(paramURI);
  }

  public String set(String paramString1, String paramString2)
  {
    checkIsInMulti();
    this.client.set(paramString1, paramString2);
    return this.client.getStatusCodeReply();
  }

  public String set(String paramString1, String paramString2, String paramString3, String paramString4, long paramLong)
  {
    checkIsInMulti();
    this.client.set(paramString1, paramString2, paramString3, paramString4, paramLong);
    return this.client.getStatusCodeReply();
  }

  public String get(String paramString)
  {
    checkIsInMulti();
    this.client.sendCommand(Protocol.Command.GET, new String[] { paramString });
    return this.client.getBulkReply();
  }

  public Boolean exists(String paramString)
  {
    checkIsInMulti();
    this.client.exists(paramString);
    return Boolean.valueOf(this.client.getIntegerReply().longValue() == -6318801176305336319L);
  }

  public Long del(String[] paramArrayOfString)
  {
    checkIsInMulti();
    this.client.del(paramArrayOfString);
    return this.client.getIntegerReply();
  }

  public Long del(String paramString)
  {
    this.client.del(new String[] { paramString });
    return this.client.getIntegerReply();
  }

  public String type(String paramString)
  {
    checkIsInMulti();
    this.client.type(paramString);
    return this.client.getStatusCodeReply();
  }

  public Set<String> keys(String paramString)
  {
    checkIsInMulti();
    this.client.keys(paramString);
    return ((Set)BuilderFactory.STRING_SET.build(this.client.getBinaryMultiBulkReply()));
  }

  public String randomKey()
  {
    checkIsInMulti();
    this.client.randomKey();
    return this.client.getBulkReply();
  }

  public String rename(String paramString1, String paramString2)
  {
    checkIsInMulti();
    this.client.rename(paramString1, paramString2);
    return this.client.getStatusCodeReply();
  }

  public Long renamenx(String paramString1, String paramString2)
  {
    checkIsInMulti();
    this.client.renamenx(paramString1, paramString2);
    return this.client.getIntegerReply();
  }

  public Long expire(String paramString, int paramInt)
  {
    checkIsInMulti();
    this.client.expire(paramString, paramInt);
    return this.client.getIntegerReply();
  }

  public Long expireAt(String paramString, long paramLong)
  {
    checkIsInMulti();
    this.client.expireAt(paramString, paramLong);
    return this.client.getIntegerReply();
  }

  public Long ttl(String paramString)
  {
    checkIsInMulti();
    this.client.ttl(paramString);
    return this.client.getIntegerReply();
  }

  public Long move(String paramString, int paramInt)
  {
    checkIsInMulti();
    this.client.move(paramString, paramInt);
    return this.client.getIntegerReply();
  }

  public String getSet(String paramString1, String paramString2)
  {
    checkIsInMulti();
    this.client.getSet(paramString1, paramString2);
    return this.client.getBulkReply();
  }

  public List<String> mget(String[] paramArrayOfString)
  {
    checkIsInMulti();
    this.client.mget(paramArrayOfString);
    return this.client.getMultiBulkReply();
  }

  public Long setnx(String paramString1, String paramString2)
  {
    checkIsInMulti();
    this.client.setnx(paramString1, paramString2);
    return this.client.getIntegerReply();
  }

  public String setex(String paramString1, int paramInt, String paramString2)
  {
    checkIsInMulti();
    this.client.setex(paramString1, paramInt, paramString2);
    return this.client.getStatusCodeReply();
  }

  public String mset(String[] paramArrayOfString)
  {
    checkIsInMulti();
    this.client.mset(paramArrayOfString);
    return this.client.getStatusCodeReply();
  }

  public Long msetnx(String[] paramArrayOfString)
  {
    checkIsInMulti();
    this.client.msetnx(paramArrayOfString);
    return this.client.getIntegerReply();
  }

  public Long decrBy(String paramString, long paramLong)
  {
    checkIsInMulti();
    this.client.decrBy(paramString, paramLong);
    return this.client.getIntegerReply();
  }

  public Long decr(String paramString)
  {
    checkIsInMulti();
    this.client.decr(paramString);
    return this.client.getIntegerReply();
  }

  public Long incrBy(String paramString, long paramLong)
  {
    checkIsInMulti();
    this.client.incrBy(paramString, paramLong);
    return this.client.getIntegerReply();
  }

  public Long incr(String paramString)
  {
    checkIsInMulti();
    this.client.incr(paramString);
    return this.client.getIntegerReply();
  }

  public Long append(String paramString1, String paramString2)
  {
    checkIsInMulti();
    this.client.append(paramString1, paramString2);
    return this.client.getIntegerReply();
  }

  public String substr(String paramString, int paramInt1, int paramInt2)
  {
    checkIsInMulti();
    this.client.substr(paramString, paramInt1, paramInt2);
    return this.client.getBulkReply();
  }

  public Long hset(String paramString1, String paramString2, String paramString3)
  {
    checkIsInMulti();
    this.client.hset(paramString1, paramString2, paramString3);
    return this.client.getIntegerReply();
  }

  public String hget(String paramString1, String paramString2)
  {
    checkIsInMulti();
    this.client.hget(paramString1, paramString2);
    return this.client.getBulkReply();
  }

  public Long hsetnx(String paramString1, String paramString2, String paramString3)
  {
    checkIsInMulti();
    this.client.hsetnx(paramString1, paramString2, paramString3);
    return this.client.getIntegerReply();
  }

  public String hmset(String paramString, Map<String, String> paramMap)
  {
    checkIsInMulti();
    this.client.hmset(paramString, paramMap);
    return this.client.getStatusCodeReply();
  }

  public List<String> hmget(String paramString, String[] paramArrayOfString)
  {
    checkIsInMulti();
    this.client.hmget(paramString, paramArrayOfString);
    return this.client.getMultiBulkReply();
  }

  public Long hincrBy(String paramString1, String paramString2, long paramLong)
  {
    checkIsInMulti();
    this.client.hincrBy(paramString1, paramString2, paramLong);
    return this.client.getIntegerReply();
  }

  public Boolean hexists(String paramString1, String paramString2)
  {
    checkIsInMulti();
    this.client.hexists(paramString1, paramString2);
    return Boolean.valueOf(this.client.getIntegerReply().longValue() == -6318801176305336319L);
  }

  public Long hdel(String paramString, String[] paramArrayOfString)
  {
    checkIsInMulti();
    this.client.hdel(paramString, paramArrayOfString);
    return this.client.getIntegerReply();
  }

  public Long hlen(String paramString)
  {
    checkIsInMulti();
    this.client.hlen(paramString);
    return this.client.getIntegerReply();
  }

  public Set<String> hkeys(String paramString)
  {
    checkIsInMulti();
    this.client.hkeys(paramString);
    return ((Set)BuilderFactory.STRING_SET.build(this.client.getBinaryMultiBulkReply()));
  }

  public List<String> hvals(String paramString)
  {
    checkIsInMulti();
    this.client.hvals(paramString);
    List localList = this.client.getMultiBulkReply();
    return localList;
  }

  public Map<String, String> hgetAll(String paramString)
  {
    checkIsInMulti();
    this.client.hgetAll(paramString);
    return ((Map)BuilderFactory.STRING_MAP.build(this.client.getBinaryMultiBulkReply()));
  }

  public Long rpush(String paramString, String[] paramArrayOfString)
  {
    checkIsInMulti();
    this.client.rpush(paramString, paramArrayOfString);
    return this.client.getIntegerReply();
  }

  public Long lpush(String paramString, String[] paramArrayOfString)
  {
    checkIsInMulti();
    this.client.lpush(paramString, paramArrayOfString);
    return this.client.getIntegerReply();
  }

  public Long llen(String paramString)
  {
    checkIsInMulti();
    this.client.llen(paramString);
    return this.client.getIntegerReply();
  }

  public List<String> lrange(String paramString, long paramLong1, long paramLong2)
  {
    checkIsInMulti();
    this.client.lrange(paramString, paramLong1, paramLong2);
    return this.client.getMultiBulkReply();
  }

  public String ltrim(String paramString, long paramLong1, long paramLong2)
  {
    checkIsInMulti();
    this.client.ltrim(paramString, paramLong1, paramLong2);
    return this.client.getStatusCodeReply();
  }

  public String lindex(String paramString, long paramLong)
  {
    checkIsInMulti();
    this.client.lindex(paramString, paramLong);
    return this.client.getBulkReply();
  }

  public String lset(String paramString1, long paramLong, String paramString2)
  {
    checkIsInMulti();
    this.client.lset(paramString1, paramLong, paramString2);
    return this.client.getStatusCodeReply();
  }

  public Long lrem(String paramString1, long paramLong, String paramString2)
  {
    checkIsInMulti();
    this.client.lrem(paramString1, paramLong, paramString2);
    return this.client.getIntegerReply();
  }

  public String lpop(String paramString)
  {
    checkIsInMulti();
    this.client.lpop(paramString);
    return this.client.getBulkReply();
  }

  public String rpop(String paramString)
  {
    checkIsInMulti();
    this.client.rpop(paramString);
    return this.client.getBulkReply();
  }

  public String rpoplpush(String paramString1, String paramString2)
  {
    checkIsInMulti();
    this.client.rpoplpush(paramString1, paramString2);
    return this.client.getBulkReply();
  }

  public Long sadd(String paramString, String[] paramArrayOfString)
  {
    checkIsInMulti();
    this.client.sadd(paramString, paramArrayOfString);
    return this.client.getIntegerReply();
  }

  public Set<String> smembers(String paramString)
  {
    checkIsInMulti();
    this.client.smembers(paramString);
    List localList = this.client.getMultiBulkReply();
    return new HashSet(localList);
  }

  public Long srem(String paramString, String[] paramArrayOfString)
  {
    checkIsInMulti();
    this.client.srem(paramString, paramArrayOfString);
    return this.client.getIntegerReply();
  }

  public String spop(String paramString)
  {
    checkIsInMulti();
    this.client.spop(paramString);
    return this.client.getBulkReply();
  }

  public Long smove(String paramString1, String paramString2, String paramString3)
  {
    checkIsInMulti();
    this.client.smove(paramString1, paramString2, paramString3);
    return this.client.getIntegerReply();
  }

  public Long scard(String paramString)
  {
    checkIsInMulti();
    this.client.scard(paramString);
    return this.client.getIntegerReply();
  }

  public Boolean sismember(String paramString1, String paramString2)
  {
    checkIsInMulti();
    this.client.sismember(paramString1, paramString2);
    return Boolean.valueOf(this.client.getIntegerReply().longValue() == -6318801176305336319L);
  }

  public Set<String> sinter(String[] paramArrayOfString)
  {
    checkIsInMulti();
    this.client.sinter(paramArrayOfString);
    List localList = this.client.getMultiBulkReply();
    return new HashSet(localList);
  }

  public Long sinterstore(String paramString, String[] paramArrayOfString)
  {
    checkIsInMulti();
    this.client.sinterstore(paramString, paramArrayOfString);
    return this.client.getIntegerReply();
  }

  public Set<String> sunion(String[] paramArrayOfString)
  {
    checkIsInMulti();
    this.client.sunion(paramArrayOfString);
    List localList = this.client.getMultiBulkReply();
    return new HashSet(localList);
  }

  public Long sunionstore(String paramString, String[] paramArrayOfString)
  {
    checkIsInMulti();
    this.client.sunionstore(paramString, paramArrayOfString);
    return this.client.getIntegerReply();
  }

  public Set<String> sdiff(String[] paramArrayOfString)
  {
    checkIsInMulti();
    this.client.sdiff(paramArrayOfString);
    return ((Set)BuilderFactory.STRING_SET.build(this.client.getBinaryMultiBulkReply()));
  }

  public Long sdiffstore(String paramString, String[] paramArrayOfString)
  {
    checkIsInMulti();
    this.client.sdiffstore(paramString, paramArrayOfString);
    return this.client.getIntegerReply();
  }

  public String srandmember(String paramString)
  {
    checkIsInMulti();
    this.client.srandmember(paramString);
    return this.client.getBulkReply();
  }

  public List<String> srandmember(String paramString, int paramInt)
  {
    checkIsInMulti();
    this.client.srandmember(paramString, paramInt);
    return this.client.getMultiBulkReply();
  }

  public Long zadd(String paramString1, double paramDouble, String paramString2)
  {
    checkIsInMulti();
    this.client.zadd(paramString1, paramDouble, paramString2);
    return this.client.getIntegerReply();
  }

  public Long zadd(String paramString, Map<Double, String> paramMap)
  {
    checkIsInMulti();
    this.client.zadd(paramString, paramMap);
    return this.client.getIntegerReply();
  }

  public Set<String> zrange(String paramString, long paramLong1, long paramLong2)
  {
    checkIsInMulti();
    this.client.zrange(paramString, paramLong1, paramLong2);
    List localList = this.client.getMultiBulkReply();
    return new LinkedHashSet(localList);
  }

  public Long zrem(String paramString, String[] paramArrayOfString)
  {
    checkIsInMulti();
    this.client.zrem(paramString, paramArrayOfString);
    return this.client.getIntegerReply();
  }

  public Double zincrby(String paramString1, double paramDouble, String paramString2)
  {
    checkIsInMulti();
    this.client.zincrby(paramString1, paramDouble, paramString2);
    String str = this.client.getBulkReply();
    return Double.valueOf(str);
  }

  public Long zrank(String paramString1, String paramString2)
  {
    checkIsInMulti();
    this.client.zrank(paramString1, paramString2);
    return this.client.getIntegerReply();
  }

  public Long zrevrank(String paramString1, String paramString2)
  {
    checkIsInMulti();
    this.client.zrevrank(paramString1, paramString2);
    return this.client.getIntegerReply();
  }

  public Set<String> zrevrange(String paramString, long paramLong1, long paramLong2)
  {
    checkIsInMulti();
    this.client.zrevrange(paramString, paramLong1, paramLong2);
    List localList = this.client.getMultiBulkReply();
    return new LinkedHashSet(localList);
  }

  public Set<Tuple> zrangeWithScores(String paramString, long paramLong1, long paramLong2)
  {
    checkIsInMulti();
    this.client.zrangeWithScores(paramString, paramLong1, paramLong2);
    Set localSet = getTupledSet();
    return localSet;
  }

  public Set<Tuple> zrevrangeWithScores(String paramString, long paramLong1, long paramLong2)
  {
    checkIsInMulti();
    this.client.zrevrangeWithScores(paramString, paramLong1, paramLong2);
    Set localSet = getTupledSet();
    return localSet;
  }

  public Long zcard(String paramString)
  {
    checkIsInMulti();
    this.client.zcard(paramString);
    return this.client.getIntegerReply();
  }

  public Double zscore(String paramString1, String paramString2)
  {
    checkIsInMulti();
    this.client.zscore(paramString1, paramString2);
    String str = this.client.getBulkReply();
    return ((str != null) ? new Double(str) : null);
  }

  public String watch(String[] paramArrayOfString)
  {
    this.client.watch(paramArrayOfString);
    return this.client.getStatusCodeReply();
  }

  public List<String> sort(String paramString)
  {
    checkIsInMulti();
    this.client.sort(paramString);
    return this.client.getMultiBulkReply();
  }

  public List<String> sort(String paramString, SortingParams paramSortingParams)
  {
    checkIsInMulti();
    this.client.sort(paramString, paramSortingParams);
    return this.client.getMultiBulkReply();
  }

  public List<String> blpop(int paramInt, String[] paramArrayOfString)
  {
    checkIsInMulti();
    ArrayList localArrayList = new ArrayList();
    Object localObject1 = paramArrayOfString;
    int i = localObject1.length;
    for (int j = 0; j < i; ++j)
    {
      Object localObject2 = localObject1[j];
      localArrayList.add(localObject2);
    }
    localArrayList.add(String.valueOf(paramInt));
    this.client.blpop((String[])localArrayList.toArray(new String[localArrayList.size()]));
    this.client.setTimeoutInfinite();
    localObject1 = this.client.getMultiBulkReply();
    this.client.rollbackTimeout();
    return ((List<String>)localObject1);
  }

  public List<String> blpop(String[] paramArrayOfString)
  {
    this.client.blpop(paramArrayOfString);
    this.client.setTimeoutInfinite();
    List localList = this.client.getMultiBulkReply();
    this.client.rollbackTimeout();
    return localList;
  }

  public List<String> brpop(String[] paramArrayOfString)
  {
    this.client.brpop(paramArrayOfString);
    this.client.setTimeoutInfinite();
    List localList = this.client.getMultiBulkReply();
    this.client.rollbackTimeout();
    return localList;
  }

  public List<String> blpop(String paramString)
  {
    String[] arrayOfString = new String[1];
    arrayOfString[0] = paramString;
    this.client.blpop(arrayOfString);
    this.client.setTimeoutInfinite();
    List localList = this.client.getMultiBulkReply();
    this.client.rollbackTimeout();
    return localList;
  }

  public List<String> brpop(String paramString)
  {
    String[] arrayOfString = new String[1];
    arrayOfString[0] = paramString;
    this.client.brpop(arrayOfString);
    this.client.setTimeoutInfinite();
    List localList = this.client.getMultiBulkReply();
    this.client.rollbackTimeout();
    return localList;
  }

  public Long sort(String paramString1, SortingParams paramSortingParams, String paramString2)
  {
    checkIsInMulti();
    this.client.sort(paramString1, paramSortingParams, paramString2);
    return this.client.getIntegerReply();
  }

  public Long sort(String paramString1, String paramString2)
  {
    checkIsInMulti();
    this.client.sort(paramString1, paramString2);
    return this.client.getIntegerReply();
  }

  public List<String> brpop(int paramInt, String[] paramArrayOfString)
  {
    checkIsInMulti();
    ArrayList localArrayList = new ArrayList();
    Object localObject1 = paramArrayOfString;
    int i = localObject1.length;
    for (int j = 0; j < i; ++j)
    {
      Object localObject2 = localObject1[j];
      localArrayList.add(localObject2);
    }
    localArrayList.add(String.valueOf(paramInt));
    this.client.brpop((String[])localArrayList.toArray(new String[localArrayList.size()]));
    this.client.setTimeoutInfinite();
    localObject1 = this.client.getMultiBulkReply();
    this.client.rollbackTimeout();
    return ((List<String>)localObject1);
  }

  public Long zcount(String paramString, double paramDouble1, double paramDouble2)
  {
    checkIsInMulti();
    this.client.zcount(paramString, paramDouble1, paramDouble2);
    return this.client.getIntegerReply();
  }

  public Long zcount(String paramString1, String paramString2, String paramString3)
  {
    checkIsInMulti();
    this.client.zcount(paramString1, paramString2, paramString3);
    return this.client.getIntegerReply();
  }

  public Set<String> zrangeByScore(String paramString, double paramDouble1, double paramDouble2)
  {
    checkIsInMulti();
    this.client.zrangeByScore(paramString, paramDouble1, paramDouble2);
    return new LinkedHashSet(this.client.getMultiBulkReply());
  }

  public Set<String> zrangeByScore(String paramString1, String paramString2, String paramString3)
  {
    checkIsInMulti();
    this.client.zrangeByScore(paramString1, paramString2, paramString3);
    return new LinkedHashSet(this.client.getMultiBulkReply());
  }

  public Set<String> zrangeByScore(String paramString, double paramDouble1, double paramDouble2, int paramInt1, int paramInt2)
  {
    checkIsInMulti();
    this.client.zrangeByScore(paramString, paramDouble1, paramDouble2, paramInt1, paramInt2);
    return new LinkedHashSet(this.client.getMultiBulkReply());
  }

  public Set<String> zrangeByScore(String paramString1, String paramString2, String paramString3, int paramInt1, int paramInt2)
  {
    checkIsInMulti();
    this.client.zrangeByScore(paramString1, paramString2, paramString3, paramInt1, paramInt2);
    return new LinkedHashSet(this.client.getMultiBulkReply());
  }

  public Set<Tuple> zrangeByScoreWithScores(String paramString, double paramDouble1, double paramDouble2)
  {
    checkIsInMulti();
    this.client.zrangeByScoreWithScores(paramString, paramDouble1, paramDouble2);
    Set localSet = getTupledSet();
    return localSet;
  }

  public Set<Tuple> zrangeByScoreWithScores(String paramString1, String paramString2, String paramString3)
  {
    checkIsInMulti();
    this.client.zrangeByScoreWithScores(paramString1, paramString2, paramString3);
    Set localSet = getTupledSet();
    return localSet;
  }

  public Set<Tuple> zrangeByScoreWithScores(String paramString, double paramDouble1, double paramDouble2, int paramInt1, int paramInt2)
  {
    checkIsInMulti();
    this.client.zrangeByScoreWithScores(paramString, paramDouble1, paramDouble2, paramInt1, paramInt2);
    Set localSet = getTupledSet();
    return localSet;
  }

  public Set<Tuple> zrangeByScoreWithScores(String paramString1, String paramString2, String paramString3, int paramInt1, int paramInt2)
  {
    checkIsInMulti();
    this.client.zrangeByScoreWithScores(paramString1, paramString2, paramString3, paramInt1, paramInt2);
    Set localSet = getTupledSet();
    return localSet;
  }

  private Set<Tuple> getTupledSet()
  {
    checkIsInMulti();
    List localList = this.client.getMultiBulkReply();
    LinkedHashSet localLinkedHashSet = new LinkedHashSet();
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
      localLinkedHashSet.add(new Tuple((String)localIterator.next(), Double.valueOf((String)localIterator.next())));
    return localLinkedHashSet;
  }

  public Set<String> zrevrangeByScore(String paramString, double paramDouble1, double paramDouble2)
  {
    checkIsInMulti();
    this.client.zrevrangeByScore(paramString, paramDouble1, paramDouble2);
    return new LinkedHashSet(this.client.getMultiBulkReply());
  }

  public Set<String> zrevrangeByScore(String paramString1, String paramString2, String paramString3)
  {
    checkIsInMulti();
    this.client.zrevrangeByScore(paramString1, paramString2, paramString3);
    return new LinkedHashSet(this.client.getMultiBulkReply());
  }

  public Set<String> zrevrangeByScore(String paramString, double paramDouble1, double paramDouble2, int paramInt1, int paramInt2)
  {
    checkIsInMulti();
    this.client.zrevrangeByScore(paramString, paramDouble1, paramDouble2, paramInt1, paramInt2);
    return new LinkedHashSet(this.client.getMultiBulkReply());
  }

  public Set<Tuple> zrevrangeByScoreWithScores(String paramString, double paramDouble1, double paramDouble2)
  {
    checkIsInMulti();
    this.client.zrevrangeByScoreWithScores(paramString, paramDouble1, paramDouble2);
    Set localSet = getTupledSet();
    return localSet;
  }

  public Set<Tuple> zrevrangeByScoreWithScores(String paramString, double paramDouble1, double paramDouble2, int paramInt1, int paramInt2)
  {
    checkIsInMulti();
    this.client.zrevrangeByScoreWithScores(paramString, paramDouble1, paramDouble2, paramInt1, paramInt2);
    Set localSet = getTupledSet();
    return localSet;
  }

  public Set<Tuple> zrevrangeByScoreWithScores(String paramString1, String paramString2, String paramString3, int paramInt1, int paramInt2)
  {
    checkIsInMulti();
    this.client.zrevrangeByScoreWithScores(paramString1, paramString2, paramString3, paramInt1, paramInt2);
    Set localSet = getTupledSet();
    return localSet;
  }

  public Set<String> zrevrangeByScore(String paramString1, String paramString2, String paramString3, int paramInt1, int paramInt2)
  {
    checkIsInMulti();
    this.client.zrevrangeByScore(paramString1, paramString2, paramString3, paramInt1, paramInt2);
    return new LinkedHashSet(this.client.getMultiBulkReply());
  }

  public Set<Tuple> zrevrangeByScoreWithScores(String paramString1, String paramString2, String paramString3)
  {
    checkIsInMulti();
    this.client.zrevrangeByScoreWithScores(paramString1, paramString2, paramString3);
    Set localSet = getTupledSet();
    return localSet;
  }

  public Long zremrangeByRank(String paramString, long paramLong1, long paramLong2)
  {
    checkIsInMulti();
    this.client.zremrangeByRank(paramString, paramLong1, paramLong2);
    return this.client.getIntegerReply();
  }

  public Long zremrangeByScore(String paramString, double paramDouble1, double paramDouble2)
  {
    checkIsInMulti();
    this.client.zremrangeByScore(paramString, paramDouble1, paramDouble2);
    return this.client.getIntegerReply();
  }

  public Long zremrangeByScore(String paramString1, String paramString2, String paramString3)
  {
    checkIsInMulti();
    this.client.zremrangeByScore(paramString1, paramString2, paramString3);
    return this.client.getIntegerReply();
  }

  public Long zunionstore(String paramString, String[] paramArrayOfString)
  {
    checkIsInMulti();
    this.client.zunionstore(paramString, paramArrayOfString);
    return this.client.getIntegerReply();
  }

  public Long zunionstore(String paramString, ZParams paramZParams, String[] paramArrayOfString)
  {
    checkIsInMulti();
    this.client.zunionstore(paramString, paramZParams, paramArrayOfString);
    return this.client.getIntegerReply();
  }

  public Long zinterstore(String paramString, String[] paramArrayOfString)
  {
    checkIsInMulti();
    this.client.zinterstore(paramString, paramArrayOfString);
    return this.client.getIntegerReply();
  }

  public Long zinterstore(String paramString, ZParams paramZParams, String[] paramArrayOfString)
  {
    checkIsInMulti();
    this.client.zinterstore(paramString, paramZParams, paramArrayOfString);
    return this.client.getIntegerReply();
  }

  public Long strlen(String paramString)
  {
    this.client.strlen(paramString);
    return this.client.getIntegerReply();
  }

  public Long lpushx(String paramString, String[] paramArrayOfString)
  {
    this.client.lpushx(paramString, paramArrayOfString);
    return this.client.getIntegerReply();
  }

  public Long persist(String paramString)
  {
    this.client.persist(paramString);
    return this.client.getIntegerReply();
  }

  public Long rpushx(String paramString, String[] paramArrayOfString)
  {
    this.client.rpushx(paramString, paramArrayOfString);
    return this.client.getIntegerReply();
  }

  public String echo(String paramString)
  {
    this.client.echo(paramString);
    return this.client.getBulkReply();
  }

  public Long linsert(String paramString1, BinaryClient.LIST_POSITION paramLIST_POSITION, String paramString2, String paramString3)
  {
    this.client.linsert(paramString1, paramLIST_POSITION, paramString2, paramString3);
    return this.client.getIntegerReply();
  }

  public String brpoplpush(String paramString1, String paramString2, int paramInt)
  {
    this.client.brpoplpush(paramString1, paramString2, paramInt);
    this.client.setTimeoutInfinite();
    String str = this.client.getBulkReply();
    this.client.rollbackTimeout();
    return str;
  }

  public Boolean setbit(String paramString, long paramLong, boolean paramBoolean)
  {
    this.client.setbit(paramString, paramLong, paramBoolean);
    return Boolean.valueOf(this.client.getIntegerReply().longValue() == -6318801176305336319L);
  }

  public Boolean setbit(String paramString1, long paramLong, String paramString2)
  {
    this.client.setbit(paramString1, paramLong, paramString2);
    return Boolean.valueOf(this.client.getIntegerReply().longValue() == -6318801176305336319L);
  }

  public Boolean getbit(String paramString, long paramLong)
  {
    this.client.getbit(paramString, paramLong);
    return Boolean.valueOf(this.client.getIntegerReply().longValue() == -6318801176305336319L);
  }

  public Long setrange(String paramString1, long paramLong, String paramString2)
  {
    this.client.setrange(paramString1, paramLong, paramString2);
    return this.client.getIntegerReply();
  }

  public String getrange(String paramString, long paramLong1, long paramLong2)
  {
    this.client.getrange(paramString, paramLong1, paramLong2);
    return this.client.getBulkReply();
  }

  public List<String> configGet(String paramString)
  {
    this.client.configGet(paramString);
    return this.client.getMultiBulkReply();
  }

  public String configSet(String paramString1, String paramString2)
  {
    this.client.configSet(paramString1, paramString2);
    return this.client.getStatusCodeReply();
  }

  public Object eval(String paramString, int paramInt, String[] paramArrayOfString)
  {
    this.client.setTimeoutInfinite();
    this.client.eval(paramString, paramInt, paramArrayOfString);
    return getEvalResult();
  }

  public void subscribe(JedisPubSub paramJedisPubSub, String[] paramArrayOfString)
  {
    this.client.setTimeoutInfinite();
    paramJedisPubSub.proceed(this.client, paramArrayOfString);
    this.client.rollbackTimeout();
  }

  public Long publish(String paramString1, String paramString2)
  {
    checkIsInMulti();
    connect();
    this.client.publish(paramString1, paramString2);
    return this.client.getIntegerReply();
  }

  public void psubscribe(JedisPubSub paramJedisPubSub, String[] paramArrayOfString)
  {
    checkIsInMulti();
    connect();
    this.client.setTimeoutInfinite();
    paramJedisPubSub.proceedWithPatterns(this.client, paramArrayOfString);
    this.client.rollbackTimeout();
  }

  protected static String[] getParams(List<String> paramList1, List<String> paramList2)
  {
    int i = paramList1.size();
    int j = paramList2.size();
    String[] arrayOfString = new String[i + paramList2.size()];
    for (int k = 0; k < i; ++k)
      arrayOfString[k] = ((String)paramList1.get(k));
    for (k = 0; k < j; ++k)
      arrayOfString[(i + k)] = ((String)paramList2.get(k));
    return arrayOfString;
  }

  public Object eval(String paramString, List<String> paramList1, List<String> paramList2)
  {
    return eval(paramString, paramList1.size(), getParams(paramList1, paramList2));
  }

  public Object eval(String paramString)
  {
    return eval(paramString, 0, new String[0]);
  }

  public Object evalsha(String paramString)
  {
    return evalsha(paramString, 0, new String[0]);
  }

  private Object getEvalResult()
  {
    Object localObject1 = this.client.getOne();
    if (localObject1 instanceof byte[])
      return SafeEncoder.encode((byte[])(byte[])localObject1);
    if (localObject1 instanceof List)
    {
      List localList = (List)localObject1;
      ArrayList localArrayList = new ArrayList(localList.size());
      Iterator localIterator = localList.iterator();
      while (localIterator.hasNext())
      {
        Object localObject2 = localIterator.next();
        localArrayList.add((localObject2 == null) ? null : SafeEncoder.encode((byte[])(byte[])localObject2));
      }
      return localArrayList;
    }
    return localObject1;
  }

  public Object evalsha(String paramString, List<String> paramList1, List<String> paramList2)
  {
    return evalsha(paramString, paramList1.size(), getParams(paramList1, paramList2));
  }

  public Object evalsha(String paramString, int paramInt, String[] paramArrayOfString)
  {
    checkIsInMulti();
    this.client.evalsha(paramString, paramInt, paramArrayOfString);
    return getEvalResult();
  }

  public Boolean scriptExists(String paramString)
  {
    String[] arrayOfString = new String[1];
    arrayOfString[0] = paramString;
    return ((Boolean)scriptExists(arrayOfString).get(0));
  }

  public List<Boolean> scriptExists(String[] paramArrayOfString)
  {
    this.client.scriptExists(paramArrayOfString);
    List localList = this.client.getIntegerMultiBulkReply();
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      Long localLong = (Long)localIterator.next();
      localArrayList.add(Boolean.valueOf(localLong.longValue() == -6318799733196324863L));
    }
    return localArrayList;
  }

  public String scriptLoad(String paramString)
  {
    this.client.scriptLoad(paramString);
    return this.client.getBulkReply();
  }

  public List<Slowlog> slowlogGet()
  {
    this.client.slowlogGet();
    return Slowlog.from(this.client.getObjectMultiBulkReply());
  }

  public List<Slowlog> slowlogGet(long paramLong)
  {
    this.client.slowlogGet(paramLong);
    return Slowlog.from(this.client.getObjectMultiBulkReply());
  }

  public Long objectRefcount(String paramString)
  {
    this.client.objectRefcount(paramString);
    return this.client.getIntegerReply();
  }

  public String objectEncoding(String paramString)
  {
    this.client.objectEncoding(paramString);
    return this.client.getBulkReply();
  }

  public Long objectIdletime(String paramString)
  {
    this.client.objectIdletime(paramString);
    return this.client.getIntegerReply();
  }

  public Long bitcount(String paramString)
  {
    this.client.bitcount(paramString);
    return this.client.getIntegerReply();
  }

  public Long bitcount(String paramString, long paramLong1, long paramLong2)
  {
    this.client.bitcount(paramString, paramLong1, paramLong2);
    return this.client.getIntegerReply();
  }

  public Long bitop(BitOP paramBitOP, String paramString, String[] paramArrayOfString)
  {
    this.client.bitop(paramBitOP, paramString, paramArrayOfString);
    return this.client.getIntegerReply();
  }

  public List<Map<String, String>> sentinelMasters()
  {
    this.client.sentinel(new String[] { "masters" });
    List localList = this.client.getObjectMultiBulkReply();
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      Object localObject = localIterator.next();
      localArrayList.add(BuilderFactory.STRING_MAP.build((List)localObject));
    }
    return localArrayList;
  }

  public List<String> sentinelGetMasterAddrByName(String paramString)
  {
    this.client.sentinel(new String[] { "get-master-addr-by-name", paramString });
    List localList = this.client.getObjectMultiBulkReply();
    return ((List)BuilderFactory.STRING_LIST.build(localList));
  }

  public Long sentinelReset(String paramString)
  {
    this.client.sentinel(new String[] { "reset", paramString });
    return this.client.getIntegerReply();
  }

  public List<Map<String, String>> sentinelSlaves(String paramString)
  {
    this.client.sentinel(new String[] { "slaves", paramString });
    List localList = this.client.getObjectMultiBulkReply();
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      Object localObject = localIterator.next();
      localArrayList.add(BuilderFactory.STRING_MAP.build((List)localObject));
    }
    return localArrayList;
  }

  public List<? extends Object> sentinelIsMasterDownByAddr(String paramString, int paramInt)
  {
    this.client.sentinel("is-master-down-by-addr", paramString, paramInt);
    List localList = this.client.getObjectMultiBulkReply();
    return Arrays.asList(new Serializable[] { (Serializable)BuilderFactory.LONG.build(localList.get(0)), (Serializable)BuilderFactory.STRING.build(localList.get(1)) });
  }

  public byte[] dump(String paramString)
  {
    checkIsInMulti();
    this.client.dump(paramString);
    return this.client.getBinaryBulkReply();
  }

  public String restore(String paramString, int paramInt, byte[] paramArrayOfByte)
  {
    checkIsInMulti();
    this.client.restore(paramString, paramInt, paramArrayOfByte);
    return this.client.getStatusCodeReply();
  }

  public Long pexpire(String paramString, int paramInt)
  {
    checkIsInMulti();
    this.client.pexpire(paramString, paramInt);
    return this.client.getIntegerReply();
  }

  public Long pexpireAt(String paramString, long paramLong)
  {
    checkIsInMulti();
    this.client.pexpireAt(paramString, paramLong);
    return this.client.getIntegerReply();
  }

  public Long pttl(String paramString)
  {
    checkIsInMulti();
    this.client.pttl(paramString);
    return this.client.getIntegerReply();
  }

  public Double incrByFloat(String paramString, double paramDouble)
  {
    checkIsInMulti();
    this.client.incrByFloat(paramString, paramDouble);
    String str = this.client.getBulkReply();
    return ((str != null) ? new Double(str) : null);
  }

  public String psetex(String paramString1, int paramInt, String paramString2)
  {
    checkIsInMulti();
    this.client.psetex(paramString1, paramInt, paramString2);
    return this.client.getStatusCodeReply();
  }

  public String set(String paramString1, String paramString2, String paramString3)
  {
    checkIsInMulti();
    this.client.set(paramString1, paramString2, paramString3);
    return this.client.getStatusCodeReply();
  }

  public String set(String paramString1, String paramString2, String paramString3, String paramString4, int paramInt)
  {
    checkIsInMulti();
    this.client.set(paramString1, paramString2, paramString3, paramString4, paramInt);
    return this.client.getStatusCodeReply();
  }

  public String clientKill(String paramString)
  {
    checkIsInMulti();
    this.client.clientKill(paramString);
    return this.client.getStatusCodeReply();
  }

  public String clientSetname(String paramString)
  {
    checkIsInMulti();
    this.client.clientSetname(paramString);
    return this.client.getStatusCodeReply();
  }

  public String migrate(String paramString1, int paramInt1, String paramString2, int paramInt2, int paramInt3)
  {
    checkIsInMulti();
    this.client.migrate(paramString1, paramInt1, paramString2, paramInt2, paramInt3);
    return this.client.getStatusCodeReply();
  }

  public Double hincrByFloat(String paramString1, String paramString2, double paramDouble)
  {
    checkIsInMulti();
    this.client.hincrByFloat(paramString1, paramString2, paramDouble);
    String str = this.client.getBulkReply();
    return ((str != null) ? new Double(str) : null);
  }
}