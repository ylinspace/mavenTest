package com.ycache.redis.clients.util;

import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.OutputStream;

public final class RedisOutputStream extends FilterOutputStream
{
  protected final byte[] buf;
  protected int count;
  private static final int[] sizeTable = { 9, 99, 999, 9999, 99999, 999999, 9999999, 99999999, 999999999, 2147483647 };
  private static final byte[] DigitTens = { 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 49, 49, 49, 49, 49, 49, 49, 49, 49, 49, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 52, 52, 52, 52, 52, 52, 52, 52, 52, 52, 53, 53, 53, 53, 53, 53, 53, 53, 53, 53, 54, 54, 54, 54, 54, 54, 54, 54, 54, 54, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 56, 56, 56, 56, 56, 56, 56, 56, 56, 56, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57 };
  private static final byte[] DigitOnes = { 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57 };
  private static final byte[] digits = { 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122 };

  public RedisOutputStream(OutputStream paramOutputStream)
  {
    this(paramOutputStream, 8192);
  }

  public RedisOutputStream(OutputStream paramOutputStream, int paramInt)
  {
    super(paramOutputStream);
    if (paramInt <= 0)
      throw new IllegalArgumentException("Buffer size <= 0");
    this.buf = new byte[paramInt];
  }

  private void flushBuffer()
    throws IOException
  {
    if (this.count > 0)
    {
      this.out.write(this.buf, 0, this.count);
      this.count = 0;
    }
  }

  public void write(byte paramByte)
    throws IOException
  {
    this.buf[(this.count++)] = paramByte;
    if (this.count == this.buf.length)
      flushBuffer();
  }

  public void write(byte[] paramArrayOfByte)
    throws IOException
  {
    write(paramArrayOfByte, 0, paramArrayOfByte.length);
  }

  public void write(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException
  {
    if (paramInt2 >= this.buf.length)
    {
      flushBuffer();
      this.out.write(paramArrayOfByte, paramInt1, paramInt2);
    }
    else
    {
      if (paramInt2 >= this.buf.length - this.count)
        flushBuffer();
      System.arraycopy(paramArrayOfByte, paramInt1, this.buf, this.count, paramInt2);
      this.count += paramInt2;
    }
  }

  public void writeAsciiCrLf(String paramString)
    throws IOException
  {
    int i = paramString.length();
    for (int j = 0; j != i; ++j)
    {
      this.buf[(this.count++)] = (byte)paramString.charAt(j);
      if (this.count == this.buf.length)
        flushBuffer();
    }
    writeCrLf();
  }

  public static boolean isSurrogate(char paramChar)
  {
    return ((paramChar >= 55296) && (paramChar <= 57343));
  }

  public static int utf8Length(String paramString)
  {
    int i = paramString.length();
    int j = 0;
    for (int k = 0; k != i; ++k)
    {
      int l = paramString.charAt(k);
      if (l < 128)
      {
        ++j;
      }
      else if (l < 2048)
      {
        j += 2;
      }
      else if (isSurrogate(l))
      {
        ++k;
        j += 4;
      }
      else
      {
        j += 3;
      }
    }
    return j;
  }

  public void writeCrLf()
    throws IOException
  {
    if (2 >= this.buf.length - this.count)
      flushBuffer();
    this.buf[(this.count++)] = 13;
    this.buf[(this.count++)] = 10;
  }

  public void writeUtf8CrLf(String paramString)
    throws IOException
  {
    int k;
    int i = paramString.length();
    for (int j = 0; j < i; ++j)
    {
      k = paramString.charAt(j);
      if (k >= 128)
        break;
      this.buf[(this.count++)] = (byte)k;
      if (this.count == this.buf.length)
        flushBuffer();
    }
    while (j < i)
    {
      k = paramString.charAt(j);
      if (k < 128)
      {
        this.buf[(this.count++)] = (byte)k;
        if (this.count == this.buf.length)
          flushBuffer();
      }
      else if (k < 2048)
      {
        if (2 >= this.buf.length - this.count)
          flushBuffer();
        this.buf[(this.count++)] = (byte)(0xC0 | k >> 6);
        this.buf[(this.count++)] = (byte)(0x80 | k & 0x3F);
      }
      else if (isSurrogate(k))
      {
        if (4 >= this.buf.length - this.count)
          flushBuffer();
        int l = Character.toCodePoint(k, paramString.charAt(j++));
        this.buf[(this.count++)] = (byte)(0xF0 | l >> 18);
        this.buf[(this.count++)] = (byte)(0x80 | l >> 12 & 0x3F);
        this.buf[(this.count++)] = (byte)(0x80 | l >> 6 & 0x3F);
        this.buf[(this.count++)] = (byte)(0x80 | l & 0x3F);
      }
      else
      {
        if (3 >= this.buf.length - this.count)
          flushBuffer();
        this.buf[(this.count++)] = (byte)(0xE0 | k >> 12);
        this.buf[(this.count++)] = (byte)(0x80 | k >> 6 & 0x3F);
        this.buf[(this.count++)] = (byte)(0x80 | k & 0x3F);
      }
      ++j;
    }
    writeCrLf();
  }

  public void writeIntCrLf(int paramInt)
    throws IOException
  {
    int j;
    int k;
    if (paramInt < 0)
    {
      write(45);
      paramInt = -paramInt;
    }
    for (int i = 0; paramInt > sizeTable[i]; ++i);
    if (++i >= this.buf.length - this.count)
      flushBuffer();
    int l = this.count + i;
    while (paramInt >= 65536)
    {
      j = paramInt / 100;
      k = paramInt - (j << 6) + (j << 5) + (j << 2);
      paramInt = j;
      this.buf[(--l)] = DigitOnes[k];
      this.buf[(--l)] = DigitTens[k];
    }
    do
    {
      j = paramInt * 52429 >>> 19;
      k = paramInt - (j << 3) + (j << 1);
      this.buf[(--l)] = digits[k];
      paramInt = j;
    }
    while (paramInt != 0);
    this.count += i;
    writeCrLf();
  }

  public void flush()
    throws IOException
  {
    flushBuffer();
    this.out.flush();
  }
}