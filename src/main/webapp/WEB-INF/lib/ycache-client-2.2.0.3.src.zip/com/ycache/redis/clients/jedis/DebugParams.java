package com.ycache.redis.clients.jedis;

public class DebugParams
{
  private String[] command;

  public String[] getCommand()
  {
    return this.command;
  }

  public static DebugParams SEGFAULT()
  {
    DebugParams localDebugParams = new DebugParams();
    localDebugParams.command = { "SEGFAULT" };
    return localDebugParams;
  }

  public static DebugParams OBJECT(String paramString)
  {
    DebugParams localDebugParams = new DebugParams();
    localDebugParams.command = { "OBJECT", paramString };
    return localDebugParams;
  }

  public static DebugParams RELOAD()
  {
    DebugParams localDebugParams = new DebugParams();
    localDebugParams.command = { "RELOAD" };
    return localDebugParams;
  }
}