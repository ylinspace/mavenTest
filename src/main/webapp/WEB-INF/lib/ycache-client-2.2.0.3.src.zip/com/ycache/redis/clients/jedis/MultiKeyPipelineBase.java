package com.ycache.redis.clients.jedis;

import java.util.List;
import java.util.Map;
import java.util.Set;

abstract class MultiKeyPipelineBase extends PipelineBase
  implements BasicRedisPipeline, MultiKeyBinaryRedisPipeline, MultiKeyCommandsPipeline
{
  protected Client client = null;

  public Response<List<String>> brpop(String[] paramArrayOfString)
  {
    this.client.brpop(paramArrayOfString);
    return getResponse(BuilderFactory.STRING_LIST);
  }

  public Response<List<String>> brpop(int paramInt, String[] paramArrayOfString)
  {
    this.client.brpop(paramInt, paramArrayOfString);
    return getResponse(BuilderFactory.STRING_LIST);
  }

  public Response<List<String>> blpop(String[] paramArrayOfString)
  {
    this.client.blpop(paramArrayOfString);
    return getResponse(BuilderFactory.STRING_LIST);
  }

  public Response<List<String>> blpop(int paramInt, String[] paramArrayOfString)
  {
    this.client.blpop(paramInt, paramArrayOfString);
    return getResponse(BuilderFactory.STRING_LIST);
  }

  public Response<Map<String, String>> blpopMap(int paramInt, String[] paramArrayOfString)
  {
    this.client.blpop(paramInt, paramArrayOfString);
    return getResponse(BuilderFactory.STRING_MAP);
  }

  public Response<List<byte[]>> brpop(byte[][] paramArrayOfByte)
  {
    this.client.brpop(paramArrayOfByte);
    return getResponse(BuilderFactory.BYTE_ARRAY_LIST);
  }

  public Response<List<String>> brpop(int paramInt, byte[][] paramArrayOfByte)
  {
    this.client.brpop(paramInt, paramArrayOfByte);
    return getResponse(BuilderFactory.STRING_LIST);
  }

  public Response<Map<String, String>> brpopMap(int paramInt, String[] paramArrayOfString)
  {
    this.client.blpop(paramInt, paramArrayOfString);
    return getResponse(BuilderFactory.STRING_MAP);
  }

  public Response<List<byte[]>> blpop(byte[][] paramArrayOfByte)
  {
    this.client.blpop(paramArrayOfByte);
    return getResponse(BuilderFactory.BYTE_ARRAY_LIST);
  }

  public Response<List<String>> blpop(int paramInt, byte[][] paramArrayOfByte)
  {
    this.client.blpop(paramInt, paramArrayOfByte);
    return getResponse(BuilderFactory.STRING_LIST);
  }

  public Response<Long> del(String[] paramArrayOfString)
  {
    this.client.del(paramArrayOfString);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> del(byte[][] paramArrayOfByte)
  {
    this.client.del(paramArrayOfByte);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Set<String>> keys(String paramString)
  {
    getClient(paramString).keys(paramString);
    return getResponse(BuilderFactory.STRING_SET);
  }

  public Response<Set<byte[]>> keys(byte[] paramArrayOfByte)
  {
    getClient(paramArrayOfByte).keys(paramArrayOfByte);
    return getResponse(BuilderFactory.BYTE_ARRAY_ZSET);
  }

  public Response<List<String>> mget(String[] paramArrayOfString)
  {
    this.client.mget(paramArrayOfString);
    return getResponse(BuilderFactory.STRING_LIST);
  }

  public Response<List<byte[]>> mget(byte[][] paramArrayOfByte)
  {
    this.client.mget(paramArrayOfByte);
    return getResponse(BuilderFactory.BYTE_ARRAY_LIST);
  }

  public Response<String> mset(String[] paramArrayOfString)
  {
    this.client.mset(paramArrayOfString);
    return getResponse(BuilderFactory.STRING);
  }

  public Response<String> mset(byte[][] paramArrayOfByte)
  {
    this.client.mset(paramArrayOfByte);
    return getResponse(BuilderFactory.STRING);
  }

  public Response<Long> msetnx(String[] paramArrayOfString)
  {
    this.client.msetnx(paramArrayOfString);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> msetnx(byte[][] paramArrayOfByte)
  {
    this.client.msetnx(paramArrayOfByte);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<String> rename(String paramString1, String paramString2)
  {
    this.client.rename(paramString1, paramString2);
    return getResponse(BuilderFactory.STRING);
  }

  public Response<String> rename(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    this.client.rename(paramArrayOfByte1, paramArrayOfByte2);
    return getResponse(BuilderFactory.STRING);
  }

  public Response<Long> renamenx(String paramString1, String paramString2)
  {
    this.client.renamenx(paramString1, paramString2);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> renamenx(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    this.client.renamenx(paramArrayOfByte1, paramArrayOfByte2);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<String> rpoplpush(String paramString1, String paramString2)
  {
    this.client.rpoplpush(paramString1, paramString2);
    return getResponse(BuilderFactory.STRING);
  }

  public Response<byte[]> rpoplpush(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    this.client.rpoplpush(paramArrayOfByte1, paramArrayOfByte2);
    return getResponse(BuilderFactory.BYTE_ARRAY);
  }

  public Response<Set<String>> sdiff(String[] paramArrayOfString)
  {
    this.client.sdiff(paramArrayOfString);
    return getResponse(BuilderFactory.STRING_SET);
  }

  public Response<Set<byte[]>> sdiff(byte[][] paramArrayOfByte)
  {
    this.client.sdiff(paramArrayOfByte);
    return getResponse(BuilderFactory.BYTE_ARRAY_ZSET);
  }

  public Response<Long> sdiffstore(String paramString, String[] paramArrayOfString)
  {
    this.client.sdiffstore(paramString, paramArrayOfString);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> sdiffstore(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1)
  {
    this.client.sdiffstore(paramArrayOfByte, paramArrayOfByte1);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Set<String>> sinter(String[] paramArrayOfString)
  {
    this.client.sinter(paramArrayOfString);
    return getResponse(BuilderFactory.STRING_SET);
  }

  public Response<Set<byte[]>> sinter(byte[][] paramArrayOfByte)
  {
    this.client.sinter(paramArrayOfByte);
    return getResponse(BuilderFactory.BYTE_ARRAY_ZSET);
  }

  public Response<Long> sinterstore(String paramString, String[] paramArrayOfString)
  {
    this.client.sinterstore(paramString, paramArrayOfString);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> sinterstore(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1)
  {
    this.client.sinterstore(paramArrayOfByte, paramArrayOfByte1);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> smove(String paramString1, String paramString2, String paramString3)
  {
    this.client.smove(paramString1, paramString2, paramString3);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> smove(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
  {
    this.client.smove(paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> sort(String paramString1, SortingParams paramSortingParams, String paramString2)
  {
    this.client.sort(paramString1, paramSortingParams, paramString2);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> sort(byte[] paramArrayOfByte1, SortingParams paramSortingParams, byte[] paramArrayOfByte2)
  {
    this.client.sort(paramArrayOfByte1, paramSortingParams, paramArrayOfByte2);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> sort(String paramString1, String paramString2)
  {
    this.client.sort(paramString1, paramString2);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> sort(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    this.client.sort(paramArrayOfByte1, paramArrayOfByte2);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Set<String>> sunion(String[] paramArrayOfString)
  {
    this.client.sunion(paramArrayOfString);
    return getResponse(BuilderFactory.STRING_SET);
  }

  public Response<Set<byte[]>> sunion(byte[][] paramArrayOfByte)
  {
    this.client.sunion(paramArrayOfByte);
    return getResponse(BuilderFactory.BYTE_ARRAY_ZSET);
  }

  public Response<Long> sunionstore(String paramString, String[] paramArrayOfString)
  {
    this.client.sunionstore(paramString, paramArrayOfString);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> sunionstore(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1)
  {
    this.client.sunionstore(paramArrayOfByte, paramArrayOfByte1);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<String> watch(String[] paramArrayOfString)
  {
    this.client.watch(paramArrayOfString);
    return getResponse(BuilderFactory.STRING);
  }

  public Response<String> watch(byte[][] paramArrayOfByte)
  {
    this.client.watch(paramArrayOfByte);
    return getResponse(BuilderFactory.STRING);
  }

  public Response<Long> zinterstore(String paramString, String[] paramArrayOfString)
  {
    this.client.zinterstore(paramString, paramArrayOfString);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> zinterstore(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1)
  {
    this.client.zinterstore(paramArrayOfByte, paramArrayOfByte1);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> zinterstore(String paramString, ZParams paramZParams, String[] paramArrayOfString)
  {
    this.client.zinterstore(paramString, paramZParams, paramArrayOfString);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> zinterstore(byte[] paramArrayOfByte, ZParams paramZParams, byte[][] paramArrayOfByte1)
  {
    this.client.zinterstore(paramArrayOfByte, paramZParams, paramArrayOfByte1);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> zunionstore(String paramString, String[] paramArrayOfString)
  {
    this.client.zunionstore(paramString, paramArrayOfString);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> zunionstore(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1)
  {
    this.client.zunionstore(paramArrayOfByte, paramArrayOfByte1);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> zunionstore(String paramString, ZParams paramZParams, String[] paramArrayOfString)
  {
    this.client.zunionstore(paramString, paramZParams, paramArrayOfString);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> zunionstore(byte[] paramArrayOfByte, ZParams paramZParams, byte[][] paramArrayOfByte1)
  {
    this.client.zunionstore(paramArrayOfByte, paramZParams, paramArrayOfByte1);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<String> bgrewriteaof()
  {
    this.client.bgrewriteaof();
    return getResponse(BuilderFactory.STRING);
  }

  public Response<String> bgsave()
  {
    this.client.bgsave();
    return getResponse(BuilderFactory.STRING);
  }

  public Response<String> configGet(String paramString)
  {
    this.client.configGet(paramString);
    return getResponse(BuilderFactory.STRING);
  }

  public Response<String> configSet(String paramString1, String paramString2)
  {
    this.client.configSet(paramString1, paramString2);
    return getResponse(BuilderFactory.STRING);
  }

  public Response<String> brpoplpush(String paramString1, String paramString2, int paramInt)
  {
    this.client.brpoplpush(paramString1, paramString2, paramInt);
    return getResponse(BuilderFactory.STRING);
  }

  public Response<byte[]> brpoplpush(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, int paramInt)
  {
    this.client.brpoplpush(paramArrayOfByte1, paramArrayOfByte2, paramInt);
    return getResponse(BuilderFactory.BYTE_ARRAY);
  }

  public Response<String> configResetStat()
  {
    this.client.configResetStat();
    return getResponse(BuilderFactory.STRING);
  }

  public Response<String> save()
  {
    this.client.save();
    return getResponse(BuilderFactory.STRING);
  }

  public Response<Long> lastsave()
  {
    this.client.lastsave();
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> publish(String paramString1, String paramString2)
  {
    this.client.publish(paramString1, paramString2);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> publish(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    this.client.publish(paramArrayOfByte1, paramArrayOfByte2);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<String> randomKey()
  {
    this.client.randomKey();
    return getResponse(BuilderFactory.STRING);
  }

  public Response<byte[]> randomKeyBinary()
  {
    this.client.randomKey();
    return getResponse(BuilderFactory.BYTE_ARRAY);
  }

  public Response<String> flushDB()
  {
    this.client.flushDB();
    return getResponse(BuilderFactory.STRING);
  }

  public Response<String> flushAll()
  {
    this.client.flushAll();
    return getResponse(BuilderFactory.STRING);
  }

  public Response<String> info()
  {
    this.client.info();
    return getResponse(BuilderFactory.STRING);
  }

  public Response<Long> dbSize()
  {
    this.client.dbSize();
    return getResponse(BuilderFactory.LONG);
  }

  public Response<String> shutdown()
  {
    this.client.shutdown();
    return getResponse(BuilderFactory.STRING);
  }

  public Response<String> ping()
  {
    this.client.ping();
    return getResponse(BuilderFactory.STRING);
  }

  public Response<String> select(int paramInt)
  {
    this.client.select(paramInt);
    return getResponse(BuilderFactory.STRING);
  }

  public Response<Long> bitop(BitOP paramBitOP, byte[] paramArrayOfByte, byte[][] paramArrayOfByte1)
  {
    this.client.bitop(paramBitOP, paramArrayOfByte, paramArrayOfByte1);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> bitop(BitOP paramBitOP, String paramString, String[] paramArrayOfString)
  {
    this.client.bitop(paramBitOP, paramString, paramArrayOfString);
    return getResponse(BuilderFactory.LONG);
  }
}