package com.ycache.redis.clients.jedis;

import java.util.LinkedList;
import java.util.Queue;

public class Queable
{
  private Queue<Response<?>> pipelinedResponses = new LinkedList();

  protected void clean()
  {
    this.pipelinedResponses.clear();
  }

  protected Response<?> generateResponse(Object paramObject)
  {
    Response localResponse = (Response)this.pipelinedResponses.poll();
    if (localResponse != null)
      localResponse.set(paramObject);
    return localResponse;
  }

  protected <T> Response<T> getResponse(Builder<T> paramBuilder)
  {
    Response localResponse = new Response(paramBuilder);
    this.pipelinedResponses.add(localResponse);
    return localResponse;
  }
}