package com.ycache.danga.MemCached;

import com.yihaodian.arc.cache.zk.ZKProxy;
import com.yihaodian.common.ycache.util.YMemcachedProxyUtil;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.channels.SocketChannel;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.locks.ReentrantLock;
import java.util.zip.CRC32;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

public class SockIOPool
{
  private static Logger log = Logger.getLogger(SockIOPool.class.getName());
  private static Map<String, SockIOPool> pools = new HashMap();
  private static ThreadLocal<MessageDigest> MD5 = new ThreadLocal()
  {
    protected MessageDigest initialValue()
    {
      try
      {
        return MessageDigest.getInstance("MD5");
      }
      catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
      {
        SockIOPool.access$000().error("++++ no md5 algorithm found");
        throw new IllegalStateException("++++ no md5 algorythm found");
      }
    }
  };
  private static final Integer ZERO = new Integer(0);
  public static final int NATIVE_HASH = 0;
  public static final int OLD_COMPAT_HASH = 1;
  public static final int NEW_COMPAT_HASH = 2;
  public static final int CONSISTENT_HASH = 3;
  public static final long MAX_RETRY_DELAY = 600000L;
  private MaintThread maintThread;
  private boolean initialized = false;
  private int maxCreate = 1;
  private int poolMultiplier = 3;
  private int initConn = 10;
  private int minConn = 5;
  private int maxConn = 100;
  private long maxIdle = 300000L;
  private long maxBusyTime = 30000L;
  private long maintSleep = 30000L;
  private int socketTO = 3000;
  private int socketConnectTO = 3000;
  private boolean aliveCheck = false;
  private boolean failover = true;
  private boolean failback = true;
  private boolean nagle = false;
  private int hashingAlg = 0;
  private boolean noReply = false;
  private final ReentrantLock hostDeadLock = new ReentrantLock();
  private String[] servers;
  private Integer[] weights;
  private Integer totalWeight = Integer.valueOf(0);
  private List<String> buckets;
  private TreeMap<Long, String> consistentBuckets;
  private Map<String, Date> hostDead;
  private Map<String, Long> hostDeadDur;
  private Map<String, Map<SockIO, Long>> availPool;
  private Map<String, Map<SockIO, Long>> busyPool;
  private Map<SockIO, Integer> deadPool;
  private String poolName;
  private ZKProxy zkProxy;
  private final ReentrantLock initDeadLock = new ReentrantLock();
  private CountDownLatch reInitSignal;
  private final Object reInitSignalLock = new Object();
  private boolean isNutcracker = false;
  private static final String MEM_ADDR = "memcache-servers";
  private String masterIDC;
  private String zkGroup;
  private String originalPoolName;

  public static synchronized SockIOPool getInstance(String paramString)
  {
    if (pools.containsKey(paramString))
      return ((SockIOPool)pools.get(paramString));
    SockIOPool localSockIOPool = new SockIOPool();
    localSockIOPool.poolName = paramString;
    pools.put(paramString, localSockIOPool);
    return localSockIOPool;
  }

  public static SockIOPool getInstance()
  {
    return getInstance("default");
  }

  public void setServers(String[] paramArrayOfString)
  {
    this.servers = paramArrayOfString;
  }

  public String[] getServers()
  {
    return this.servers;
  }

  public void setWeights(Integer[] paramArrayOfInteger)
  {
    this.weights = paramArrayOfInteger;
  }

  public Integer[] getWeights()
  {
    return this.weights;
  }

  public void setInitConn(int paramInt)
  {
    this.initConn = paramInt;
  }

  public int getInitConn()
  {
    return this.initConn;
  }

  public void setMinConn(int paramInt)
  {
    this.minConn = paramInt;
  }

  public int getMinConn()
  {
    return this.minConn;
  }

  public void setMaxConn(int paramInt)
  {
    this.maxConn = paramInt;
  }

  public int getMaxConn()
  {
    return this.maxConn;
  }

  public void setMaxIdle(long paramLong)
  {
    this.maxIdle = paramLong;
  }

  public long getMaxIdle()
  {
    return this.maxIdle;
  }

  public void setMaxBusyTime(long paramLong)
  {
    this.maxBusyTime = paramLong;
  }

  public long getMaxBusy()
  {
    return this.maxBusyTime;
  }

  public void setMaintSleep(long paramLong)
  {
    this.maintSleep = paramLong;
  }

  public long getMaintSleep()
  {
    return this.maintSleep;
  }

  public void setSocketTO(int paramInt)
  {
    this.socketTO = paramInt;
  }

  public int getSocketTO()
  {
    return this.socketTO;
  }

  public void setSocketConnectTO(int paramInt)
  {
    this.socketConnectTO = paramInt;
  }

  public int getSocketConnectTO()
  {
    return this.socketConnectTO;
  }

  public void setFailover(boolean paramBoolean)
  {
    this.failover = paramBoolean;
  }

  public boolean getFailover()
  {
    return this.failover;
  }

  public void setFailback(boolean paramBoolean)
  {
    this.failback = paramBoolean;
  }

  public boolean getFailback()
  {
    return this.failback;
  }

  public void setAliveCheck(boolean paramBoolean)
  {
    this.aliveCheck = paramBoolean;
  }

  public boolean getAliveCheck()
  {
    return this.aliveCheck;
  }

  public void setNagle(boolean paramBoolean)
  {
    this.nagle = paramBoolean;
  }

  public boolean getNagle()
  {
    return this.nagle;
  }

  public void setHashingAlg(int paramInt)
  {
    this.hashingAlg = paramInt;
  }

  public int getHashingAlg()
  {
    return this.hashingAlg;
  }

  public void setNoreply(boolean paramBoolean)
  {
    this.noReply = paramBoolean;
  }

  public boolean getNoreply()
  {
    return this.noReply;
  }

  private static long origCompatHashingAlg(String paramString)
  {
    long l = -6318801846320234496L;
    char[] arrayOfChar = paramString.toCharArray();
    for (int i = 0; i < arrayOfChar.length; ++i)
      l = l * 33L + arrayOfChar[i];
    return l;
  }

  private static long newCompatHashingAlg(String paramString)
  {
    CRC32 localCRC32 = new CRC32();
    localCRC32.update(paramString.getBytes());
    long l = localCRC32.getValue();
    return (l >> 16 & 0x7FFF);
  }

  private static long md5HashingAlg(String paramString)
  {
    MessageDigest localMessageDigest = (MessageDigest)MD5.get();
    localMessageDigest.reset();
    localMessageDigest.update(paramString.getBytes());
    byte[] arrayOfByte = localMessageDigest.digest();
    long l = (arrayOfByte[3] & 0xFF) << 24 | (arrayOfByte[2] & 0xFF) << 16 | (arrayOfByte[1] & 0xFF) << 8 | arrayOfByte[0] & 0xFF;
    return l;
  }

  private long getHash(String paramString, Integer paramInteger)
  {
    if (paramInteger != null)
    {
      if (this.hashingAlg == 3)
        return (paramInteger.longValue() & 0xFFFFFFFF);
      return paramInteger.longValue();
    }
    switch (this.hashingAlg)
    {
    case 0:
      return paramString.hashCode();
    case 1:
      return origCompatHashingAlg(paramString);
    case 2:
      return newCompatHashingAlg(paramString);
    case 3:
      return md5HashingAlg(paramString);
    }
    this.hashingAlg = 0;
    return paramString.hashCode();
  }

  private long getBucket(String paramString, Integer paramInteger)
  {
    long l1 = getHash(paramString, paramInteger);
    if (this.hashingAlg == 3)
      return findPointFor(Long.valueOf(l1)).longValue();
    long l2 = l1 % this.buckets.size();
    if (l2 < -6318802464795525120L)
      l2 *= -1L;
    return l2;
  }

  private Long findPointFor(Long paramLong)
  {
    SortedMap localSortedMap = this.consistentBuckets.tailMap(paramLong);
    return ((localSortedMap.isEmpty()) ? (Long)this.consistentBuckets.firstKey() : (Long)localSortedMap.firstKey());
  }

  public void initialize()
  {
    synchronized (this)
    {
      if ((!(this.initialized)) || ((this.buckets == null) && (this.consistentBuckets == null)) || (this.availPool == null) || (this.busyPool == null))
        break label50;
      log.error("++++ trying to initialize an already initialized pool");
      return;
      label50: String str1 = getConfigPath();
      File localFile = new File(str1);
      if (localFile.exists())
        break label76;
      localFile.mkdirs();
      label76: str1 = str1 + "memcache_server.properties";
      int i = 0;
      try
      {
        this.originalPoolName = this.poolName;
        String str2 = null;
        if (StringUtils.isNotBlank(this.masterIDC))
        {
          this.originalPoolName = YMemcachedProxyUtil.getOriginalPoolName(this.poolName, this.masterIDC);
          if ("nh".equals(this.masterIDC))
            str2 = "yihaodian_common";
          else
            str2 = "yihaodian_common_" + this.masterIDC;
        }
        if (StringUtils.isNotBlank(this.zkGroup))
          str2 = this.zkGroup;
        log.info("originalPoolName is:" + this.originalPoolName + ", commonPoolGroup is:" + str2);
        this.zkProxy = new ZKProxy(this, this.originalPoolName, str2);
        localObject1 = this.zkProxy.getMCServerConnections(this.originalPoolName);
        if (((List)localObject1).size() > 0)
          this.servers = ((String[])((List)localObject1).toArray(new String[((List)localObject1).size()]));
        this.isNutcracker = true;
      }
      catch (Exception localException)
      {
        log.warn(this.poolName + " cause an exception:" + localException.getMessage() + "trying to connect zk fail, put local memcache config to servers.");
        localObject1 = loadPropertiesFile(str1);
        String str3 = ((Properties)localObject1).getProperty("memcache-servers");
        if ((str3 == null) || (str3.equalsIgnoreCase("")))
          log.error(this.poolName + " cause an exception: [" + localException.getMessage() + "], maybe try to connect zk fail. Tring to get local memcache config to get servers address, fail again. result: " + str1 + ": file is not exist or property [" + "memcache-servers" + "] is not exist.");
        else
          this.servers = str3.split(",");
        log.warn(str3);
        i = 1;
      }
      if ((this.servers != null) && (this.servers.length > 0))
        break label536;
      log.error(this.poolName + ": ++++ trying to initialize with no servers");
      throw new IllegalStateException(this.poolName + ": ++++ trying to initialize with no servers");
      label536: if (i != 0)
        break label770;
      log.warn(this.poolName + " initialize successfully, memcache server is: ");
      Properties localProperties = new Properties();
      Object localObject1 = "";
      for (int j = 0; j < this.servers.length; ++j)
        if (j == 0)
          localObject1 = this.servers[j];
        else
          localObject1 = ((String)localObject1) + "," + this.servers[j];
      log.warn(localObject1);
      FileOutputStream localFileOutputStream = null;
      try
      {
        localFileOutputStream = new FileOutputStream(str1);
        localProperties.setProperty("memcache-servers", (String)localObject1);
        localProperties.store(localFileOutputStream, this.poolName);
      }
      catch (IOException localIOException3)
      {
        localIOException2.printStackTrace();
      }
      finally
      {
        if (localFileOutputStream != null)
          try
          {
            localFileOutputStream.close();
          }
          catch (IOException localIOException4)
          {
            localIOException4.printStackTrace();
          }
      }
      label770: this.availPool = new HashMap(this.servers.length * this.initConn);
      this.busyPool = new HashMap(this.servers.length * this.initConn);
      this.deadPool = new IdentityHashMap();
      this.hostDeadDur = new HashMap();
      this.hostDead = new HashMap();
      this.maxCreate = ((this.poolMultiplier > this.minConn) ? this.minConn : this.minConn / this.poolMultiplier);
      if (!(log.isDebugEnabled()))
        break label977;
      log.debug("++++ initializing pool with following settings:");
      log.debug("++++ initial size: " + this.initConn);
      log.debug("++++ min spare   : " + this.minConn);
      log.debug("++++ max spare   : " + this.maxConn);
      label977: if ((this.servers != null) && (this.servers.length > 0))
        break label1010;
      log.error("++++ trying to initialize with no servers");
      throw new IllegalStateException("++++ trying to initialize with no servers");
      label1010: if (this.hashingAlg != 3)
        break label1025;
      populateConsistentBuckets();
      break label1029:
      label1025: populateBuckets();
      label1029: this.initialized = true;
      if (this.maintSleep <= -6318801949399449600L)
        break label1047;
      label1047: startMaintThread();
    }
  }

  public String getConfigPath()
  {
    String str = System.getProperty("global.config.path") + File.separator + "ycc" + File.separator + "snapshot" + File.separator + this.poolName + File.separator + "ycache" + File.separator;
    if ((str != null) && (!(str.equalsIgnoreCase(""))))
      return str;
    return System.getProperty("user.home") + File.separator;
  }

  public void reInitialize()
    throws Exception
  {
    if (!(this.initialized))
      throw new Exception("pool uninitialize, first initialize");
    this.initDeadLock.lock();
    this.reInitSignal = new CountDownLatch(1);
    try
    {
      List localList = this.zkProxy.getMCServerConnections(this.originalPoolName);
      if (localList.size() > 0)
        this.servers = ((String[])localList.toArray(new String[localList.size()]));
      this.isNutcracker = true;
    }
    catch (Exception localException)
    {
      log.error("", localException);
    }
    if ((this.servers == null) || (this.servers.length <= 0))
    {
      log.error("++++ trying to initialize with no servers");
      throw new Exception("++++ trying to initialize with no servers");
    }
    try
    {
      ??? = Arrays.asList(this.servers);
      ArrayList localArrayList = new ArrayList(this.availPool.keySet());
      localArrayList.addAll(this.busyPool.keySet());
      Iterator localIterator1 = localArrayList.iterator();
      while (localIterator1.hasNext())
      {
        String str = (String)localIterator1.next();
        if (!(((List)???).contains(str)))
        {
          Iterator localIterator2;
          SockIO localSockIO;
          Map localMap = (Map)this.availPool.remove(str);
          if (localMap != null)
          {
            localIterator2 = localMap.keySet().iterator();
            while (localIterator2.hasNext())
            {
              localSockIO = (SockIO)localIterator2.next();
              localSockIO.trueClose(false);
            }
          }
          localMap = (Map)this.busyPool.remove(str);
          if (localMap != null)
          {
            localIterator2 = localMap.keySet().iterator();
            while (localIterator2.hasNext())
            {
              localSockIO = (SockIO)localIterator2.next();
              localSockIO.trueClose(false);
            }
          }
        }
      }
      if (this.hashingAlg == 3)
        populateConsistentBuckets();
      else
        populateBuckets();
    }
    finally
    {
      synchronized (this.reInitSignalLock)
      {
        this.reInitSignal.countDown();
        this.reInitSignal = null;
      }
      this.initDeadLock.unlock();
    }
  }

  private void populateBuckets()
  {
    if (log.isDebugEnabled())
      log.debug("++++ initializing internal hashing structure for consistent hashing");
    this.buckets = new ArrayList();
    label435: for (int i = 0; i < this.servers.length; ++i)
      if (!(this.availPool.containsKey(this.servers[i])))
      {
        if (this.busyPool.containsKey(this.servers[i]))
          break label435:
        if ((this.weights != null) && (this.weights.length > i))
        {
          for (int j = 0; j < this.weights[i].intValue(); ++j)
          {
            this.buckets.add(this.servers[i]);
            if (log.isDebugEnabled())
              log.debug("++++ added " + this.servers[i] + " to server bucket");
          }
        }
        else
        {
          this.buckets.add(this.servers[i]);
          if (log.isDebugEnabled())
            log.debug("++++ added " + this.servers[i] + " to server bucket");
        }
        if (log.isDebugEnabled())
          log.debug("+++ creating initial connections (" + this.initConn + ") for host: " + this.servers[i]);
        SockIO localSockIO = null;
        for (int k = 0; k < this.initConn; ++k)
        {
          localSockIO = createSocket(this.servers[i]);
          if (localSockIO == null)
          {
            log.error("++++ failed to create connection to: " + this.servers[i] + " -- only " + k + " created.");
            break;
          }
          addSocketToPool(this.availPool, this.servers[i], localSockIO);
          if (log.isDebugEnabled())
            log.debug("++++ created and added socket: " + localSockIO.toString() + " for host " + this.servers[i]);
        }
      }
  }

  private void populateConsistentBuckets()
  {
    if (log.isDebugEnabled())
      log.debug("++++ initializing internal hashing structure for consistent hashing");
    this.consistentBuckets = new TreeMap();
    MessageDigest localMessageDigest = (MessageDigest)MD5.get();
    if ((this.totalWeight.intValue() <= 0) && (this.weights != null))
      for (i = 0; i < this.weights.length; ++i)
      {
        SockIOPool localSockIOPool = this;
        (localSockIOPool.totalWeight = Integer.valueOf(localSockIOPool.totalWeight.intValue() + ((this.weights[i] == null) ? 1 : this.weights[i].intValue())));
      }
    else if (this.weights == null)
      this.totalWeight = Integer.valueOf(this.servers.length);
    for (int i = 0; i < this.servers.length; ++i)
    {
      int j = 1;
      if ((this.weights != null) && (this.weights[i] != null))
        j = this.weights[i].intValue();
      double d = Math.floor(40 * this.servers.length * j / this.totalWeight.intValue());
      long l = -6318801451183243264L;
      while (l < d)
      {
        byte[] arrayOfByte = localMessageDigest.digest(this.servers[i] + "-" + l.getBytes());
        for (int i1 = 0; i1 < 4; ++i1)
        {
          Long localLong = Long.valueOf((arrayOfByte[(3 + i1 * 4)] & 0xFF) << 24 | (arrayOfByte[(2 + i1 * 4)] & 0xFF) << 16 | (arrayOfByte[(1 + i1 * 4)] & 0xFF) << 8 | arrayOfByte[(0 + i1 * 4)] & 0xFF);
          this.consistentBuckets.put(localLong, this.servers[i]);
          if (log.isDebugEnabled())
            log.debug("++++ added " + this.servers[i] + " to server bucket");
        }
        l += -6318801038866382847L;
      }
      if (!(this.availPool.containsKey(this.servers[i])))
      {
        if (this.busyPool.containsKey(this.servers[i]))
          break label650:
        if (log.isDebugEnabled())
          log.debug("+++ creating initial connections (" + this.initConn + ") for host: " + this.servers[i]);
        SockIO localSockIO = null;
        for (int k = 0; k < this.initConn; ++k)
        {
          localSockIO = createSocket(this.servers[i]);
          if (localSockIO == null)
          {
            log.error("++++ failed to create connection to: " + this.servers[i] + " -- only " + k + " created.");
            break;
          }
          addSocketToPool(this.availPool, this.servers[i], localSockIO);
          label650: if (log.isDebugEnabled())
            log.debug("++++ created and added socket: " + localSockIO.toString() + " for host " + this.servers[i]);
        }
      }
    }
  }

  public boolean isInitialized()
  {
    return this.initialized;
  }

  protected SockIO createSocket(String paramString)
  {
    long l;
    SockIO localSockIO = null;
    this.hostDeadLock.lock();
    try
    {
      if ((this.failover) && (this.failback) && (this.hostDead.containsKey(paramString)) && (this.hostDeadDur.containsKey(paramString)))
      {
        Date localDate1 = (Date)this.hostDead.get(paramString);
        l = ((Long)this.hostDeadDur.get(paramString)).longValue();
        if (localDate1.getTime() + l > System.currentTimeMillis())
        {
          Object localObject1 = null;
          return localObject1;
        }
      }
    }
    finally
    {
      this.hostDeadLock.unlock();
    }
    try
    {
      localSockIO = new SockIO(this, paramString, this.socketTO, this.socketConnectTO, this.nagle);
      if (!(localSockIO.isConnected()))
      {
        log.error("++++ failed to get SockIO obj for: " + paramString + " -- new socket is not connected");
        this.deadPool.put(localSockIO, ZERO);
        localSockIO = null;
      }
    }
    catch (Exception localException)
    {
      log.error("++++ failed to get SockIO obj for: " + paramString);
      log.error(localException.getMessage(), localException);
      localSockIO = null;
    }
    this.hostDeadLock.lock();
    try
    {
      if (localSockIO == null)
      {
        Date localDate2 = new Date();
        this.hostDead.put(paramString, localDate2);
        l = (this.hostDeadDur.containsKey(paramString)) ? ((Long)this.hostDeadDur.get(paramString)).longValue() * 2L : 1000L;
        if (l > 600000L)
          l = 600000L;
        this.hostDeadDur.put(paramString, new Long(l));
        if (log.isDebugEnabled())
          log.debug("++++ ignoring dead host: " + paramString + " for " + l + " ms");
        clearHostFromPool(this.availPool, paramString);
      }
      else
      {
        if (log.isDebugEnabled())
          log.debug("++++ created socket (" + localSockIO.toString() + ") for host: " + paramString);
        if ((this.hostDead.containsKey(paramString)) || (this.hostDeadDur.containsKey(paramString)))
        {
          this.hostDead.remove(paramString);
          this.hostDeadDur.remove(paramString);
        }
      }
    }
    finally
    {
      this.hostDeadLock.unlock();
    }
    return localSockIO;
  }

  public String getHost(String paramString)
  {
    return getHost(paramString, null);
  }

  public String getHost(String paramString, Integer paramInteger)
  {
    SockIO localSockIO = getSock(paramString, paramInteger);
    String str = localSockIO.getHost();
    localSockIO.close();
    return str;
  }

  public SockIO getSock(String paramString)
  {
    return getSock(paramString, null);
  }

  public SockIO getSock(String paramString, Integer paramInteger)
  {
    if (log.isDebugEnabled())
      log.debug("cache socket pick " + paramString + " " + paramInteger);
    if (!(this.initialized))
    {
      log.error("attempting to get SockIO from uninitialized pool!");
      return null;
    }
    int i = 0;
    synchronized (this.reInitSignalLock)
    {
      if (this.reInitSignal != null)
        i = 1;
    }
    if (i != 0)
      try
      {
        this.reInitSignal.await();
      }
      catch (InterruptedException localInterruptedException)
      {
        log.error("", localInterruptedException);
      }
    if (((this.hashingAlg == 3) && (this.consistentBuckets.size() == 0)) || ((this.buckets != null) && (this.buckets.size() == 0)))
      return null;
    if (((this.hashingAlg == 3) && (this.consistentBuckets.size() == 1)) || ((this.buckets != null) && (this.buckets.size() == 1)))
    {
      localObject2 = (this.hashingAlg == 3) ? getConnection((String)this.consistentBuckets.get(this.consistentBuckets.firstKey())) : getConnection((String)this.buckets.get(0));
      if ((localObject2 != null) && (((SockIO)localObject2).isConnected()))
      {
        if ((this.aliveCheck) && (!(((SockIO)localObject2).isAlive())))
        {
          ((SockIO)localObject2).close();
          try
          {
            ((SockIO)localObject2).trueClose();
          }
          catch (IOException localIOException1)
          {
            log.error("failed to close dead socket");
          }
          localObject2 = null;
        }
      }
      else if (localObject2 != null)
      {
        this.deadPool.put(localObject2, ZERO);
        localObject2 = null;
      }
      return localObject2;
    }
    Object localObject2 = new HashSet(Arrays.asList(this.servers));
    long l = getBucket(paramString, paramInteger);
    String str1 = (this.hashingAlg == 3) ? (String)this.consistentBuckets.get(Long.valueOf(l)) : (String)this.buckets.get((int)l);
    while (!(((Set)localObject2).isEmpty()))
    {
      SockIO localSockIO = getConnection(str1);
      if (log.isDebugEnabled())
        log.debug("cache choose " + str1 + " for " + paramString);
      if ((localSockIO != null) && (localSockIO.isConnected()))
      {
        if (this.aliveCheck)
        {
          if (localSockIO.isAlive())
            return localSockIO;
          localSockIO.close();
          try
          {
            localSockIO.trueClose();
          }
          catch (IOException localIOException2)
          {
            log.error("failed to close dead socket");
          }
          localSockIO = null;
          break label547:
        }
        return localSockIO;
      }
      if (localSockIO != null)
      {
        this.deadPool.put(localSockIO, ZERO);
        localSockIO = null;
      }
      if (!(this.failover))
        label547: return null;
      ((Set)localObject2).remove(str1);
      if (((Set)localObject2).isEmpty())
        break;
      for (int j = 0; !(((Set)localObject2).contains(str1)); ++j)
      {
        String str2 = String.format("%s%s", new Object[] { Integer.valueOf(j), paramString });
        if (log.isDebugEnabled())
          log.debug("rehashing with: " + str2);
        l = getBucket(str2, null);
        str1 = (this.hashingAlg == 3) ? (String)this.consistentBuckets.get(Long.valueOf(l)) : (String)this.buckets.get((int)l);
      }
    }
    return ((SockIO)null);
  }

  public SockIO getConnection(String paramString)
  {
    if (!(this.initialized))
    {
      log.error("attempting to get SockIO from uninitialized pool!");
      return null;
    }
    if (paramString == null)
      return null;
    synchronized (this)
    {
      if ((this.availPool == null) || (this.availPool.isEmpty()))
        break label210;
      ??? = (Map)this.availPool.get(paramString);
      if ((??? == null) || (((Map)???).isEmpty()))
        break label210;
      Iterator localIterator = ((Map)???).keySet().iterator();
      while (true)
      {
        if (!(localIterator.hasNext()))
          break label210;
        SockIO localSockIO = (SockIO)localIterator.next();
        if (localSockIO.isConnected())
        {
          if (log.isDebugEnabled())
            log.debug("++++ moving socket for host (" + paramString + ") to busy pool ... socket: " + localSockIO);
          localIterator.remove();
          addSocketToPool(this.busyPool, paramString, localSockIO);
          return localSockIO;
        }
        this.deadPool.put(localSockIO, ZERO);
        label210: localIterator.remove();
      }
    }
    ??? = createSocket(paramString);
    if (??? != null)
      synchronized (this)
      {
        addSocketToPool(this.busyPool, paramString, (SockIO)???);
      }
    return ((SockIO)(SockIO)???);
  }

  protected synchronized void addSocketToPool(Map<String, Map<SockIO, Long>> paramMap, String paramString, SockIO paramSockIO)
  {
    if (paramMap.containsKey(paramString))
    {
      localObject = (Map)paramMap.get(paramString);
      if (localObject != null)
      {
        ((Map)localObject).put(paramSockIO, new Long(System.currentTimeMillis()));
        return;
      }
    }
    Object localObject = new IdentityHashMap();
    ((Map)localObject).put(paramSockIO, new Long(System.currentTimeMillis()));
    paramMap.put(paramString, localObject);
  }

  protected void removeSocketFromPool(Map<String, Map<SockIO, Long>> paramMap, String paramString, SockIO paramSockIO)
  {
    if (paramMap.containsKey(paramString))
    {
      Map localMap = (Map)paramMap.get(paramString);
      if (localMap != null)
        localMap.remove(paramSockIO);
    }
  }

  protected synchronized void clearHostFromPool(Map<String, Map<SockIO, Long>> paramMap, String paramString)
  {
    if (paramMap.containsKey(paramString))
    {
      Map localMap = (Map)paramMap.get(paramString);
      if ((localMap != null) && (localMap.size() > 0))
      {
        Iterator localIterator = localMap.keySet().iterator();
        while (localIterator.hasNext())
        {
          SockIO localSockIO = (SockIO)localIterator.next();
          try
          {
            localSockIO.trueClose();
          }
          catch (IOException localIOException)
          {
            log.error("++++ failed to close socket: " + localIOException.getMessage());
          }
          localIterator.remove();
          localSockIO = null;
        }
      }
    }
  }

  private void checkIn(SockIO paramSockIO, boolean paramBoolean)
  {
    String str = paramSockIO.getHost();
    if (log.isDebugEnabled())
      log.debug("++++ calling check-in on socket: " + paramSockIO.toString() + " for host: " + str);
    synchronized (this)
    {
      if (log.isDebugEnabled())
        log.debug("++++ removing socket (" + paramSockIO.toString() + ") from busy pool for host: " + str);
      removeSocketFromPool(this.busyPool, str, paramSockIO);
      if ((paramSockIO.isConnected()) && (paramBoolean))
      {
        if (log.isDebugEnabled())
          log.debug("++++ returning socket (" + paramSockIO.toString() + " to avail pool for host: " + str);
        addSocketToPool(this.availPool, str, paramSockIO);
      }
      else
      {
        this.deadPool.put(paramSockIO, ZERO);
        paramSockIO = null;
      }
    }
  }

  private void checkIn(SockIO paramSockIO)
  {
    checkIn(paramSockIO, true);
  }

  protected void closePool(Map<String, Map<SockIO, Long>> paramMap)
  {
    Iterator localIterator1 = paramMap.keySet().iterator();
    while (localIterator1.hasNext())
    {
      String str = (String)localIterator1.next();
      Map localMap = (Map)paramMap.get(str);
      Iterator localIterator2 = localMap.keySet().iterator();
      while (localIterator2.hasNext())
      {
        SockIO localSockIO = (SockIO)localIterator2.next();
        try
        {
          localSockIO.trueClose();
        }
        catch (IOException localIOException)
        {
          log.error("++++ failed to trueClose socket: " + localSockIO.toString() + " for host: " + str);
        }
        localIterator2.remove();
        localSockIO = null;
      }
    }
  }

  // ERROR //
  public void shutDown()
  {
    // Byte code:
    //   0: aload_0
    //   1: dup
    //   2: astore_1
    //   3: monitorenter
    //   4: getstatic 3	com/ycache/danga/MemCached/SockIOPool:log	Lorg/apache/log4j/Logger;
    //   7: invokevirtual 153	org/apache/log4j/Logger:isDebugEnabled	()Z
    //   10: ifeq +12 -> 22
    //   13: getstatic 3	com/ycache/danga/MemCached/SockIOPool:log	Lorg/apache/log4j/Logger;
    //   16: ldc_w 281
    //   19: invokevirtual 155	org/apache/log4j/Logger:debug	(Ljava/lang/Object;)V
    //   22: aload_0
    //   23: getfield 282	com/ycache/danga/MemCached/SockIOPool:maintThread	Lcom/ycache/danga/MemCached/SockIOPool$MaintThread;
    //   26: ifnull +58 -> 84
    //   29: aload_0
    //   30: getfield 282	com/ycache/danga/MemCached/SockIOPool:maintThread	Lcom/ycache/danga/MemCached/SockIOPool$MaintThread;
    //   33: invokevirtual 283	com/ycache/danga/MemCached/SockIOPool$MaintThread:isRunning	()Z
    //   36: ifeq +48 -> 84
    //   39: aload_0
    //   40: invokevirtual 284	com/ycache/danga/MemCached/SockIOPool:stopMaintThread	()V
    //   43: aload_0
    //   44: getfield 282	com/ycache/danga/MemCached/SockIOPool:maintThread	Lcom/ycache/danga/MemCached/SockIOPool$MaintThread;
    //   47: invokevirtual 283	com/ycache/danga/MemCached/SockIOPool$MaintThread:isRunning	()Z
    //   50: ifeq +34 -> 84
    //   53: getstatic 3	com/ycache/danga/MemCached/SockIOPool:log	Lorg/apache/log4j/Logger;
    //   56: invokevirtual 153	org/apache/log4j/Logger:isDebugEnabled	()Z
    //   59: ifeq +12 -> 71
    //   62: getstatic 3	com/ycache/danga/MemCached/SockIOPool:log	Lorg/apache/log4j/Logger;
    //   65: ldc_w 285
    //   68: invokevirtual 155	org/apache/log4j/Logger:debug	(Ljava/lang/Object;)V
    //   71: ldc2_w 286
    //   74: invokestatic 288	java/lang/Thread:sleep	(J)V
    //   77: goto -34 -> 43
    //   80: astore_2
    //   81: goto -38 -> 43
    //   84: getstatic 3	com/ycache/danga/MemCached/SockIOPool:log	Lorg/apache/log4j/Logger;
    //   87: invokevirtual 153	org/apache/log4j/Logger:isDebugEnabled	()Z
    //   90: ifeq +12 -> 102
    //   93: getstatic 3	com/ycache/danga/MemCached/SockIOPool:log	Lorg/apache/log4j/Logger;
    //   96: ldc_w 289
    //   99: invokevirtual 155	org/apache/log4j/Logger:debug	(Ljava/lang/Object;)V
    //   102: aload_0
    //   103: aload_0
    //   104: getfield 83	com/ycache/danga/MemCached/SockIOPool:availPool	Ljava/util/Map;
    //   107: invokevirtual 290	com/ycache/danga/MemCached/SockIOPool:closePool	(Ljava/util/Map;)V
    //   110: aload_0
    //   111: aload_0
    //   112: getfield 84	com/ycache/danga/MemCached/SockIOPool:busyPool	Ljava/util/Map;
    //   115: invokevirtual 290	com/ycache/danga/MemCached/SockIOPool:closePool	(Ljava/util/Map;)V
    //   118: aload_0
    //   119: aconst_null
    //   120: putfield 83	com/ycache/danga/MemCached/SockIOPool:availPool	Ljava/util/Map;
    //   123: aload_0
    //   124: aconst_null
    //   125: putfield 84	com/ycache/danga/MemCached/SockIOPool:busyPool	Ljava/util/Map;
    //   128: aload_0
    //   129: aconst_null
    //   130: putfield 73	com/ycache/danga/MemCached/SockIOPool:buckets	Ljava/util/List;
    //   133: aload_0
    //   134: aconst_null
    //   135: putfield 77	com/ycache/danga/MemCached/SockIOPool:consistentBuckets	Ljava/util/TreeMap;
    //   138: aload_0
    //   139: aconst_null
    //   140: putfield 151	com/ycache/danga/MemCached/SockIOPool:hostDeadDur	Ljava/util/Map;
    //   143: aload_0
    //   144: aconst_null
    //   145: putfield 152	com/ycache/danga/MemCached/SockIOPool:hostDead	Ljava/util/Map;
    //   148: aload_0
    //   149: aconst_null
    //   150: putfield 282	com/ycache/danga/MemCached/SockIOPool:maintThread	Lcom/ycache/danga/MemCached/SockIOPool$MaintThread;
    //   153: aload_0
    //   154: iconst_0
    //   155: putfield 5	com/ycache/danga/MemCached/SockIOPool:initialized	Z
    //   158: getstatic 3	com/ycache/danga/MemCached/SockIOPool:log	Lorg/apache/log4j/Logger;
    //   161: invokevirtual 153	org/apache/log4j/Logger:isDebugEnabled	()Z
    //   164: ifeq +12 -> 176
    //   167: getstatic 3	com/ycache/danga/MemCached/SockIOPool:log	Lorg/apache/log4j/Logger;
    //   170: ldc_w 291
    //   173: invokevirtual 155	org/apache/log4j/Logger:debug	(Ljava/lang/Object;)V
    //   176: aload_1
    //   177: monitorexit
    //   178: goto +8 -> 186
    //   181: astore_3
    //   182: aload_1
    //   183: monitorexit
    //   184: aload_3
    //   185: athrow
    //   186: return
    //
    // Exception table:
    //   from	to	target	type
    //   71	77	80	Exception
    //   4	178	181	finally
    //   181	184	181	finally
  }

  protected void startMaintThread()
  {
    if (this.maintThread != null)
    {
      if (this.maintThread.isRunning())
        log.error("main thread already running");
      else
        this.maintThread.start();
    }
    else
    {
      this.maintThread = new MaintThread(this);
      this.maintThread.setInterval(this.maintSleep);
      this.maintThread.start();
    }
  }

  protected void stopMaintThread()
  {
    if ((this.maintThread != null) && (this.maintThread.isRunning()))
      this.maintThread.stopThread();
  }

  protected void selfMaint()
  {
    Object localObject4;
    Object localObject5;
    SockIO localSockIO1;
    if (log.isDebugEnabled())
      log.debug("++++ Starting self maintenance....");
    HashMap localHashMap = new HashMap();
    synchronized (this)
    {
      ??? = this.availPool.keySet().iterator();
      while (((Iterator)???).hasNext())
      {
        ??? = (String)((Iterator)???).next();
        localObject4 = (Map)this.availPool.get(???);
        if (log.isDebugEnabled())
          log.debug("++++ Size of avail pool for host (" + ((String)???) + ") = " + ((Map)localObject4).size());
        if (((Map)localObject4).size() < this.minConn)
        {
          int i = this.minConn - ((Map)localObject4).size();
          localHashMap.put(???, Integer.valueOf(i));
        }
      }
    }
    ??? = new HashMap();
    ??? = localHashMap.keySet().iterator();
    while (((Iterator)???).hasNext())
    {
      ??? = (String)((Iterator)???).next();
      localObject4 = (Integer)localHashMap.get(???);
      if (log.isDebugEnabled())
        log.debug("++++ Need to create " + localObject4 + " new sockets for pool for host: " + ((String)???));
      localObject5 = new HashSet(((Integer)localObject4).intValue());
      for (int j = 0; j < ((Integer)localObject4).intValue(); ++j)
      {
        localSockIO1 = createSocket((String)???);
        if (localSockIO1 == null)
          break;
        ((Set)localObject5).add(localSockIO1);
      }
      ((Map)???).put(???, localObject5);
    }
    synchronized (this)
    {
      ??? = ((Map)???).keySet().iterator();
      while (((Iterator)???).hasNext())
      {
        localObject4 = (String)((Iterator)???).next();
        localObject5 = (Set)((Map)???).get(localObject4);
        Iterator localIterator1 = ((Set)localObject5).iterator();
        while (localIterator1.hasNext())
        {
          localSockIO1 = (SockIO)localIterator1.next();
          addSocketToPool(this.availPool, (String)localObject4, localSockIO1);
        }
      }
      ??? = this.availPool.keySet().iterator();
      while (((Iterator)???).hasNext())
      {
        localObject4 = (String)((Iterator)???).next();
        localObject5 = (Map)this.availPool.get(localObject4);
        if (log.isDebugEnabled())
          log.debug("++++ Size of avail pool for host (" + ((String)localObject4) + ") = " + ((Map)localObject5).size());
        if (((Map)localObject5).size() > this.maxConn)
        {
          int k = ((Map)localObject5).size() - this.maxConn;
          int l = (k <= this.poolMultiplier) ? k : k / this.poolMultiplier;
          if (log.isDebugEnabled())
            log.debug("++++ need to remove " + l + " spare sockets for pool for host: " + ((String)localObject4));
          Iterator localIterator3 = ((Map)localObject5).keySet().iterator();
          while (localIterator3.hasNext())
          {
            if (l <= 0)
              break;
            SockIO localSockIO3 = (SockIO)localIterator3.next();
            long l2 = ((Long)((Map)localObject5).get(localSockIO3)).longValue();
            if (l2 + this.maxIdle < System.currentTimeMillis())
            {
              if (log.isDebugEnabled())
                log.debug("+++ removing stale entry from pool as it is past its idle timeout and pool is over max spare");
              this.deadPool.put(localSockIO3, ZERO);
              localIterator3.remove();
              --l;
            }
          }
        }
      }
      ??? = this.busyPool.keySet().iterator();
      while (((Iterator)???).hasNext())
      {
        localObject4 = (String)((Iterator)???).next();
        localObject5 = (Map)this.busyPool.get(localObject4);
        if (log.isDebugEnabled())
          log.debug("++++ Size of busy pool for host (" + ((String)localObject4) + ")  = " + ((Map)localObject5).size());
        Iterator localIterator2 = ((Map)localObject5).keySet().iterator();
        while (localIterator2.hasNext())
        {
          SockIO localSockIO2 = (SockIO)localIterator2.next();
          long l1 = ((Long)((Map)localObject5).get(localSockIO2)).longValue();
          if (l1 + this.maxBusyTime < System.currentTimeMillis())
          {
            log.error("+++ removing potentially hung connection from busy pool ... socket in pool for " + (System.currentTimeMillis() - l1) + "ms");
            this.deadPool.put(localSockIO2, ZERO);
            localIterator2.remove();
          }
        }
      }
    }
    synchronized (this.deadPool)
    {
      ??? = this.deadPool.keySet();
      this.deadPool = new IdentityHashMap();
    }
    ??? = ((Set)???).iterator();
    while (((Iterator)???).hasNext())
    {
      localObject4 = (SockIO)((Iterator)???).next();
      try
      {
        ((SockIO)localObject4).trueClose(false);
      }
      catch (Exception localException)
      {
        log.error("++++ failed to close SockIO obj from deadPool");
        log.error(localException.getMessage(), localException);
      }
      localObject4 = null;
    }
    if (log.isDebugEnabled())
      log.debug("+++ ending self maintenance.");
  }

  public void setMasterIDC(String paramString)
  {
    this.masterIDC = paramString;
  }

  public void setZkGroup(String paramString)
  {
    this.zkGroup = paramString;
  }

  public boolean isNutcracker()
  {
    return this.isNutcracker;
  }

  public static Properties loadPropertiesFile(String paramString)
  {
    Properties localProperties = new Properties();
    FileInputStream localFileInputStream = null;
    try
    {
      File localFile = new File(paramString);
      if (localFile.exists())
        localFileInputStream = new FileInputStream(localFile);
      if (localFileInputStream != null)
        localProperties.load(localFileInputStream);
    }
    catch (IOException localIOException3)
    {
      localIOException2.printStackTrace();
    }
    finally
    {
      if (localFileInputStream != null)
        try
        {
          localFileInputStream.close();
        }
        catch (IOException localIOException4)
        {
          localIOException4.printStackTrace();
        }
    }
    return localProperties;
  }

  public static class SockIO
  implements LineInputStream
  {
    private static Logger log = Logger.getLogger(SockIO.class.getName());
    private SockIOPool pool;
    private String host;
    private Socket sock;
    private DataInputStream in;
    private BufferedOutputStream out;

    public SockIO(SockIOPool paramSockIOPool, String paramString, int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean)
      throws IOException, UnknownHostException
    {
      this.pool = paramSockIOPool;
      this.sock = getSocket(paramString, paramInt1, paramInt3);
      if (paramInt2 >= 0)
        this.sock.setSoTimeout(paramInt2);
      this.sock.setTcpNoDelay(paramBoolean);
      this.in = new DataInputStream(new BufferedInputStream(this.sock.getInputStream()));
      this.out = new BufferedOutputStream(this.sock.getOutputStream());
      this.host = new StringBuilder().append(paramString).append(":").append(paramInt1).toString();
    }

    public SockIO(SockIOPool paramSockIOPool, String paramString, int paramInt1, int paramInt2, boolean paramBoolean)
      throws IOException, UnknownHostException
    {
      this.pool = paramSockIOPool;
      String[] arrayOfString = paramString.split(":");
      this.sock = getSocket(arrayOfString[0], Integer.parseInt(arrayOfString[1]), paramInt2);
      if (paramInt1 >= 0)
        this.sock.setSoTimeout(paramInt1);
      this.sock.setTcpNoDelay(paramBoolean);
      this.in = new DataInputStream(new BufferedInputStream(this.sock.getInputStream()));
      this.out = new BufferedOutputStream(this.sock.getOutputStream());
      this.host = paramString;
    }

    protected static Socket getSocket(String paramString, int paramInt1, int paramInt2)
      throws IOException
    {
      SocketChannel localSocketChannel = SocketChannel.open();
      localSocketChannel.socket().connect(new InetSocketAddress(paramString, paramInt1), paramInt2);
      return localSocketChannel.socket();
    }

    public SocketChannel getChannel()
    {
      return this.sock.getChannel();
    }

    public String getHost()
    {
      return this.host;
    }

    public void trueClose()
      throws IOException
    {
      trueClose(true);
    }

    public void trueClose(boolean paramBoolean)
      throws IOException
    {
      if (log.isDebugEnabled())
        log.debug(new StringBuilder().append("++++ Closing socket for real: ").append(toString()).toString());
      int i = 0;
      StringBuilder localStringBuilder = new StringBuilder();
      if (this.in != null)
        try
        {
          this.in.close();
        }
        catch (IOException localIOException1)
        {
          log.error(new StringBuilder().append("++++ error closing input stream for socket: ").append(toString()).append(" for host: ").append(getHost()).toString());
          log.error(localIOException1.getMessage(), localIOException1);
          localStringBuilder.append(new StringBuilder().append("++++ error closing input stream for socket: ").append(toString()).append(" for host: ").append(getHost()).append("\n").toString());
          localStringBuilder.append(localIOException1.getMessage());
          i = 1;
        }
      if (this.out != null)
        try
        {
          this.out.close();
        }
        catch (IOException localIOException2)
        {
          log.error(new StringBuilder().append("++++ error closing output stream for socket: ").append(toString()).append(" for host: ").append(getHost()).toString());
          log.error(localIOException2.getMessage(), localIOException2);
          localStringBuilder.append(new StringBuilder().append("++++ error closing output stream for socket: ").append(toString()).append(" for host: ").append(getHost()).append("\n").toString());
          localStringBuilder.append(localIOException2.getMessage());
          i = 1;
        }
      if (this.sock != null)
        try
        {
          this.sock.close();
        }
        catch (IOException localIOException3)
        {
          log.error(new StringBuilder().append("++++ error closing socket: ").append(toString()).append(" for host: ").append(getHost()).toString());
          log.error(localIOException3.getMessage(), localIOException3);
          localStringBuilder.append(new StringBuilder().append("++++ error closing socket: ").append(toString()).append(" for host: ").append(getHost()).append("\n").toString());
          localStringBuilder.append(localIOException3.getMessage());
          i = 1;
        }
      if ((paramBoolean) && (this.sock != null))
        SockIOPool.access$100(this.pool, this, false);
      this.in = null;
      this.out = null;
      this.sock = null;
      if (i != 0)
        throw new IOException(localStringBuilder.toString());
    }

    void close()
    {
      if (log.isDebugEnabled())
        log.debug(new StringBuilder().append("++++ marking socket (").append(toString()).append(") as closed and available to return to avail pool").toString());
      SockIOPool.access$200(this.pool, this);
    }

    boolean isConnected()
    {
      return ((this.sock != null) && (this.sock.isConnected()));
    }

    boolean isAlive()
    {
      if (!(isConnected()))
        return false;
      try
      {
        write("version\r\n".getBytes());
        flush();
        String str = readLine();
      }
      catch (IOException localIOException)
      {
        return false;
      }
      return true;
    }

    public String readLine()
      throws IOException
    {
      if ((this.sock == null) || (!(this.sock.isConnected())))
      {
        log.error("++++ attempting to read from closed socket");
        throw new IOException("++++ attempting to read from closed socket");
      }
      byte[] arrayOfByte = new byte[1];
      ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
      int i = 0;
      while (this.in.read(arrayOfByte, 0, 1) != -1)
      {
        if (arrayOfByte[0] == 13)
        {
          i = 1;
        }
        else if (i != 0)
        {
          if (arrayOfByte[0] == 10)
            break;
          i = 0;
        }
        localByteArrayOutputStream.write(arrayOfByte, 0, 1);
      }
      if ((localByteArrayOutputStream == null) || (localByteArrayOutputStream.size() <= 0))
        throw new IOException("++++ Stream appears to be dead, so closing it down");
      return localByteArrayOutputStream.toString().trim();
    }

    public void discardInput()
    {
      try
      {
        while (this.in.available() > 0)
        {
          String str = readLine();
          log.warn(new StringBuilder().append("++++ surprise! get reply at noreply mode. got:").append(str).toString());
        }
      }
      catch (IOException localIOException)
      {
        localIOException.printStackTrace();
      }
    }

    public void clearEOL()
      throws IOException
    {
      if ((this.sock == null) || (!(this.sock.isConnected())))
      {
        log.error("++++ attempting to read from closed socket");
        throw new IOException("++++ attempting to read from closed socket");
      }
      byte[] arrayOfByte = new byte[1];
      int i = 0;
      while (true)
      {
        do
          while (true)
          {
            if (this.in.read(arrayOfByte, 0, 1) == -1)
              return;
            if (arrayOfByte[0] != 13)
              break;
            i = 1;
          }
        while (i == 0);
        if (arrayOfByte[0] == 10)
          return;
        i = 0;
      }
    }

    public int read(byte[] paramArrayOfByte)
      throws IOException
    {
      if ((this.sock == null) || (!(this.sock.isConnected())))
      {
        log.error("++++ attempting to read from closed socket");
        throw new IOException("++++ attempting to read from closed socket");
      }
      int i = 0;
      while (i < paramArrayOfByte.length)
      {
        int j = this.in.read(paramArrayOfByte, i, paramArrayOfByte.length - i);
        i += j;
      }
      return i;
    }

    void flush()
      throws IOException
    {
      if ((this.sock == null) || (!(this.sock.isConnected())))
      {
        log.error("++++ attempting to write to closed socket");
        throw new IOException("++++ attempting to write to closed socket");
      }
      this.out.flush();
    }

    void write(byte[] paramArrayOfByte)
      throws IOException
    {
      if ((this.sock == null) || (!(this.sock.isConnected())))
      {
        log.error("++++ attempting to write to closed socket");
        throw new IOException("++++ attempting to write to closed socket");
      }
      this.out.write(paramArrayOfByte);
    }

    public int hashCode()
    {
      return ((this.sock == null) ? 0 : this.sock.hashCode());
    }

    public String toString()
    {
      return ((this.sock == null) ? "" : this.sock.toString());
    }

    protected void finalize()
      throws Throwable
    {
      try
      {
        if (this.sock != null)
        {
          log.error("++++ closing potentially leaked socket in finalize");
          this.sock.close();
          this.sock = null;
        }
      }
      catch (Throwable localThrowable)
      {
        log.error(localThrowable.getMessage(), localThrowable);
      }
      finally
      {
        super.finalize();
      }
    }
  }

  protected static class MaintThread extends Thread
  {
    private static Logger log = Logger.getLogger(MaintThread.class.getName());
    private SockIOPool pool;
    private long interval = 3000L;
    private boolean stopThread = false;
    private boolean running;

    protected MaintThread(SockIOPool paramSockIOPool)
    {
      this.pool = paramSockIOPool;
      setDaemon(true);
      setName("MaintThread");
    }

    public void setInterval(long paramLong)
    {
      this.interval = paramLong;
    }

    public boolean isRunning()
    {
      return this.running;
    }

    public void stopThread()
    {
      this.stopThread = true;
      interrupt();
    }

    public void run()
    {
      this.running = true;
      if (!(this.stopThread));
      try
      {
        Thread.sleep(this.interval);
        if (this.pool.isInitialized())
          this.pool.selfMaint();
      }
      catch (Exception localException)
      {
        this.running = false;
      }
    }
  }
}