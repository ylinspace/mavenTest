package com.ycache.redis.clients.jedis;

import com.ycache.redis.clients.jedis.exceptions.JedisDataException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class BinaryTransaction extends Queable
{
  protected Client client = null;
  protected boolean inTransaction = true;

  public BinaryTransaction()
  {
  }

  public BinaryTransaction(Client paramClient)
  {
    this.client = paramClient;
  }

  public List<Object> exec()
  {
    this.client.exec();
    this.client.getAll(1);
    List localList = this.client.getObjectMultiBulkReply();
    if (localList == null)
      return null;
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      Object localObject = localIterator.next();
      try
      {
        localArrayList.add(generateResponse(localObject).get());
      }
      catch (JedisDataException localJedisDataException)
      {
        localArrayList.add(localJedisDataException);
      }
    }
    return localArrayList;
  }

  public List<Response<?>> execGetResponse()
  {
    this.client.exec();
    this.client.getAll(1);
    List localList = this.client.getObjectMultiBulkReply();
    if (localList == null)
      return null;
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      Object localObject = localIterator.next();
      localArrayList.add(generateResponse(localObject));
    }
    return localArrayList;
  }

  public java.lang.String discard()
  {
    this.client.discard();
    this.client.getAll(1);
    this.inTransaction = false;
    clean();
    return this.client.getStatusCodeReply();
  }

  public Response<Long> append(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    this.client.append(paramArrayOfByte1, paramArrayOfByte2);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<List<java.lang.String>> blpop(byte[][] paramArrayOfByte)
  {
    this.client.blpop(paramArrayOfByte);
    return getResponse(BuilderFactory.STRING_LIST);
  }

  public Response<List<java.lang.String>> brpop(byte[][] paramArrayOfByte)
  {
    this.client.brpop(paramArrayOfByte);
    return getResponse(BuilderFactory.STRING_LIST);
  }

  public Response<Long> decr(byte[] paramArrayOfByte)
  {
    this.client.decr(paramArrayOfByte);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> decrBy(byte[] paramArrayOfByte, long paramLong)
  {
    this.client.decrBy(paramArrayOfByte, paramLong);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> del(byte[][] paramArrayOfByte)
  {
    this.client.del(paramArrayOfByte);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<java.lang.String> echo(byte[] paramArrayOfByte)
  {
    this.client.echo(paramArrayOfByte);
    return getResponse(BuilderFactory.STRING);
  }

  public Response<Boolean> exists(byte[] paramArrayOfByte)
  {
    this.client.exists(paramArrayOfByte);
    return getResponse(BuilderFactory.BOOLEAN);
  }

  public Response<Long> expire(byte[] paramArrayOfByte, int paramInt)
  {
    this.client.expire(paramArrayOfByte, paramInt);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> expireAt(byte[] paramArrayOfByte, long paramLong)
  {
    this.client.expireAt(paramArrayOfByte, paramLong);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<byte[]> get(byte[] paramArrayOfByte)
  {
    this.client.get(paramArrayOfByte);
    return getResponse(BuilderFactory.BYTE_ARRAY);
  }

  public Response<java.lang.String> getSet(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    this.client.getSet(paramArrayOfByte1, paramArrayOfByte2);
    return getResponse(BuilderFactory.STRING);
  }

  public Response<Long> hdel(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    this.client.hdel(paramArrayOfByte1, new byte[][] { paramArrayOfByte2 });
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Boolean> hexists(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    this.client.hexists(paramArrayOfByte1, paramArrayOfByte2);
    return getResponse(BuilderFactory.BOOLEAN);
  }

  public Response<byte[]> hget(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    this.client.hget(paramArrayOfByte1, paramArrayOfByte2);
    return getResponse(BuilderFactory.BYTE_ARRAY);
  }

  public Response<Map<java.lang.String, java.lang.String>> hgetAll(byte[] paramArrayOfByte)
  {
    this.client.hgetAll(paramArrayOfByte);
    return getResponse(BuilderFactory.STRING_MAP);
  }

  public Response<Long> hincrBy(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, long paramLong)
  {
    this.client.hincrBy(paramArrayOfByte1, paramArrayOfByte2, paramLong);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Set<byte[]>> hkeys(byte[] paramArrayOfByte)
  {
    this.client.hkeys(paramArrayOfByte);
    return getResponse(BuilderFactory.BYTE_ARRAY_ZSET);
  }

  public Response<Long> hlen(byte[] paramArrayOfByte)
  {
    this.client.hlen(paramArrayOfByte);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<List<byte[]>> hmget(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1)
  {
    this.client.hmget(paramArrayOfByte, paramArrayOfByte1);
    return getResponse(BuilderFactory.BYTE_ARRAY_LIST);
  }

  public Response<byte[]> hmset(byte[] paramArrayOfByte, Map<byte[], byte[]> paramMap)
  {
    this.client.hmset(paramArrayOfByte, paramMap);
    return getResponse(BuilderFactory.BYTE_ARRAY);
  }

  public Response<Long> hset(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
  {
    this.client.hset(paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> hsetnx(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
  {
    this.client.hsetnx(paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<List<byte[]>> hvals(byte[] paramArrayOfByte)
  {
    this.client.hvals(paramArrayOfByte);
    return getResponse(BuilderFactory.BYTE_ARRAY_LIST);
  }

  public Response<Long> incr(byte[] paramArrayOfByte)
  {
    this.client.incr(paramArrayOfByte);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> incrBy(byte[] paramArrayOfByte, long paramLong)
  {
    this.client.incrBy(paramArrayOfByte, paramLong);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Set<byte[]>> keys(byte[] paramArrayOfByte)
  {
    this.client.keys(paramArrayOfByte);
    return getResponse(BuilderFactory.BYTE_ARRAY_ZSET);
  }

  public Response<byte[]> lindex(byte[] paramArrayOfByte, long paramLong)
  {
    this.client.lindex(paramArrayOfByte, paramLong);
    return getResponse(BuilderFactory.BYTE_ARRAY);
  }

  public Response<Long> linsert(byte[] paramArrayOfByte1, BinaryClient.LIST_POSITION paramLIST_POSITION, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
  {
    this.client.linsert(paramArrayOfByte1, paramLIST_POSITION, paramArrayOfByte2, paramArrayOfByte3);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> llen(byte[] paramArrayOfByte)
  {
    this.client.llen(paramArrayOfByte);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<byte[]> lpop(byte[] paramArrayOfByte)
  {
    this.client.lpop(paramArrayOfByte);
    return getResponse(BuilderFactory.BYTE_ARRAY);
  }

  public Response<Long> lpush(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    this.client.lpush(paramArrayOfByte1, new byte[][] { paramArrayOfByte2 });
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> lpushx(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    this.client.lpushx(paramArrayOfByte1, new byte[][] { paramArrayOfByte2 });
    return getResponse(BuilderFactory.LONG);
  }

  public Response<List<byte[]>> lrange(byte[] paramArrayOfByte, long paramLong1, long paramLong2)
  {
    this.client.lrange(paramArrayOfByte, paramLong1, paramLong2);
    return getResponse(BuilderFactory.BYTE_ARRAY_LIST);
  }

  public Response<Long> lrem(byte[] paramArrayOfByte1, long paramLong, byte[] paramArrayOfByte2)
  {
    this.client.lrem(paramArrayOfByte1, paramLong, paramArrayOfByte2);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<java.lang.String> lset(byte[] paramArrayOfByte1, long paramLong, byte[] paramArrayOfByte2)
  {
    this.client.lset(paramArrayOfByte1, paramLong, paramArrayOfByte2);
    return getResponse(BuilderFactory.STRING);
  }

  public Response<java.lang.String> ltrim(byte[] paramArrayOfByte, long paramLong1, long paramLong2)
  {
    this.client.ltrim(paramArrayOfByte, paramLong1, paramLong2);
    return getResponse(BuilderFactory.STRING);
  }

  public Response<List<byte[]>> mget(byte[][] paramArrayOfByte)
  {
    this.client.mget(paramArrayOfByte);
    return getResponse(BuilderFactory.BYTE_ARRAY_LIST);
  }

  public Response<Long> move(byte[] paramArrayOfByte, int paramInt)
  {
    this.client.move(paramArrayOfByte, paramInt);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<java.lang.String> mset(byte[][] paramArrayOfByte)
  {
    this.client.mset(paramArrayOfByte);
    return getResponse(BuilderFactory.STRING);
  }

  public Response<Long> msetnx(byte[][] paramArrayOfByte)
  {
    this.client.msetnx(paramArrayOfByte);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> persist(byte[] paramArrayOfByte)
  {
    this.client.persist(paramArrayOfByte);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<java.lang.String> rename(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    this.client.rename(paramArrayOfByte1, paramArrayOfByte2);
    return getResponse(BuilderFactory.STRING);
  }

  public Response<Long> renamenx(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    this.client.renamenx(paramArrayOfByte1, paramArrayOfByte2);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<byte[]> rpop(byte[] paramArrayOfByte)
  {
    this.client.rpop(paramArrayOfByte);
    return getResponse(BuilderFactory.BYTE_ARRAY);
  }

  public Response<byte[]> rpoplpush(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    this.client.rpoplpush(paramArrayOfByte1, paramArrayOfByte2);
    return getResponse(BuilderFactory.BYTE_ARRAY);
  }

  public Response<Long> rpush(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    this.client.rpush(paramArrayOfByte1, new byte[][] { paramArrayOfByte2 });
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> rpushx(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    this.client.rpushx(paramArrayOfByte1, new byte[][] { paramArrayOfByte2 });
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> sadd(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    this.client.sadd(paramArrayOfByte1, new byte[][] { paramArrayOfByte2 });
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> scard(byte[] paramArrayOfByte)
  {
    this.client.scard(paramArrayOfByte);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Set<byte[]>> sdiff(byte[][] paramArrayOfByte)
  {
    this.client.sdiff(paramArrayOfByte);
    return getResponse(BuilderFactory.BYTE_ARRAY_ZSET);
  }

  public Response<Long> sdiffstore(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1)
  {
    this.client.sdiffstore(paramArrayOfByte, paramArrayOfByte1);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<byte[]> set(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    this.client.set(paramArrayOfByte1, paramArrayOfByte2);
    return getResponse(BuilderFactory.BYTE_ARRAY);
  }

  public Response<Boolean> setbit(java.lang.String paramString, long paramLong, boolean paramBoolean)
  {
    this.client.setbit(paramString, paramLong, paramBoolean);
    return getResponse(BuilderFactory.BOOLEAN);
  }

  public Response<java.lang.String> setex(byte[] paramArrayOfByte1, int paramInt, byte[] paramArrayOfByte2)
  {
    this.client.setex(paramArrayOfByte1, paramInt, paramArrayOfByte2);
    return getResponse(BuilderFactory.STRING);
  }

  public Response<Long> setnx(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    this.client.setnx(paramArrayOfByte1, paramArrayOfByte2);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Set<byte[]>> sinter(byte[][] paramArrayOfByte)
  {
    this.client.sinter(paramArrayOfByte);
    return getResponse(BuilderFactory.BYTE_ARRAY_ZSET);
  }

  public Response<Long> sinterstore(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1)
  {
    this.client.sinterstore(paramArrayOfByte, paramArrayOfByte1);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Boolean> sismember(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    this.client.sismember(paramArrayOfByte1, paramArrayOfByte2);
    return getResponse(BuilderFactory.BOOLEAN);
  }

  public Response<Set<byte[]>> smembers(byte[] paramArrayOfByte)
  {
    this.client.smembers(paramArrayOfByte);
    return getResponse(BuilderFactory.BYTE_ARRAY_ZSET);
  }

  public Response<Long> smove(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
  {
    this.client.smove(paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<List<byte[]>> sort(byte[] paramArrayOfByte)
  {
    this.client.sort(paramArrayOfByte);
    return getResponse(BuilderFactory.BYTE_ARRAY_LIST);
  }

  public Response<List<byte[]>> sort(byte[] paramArrayOfByte, SortingParams paramSortingParams)
  {
    this.client.sort(paramArrayOfByte, paramSortingParams);
    return getResponse(BuilderFactory.BYTE_ARRAY_LIST);
  }

  public Response<List<byte[]>> sort(byte[] paramArrayOfByte1, SortingParams paramSortingParams, byte[] paramArrayOfByte2)
  {
    this.client.sort(paramArrayOfByte1, paramSortingParams, paramArrayOfByte2);
    return getResponse(BuilderFactory.BYTE_ARRAY_LIST);
  }

  public Response<List<byte[]>> sort(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    this.client.sort(paramArrayOfByte1, paramArrayOfByte2);
    return getResponse(BuilderFactory.BYTE_ARRAY_LIST);
  }

  public Response<byte[]> spop(byte[] paramArrayOfByte)
  {
    this.client.spop(paramArrayOfByte);
    return getResponse(BuilderFactory.BYTE_ARRAY);
  }

  public Response<byte[]> srandmember(byte[] paramArrayOfByte)
  {
    this.client.srandmember(paramArrayOfByte);
    return getResponse(BuilderFactory.BYTE_ARRAY);
  }

  public Response<Long> srem(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    this.client.srem(paramArrayOfByte1, new byte[][] { paramArrayOfByte2 });
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> strlen(byte[] paramArrayOfByte)
  {
    this.client.strlen(paramArrayOfByte);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<java.lang.String> substr(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    this.client.substr(paramArrayOfByte, paramInt1, paramInt2);
    return getResponse(BuilderFactory.STRING);
  }

  public Response<Set<byte[]>> sunion(byte[][] paramArrayOfByte)
  {
    this.client.sunion(paramArrayOfByte);
    return getResponse(BuilderFactory.BYTE_ARRAY_ZSET);
  }

  public Response<Long> sunionstore(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1)
  {
    this.client.sunionstore(paramArrayOfByte, paramArrayOfByte1);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> ttl(byte[] paramArrayOfByte)
  {
    this.client.ttl(paramArrayOfByte);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<java.lang.String> type(byte[] paramArrayOfByte)
  {
    this.client.type(paramArrayOfByte);
    return getResponse(BuilderFactory.STRING);
  }

  public Response<Long> zadd(byte[] paramArrayOfByte1, double paramDouble, byte[] paramArrayOfByte2)
  {
    this.client.zadd(paramArrayOfByte1, paramDouble, paramArrayOfByte2);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> zcard(byte[] paramArrayOfByte)
  {
    this.client.zcard(paramArrayOfByte);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> zcount(byte[] paramArrayOfByte, double paramDouble1, double paramDouble2)
  {
    return zcount(paramArrayOfByte, Protocol.toByteArray(paramDouble1), Protocol.toByteArray(paramDouble2));
  }

  public Response<Long> zcount(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
  {
    this.client.zcount(paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Double> zincrby(byte[] paramArrayOfByte1, double paramDouble, byte[] paramArrayOfByte2)
  {
    this.client.zincrby(paramArrayOfByte1, paramDouble, paramArrayOfByte2);
    return getResponse(BuilderFactory.DOUBLE);
  }

  public Response<Long> zinterstore(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1)
  {
    this.client.zinterstore(paramArrayOfByte, paramArrayOfByte1);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> zinterstore(byte[] paramArrayOfByte, ZParams paramZParams, byte[][] paramArrayOfByte1)
  {
    this.client.zinterstore(paramArrayOfByte, paramZParams, paramArrayOfByte1);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Set<byte[]>> zrange(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    this.client.zrange(paramArrayOfByte, paramInt1, paramInt2);
    return getResponse(BuilderFactory.BYTE_ARRAY_ZSET);
  }

  public Response<Set<byte[]>> zrangeByScore(byte[] paramArrayOfByte, double paramDouble1, double paramDouble2)
  {
    return zrangeByScore(paramArrayOfByte, Protocol.toByteArray(paramDouble1), Protocol.toByteArray(paramDouble2));
  }

  public Response<Set<byte[]>> zrangeByScore(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
  {
    this.client.zrangeByScore(paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3);
    return getResponse(BuilderFactory.BYTE_ARRAY_ZSET);
  }

  public Response<Set<byte[]>> zrangeByScore(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3, int paramInt1, int paramInt2)
  {
    this.client.zrangeByScore(paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3, paramInt1, paramInt2);
    return getResponse(BuilderFactory.BYTE_ARRAY_ZSET);
  }

  public Response<Set<byte[]>> zrangeByScore(byte[] paramArrayOfByte, double paramDouble1, double paramDouble2, int paramInt1, int paramInt2)
  {
    return zrangeByScore(paramArrayOfByte, Protocol.toByteArray(paramDouble1), Protocol.toByteArray(paramDouble2), paramInt1, paramInt2);
  }

  public Response<Set<Tuple>> zrangeByScoreWithScores(byte[] paramArrayOfByte, double paramDouble1, double paramDouble2)
  {
    return zrangeByScoreWithScores(paramArrayOfByte, Protocol.toByteArray(paramDouble1), Protocol.toByteArray(paramDouble2));
  }

  public Response<Set<Tuple>> zrangeByScoreWithScores(byte[] paramArrayOfByte, double paramDouble1, double paramDouble2, int paramInt1, int paramInt2)
  {
    return zrangeByScoreWithScores(paramArrayOfByte, Protocol.toByteArray(paramDouble1), Protocol.toByteArray(paramDouble2), paramInt1, paramInt2);
  }

  public Response<Set<Tuple>> zrangeByScoreWithScores(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
  {
    this.client.zrangeByScoreWithScores(paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3);
    return getResponse(BuilderFactory.TUPLE_ZSET_BINARY);
  }

  public Response<Set<Tuple>> zrangeByScoreWithScores(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3, int paramInt1, int paramInt2)
  {
    this.client.zrangeByScoreWithScores(paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3, paramInt1, paramInt2);
    return getResponse(BuilderFactory.TUPLE_ZSET_BINARY);
  }

  public Response<Set<Tuple>> zrangeWithScores(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    this.client.zrangeWithScores(paramArrayOfByte, paramInt1, paramInt2);
    return getResponse(BuilderFactory.TUPLE_ZSET_BINARY);
  }

  public Response<Long> zrank(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    this.client.zrank(paramArrayOfByte1, paramArrayOfByte2);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> zrem(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    this.client.zrem(paramArrayOfByte1, new byte[][] { paramArrayOfByte2 });
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> zremrangeByRank(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    this.client.zremrangeByRank(paramArrayOfByte, paramInt1, paramInt2);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> zremrangeByScore(byte[] paramArrayOfByte, double paramDouble1, double paramDouble2)
  {
    return zremrangeByScore(paramArrayOfByte, Protocol.toByteArray(paramDouble1), Protocol.toByteArray(paramDouble2));
  }

  public Response<Long> zremrangeByScore(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
  {
    this.client.zremrangeByScore(paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Set<byte[]>> zrevrange(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    this.client.zrevrange(paramArrayOfByte, paramInt1, paramInt2);
    return getResponse(BuilderFactory.BYTE_ARRAY_ZSET);
  }

  public Response<Set<Tuple>> zrevrangeWithScores(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    this.client.zrevrangeWithScores(paramArrayOfByte, paramInt1, paramInt2);
    return getResponse(BuilderFactory.TUPLE_ZSET_BINARY);
  }

  public Response<Long> zrevrank(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    this.client.zrevrank(paramArrayOfByte1, paramArrayOfByte2);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Double> zscore(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    this.client.zscore(paramArrayOfByte1, paramArrayOfByte2);
    return getResponse(BuilderFactory.DOUBLE);
  }

  public Response<Long> zunionstore(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1)
  {
    this.client.zunionstore(paramArrayOfByte, paramArrayOfByte1);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> zunionstore(byte[] paramArrayOfByte, ZParams paramZParams, byte[][] paramArrayOfByte1)
  {
    this.client.zunionstore(paramArrayOfByte, paramZParams, paramArrayOfByte1);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<byte[]> brpoplpush(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, int paramInt)
  {
    this.client.brpoplpush(paramArrayOfByte1, paramArrayOfByte2, paramInt);
    return getResponse(BuilderFactory.BYTE_ARRAY);
  }

  public Response<java.lang.String> select(int paramInt)
  {
    this.client.select(paramInt);
    return getResponse(BuilderFactory.STRING);
  }

  public Response<java.lang.String> flushDB()
  {
    this.client.flushDB();
    return getResponse(BuilderFactory.STRING);
  }

  public Response<java.lang.String> flushAll()
  {
    this.client.flushAll();
    return getResponse(BuilderFactory.STRING);
  }

  public Response<java.lang.String> save()
  {
    this.client.save();
    return getResponse(BuilderFactory.STRING);
  }

  public Response<java.lang.String> info()
  {
    this.client.info();
    return getResponse(BuilderFactory.STRING);
  }

  public Response<Long> lastsave()
  {
    this.client.lastsave();
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> dbSize()
  {
    this.client.dbSize();
    return getResponse(BuilderFactory.LONG);
  }

  public Response<List<byte[]>> configGet(byte[] paramArrayOfByte)
  {
    this.client.configGet(paramArrayOfByte);
    return getResponse(BuilderFactory.BYTE_ARRAY_LIST);
  }

  public Response<byte[]> configSet(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    this.client.configSet(paramArrayOfByte1, paramArrayOfByte2);
    return getResponse(BuilderFactory.BYTE_ARRAY);
  }

  public Response<java.lang.String> configResetStat()
  {
    this.client.configResetStat();
    return getResponse(BuilderFactory.STRING);
  }

  public Response<java.lang.String> shutdown()
  {
    this.client.shutdown();
    return getResponse(BuilderFactory.STRING);
  }

  public Response<Boolean> getbit(byte[] paramArrayOfByte, long paramLong)
  {
    this.client.getbit(paramArrayOfByte, paramLong);
    return getResponse(BuilderFactory.BOOLEAN);
  }

  public Response<Boolean> setbit(byte[] paramArrayOfByte1, long paramLong, byte[] paramArrayOfByte2)
  {
    this.client.setbit(paramArrayOfByte1, paramLong, paramArrayOfByte2);
    return getResponse(BuilderFactory.BOOLEAN);
  }

  public Response<java.lang.String> ping()
  {
    this.client.ping();
    return getResponse(BuilderFactory.STRING);
  }

  public Response<Long> setrange(byte[] paramArrayOfByte1, long paramLong, byte[] paramArrayOfByte2)
  {
    this.client.setrange(paramArrayOfByte1, paramLong, paramArrayOfByte2);
    return getResponse(BuilderFactory.LONG);
  }

  public Response<java.lang.String> randomKey()
  {
    this.client.randomKey();
    return getResponse(BuilderFactory.STRING);
  }

  public Response<Long> publish(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    this.client.publish(paramArrayOfByte1, paramArrayOfByte2);
    return getResponse(BuilderFactory.LONG);
  }
}