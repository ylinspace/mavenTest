package com.ycache.redis.clients.util;

public abstract class ShardInfo<T>
{
  private int weight;

  public ShardInfo()
  {
  }

  public ShardInfo(int paramInt)
  {
    this.weight = paramInt;
  }

  public int getWeight()
  {
    return this.weight;
  }

  protected abstract T createResource();

  public abstract String getName();
}