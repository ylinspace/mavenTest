package com.ycache.redis.clients.util;

import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Sharded<R, S extends ShardInfo<R>>
{
  public static final int DEFAULT_WEIGHT = 1;
  private TreeMap<Long, S> nodes;
  private final Hashing algo;
  private final Map<ShardInfo<R>, R> resources;
  private Pattern tagPattern;
  public static final Pattern DEFAULT_KEY_TAG_PATTERN = Pattern.compile("\\{(.+?)\\}");

  public Sharded(List<S> paramList)
  {
    this(paramList, Hashing.MURMUR_HASH);
  }

  public Sharded(List<S> paramList, Hashing paramHashing)
  {
    this.resources = new LinkedHashMap();
    this.tagPattern = null;
    this.algo = paramHashing;
    initialize(paramList);
  }

  public Sharded(List<S> paramList, Pattern paramPattern)
  {
    this(paramList, Hashing.MURMUR_HASH, paramPattern);
  }

  public Sharded(List<S> paramList, Hashing paramHashing, Pattern paramPattern)
  {
    this.resources = new LinkedHashMap();
    this.tagPattern = null;
    this.algo = paramHashing;
    this.tagPattern = paramPattern;
    initialize(paramList);
  }

  private void initialize(List<S> paramList)
  {
    this.nodes = new TreeMap();
    for (int i = 0; i != paramList.size(); ++i)
    {
      int j;
      ShardInfo localShardInfo = (ShardInfo)paramList.get(i);
      if (localShardInfo.getName() == null)
        for (j = 0; j < 160 * localShardInfo.getWeight(); ++j)
          this.nodes.put(Long.valueOf(this.algo.hash("SHARD-" + i + "-NODE-" + j)), localShardInfo);
      else
        for (j = 0; j < 160 * localShardInfo.getWeight(); ++j)
          this.nodes.put(Long.valueOf(this.algo.hash(localShardInfo.getName() + "*" + localShardInfo.getWeight() + j)), localShardInfo);
      this.resources.put(localShardInfo, localShardInfo.createResource());
    }
  }

  public R getShard(byte[] paramArrayOfByte)
  {
    return this.resources.get(getShardInfo(paramArrayOfByte));
  }

  public R getShard(String paramString)
  {
    return this.resources.get(getShardInfo(paramString));
  }

  public S getShardInfo(byte[] paramArrayOfByte)
  {
    SortedMap localSortedMap = this.nodes.tailMap(Long.valueOf(this.algo.hash(paramArrayOfByte)));
    if (localSortedMap.isEmpty())
      return ((ShardInfo)this.nodes.get(this.nodes.firstKey()));
    return ((ShardInfo)localSortedMap.get(localSortedMap.firstKey()));
  }

  public S getShardInfo(String paramString)
  {
    return getShardInfo(SafeEncoder.encode(getKeyTag(paramString)));
  }

  public String getKeyTag(String paramString)
  {
    if (this.tagPattern != null)
    {
      Matcher localMatcher = this.tagPattern.matcher(paramString);
      if (localMatcher.find())
        return localMatcher.group(1);
    }
    return paramString;
  }

  public Collection<S> getAllShardInfo()
  {
    return Collections.unmodifiableCollection(this.nodes.values());
  }

  public Collection<R> getAllShards()
  {
    return Collections.unmodifiableCollection(this.resources.values());
  }
}