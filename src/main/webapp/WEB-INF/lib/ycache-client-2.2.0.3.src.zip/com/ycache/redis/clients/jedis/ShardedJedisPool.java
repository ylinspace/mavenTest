package com.ycache.redis.clients.jedis;

import com.ycache.redis.clients.util.Hashing;
import com.ycache.redis.clients.util.Pool;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Pattern;
import org.apache.commons.pool.BasePoolableObjectFactory;
import org.apache.commons.pool.impl.GenericObjectPool.Config;

public class ShardedJedisPool extends Pool<ShardedJedis>
{
  String poolName;

  public ShardedJedisPool(GenericObjectPool.Config paramConfig, List<JedisShardInfo> paramList)
  {
    this(paramConfig, paramList, Hashing.MURMUR_HASH);
  }

  public ShardedJedisPool(GenericObjectPool.Config paramConfig, List<JedisShardInfo> paramList, Hashing paramHashing)
  {
    this(paramConfig, paramList, paramHashing, null);
  }

  public ShardedJedisPool(GenericObjectPool.Config paramConfig, List<JedisShardInfo> paramList, Pattern paramPattern)
  {
    this(paramConfig, paramList, Hashing.MURMUR_HASH, paramPattern);
  }

  public ShardedJedisPool(GenericObjectPool.Config paramConfig, List<JedisShardInfo> paramList, Hashing paramHashing, Pattern paramPattern)
  {
    super(paramConfig, new ShardedJedisFactory(paramList, paramHashing, paramPattern));
    this.poolName = null;
  }

  public void setPoolName(String paramString)
  {
    this.poolName = paramString;
  }

  public String getPoolName()
  {
    return this.poolName;
  }

  private static class ShardedJedisFactory extends BasePoolableObjectFactory
  {
    private List<JedisShardInfo> shards;
    private Hashing algo;
    private Pattern keyTagPattern;

    public ShardedJedisFactory(List<JedisShardInfo> paramList, Hashing paramHashing, Pattern paramPattern)
    {
      this.shards = paramList;
      this.algo = paramHashing;
      this.keyTagPattern = paramPattern;
    }

    public Object makeObject()
      throws Exception
    {
      ShardedJedis localShardedJedis = new ShardedJedis(this.shards, this.algo, this.keyTagPattern);
      return localShardedJedis;
    }

    public void destroyObject(Object paramObject)
      throws Exception
    {
      if ((paramObject != null) && (paramObject instanceof ShardedJedis))
      {
        ShardedJedis localShardedJedis = (ShardedJedis)paramObject;
        Iterator localIterator = localShardedJedis.getAllShards().iterator();
        while (localIterator.hasNext())
        {
          Jedis localJedis = (Jedis)localIterator.next();
          try
          {
            try
            {
              localJedis.quit();
            }
            catch (Exception localException1)
            {
            }
            localJedis.disconnect();
          }
          catch (Exception localException2)
          {
          }
        }
      }
    }

    public boolean validateObject(Object paramObject)
    {
      ShardedJedis localShardedJedis;
      try
      {
        localShardedJedis = (ShardedJedis)paramObject;
        Iterator localIterator = localShardedJedis.getAllShards().iterator();
        while (localIterator.hasNext())
        {
          Jedis localJedis = (Jedis)localIterator.next();
          if (!(localJedis.ping().equals("PONG")))
            return false;
        }
        return true;
      }
      catch (Exception localException)
      {
      }
      return false;
    }
  }
}