package com.ycache.redis.clients.jedis;

import com.ycache.redis.clients.jedis.exceptions.JedisConnectionException;
import com.ycache.redis.clients.jedis.exceptions.JedisException;
import com.ycache.redis.clients.util.SafeEncoder;
import java.util.Arrays;
import java.util.List;

public abstract class JedisPubSub
{
  private int subscribedChannels = 0;
  private Client client;

  public abstract void onMessage(String paramString1, String paramString2);

  public abstract void onPMessage(String paramString1, String paramString2, String paramString3);

  public abstract void onSubscribe(String paramString, int paramInt);

  public abstract void onUnsubscribe(String paramString, int paramInt);

  public abstract void onPUnsubscribe(String paramString, int paramInt);

  public abstract void onPSubscribe(String paramString, int paramInt);

  public void unsubscribe()
  {
    if (this.client == null)
      throw new JedisConnectionException("JedisPubSub was not subscribed to a Jedis instance.");
    this.client.unsubscribe();
    this.client.flush();
  }

  public void unsubscribe(String[] paramArrayOfString)
  {
    this.client.unsubscribe(paramArrayOfString);
    this.client.flush();
  }

  public void subscribe(String[] paramArrayOfString)
  {
    this.client.subscribe(paramArrayOfString);
    this.client.flush();
  }

  public void psubscribe(String[] paramArrayOfString)
  {
    this.client.psubscribe(paramArrayOfString);
    this.client.flush();
  }

  public void punsubscribe()
  {
    this.client.punsubscribe();
    this.client.flush();
  }

  public void punsubscribe(String[] paramArrayOfString)
  {
    this.client.punsubscribe(paramArrayOfString);
    this.client.flush();
  }

  public boolean isSubscribed()
  {
    return (this.subscribedChannels > 0);
  }

  public void proceedWithPatterns(Client paramClient, String[] paramArrayOfString)
  {
    this.client = paramClient;
    paramClient.psubscribe(paramArrayOfString);
    paramClient.flush();
    process(paramClient);
  }

  public void proceed(Client paramClient, String[] paramArrayOfString)
  {
    this.client = paramClient;
    paramClient.subscribe(paramArrayOfString);
    paramClient.flush();
    process(paramClient);
  }

  private void process(Client paramClient)
  {
    do
    {
      byte[] arrayOfByte2;
      Object localObject2;
      List localList = paramClient.getObjectMultiBulkReply();
      Object localObject1 = localList.get(0);
      if (!(localObject1 instanceof byte[]))
        throw new JedisException("Unknown message type: " + localObject1);
      byte[] arrayOfByte1 = (byte[])(byte[])localObject1;
      if (Arrays.equals(Protocol.Keyword.SUBSCRIBE.raw, arrayOfByte1))
      {
        this.subscribedChannels = ((Long)localList.get(2)).intValue();
        arrayOfByte2 = (byte[])(byte[])localList.get(1);
        localObject2 = (arrayOfByte2 == null) ? null : SafeEncoder.encode(arrayOfByte2);
        onSubscribe((String)localObject2, this.subscribedChannels);
      }
      else if (Arrays.equals(Protocol.Keyword.UNSUBSCRIBE.raw, arrayOfByte1))
      {
        this.subscribedChannels = ((Long)localList.get(2)).intValue();
        arrayOfByte2 = (byte[])(byte[])localList.get(1);
        localObject2 = (arrayOfByte2 == null) ? null : SafeEncoder.encode(arrayOfByte2);
        onUnsubscribe((String)localObject2, this.subscribedChannels);
      }
      else
      {
        Object localObject3;
        String str1;
        if (Arrays.equals(Protocol.Keyword.MESSAGE.raw, arrayOfByte1))
        {
          arrayOfByte2 = (byte[])(byte[])localList.get(1);
          localObject2 = (byte[])(byte[])localList.get(2);
          localObject3 = (arrayOfByte2 == null) ? null : SafeEncoder.encode(arrayOfByte2);
          str1 = (localObject2 == null) ? null : SafeEncoder.encode(localObject2);
          onMessage((String)localObject3, str1);
        }
        else if (Arrays.equals(Protocol.Keyword.PMESSAGE.raw, arrayOfByte1))
        {
          arrayOfByte2 = (byte[])(byte[])localList.get(1);
          localObject2 = (byte[])(byte[])localList.get(2);
          localObject3 = (byte[])(byte[])localList.get(3);
          str1 = (arrayOfByte2 == null) ? null : SafeEncoder.encode(arrayOfByte2);
          String str2 = (localObject2 == null) ? null : SafeEncoder.encode(localObject2);
          String str3 = (localObject3 == null) ? null : SafeEncoder.encode(localObject3);
          onPMessage(str1, str2, str3);
        }
        else if (Arrays.equals(Protocol.Keyword.PSUBSCRIBE.raw, arrayOfByte1))
        {
          this.subscribedChannels = ((Long)localList.get(2)).intValue();
          arrayOfByte2 = (byte[])(byte[])localList.get(1);
          localObject2 = (arrayOfByte2 == null) ? null : SafeEncoder.encode(arrayOfByte2);
          onPSubscribe((String)localObject2, this.subscribedChannels);
        }
        else if (Arrays.equals(Protocol.Keyword.PUNSUBSCRIBE.raw, arrayOfByte1))
        {
          this.subscribedChannels = ((Long)localList.get(2)).intValue();
          arrayOfByte2 = (byte[])(byte[])localList.get(1);
          localObject2 = (arrayOfByte2 == null) ? null : SafeEncoder.encode(arrayOfByte2);
          onPUnsubscribe((String)localObject2, this.subscribedChannels);
        }
        else
        {
          throw new JedisException("Unknown message type: " + localObject1);
        }
      }
    }
    while (isSubscribed());
  }

  public int getSubscribedChannels()
  {
    return this.subscribedChannels;
  }
}