package com.ycache.danga.MemCached.test;

import com.ycache.danga.MemCached.Logger;
import com.ycache.danga.MemCached.MemCachedClient;
import com.ycache.danga.MemCached.SockIOPool;
import java.io.PrintStream;
import org.apache.log4j.BasicConfigurator;

public class TestMemcached
{
  public static void main(String[] paramArrayOfString)
  {
    boolean bool;
    String str;
    BasicConfigurator.configure();
    String[] arrayOfString = { "192.168.1.1:1624", "192.168.1.1:1625" };
    SockIOPool localSockIOPool = SockIOPool.getInstance();
    localSockIOPool.setServers(arrayOfString);
    localSockIOPool.setFailover(true);
    localSockIOPool.setInitConn(10);
    localSockIOPool.setMinConn(5);
    localSockIOPool.setMaxConn(250);
    localSockIOPool.setMaintSleep(30L);
    localSockIOPool.setNagle(false);
    localSockIOPool.setSocketTO(3000);
    localSockIOPool.setAliveCheck(true);
    localSockIOPool.initialize();
    MemCachedClient localMemCachedClient = new MemCachedClient();
    Logger.getLogger(MemCachedClient.class.getName()).setLevel(2);
    for (int i = 0; i < 10; ++i)
    {
      bool = localMemCachedClient.set("" + i, "Hello!");
      str = (String)localMemCachedClient.get("" + i);
      System.out.println(String.format("set( %d ): %s", new Object[] { Integer.valueOf(i), Boolean.valueOf(bool) }));
      System.out.println(String.format("get( %d ): %s", new Object[] { Integer.valueOf(i), str }));
    }
    System.out.println("\n\t -- sleeping --\n");
    try
    {
      Thread.sleep(10000L);
    }
    catch (Exception localException)
    {
    }
    for (int j = 0; j < 10; ++j)
    {
      bool = localMemCachedClient.set("" + j, "Hello!");
      str = (String)localMemCachedClient.get("" + j);
      System.out.println(String.format("set( %d ): %s", new Object[] { Integer.valueOf(j), Boolean.valueOf(bool) }));
      System.out.println(String.format("get( %d ): %s", new Object[] { Integer.valueOf(j), str }));
    }
  }
}