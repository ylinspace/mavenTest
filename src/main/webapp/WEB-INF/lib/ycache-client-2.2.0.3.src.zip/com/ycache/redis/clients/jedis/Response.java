package com.ycache.redis.clients.jedis;

import com.ycache.redis.clients.jedis.exceptions.JedisDataException;

public class Response<T>
{
  protected T response = null;
  private boolean built = false;
  private boolean set = false;
  private Builder<T> builder;
  private Object data;

  public Response(Builder<T> paramBuilder)
  {
    this.builder = paramBuilder;
  }

  public void set(Object paramObject)
  {
    this.data = paramObject;
    this.set = true;
  }

  public T get()
  {
    if (!(this.set))
      throw new JedisDataException("Please close pipeline or multi block before calling this method.");
    if (!(this.built))
    {
      if (this.data != null)
      {
        if (this.data instanceof JedisDataException)
          throw new JedisDataException((JedisDataException)this.data);
        this.response = this.builder.build(this.data);
      }
      this.data = null;
      this.built = true;
    }
    return this.response;
  }

  public String toString()
  {
    return "Response " + this.builder.toString();
  }
}