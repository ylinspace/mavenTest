package com.ycache.redis.clients.jedis;

import com.ycache.redis.clients.util.ShardInfo;
import java.net.URI;

public class JedisShardInfo extends ShardInfo<Jedis>
{
  private int timeout;
  private String host;
  private int port;
  private String password;
  private String name;

  public String toString()
  {
    return this.host + ":" + this.port + "*" + getWeight();
  }

  public String getHost()
  {
    return this.host;
  }

  public int getPort()
  {
    return this.port;
  }

  public JedisShardInfo(String paramString)
  {
    super(1);
    this.password = null;
    this.name = null;
    URI localURI = URI.create(paramString);
    if ((localURI.getScheme() != null) && (localURI.getScheme().equals("redis")))
    {
      this.host = localURI.getHost();
      this.port = localURI.getPort();
      this.password = localURI.getUserInfo().split(":", 2)[1];
    }
    else
    {
      this.host = paramString;
      this.port = 6379;
    }
  }

  public JedisShardInfo(String paramString1, String paramString2)
  {
    this(paramString1, 6379, paramString2);
  }

  public JedisShardInfo(String paramString, int paramInt)
  {
    this(paramString, paramInt, 2000);
  }

  public JedisShardInfo(String paramString1, int paramInt, String paramString2)
  {
    this(paramString1, paramInt, 2000, paramString2);
  }

  public JedisShardInfo(String paramString, int paramInt1, int paramInt2)
  {
    this(paramString, paramInt1, paramInt2, 1);
  }

  public JedisShardInfo(String paramString1, int paramInt1, int paramInt2, String paramString2)
  {
    this(paramString1, paramInt1, paramInt2, 1);
    this.name = paramString2;
  }

  public JedisShardInfo(String paramString, int paramInt1, int paramInt2, int paramInt3)
  {
    super(paramInt3);
    this.password = null;
    this.name = null;
    this.host = paramString;
    this.port = paramInt1;
    this.timeout = paramInt2;
  }

  public JedisShardInfo(URI paramURI)
  {
    super(1);
    this.password = null;
    this.name = null;
    this.host = paramURI.getHost();
    this.port = paramURI.getPort();
    this.password = paramURI.getUserInfo().split(":", 2)[1];
  }

  public String getPassword()
  {
    return this.password;
  }

  public void setPassword(String paramString)
  {
    this.password = paramString;
  }

  public int getTimeout()
  {
    return this.timeout;
  }

  public void setTimeout(int paramInt)
  {
    this.timeout = paramInt;
  }

  public String getName()
  {
    return this.name;
  }

  public Jedis createResource()
  {
    return new Jedis(this);
  }
}