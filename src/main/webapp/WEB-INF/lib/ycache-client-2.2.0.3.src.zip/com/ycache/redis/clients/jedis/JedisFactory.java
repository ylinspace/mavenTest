package com.ycache.redis.clients.jedis;

import org.apache.commons.pool.BasePoolableObjectFactory;

class JedisFactory extends BasePoolableObjectFactory
{
  private final String host;
  private final int port;
  private final int timeout;
  private final String password;
  private final int database;

  public JedisFactory(String paramString1, int paramInt1, int paramInt2, String paramString2, int paramInt3)
  {
    this.host = paramString1;
    this.port = paramInt1;
    this.timeout = paramInt2;
    this.password = paramString2;
    this.database = paramInt3;
  }

  public Object makeObject()
    throws Exception
  {
    Jedis localJedis = new Jedis(this.host, this.port, this.timeout);
    localJedis.connect();
    if (null != this.password)
      localJedis.auth(this.password);
    if (this.database != 0)
      localJedis.select(this.database);
    return localJedis;
  }

  public void activateObject(Object paramObject)
    throws Exception
  {
    if (paramObject instanceof Jedis)
    {
      Jedis localJedis = (Jedis)paramObject;
      if (localJedis.getDB().longValue() != this.database)
        localJedis.select(this.database);
    }
  }

  public void destroyObject(Object paramObject)
    throws Exception
  {
    if (paramObject instanceof Jedis)
    {
      Jedis localJedis = (Jedis)paramObject;
      if (localJedis.isConnected())
        try
        {
          try
          {
            localJedis.quit();
          }
          catch (Exception localException1)
          {
          }
          localJedis.disconnect();
        }
        catch (Exception localException2)
        {
        }
    }
  }

  public boolean validateObject(Object paramObject)
  {
    if (paramObject instanceof Jedis)
    {
      Jedis localJedis = (Jedis)paramObject;
      try
      {
        return ((localJedis.isConnected()) && (localJedis.ping().equals("PONG")));
      }
      catch (Exception localException)
      {
        return false;
      }
    }
    return false;
  }
}