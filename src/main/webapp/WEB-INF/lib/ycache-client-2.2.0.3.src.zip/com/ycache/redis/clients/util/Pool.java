package com.ycache.redis.clients.util;

import com.ycache.redis.clients.jedis.exceptions.JedisConnectionException;
import com.ycache.redis.clients.jedis.exceptions.JedisException;
import org.apache.commons.pool.PoolableObjectFactory;
import org.apache.commons.pool.impl.GenericObjectPool;
import org.apache.commons.pool.impl.GenericObjectPool.Config;

public abstract class Pool<T>
{
  protected GenericObjectPool internalPool;

  public Pool()
  {
  }

  public Pool(GenericObjectPool.Config paramConfig, PoolableObjectFactory paramPoolableObjectFactory)
  {
    initPool(paramConfig, paramPoolableObjectFactory);
  }

  public void initPool(GenericObjectPool.Config paramConfig, PoolableObjectFactory paramPoolableObjectFactory)
  {
    if (this.internalPool != null)
      try
      {
        destroy();
      }
      catch (Exception localException)
      {
      }
    this.internalPool = new GenericObjectPool(paramPoolableObjectFactory, paramConfig);
  }

  public T getResource()
  {
    try
    {
      return this.internalPool.borrowObject();
    }
    catch (Exception localException)
    {
      throw new JedisConnectionException("Could not get a resource from the pool. borrowed:" + this.internalPool.getNumActive() + " idle:" + this.internalPool.getNumIdle(), localException);
    }
  }

  public void returnResourceObject(Object paramObject)
  {
    try
    {
      this.internalPool.returnObject(paramObject);
    }
    catch (Exception localException)
    {
      throw new JedisException("Could not return the resource to the pool", localException);
    }
  }

  public void returnBrokenResource(T paramT)
  {
    returnBrokenResourceObject(paramT);
  }

  public void returnResource(T paramT)
  {
    returnResourceObject(paramT);
  }

  protected void returnBrokenResourceObject(Object paramObject)
  {
    try
    {
      this.internalPool.invalidateObject(paramObject);
    }
    catch (Exception localException)
    {
      throw new JedisException("Could not return the resource to the pool", localException);
    }
  }

  public void destroy()
  {
    try
    {
      this.internalPool.close();
    }
    catch (Exception localException)
    {
      throw new JedisException("Could not destroy the pool", localException);
    }
  }
}