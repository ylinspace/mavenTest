package com.ycache.redis.clients.jedis;

import [B;
import com.ycache.redis.clients.util.SafeEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class Client extends BinaryClient
  implements Commands
{
  public Client(String paramString)
  {
    super(paramString);
  }

  public Client(String paramString, int paramInt)
  {
    super(paramString, paramInt);
  }

  public void set(String paramString1, String paramString2)
  {
    set(SafeEncoder.encode(paramString1), SafeEncoder.encode(paramString2));
  }

  public void set(String paramString1, String paramString2, String paramString3, String paramString4, long paramLong)
  {
    set(SafeEncoder.encode(paramString1), SafeEncoder.encode(paramString2), SafeEncoder.encode(paramString3), SafeEncoder.encode(paramString4), paramLong);
  }

  public void get(String paramString)
  {
    get(SafeEncoder.encode(paramString));
  }

  public void exists(String paramString)
  {
    exists(SafeEncoder.encode(paramString));
  }

  public void del(String[] paramArrayOfString)
  {
    [B[] arrayOf[B = new byte[paramArrayOfString.length][];
    for (int i = 0; i < paramArrayOfString.length; ++i)
      arrayOf[B[i] = SafeEncoder.encode(paramArrayOfString[i]);
    del(arrayOf[B);
  }

  public void type(String paramString)
  {
    type(SafeEncoder.encode(paramString));
  }

  public void keys(String paramString)
  {
    keys(SafeEncoder.encode(paramString));
  }

  public void rename(String paramString1, String paramString2)
  {
    rename(SafeEncoder.encode(paramString1), SafeEncoder.encode(paramString2));
  }

  public void renamenx(String paramString1, String paramString2)
  {
    renamenx(SafeEncoder.encode(paramString1), SafeEncoder.encode(paramString2));
  }

  public void expire(String paramString, int paramInt)
  {
    expire(SafeEncoder.encode(paramString), paramInt);
  }

  public void expireAt(String paramString, long paramLong)
  {
    expireAt(SafeEncoder.encode(paramString), paramLong);
  }

  public void ttl(String paramString)
  {
    ttl(SafeEncoder.encode(paramString));
  }

  public void move(String paramString, int paramInt)
  {
    move(SafeEncoder.encode(paramString), paramInt);
  }

  public void getSet(String paramString1, String paramString2)
  {
    getSet(SafeEncoder.encode(paramString1), SafeEncoder.encode(paramString2));
  }

  public void mget(String[] paramArrayOfString)
  {
    [B[] arrayOf[B = new byte[paramArrayOfString.length][];
    for (int i = 0; i < arrayOf[B.length; ++i)
      arrayOf[B[i] = SafeEncoder.encode(paramArrayOfString[i]);
    mget(arrayOf[B);
  }

  public void setnx(String paramString1, String paramString2)
  {
    setnx(SafeEncoder.encode(paramString1), SafeEncoder.encode(paramString2));
  }

  public void setex(String paramString1, int paramInt, String paramString2)
  {
    setex(SafeEncoder.encode(paramString1), paramInt, SafeEncoder.encode(paramString2));
  }

  public void mset(String[] paramArrayOfString)
  {
    [B[] arrayOf[B = new byte[paramArrayOfString.length][];
    for (int i = 0; i < paramArrayOfString.length; ++i)
      arrayOf[B[i] = SafeEncoder.encode(paramArrayOfString[i]);
    mset(arrayOf[B);
  }

  public void msetnx(String[] paramArrayOfString)
  {
    [B[] arrayOf[B = new byte[paramArrayOfString.length][];
    for (int i = 0; i < paramArrayOfString.length; ++i)
      arrayOf[B[i] = SafeEncoder.encode(paramArrayOfString[i]);
    msetnx(arrayOf[B);
  }

  public void decrBy(String paramString, long paramLong)
  {
    decrBy(SafeEncoder.encode(paramString), paramLong);
  }

  public void decr(String paramString)
  {
    decr(SafeEncoder.encode(paramString));
  }

  public void incrBy(String paramString, long paramLong)
  {
    incrBy(SafeEncoder.encode(paramString), paramLong);
  }

  public void incr(String paramString)
  {
    incr(SafeEncoder.encode(paramString));
  }

  public void append(String paramString1, String paramString2)
  {
    append(SafeEncoder.encode(paramString1), SafeEncoder.encode(paramString2));
  }

  public void substr(String paramString, int paramInt1, int paramInt2)
  {
    substr(SafeEncoder.encode(paramString), paramInt1, paramInt2);
  }

  public void hset(String paramString1, String paramString2, String paramString3)
  {
    hset(SafeEncoder.encode(paramString1), SafeEncoder.encode(paramString2), SafeEncoder.encode(paramString3));
  }

  public void hget(String paramString1, String paramString2)
  {
    hget(SafeEncoder.encode(paramString1), SafeEncoder.encode(paramString2));
  }

  public void hsetnx(String paramString1, String paramString2, String paramString3)
  {
    hsetnx(SafeEncoder.encode(paramString1), SafeEncoder.encode(paramString2), SafeEncoder.encode(paramString3));
  }

  public void hmset(String paramString, Map<String, String> paramMap)
  {
    HashMap localHashMap = new HashMap(paramMap.size());
    Iterator localIterator = paramMap.entrySet().iterator();
    while (localIterator.hasNext())
    {
      Map.Entry localEntry = (Map.Entry)localIterator.next();
      localHashMap.put(SafeEncoder.encode((String)localEntry.getKey()), SafeEncoder.encode((String)localEntry.getValue()));
    }
    hmset(SafeEncoder.encode(paramString), localHashMap);
  }

  public void hmget(String paramString, String[] paramArrayOfString)
  {
    [B[] arrayOf[B = new byte[paramArrayOfString.length][];
    for (int i = 0; i < arrayOf[B.length; ++i)
      arrayOf[B[i] = SafeEncoder.encode(paramArrayOfString[i]);
    hmget(SafeEncoder.encode(paramString), arrayOf[B);
  }

  public void hincrBy(String paramString1, String paramString2, long paramLong)
  {
    hincrBy(SafeEncoder.encode(paramString1), SafeEncoder.encode(paramString2), paramLong);
  }

  public void hexists(String paramString1, String paramString2)
  {
    hexists(SafeEncoder.encode(paramString1), SafeEncoder.encode(paramString2));
  }

  public void hdel(String paramString, String[] paramArrayOfString)
  {
    hdel(SafeEncoder.encode(paramString), SafeEncoder.encodeMany(paramArrayOfString));
  }

  public void hlen(String paramString)
  {
    hlen(SafeEncoder.encode(paramString));
  }

  public void hkeys(String paramString)
  {
    hkeys(SafeEncoder.encode(paramString));
  }

  public void hvals(String paramString)
  {
    hvals(SafeEncoder.encode(paramString));
  }

  public void hgetAll(String paramString)
  {
    hgetAll(SafeEncoder.encode(paramString));
  }

  public void rpush(String paramString, String[] paramArrayOfString)
  {
    rpush(SafeEncoder.encode(paramString), SafeEncoder.encodeMany(paramArrayOfString));
  }

  public void lpush(String paramString, String[] paramArrayOfString)
  {
    lpush(SafeEncoder.encode(paramString), SafeEncoder.encodeMany(paramArrayOfString));
  }

  public void llen(String paramString)
  {
    llen(SafeEncoder.encode(paramString));
  }

  public void lrange(String paramString, long paramLong1, long paramLong2)
  {
    lrange(SafeEncoder.encode(paramString), paramLong1, paramLong2);
  }

  public void ltrim(String paramString, long paramLong1, long paramLong2)
  {
    ltrim(SafeEncoder.encode(paramString), paramLong1, paramLong2);
  }

  public void lindex(String paramString, long paramLong)
  {
    lindex(SafeEncoder.encode(paramString), paramLong);
  }

  public void lset(String paramString1, long paramLong, String paramString2)
  {
    lset(SafeEncoder.encode(paramString1), paramLong, SafeEncoder.encode(paramString2));
  }

  public void lrem(String paramString1, long paramLong, String paramString2)
  {
    lrem(SafeEncoder.encode(paramString1), paramLong, SafeEncoder.encode(paramString2));
  }

  public void lpop(String paramString)
  {
    lpop(SafeEncoder.encode(paramString));
  }

  public void rpop(String paramString)
  {
    rpop(SafeEncoder.encode(paramString));
  }

  public void rpoplpush(String paramString1, String paramString2)
  {
    rpoplpush(SafeEncoder.encode(paramString1), SafeEncoder.encode(paramString2));
  }

  public void sadd(String paramString, String[] paramArrayOfString)
  {
    sadd(SafeEncoder.encode(paramString), SafeEncoder.encodeMany(paramArrayOfString));
  }

  public void smembers(String paramString)
  {
    smembers(SafeEncoder.encode(paramString));
  }

  public void srem(String paramString, String[] paramArrayOfString)
  {
    srem(SafeEncoder.encode(paramString), SafeEncoder.encodeMany(paramArrayOfString));
  }

  public void spop(String paramString)
  {
    spop(SafeEncoder.encode(paramString));
  }

  public void smove(String paramString1, String paramString2, String paramString3)
  {
    smove(SafeEncoder.encode(paramString1), SafeEncoder.encode(paramString2), SafeEncoder.encode(paramString3));
  }

  public void scard(String paramString)
  {
    scard(SafeEncoder.encode(paramString));
  }

  public void sismember(String paramString1, String paramString2)
  {
    sismember(SafeEncoder.encode(paramString1), SafeEncoder.encode(paramString2));
  }

  public void sinter(String[] paramArrayOfString)
  {
    [B[] arrayOf[B = new byte[paramArrayOfString.length][];
    for (int i = 0; i < arrayOf[B.length; ++i)
      arrayOf[B[i] = SafeEncoder.encode(paramArrayOfString[i]);
    sinter(arrayOf[B);
  }

  public void sinterstore(String paramString, String[] paramArrayOfString)
  {
    [B[] arrayOf[B = new byte[paramArrayOfString.length][];
    for (int i = 0; i < arrayOf[B.length; ++i)
      arrayOf[B[i] = SafeEncoder.encode(paramArrayOfString[i]);
    sinterstore(SafeEncoder.encode(paramString), arrayOf[B);
  }

  public void sunion(String[] paramArrayOfString)
  {
    [B[] arrayOf[B = new byte[paramArrayOfString.length][];
    for (int i = 0; i < arrayOf[B.length; ++i)
      arrayOf[B[i] = SafeEncoder.encode(paramArrayOfString[i]);
    sunion(arrayOf[B);
  }

  public void sunionstore(String paramString, String[] paramArrayOfString)
  {
    [B[] arrayOf[B = new byte[paramArrayOfString.length][];
    for (int i = 0; i < arrayOf[B.length; ++i)
      arrayOf[B[i] = SafeEncoder.encode(paramArrayOfString[i]);
    sunionstore(SafeEncoder.encode(paramString), arrayOf[B);
  }

  public void sdiff(String[] paramArrayOfString)
  {
    [B[] arrayOf[B = new byte[paramArrayOfString.length][];
    for (int i = 0; i < arrayOf[B.length; ++i)
      arrayOf[B[i] = SafeEncoder.encode(paramArrayOfString[i]);
    sdiff(arrayOf[B);
  }

  public void sdiffstore(String paramString, String[] paramArrayOfString)
  {
    [B[] arrayOf[B = new byte[paramArrayOfString.length][];
    for (int i = 0; i < arrayOf[B.length; ++i)
      arrayOf[B[i] = SafeEncoder.encode(paramArrayOfString[i]);
    sdiffstore(SafeEncoder.encode(paramString), arrayOf[B);
  }

  public void srandmember(String paramString)
  {
    srandmember(SafeEncoder.encode(paramString));
  }

  public void zadd(String paramString1, double paramDouble, String paramString2)
  {
    zadd(SafeEncoder.encode(paramString1), paramDouble, SafeEncoder.encode(paramString2));
  }

  public void zrange(String paramString, long paramLong1, long paramLong2)
  {
    zrange(SafeEncoder.encode(paramString), paramLong1, paramLong2);
  }

  public void zrem(String paramString, String[] paramArrayOfString)
  {
    zrem(SafeEncoder.encode(paramString), SafeEncoder.encodeMany(paramArrayOfString));
  }

  public void zincrby(String paramString1, double paramDouble, String paramString2)
  {
    zincrby(SafeEncoder.encode(paramString1), paramDouble, SafeEncoder.encode(paramString2));
  }

  public void zrank(String paramString1, String paramString2)
  {
    zrank(SafeEncoder.encode(paramString1), SafeEncoder.encode(paramString2));
  }

  public void zrevrank(String paramString1, String paramString2)
  {
    zrevrank(SafeEncoder.encode(paramString1), SafeEncoder.encode(paramString2));
  }

  public void zrevrange(String paramString, long paramLong1, long paramLong2)
  {
    zrevrange(SafeEncoder.encode(paramString), paramLong1, paramLong2);
  }

  public void zrangeWithScores(String paramString, long paramLong1, long paramLong2)
  {
    zrangeWithScores(SafeEncoder.encode(paramString), paramLong1, paramLong2);
  }

  public void zrevrangeWithScores(String paramString, long paramLong1, long paramLong2)
  {
    zrevrangeWithScores(SafeEncoder.encode(paramString), paramLong1, paramLong2);
  }

  public void zcard(String paramString)
  {
    zcard(SafeEncoder.encode(paramString));
  }

  public void zscore(String paramString1, String paramString2)
  {
    zscore(SafeEncoder.encode(paramString1), SafeEncoder.encode(paramString2));
  }

  public void watch(String[] paramArrayOfString)
  {
    [B[] arrayOf[B = new byte[paramArrayOfString.length][];
    for (int i = 0; i < arrayOf[B.length; ++i)
      arrayOf[B[i] = SafeEncoder.encode(paramArrayOfString[i]);
    watch(arrayOf[B);
  }

  public void sort(String paramString)
  {
    sort(SafeEncoder.encode(paramString));
  }

  public void sort(String paramString, SortingParams paramSortingParams)
  {
    sort(SafeEncoder.encode(paramString), paramSortingParams);
  }

  public void blpop(String[] paramArrayOfString)
  {
    [B[] arrayOf[B = new byte[paramArrayOfString.length][];
    for (int i = 0; i < arrayOf[B.length; ++i)
      arrayOf[B[i] = SafeEncoder.encode(paramArrayOfString[i]);
    blpop(arrayOf[B);
  }

  public void blpop(int paramInt, String[] paramArrayOfString)
  {
    ArrayList localArrayList = new ArrayList();
    String[] arrayOfString = paramArrayOfString;
    int i = arrayOfString.length;
    for (int j = 0; j < i; ++j)
    {
      String str = arrayOfString[j];
      localArrayList.add(str);
    }
    localArrayList.add(String.valueOf(paramInt));
    blpop((String[])localArrayList.toArray(new String[localArrayList.size()]));
  }

  public void sort(String paramString1, SortingParams paramSortingParams, String paramString2)
  {
    sort(SafeEncoder.encode(paramString1), paramSortingParams, SafeEncoder.encode(paramString2));
  }

  public void sort(String paramString1, String paramString2)
  {
    sort(SafeEncoder.encode(paramString1), SafeEncoder.encode(paramString2));
  }

  public void brpop(String[] paramArrayOfString)
  {
    [B[] arrayOf[B = new byte[paramArrayOfString.length][];
    for (int i = 0; i < arrayOf[B.length; ++i)
      arrayOf[B[i] = SafeEncoder.encode(paramArrayOfString[i]);
    brpop(arrayOf[B);
  }

  public void brpop(int paramInt, String[] paramArrayOfString)
  {
    ArrayList localArrayList = new ArrayList();
    String[] arrayOfString = paramArrayOfString;
    int i = arrayOfString.length;
    for (int j = 0; j < i; ++j)
    {
      String str = arrayOfString[j];
      localArrayList.add(str);
    }
    localArrayList.add(String.valueOf(paramInt));
    brpop((String[])localArrayList.toArray(new String[localArrayList.size()]));
  }

  public void zcount(String paramString, double paramDouble1, double paramDouble2)
  {
    zcount(SafeEncoder.encode(paramString), Protocol.toByteArray(paramDouble1), Protocol.toByteArray(paramDouble2));
  }

  public void zcount(String paramString1, String paramString2, String paramString3)
  {
    zcount(SafeEncoder.encode(paramString1), SafeEncoder.encode(paramString2), SafeEncoder.encode(paramString3));
  }

  public void zrangeByScore(String paramString, double paramDouble1, double paramDouble2)
  {
    zrangeByScore(SafeEncoder.encode(paramString), Protocol.toByteArray(paramDouble1), Protocol.toByteArray(paramDouble2));
  }

  public void zrangeByScore(String paramString1, String paramString2, String paramString3)
  {
    zrangeByScore(SafeEncoder.encode(paramString1), SafeEncoder.encode(paramString2), SafeEncoder.encode(paramString3));
  }

  public void zrangeByScore(String paramString, double paramDouble1, double paramDouble2, int paramInt1, int paramInt2)
  {
    zrangeByScore(SafeEncoder.encode(paramString), Protocol.toByteArray(paramDouble1), Protocol.toByteArray(paramDouble2), paramInt1, paramInt2);
  }

  public void zrangeByScoreWithScores(String paramString, double paramDouble1, double paramDouble2)
  {
    zrangeByScoreWithScores(SafeEncoder.encode(paramString), Protocol.toByteArray(paramDouble1), Protocol.toByteArray(paramDouble2));
  }

  public void zrangeByScoreWithScores(String paramString, double paramDouble1, double paramDouble2, int paramInt1, int paramInt2)
  {
    zrangeByScoreWithScores(SafeEncoder.encode(paramString), Protocol.toByteArray(paramDouble1), Protocol.toByteArray(paramDouble2), paramInt1, paramInt2);
  }

  public void zrevrangeByScore(String paramString, double paramDouble1, double paramDouble2)
  {
    zrevrangeByScore(SafeEncoder.encode(paramString), Protocol.toByteArray(paramDouble1), Protocol.toByteArray(paramDouble2));
  }

  public void zrangeByScore(String paramString1, String paramString2, String paramString3, int paramInt1, int paramInt2)
  {
    zrangeByScore(SafeEncoder.encode(paramString1), SafeEncoder.encode(paramString2), SafeEncoder.encode(paramString3), paramInt1, paramInt2);
  }

  public void zrangeByScoreWithScores(String paramString1, String paramString2, String paramString3)
  {
    zrangeByScoreWithScores(SafeEncoder.encode(paramString1), SafeEncoder.encode(paramString2), SafeEncoder.encode(paramString3));
  }

  public void zrangeByScoreWithScores(String paramString1, String paramString2, String paramString3, int paramInt1, int paramInt2)
  {
    zrangeByScoreWithScores(SafeEncoder.encode(paramString1), SafeEncoder.encode(paramString2), SafeEncoder.encode(paramString3), paramInt1, paramInt2);
  }

  public void zrevrangeByScore(String paramString1, String paramString2, String paramString3)
  {
    zrevrangeByScore(SafeEncoder.encode(paramString1), SafeEncoder.encode(paramString2), SafeEncoder.encode(paramString3));
  }

  public void zrevrangeByScore(String paramString, double paramDouble1, double paramDouble2, int paramInt1, int paramInt2)
  {
    zrevrangeByScore(SafeEncoder.encode(paramString), Protocol.toByteArray(paramDouble1), Protocol.toByteArray(paramDouble2), paramInt1, paramInt2);
  }

  public void zrevrangeByScore(String paramString1, String paramString2, String paramString3, int paramInt1, int paramInt2)
  {
    zrevrangeByScore(SafeEncoder.encode(paramString1), SafeEncoder.encode(paramString2), SafeEncoder.encode(paramString3), paramInt1, paramInt2);
  }

  public void zrevrangeByScoreWithScores(String paramString, double paramDouble1, double paramDouble2)
  {
    zrevrangeByScoreWithScores(SafeEncoder.encode(paramString), Protocol.toByteArray(paramDouble1), Protocol.toByteArray(paramDouble2));
  }

  public void zrevrangeByScoreWithScores(String paramString1, String paramString2, String paramString3)
  {
    zrevrangeByScoreWithScores(SafeEncoder.encode(paramString1), SafeEncoder.encode(paramString2), SafeEncoder.encode(paramString3));
  }

  public void zrevrangeByScoreWithScores(String paramString, double paramDouble1, double paramDouble2, int paramInt1, int paramInt2)
  {
    zrevrangeByScoreWithScores(SafeEncoder.encode(paramString), Protocol.toByteArray(paramDouble1), Protocol.toByteArray(paramDouble2), paramInt1, paramInt2);
  }

  public void zrevrangeByScoreWithScores(String paramString1, String paramString2, String paramString3, int paramInt1, int paramInt2)
  {
    zrevrangeByScoreWithScores(SafeEncoder.encode(paramString1), SafeEncoder.encode(paramString2), SafeEncoder.encode(paramString3), paramInt1, paramInt2);
  }

  public void zremrangeByRank(String paramString, long paramLong1, long paramLong2)
  {
    zremrangeByRank(SafeEncoder.encode(paramString), paramLong1, paramLong2);
  }

  public void zremrangeByScore(String paramString, double paramDouble1, double paramDouble2)
  {
    zremrangeByScore(SafeEncoder.encode(paramString), Protocol.toByteArray(paramDouble1), Protocol.toByteArray(paramDouble2));
  }

  public void zremrangeByScore(String paramString1, String paramString2, String paramString3)
  {
    zremrangeByScore(SafeEncoder.encode(paramString1), SafeEncoder.encode(paramString2), SafeEncoder.encode(paramString3));
  }

  public void zunionstore(String paramString, String[] paramArrayOfString)
  {
    [B[] arrayOf[B = new byte[paramArrayOfString.length][];
    for (int i = 0; i < arrayOf[B.length; ++i)
      arrayOf[B[i] = SafeEncoder.encode(paramArrayOfString[i]);
    zunionstore(SafeEncoder.encode(paramString), arrayOf[B);
  }

  public void zunionstore(String paramString, ZParams paramZParams, String[] paramArrayOfString)
  {
    [B[] arrayOf[B = new byte[paramArrayOfString.length][];
    for (int i = 0; i < arrayOf[B.length; ++i)
      arrayOf[B[i] = SafeEncoder.encode(paramArrayOfString[i]);
    zunionstore(SafeEncoder.encode(paramString), paramZParams, arrayOf[B);
  }

  public void zinterstore(String paramString, String[] paramArrayOfString)
  {
    [B[] arrayOf[B = new byte[paramArrayOfString.length][];
    for (int i = 0; i < arrayOf[B.length; ++i)
      arrayOf[B[i] = SafeEncoder.encode(paramArrayOfString[i]);
    zinterstore(SafeEncoder.encode(paramString), arrayOf[B);
  }

  public void zinterstore(String paramString, ZParams paramZParams, String[] paramArrayOfString)
  {
    [B[] arrayOf[B = new byte[paramArrayOfString.length][];
    for (int i = 0; i < arrayOf[B.length; ++i)
      arrayOf[B[i] = SafeEncoder.encode(paramArrayOfString[i]);
    zinterstore(SafeEncoder.encode(paramString), paramZParams, arrayOf[B);
  }

  public void strlen(String paramString)
  {
    strlen(SafeEncoder.encode(paramString));
  }

  public void lpushx(String paramString, String[] paramArrayOfString)
  {
    lpushx(SafeEncoder.encode(paramString), getByteParams(paramArrayOfString));
  }

  public void persist(String paramString)
  {
    persist(SafeEncoder.encode(paramString));
  }

  public void rpushx(String paramString, String[] paramArrayOfString)
  {
    rpushx(SafeEncoder.encode(paramString), getByteParams(paramArrayOfString));
  }

  public void echo(String paramString)
  {
    echo(SafeEncoder.encode(paramString));
  }

  public void linsert(String paramString1, BinaryClient.LIST_POSITION paramLIST_POSITION, String paramString2, String paramString3)
  {
    linsert(SafeEncoder.encode(paramString1), paramLIST_POSITION, SafeEncoder.encode(paramString2), SafeEncoder.encode(paramString3));
  }

  public void brpoplpush(String paramString1, String paramString2, int paramInt)
  {
    brpoplpush(SafeEncoder.encode(paramString1), SafeEncoder.encode(paramString2), paramInt);
  }

  public void setbit(String paramString, long paramLong, boolean paramBoolean)
  {
    setbit(SafeEncoder.encode(paramString), paramLong, paramBoolean);
  }

  public void setbit(String paramString1, long paramLong, String paramString2)
  {
    setbit(SafeEncoder.encode(paramString1), paramLong, SafeEncoder.encode(paramString2));
  }

  public void getbit(String paramString, long paramLong)
  {
    getbit(SafeEncoder.encode(paramString), paramLong);
  }

  public void setrange(String paramString1, long paramLong, String paramString2)
  {
    setrange(SafeEncoder.encode(paramString1), paramLong, SafeEncoder.encode(paramString2));
  }

  public void getrange(String paramString, long paramLong1, long paramLong2)
  {
    getrange(SafeEncoder.encode(paramString), paramLong1, paramLong2);
  }

  public void publish(String paramString1, String paramString2)
  {
    publish(SafeEncoder.encode(paramString1), SafeEncoder.encode(paramString2));
  }

  public void unsubscribe(String[] paramArrayOfString)
  {
    [B[] arrayOf[B = new byte[paramArrayOfString.length][];
    for (int i = 0; i < arrayOf[B.length; ++i)
      arrayOf[B[i] = SafeEncoder.encode(paramArrayOfString[i]);
    unsubscribe(arrayOf[B);
  }

  public void psubscribe(String[] paramArrayOfString)
  {
    [B[] arrayOf[B = new byte[paramArrayOfString.length][];
    for (int i = 0; i < arrayOf[B.length; ++i)
      arrayOf[B[i] = SafeEncoder.encode(paramArrayOfString[i]);
    psubscribe(arrayOf[B);
  }

  public void punsubscribe(String[] paramArrayOfString)
  {
    [B[] arrayOf[B = new byte[paramArrayOfString.length][];
    for (int i = 0; i < arrayOf[B.length; ++i)
      arrayOf[B[i] = SafeEncoder.encode(paramArrayOfString[i]);
    punsubscribe(arrayOf[B);
  }

  public void subscribe(String[] paramArrayOfString)
  {
    [B[] arrayOf[B = new byte[paramArrayOfString.length][];
    for (int i = 0; i < arrayOf[B.length; ++i)
      arrayOf[B[i] = SafeEncoder.encode(paramArrayOfString[i]);
    subscribe(arrayOf[B);
  }

  public void configSet(String paramString1, String paramString2)
  {
    configSet(SafeEncoder.encode(paramString1), SafeEncoder.encode(paramString2));
  }

  public void configGet(String paramString)
  {
    configGet(SafeEncoder.encode(paramString));
  }

  private byte[][] getByteParams(String[] paramArrayOfString)
  {
    [B[] arrayOf[B = new byte[paramArrayOfString.length][];
    for (int i = 0; i < paramArrayOfString.length; ++i)
      arrayOf[B[i] = SafeEncoder.encode(paramArrayOfString[i]);
    return arrayOf[B;
  }

  public void eval(String paramString, int paramInt, String[] paramArrayOfString)
  {
    eval(SafeEncoder.encode(paramString), Protocol.toByteArray(paramInt), getByteParams(paramArrayOfString));
  }

  public void evalsha(String paramString, int paramInt, String[] paramArrayOfString)
  {
    evalsha(SafeEncoder.encode(paramString), Protocol.toByteArray(paramInt), getByteParams(paramArrayOfString));
  }

  public void scriptExists(String[] paramArrayOfString)
  {
    [B[] arrayOf[B = new byte[paramArrayOfString.length][];
    for (int i = 0; i < arrayOf[B.length; ++i)
      arrayOf[B[i] = SafeEncoder.encode(paramArrayOfString[i]);
    scriptExists(arrayOf[B);
  }

  public void scriptLoad(String paramString)
  {
    scriptLoad(SafeEncoder.encode(paramString));
  }

  public void zadd(String paramString, Map<Double, String> paramMap)
  {
    HashMap localHashMap = new HashMap();
    Iterator localIterator = paramMap.entrySet().iterator();
    while (localIterator.hasNext())
    {
      Map.Entry localEntry = (Map.Entry)localIterator.next();
      localHashMap.put(localEntry.getKey(), SafeEncoder.encode((String)localEntry.getValue()));
    }
    zaddBinary(SafeEncoder.encode(paramString), localHashMap);
  }

  public void objectRefcount(String paramString)
  {
    objectRefcount(SafeEncoder.encode(paramString));
  }

  public void objectIdletime(String paramString)
  {
    objectIdletime(SafeEncoder.encode(paramString));
  }

  public void objectEncoding(String paramString)
  {
    objectEncoding(SafeEncoder.encode(paramString));
  }

  public void bitcount(String paramString)
  {
    bitcount(SafeEncoder.encode(paramString));
  }

  public void bitcount(String paramString, long paramLong1, long paramLong2)
  {
    bitcount(SafeEncoder.encode(paramString), paramLong1, paramLong2);
  }

  public void bitop(BitOP paramBitOP, String paramString, String[] paramArrayOfString)
  {
    bitop(paramBitOP, SafeEncoder.encode(paramString), getByteParams(paramArrayOfString));
  }

  public void sentinel(String[] paramArrayOfString)
  {
    [B[] arrayOf[B = new byte[paramArrayOfString.length][];
    for (int i = 0; i < arrayOf[B.length; ++i)
      arrayOf[B[i] = SafeEncoder.encode(paramArrayOfString[i]);
    sentinel(arrayOf[B);
  }

  public void sentinel(String paramString1, String paramString2, int paramInt)
  {
    sentinel(new byte[][] { SafeEncoder.encode(paramString1), SafeEncoder.encode(paramString2), Protocol.toByteArray(paramInt) });
  }

  public void dump(String paramString)
  {
    dump(SafeEncoder.encode(paramString));
  }

  public void restore(String paramString, int paramInt, byte[] paramArrayOfByte)
  {
    restore(SafeEncoder.encode(paramString), paramInt, paramArrayOfByte);
  }

  public void pexpire(String paramString, int paramInt)
  {
    pexpire(SafeEncoder.encode(paramString), paramInt);
  }

  public void pexpireAt(String paramString, long paramLong)
  {
    pexpireAt(SafeEncoder.encode(paramString), paramLong);
  }

  public void pttl(String paramString)
  {
    pttl(SafeEncoder.encode(paramString));
  }

  public void incrByFloat(String paramString, double paramDouble)
  {
    incrByFloat(SafeEncoder.encode(paramString), paramDouble);
  }

  public void psetex(String paramString1, int paramInt, String paramString2)
  {
    psetex(SafeEncoder.encode(paramString1), paramInt, SafeEncoder.encode(paramString2));
  }

  public void set(String paramString1, String paramString2, String paramString3)
  {
    set(SafeEncoder.encode(paramString1), SafeEncoder.encode(paramString2), SafeEncoder.encode(paramString3));
  }

  public void set(String paramString1, String paramString2, String paramString3, String paramString4, int paramInt)
  {
    set(SafeEncoder.encode(paramString1), SafeEncoder.encode(paramString2), SafeEncoder.encode(paramString3), SafeEncoder.encode(paramString4), paramInt);
  }

  public void srandmember(String paramString, int paramInt)
  {
    srandmember(SafeEncoder.encode(paramString), paramInt);
  }

  public void clientKill(String paramString)
  {
    clientKill(SafeEncoder.encode(paramString));
  }

  public void clientSetname(String paramString)
  {
    clientSetname(SafeEncoder.encode(paramString));
  }

  public void migrate(String paramString1, int paramInt1, String paramString2, int paramInt2, int paramInt3)
  {
    migrate(SafeEncoder.encode(paramString1), paramInt1, SafeEncoder.encode(paramString2), paramInt2, paramInt3);
  }

  public void hincrByFloat(String paramString1, String paramString2, double paramDouble)
  {
    hincrByFloat(SafeEncoder.encode(paramString1), SafeEncoder.encode(paramString2), paramDouble);
  }
}