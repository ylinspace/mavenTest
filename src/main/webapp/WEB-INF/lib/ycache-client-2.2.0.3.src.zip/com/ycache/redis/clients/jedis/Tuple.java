package com.ycache.redis.clients.jedis;

import com.ycache.redis.clients.util.SafeEncoder;
import java.util.Arrays;

public class Tuple
  implements Comparable<Tuple>
{
  private byte[] element;
  private Double score;

  public int hashCode()
  {
    int i = 1;
    i = 31 * i;
    if (null != this.element)
    {
      byte[] arrayOfByte = this.element;
      int j = arrayOfByte.length;
      for (int k = 0; k < j; ++k)
      {
        int i1 = arrayOfByte[k];
        i = 31 * i + i1;
      }
    }
    long l = Double.doubleToLongBits(this.score.doubleValue());
    i = 31 * i + (int)(l ^ l >>> 32);
    return i;
  }

  public boolean equals(Object paramObject)
  {
    if (this == paramObject)
      return true;
    if (paramObject == null)
      return false;
    if (super.getClass() != paramObject.getClass())
      return false;
    Tuple localTuple = (Tuple)paramObject;
    if (this.element == null)
    {
      if (localTuple.element == null)
        break label63;
      return false;
    }
    label63: return (Arrays.equals(this.element, localTuple.element));
  }

  public int compareTo(Tuple paramTuple)
  {
    if (Arrays.equals(this.element, paramTuple.element))
      return 0;
    return ((this.score.doubleValue() < paramTuple.getScore()) ? -1 : 1);
  }

  public Tuple(String paramString, Double paramDouble)
  {
    this.element = SafeEncoder.encode(paramString);
    this.score = paramDouble;
  }

  public Tuple(byte[] paramArrayOfByte, Double paramDouble)
  {
    this.element = paramArrayOfByte;
    this.score = paramDouble;
  }

  public String getElement()
  {
    if (null != this.element)
      return SafeEncoder.encode(this.element);
    return null;
  }

  public byte[] getBinaryElement()
  {
    return this.element;
  }

  public double getScore()
  {
    return this.score.doubleValue();
  }

  public String toString()
  {
    return '[' + Arrays.toString(this.element) + ',' + this.score + ']';
  }
}