package com.ycache.redis.clients.util;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public abstract interface Hashing
{
  public static final Hashing MURMUR_HASH = new MurmurHash();
  public static final ThreadLocal<MessageDigest> md5Holder = new ThreadLocal();
  public static final Hashing MD5 = new Hashing()
  {
    public long hash(String paramString)
    {
      return hash(SafeEncoder.encode(paramString));
    }

    public long hash(byte[] paramArrayOfByte)
    {
      try
      {
        if (md5Holder.get() == null)
          md5Holder.set(MessageDigest.getInstance("MD5"));
      }
      catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
      {
        throw new IllegalStateException("++++ no md5 algorythm found");
      }
      MessageDigest localMessageDigest = (MessageDigest)md5Holder.get();
      localMessageDigest.reset();
      localMessageDigest.update(paramArrayOfByte);
      byte[] arrayOfByte = localMessageDigest.digest();
      long l = (arrayOfByte[3] & 0xFF) << 24 | (arrayOfByte[2] & 0xFF) << 16 | (arrayOfByte[1] & 0xFF) << 8 | arrayOfByte[0] & 0xFF;
      return l;
    }
  };

  public abstract long hash(String paramString);

  public abstract long hash(byte[] paramArrayOfByte);
}