package com.ycache.redis.clients.jedis.exceptions;

public class JedisException extends RuntimeException
{
  private static final long serialVersionUID = -2946266495682282677L;

  public JedisException(String paramString)
  {
    super(paramString);
  }

  public JedisException(Throwable paramThrowable)
  {
    super(paramThrowable);
  }

  public JedisException(String paramString, Throwable paramThrowable)
  {
    super(paramString, paramThrowable);
  }
}