package com.ycache.redis.clients.jedis;

import com.ycache.redis.clients.jedis.exceptions.JedisDataException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Transaction extends MultiKeyPipelineBase
{
  protected boolean inTransaction = true;

  protected Transaction()
  {
  }

  public Transaction(Client paramClient)
  {
    this.client = paramClient;
  }

  protected Client getClient(String paramString)
  {
    return this.client;
  }

  protected Client getClient(byte[] paramArrayOfByte)
  {
    return this.client;
  }

  public List<Object> exec()
  {
    this.client.exec();
    this.client.getAll(1);
    List localList = this.client.getObjectMultiBulkReply();
    if (localList == null)
      return null;
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      Object localObject = localIterator.next();
      try
      {
        localArrayList.add(generateResponse(localObject).get());
      }
      catch (JedisDataException localJedisDataException)
      {
        localArrayList.add(localJedisDataException);
      }
    }
    return localArrayList;
  }

  public List<Response<?>> execGetResponse()
  {
    this.client.exec();
    this.client.getAll(1);
    List localList = this.client.getObjectMultiBulkReply();
    if (localList == null)
      return null;
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      Object localObject = localIterator.next();
      localArrayList.add(generateResponse(localObject));
    }
    return localArrayList;
  }

  public String discard()
  {
    this.client.discard();
    this.client.getAll(1);
    this.inTransaction = false;
    clean();
    return this.client.getStatusCodeReply();
  }
}