package com.ycache.redis.clients.jedis;

import com.ycache.redis.clients.util.SafeEncoder;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

public class ZParams
{
  private List<byte[]> params = new ArrayList();

  public ZParams weights(int[] paramArrayOfInt)
  {
    this.params.add(Protocol.Keyword.WEIGHTS.raw);
    int[] arrayOfInt = paramArrayOfInt;
    int i = arrayOfInt.length;
    for (int j = 0; j < i; ++j)
    {
      int k = arrayOfInt[j];
      this.params.add(Protocol.toByteArray(k));
    }
    return this;
  }

  public Collection<byte[]> getParams()
  {
    return Collections.unmodifiableCollection(this.params);
  }

  public ZParams aggregate(Aggregate paramAggregate)
  {
    this.params.add(Protocol.Keyword.AGGREGATE.raw);
    this.params.add(paramAggregate.raw);
    return this;
  }

  public static enum Aggregate
  {
    SUM, MIN, MAX;

    public final byte[] raw = SafeEncoder.encode(name());
  }
}