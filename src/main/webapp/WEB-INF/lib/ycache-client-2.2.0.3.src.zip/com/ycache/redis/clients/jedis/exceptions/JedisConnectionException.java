package com.ycache.redis.clients.jedis.exceptions;

public class JedisConnectionException extends JedisException
{
  private static final long serialVersionUID = 3878126572474819403L;

  public JedisConnectionException(String paramString)
  {
    super(paramString);
  }

  public JedisConnectionException(Throwable paramThrowable)
  {
    super(paramThrowable);
  }

  public JedisConnectionException(String paramString, Throwable paramThrowable)
  {
    super(paramString, paramThrowable);
  }
}