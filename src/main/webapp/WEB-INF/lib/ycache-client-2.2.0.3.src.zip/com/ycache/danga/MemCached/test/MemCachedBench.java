package com.ycache.danga.MemCached.test;

import com.ycache.danga.MemCached.MemCachedClient;
import com.ycache.danga.MemCached.SockIOPool;
import java.io.PrintStream;
import java.util.Map;
import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;

public class MemCachedBench
{
  private static Logger log = Logger.getLogger(MemCachedBench.class.getName());

  public static void main(String[] paramArrayOfString)
  {
    BasicConfigurator.configure();
    Logger.getRootLogger().setLevel(Level.OFF);
    int i = Integer.parseInt(paramArrayOfString[0]);
    int j = Integer.parseInt(paramArrayOfString[1]);
    String[] arrayOfString1 = { "192.168.1.50:1624" };
    SockIOPool localSockIOPool = SockIOPool.getInstance("test");
    localSockIOPool.setServers(arrayOfString1);
    localSockIOPool.setInitConn(100);
    localSockIOPool.setMinConn(100);
    localSockIOPool.setMaxConn(500);
    localSockIOPool.setMaintSleep(20L);
    localSockIOPool.setNagle(false);
    localSockIOPool.initialize();
    MemCachedClient localMemCachedClient = new MemCachedClient("test");
    localMemCachedClient.setCompressEnable(false);
    String str1 = "testKey";
    String str2 = "This is a test of an object blah blah es, serialization does not seem to slow things down so much.  The gzip compression is horrible horrible performance, so we only use it for very large objects.  I have not done any heavy benchmarking recently";
    long l1 = System.currentTimeMillis();
    for (int k = j; k < j + i; ++k)
      localMemCachedClient.set(str1 + k, str2);
    long l2 = System.currentTimeMillis();
    long l3 = l2 - l1;
    System.out.println(i + " sets: " + l3 + "ms");
    l1 = System.currentTimeMillis();
    for (int l = j; l < j + i; ++l)
      String str3 = (String)localMemCachedClient.get(str1 + l);
    l2 = System.currentTimeMillis();
    l3 = l2 - l1;
    System.out.println(i + " gets: " + l3 + "ms");
    String[] arrayOfString2 = new String[i];
    int i1 = 0;
    for (int i2 = j; i2 < j + i; ++i2)
    {
      arrayOfString2[i1] = str1 + i2;
      ++i1;
    }
    l1 = System.currentTimeMillis();
    Map localMap = localMemCachedClient.getMulti(arrayOfString2);
    l2 = System.currentTimeMillis();
    l3 = l2 - l1;
    System.out.println(i + " getMulti: " + l3 + "ms");
    l1 = System.currentTimeMillis();
    for (int i3 = j; i3 < j + i; ++i3)
      localMemCachedClient.delete(str1 + i3);
    l2 = System.currentTimeMillis();
    l3 = l2 - l1;
    System.out.println(i + " deletes: " + l3 + "ms");
    SockIOPool.getInstance("test").shutDown();
  }
}