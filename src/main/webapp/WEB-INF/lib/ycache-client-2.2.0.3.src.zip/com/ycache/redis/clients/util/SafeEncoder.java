package com.ycache.redis.clients.util;

import [B;
import com.ycache.redis.clients.jedis.exceptions.JedisDataException;
import com.ycache.redis.clients.jedis.exceptions.JedisException;
import java.io.UnsupportedEncodingException;

public class SafeEncoder
{
  public static byte[][] encodeMany(String[] paramArrayOfString)
  {
    [B[] arrayOf[B = new byte[paramArrayOfString.length][];
    for (int i = 0; i < paramArrayOfString.length; ++i)
      arrayOf[B[i] = encode(paramArrayOfString[i]);
    return arrayOf[B;
  }

  public static byte[] encode(String paramString)
  {
    try
    {
      if (paramString == null)
        throw new JedisDataException("value sent to redis cannot be null");
      return paramString.getBytes("UTF-8");
    }
    catch (UnsupportedEncodingException localUnsupportedEncodingException)
    {
      throw new JedisException(localUnsupportedEncodingException);
    }
  }

  public static String encode(byte[] paramArrayOfByte)
  {
    try
    {
      return new String(paramArrayOfByte, "UTF-8");
    }
    catch (UnsupportedEncodingException localUnsupportedEncodingException)
    {
      throw new JedisException(localUnsupportedEncodingException);
    }
  }
}