package com.ycache.redis.clients.jedis;

import com.ycache.redis.clients.jedis.exceptions.JedisException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ShardedJedisPipelineUtils extends Queable
{
  private static final Logger logger = LoggerFactory.getLogger(ShardedJedisPipelineUtils.class);
  private ShardedJedisPool pool;
  private ShardedJedis jedis;
  private List<FutureResult> results = new ArrayList();
  private Queue<Client> clients = new LinkedList();

  public ShardedJedisPipelineUtils(ShardedJedisPool paramShardedJedisPool, ShardedJedis paramShardedJedis)
  {
    this.pool = paramShardedJedisPool;
    this.jedis = paramShardedJedis;
  }

  public List<Object> syncAndReturnAll()
  {
    ArrayList localArrayList = null;
    try
    {
      localArrayList = new ArrayList();
      Iterator localIterator = this.clients.iterator();
      while (localIterator.hasNext())
      {
        Client localClient = (Client)localIterator.next();
        localArrayList.add(generateResponse(localClient.getOne()).get());
      }
    }
    catch (Exception localException1)
    {
      if (this.jedis != null)
        try
        {
          this.pool.returnBrokenResource(this.jedis);
        }
        catch (Exception localException3)
        {
          logger.error(localException3.getMessage(), localException3);
        }
      logger.error(localException1.getMessage(), localException1);
      throw new JedisException(localException1);
    }
    if (this.jedis != null)
      try
      {
        this.pool.returnResource(this.jedis);
      }
      catch (Exception localException2)
      {
        logger.error("return resource fail." + localException2.getMessage(), localException2);
      }
    return localArrayList;
  }

  public void sync()
  {
    Iterator localIterator;
    try
    {
      localIterator = this.clients.iterator();
      while (localIterator.hasNext())
      {
        Client localClient = (Client)localIterator.next();
        generateResponse(localClient.getOne());
      }
    }
    catch (Exception localException1)
    {
      if (this.jedis != null)
        try
        {
          this.pool.returnBrokenResource(this.jedis);
        }
        catch (Exception localException3)
        {
          logger.error(localException3.getMessage(), localException3);
        }
      logger.error(localException1.getMessage(), localException1);
      throw new JedisException(localException1);
    }
    if (this.jedis != null)
      try
      {
        this.pool.returnResource(this.jedis);
      }
      catch (Exception localException2)
      {
        logger.error("return resource fail." + localException2.getMessage(), localException2);
      }
  }

  public void setShardedJedis(ShardedJedis paramShardedJedis)
  {
    this.jedis = paramShardedJedis;
  }

  public Response<String> set(String paramString1, String paramString2)
  {
    Client localClient = getClient(paramString1);
    localClient.set(paramString1, paramString2);
    this.results.add(new FutureResult(localClient));
    return getResponse(BuilderFactory.STRING);
  }

  public Response<Long> del(String paramString)
  {
    Client localClient = getClient(paramString);
    localClient.del(new String[] { paramString });
    this.results.add(new FutureResult(localClient));
    return getResponse(BuilderFactory.LONG);
  }

  public Response<String> get(String paramString)
  {
    Client localClient = getClient(paramString);
    localClient.get(paramString);
    this.results.add(new FutureResult(localClient));
    return getResponse(BuilderFactory.STRING);
  }

  public Response<Boolean> exists(String paramString)
  {
    Client localClient = getClient(paramString);
    localClient.exists(paramString);
    this.results.add(new FutureResult(localClient));
    return getResponse(BuilderFactory.BOOLEAN);
  }

  public Response<Boolean> type(String paramString)
  {
    Client localClient = getClient(paramString);
    localClient.type(paramString);
    this.results.add(new FutureResult(localClient));
    return getResponse(BuilderFactory.BOOLEAN);
  }

  public Response<Long> expire(String paramString, int paramInt)
  {
    Client localClient = getClient(paramString);
    localClient.expire(paramString, paramInt);
    this.results.add(new FutureResult(localClient));
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> expireAt(String paramString, long paramLong)
  {
    Client localClient = getClient(paramString);
    localClient.expireAt(paramString, paramLong);
    this.results.add(new FutureResult(localClient));
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> ttl(String paramString)
  {
    Client localClient = getClient(paramString);
    localClient.ttl(paramString);
    this.results.add(new FutureResult(localClient));
    return getResponse(BuilderFactory.LONG);
  }

  public Response<String> getSet(String paramString1, String paramString2)
  {
    Client localClient = getClient(paramString1);
    localClient.getSet(paramString1, paramString2);
    this.results.add(new FutureResult(localClient));
    return getResponse(BuilderFactory.STRING);
  }

  public Response<Long> setnx(String paramString1, String paramString2)
  {
    Client localClient = getClient(paramString1);
    localClient.setnx(paramString1, paramString2);
    this.results.add(new FutureResult(localClient));
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> setex(String paramString1, int paramInt, String paramString2)
  {
    Client localClient = getClient(paramString1);
    localClient.setex(paramString1, paramInt, paramString2);
    this.results.add(new FutureResult(localClient));
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> decrBy(String paramString, long paramLong)
  {
    Client localClient = getClient(paramString);
    localClient.decrBy(paramString, paramLong);
    this.results.add(new FutureResult(localClient));
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> decr(String paramString)
  {
    Client localClient = getClient(paramString);
    localClient.decr(paramString);
    this.results.add(new FutureResult(localClient));
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> incrBy(String paramString, int paramInt)
  {
    Client localClient = getClient(paramString);
    localClient.incrBy(paramString, paramInt);
    this.results.add(new FutureResult(localClient));
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> incr(String paramString)
  {
    Client localClient = getClient(paramString);
    localClient.incr(paramString);
    this.results.add(new FutureResult(localClient));
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> append(String paramString1, String paramString2)
  {
    Client localClient = getClient(paramString1);
    localClient.append(paramString1, paramString2);
    this.results.add(new FutureResult(localClient));
    return getResponse(BuilderFactory.LONG);
  }

  public Response<String> substr(String paramString, int paramInt1, int paramInt2)
  {
    Client localClient = getClient(paramString);
    localClient.substr(paramString, paramInt1, paramInt2);
    this.results.add(new FutureResult(localClient));
    return getResponse(BuilderFactory.STRING);
  }

  public Response<Long> hset(String paramString1, String paramString2, String paramString3)
  {
    Client localClient = getClient(paramString1);
    localClient.hset(paramString1, paramString2, paramString3);
    this.results.add(new FutureResult(localClient));
    return getResponse(BuilderFactory.LONG);
  }

  public Response<String> hget(String paramString1, String paramString2)
  {
    Client localClient = getClient(paramString1);
    localClient.hget(paramString1, paramString2);
    this.results.add(new FutureResult(localClient));
    return getResponse(BuilderFactory.STRING);
  }

  public Response<Long> hsetnx(String paramString1, String paramString2, String paramString3)
  {
    Client localClient = getClient(paramString1);
    localClient.hsetnx(paramString1, paramString2, paramString3);
    this.results.add(new FutureResult(localClient));
    return getResponse(BuilderFactory.LONG);
  }

  public Response<String> hmset(String paramString, Map<String, String> paramMap)
  {
    Client localClient = getClient(paramString);
    localClient.hmset(paramString, paramMap);
    this.results.add(new FutureResult(localClient));
    return getResponse(BuilderFactory.STRING);
  }

  public Response<List<String>> hmget(String paramString, String[] paramArrayOfString)
  {
    Client localClient = getClient(paramString);
    localClient.hmget(paramString, paramArrayOfString);
    this.results.add(new FutureResult(localClient));
    return getResponse(BuilderFactory.STRING_LIST);
  }

  public Response<Long> hincrBy(String paramString1, String paramString2, int paramInt)
  {
    Client localClient = getClient(paramString1);
    localClient.hincrBy(paramString1, paramString2, paramInt);
    this.results.add(new FutureResult(localClient));
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Boolean> hexists(String paramString1, String paramString2)
  {
    Client localClient = getClient(paramString1);
    localClient.hexists(paramString1, paramString2);
    this.results.add(new FutureResult(localClient));
    return getResponse(BuilderFactory.BOOLEAN);
  }

  public Response<Long> hdel(String paramString1, String paramString2)
  {
    Client localClient = getClient(paramString1);
    localClient.hdel(paramString1, new String[] { paramString2 });
    this.results.add(new FutureResult(localClient));
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> hlen(String paramString)
  {
    Client localClient = getClient(paramString);
    localClient.hlen(paramString);
    this.results.add(new FutureResult(localClient));
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Set<String>> hkeys(String paramString)
  {
    Client localClient = getClient(paramString);
    localClient.hkeys(paramString);
    this.results.add(new FutureResult(localClient));
    return getResponse(BuilderFactory.STRING_SET);
  }

  public Response<Set<String>> hvals(String paramString)
  {
    Client localClient = getClient(paramString);
    localClient.hvals(paramString);
    this.results.add(new FutureResult(localClient));
    return getResponse(BuilderFactory.STRING_SET);
  }

  public Response<Map<String, String>> hgetAll(String paramString)
  {
    Client localClient = getClient(paramString);
    localClient.hgetAll(paramString);
    this.results.add(new FutureResult(localClient));
    return getResponse(BuilderFactory.STRING_MAP);
  }

  public Response<Long> rpush(String paramString1, String paramString2)
  {
    Client localClient = getClient(paramString1);
    localClient.rpush(paramString1, new String[] { paramString2 });
    this.results.add(new FutureResult(localClient));
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> lpush(String paramString1, String paramString2)
  {
    Client localClient = getClient(paramString1);
    localClient.lpush(paramString1, new String[] { paramString2 });
    this.results.add(new FutureResult(localClient));
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> llen(String paramString)
  {
    Client localClient = getClient(paramString);
    localClient.llen(paramString);
    this.results.add(new FutureResult(localClient));
    return getResponse(BuilderFactory.LONG);
  }

  public Response<List<String>> lrange(String paramString, int paramInt1, int paramInt2)
  {
    Client localClient = getClient(paramString);
    localClient.lrange(paramString, paramInt1, paramInt2);
    this.results.add(new FutureResult(localClient));
    return getResponse(BuilderFactory.STRING_LIST);
  }

  public Response<String> ltrim(String paramString, int paramInt1, int paramInt2)
  {
    Client localClient = getClient(paramString);
    localClient.ltrim(paramString, paramInt1, paramInt2);
    this.results.add(new FutureResult(localClient));
    return getResponse(BuilderFactory.STRING);
  }

  public Response<String> lindex(String paramString, int paramInt)
  {
    Client localClient = getClient(paramString);
    localClient.lindex(paramString, paramInt);
    this.results.add(new FutureResult(localClient));
    return getResponse(BuilderFactory.STRING);
  }

  public Response<String> lset(String paramString1, int paramInt, String paramString2)
  {
    Client localClient = getClient(paramString1);
    localClient.lset(paramString1, paramInt, paramString2);
    this.results.add(new FutureResult(localClient));
    return getResponse(BuilderFactory.STRING);
  }

  public Response<Long> lrem(String paramString1, int paramInt, String paramString2)
  {
    Client localClient = getClient(paramString1);
    localClient.lrem(paramString1, paramInt, paramString2);
    this.results.add(new FutureResult(localClient));
    return getResponse(BuilderFactory.LONG);
  }

  public Response<String> lpop(String paramString)
  {
    Client localClient = getClient(paramString);
    localClient.lpop(paramString);
    this.results.add(new FutureResult(localClient));
    return getResponse(BuilderFactory.STRING);
  }

  public Response<String> rpop(String paramString)
  {
    Client localClient = getClient(paramString);
    localClient.rpop(paramString);
    this.results.add(new FutureResult(localClient));
    return getResponse(BuilderFactory.STRING);
  }

  public Response<Long> sadd(String paramString1, String paramString2)
  {
    Client localClient = getClient(paramString1);
    localClient.sadd(paramString1, new String[] { paramString2 });
    this.results.add(new FutureResult(localClient));
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Set<String>> smembers(String paramString)
  {
    Client localClient = getClient(paramString);
    localClient.smembers(paramString);
    this.results.add(new FutureResult(localClient));
    return getResponse(BuilderFactory.STRING_SET);
  }

  public Response<Long> srem(String paramString1, String paramString2)
  {
    Client localClient = getClient(paramString1);
    localClient.srem(paramString1, new String[] { paramString2 });
    this.results.add(new FutureResult(localClient));
    return getResponse(BuilderFactory.LONG);
  }

  public Response<String> spop(String paramString)
  {
    Client localClient = getClient(paramString);
    localClient.spop(paramString);
    this.results.add(new FutureResult(localClient));
    return getResponse(BuilderFactory.STRING);
  }

  public Response<Long> scard(String paramString)
  {
    Client localClient = getClient(paramString);
    localClient.scard(paramString);
    this.results.add(new FutureResult(localClient));
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Boolean> sismember(String paramString1, String paramString2)
  {
    Client localClient = getClient(paramString1);
    localClient.sismember(paramString1, paramString2);
    this.results.add(new FutureResult(localClient));
    return getResponse(BuilderFactory.BOOLEAN);
  }

  public Response<String> srandmember(String paramString)
  {
    Client localClient = getClient(paramString);
    localClient.srandmember(paramString);
    this.results.add(new FutureResult(localClient));
    return getResponse(BuilderFactory.STRING);
  }

  public Response<Long> zadd(String paramString1, double paramDouble, String paramString2)
  {
    Client localClient = getClient(paramString1);
    localClient.zadd(paramString1, paramDouble, paramString2);
    this.results.add(new FutureResult(localClient));
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Set<String>> zrange(String paramString, int paramInt1, int paramInt2)
  {
    Client localClient = getClient(paramString);
    localClient.zrange(paramString, paramInt1, paramInt2);
    this.results.add(new FutureResult(localClient));
    return getResponse(BuilderFactory.STRING_ZSET);
  }

  public Response<Long> zrem(String paramString1, String paramString2)
  {
    Client localClient = getClient(paramString1);
    localClient.zrem(paramString1, new String[] { paramString2 });
    this.results.add(new FutureResult(localClient));
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Double> zincrby(String paramString1, double paramDouble, String paramString2)
  {
    Client localClient = getClient(paramString1);
    localClient.zincrby(paramString1, paramDouble, paramString2);
    this.results.add(new FutureResult(localClient));
    return getResponse(BuilderFactory.DOUBLE);
  }

  public Response<Long> zrank(String paramString1, String paramString2)
  {
    Client localClient = getClient(paramString1);
    localClient.zrank(paramString1, paramString2);
    this.results.add(new FutureResult(localClient));
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> zrevrank(String paramString1, String paramString2)
  {
    Client localClient = getClient(paramString1);
    localClient.zrevrank(paramString1, paramString2);
    this.results.add(new FutureResult(localClient));
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Set<String>> zrevrange(String paramString, int paramInt1, int paramInt2)
  {
    Client localClient = getClient(paramString);
    localClient.zrevrange(paramString, paramInt1, paramInt2);
    this.results.add(new FutureResult(localClient));
    return getResponse(BuilderFactory.STRING_ZSET);
  }

  public Response<Set<Tuple>> zrangeWithScores(String paramString, int paramInt1, int paramInt2)
  {
    Client localClient = getClient(paramString);
    localClient.zrangeWithScores(paramString, paramInt1, paramInt2);
    this.results.add(new FutureResult(localClient));
    return getResponse(BuilderFactory.TUPLE_ZSET);
  }

  public Response<Set<Tuple>> zrevrangeWithScores(String paramString, int paramInt1, int paramInt2)
  {
    Client localClient = getClient(paramString);
    localClient.zrevrangeWithScores(paramString, paramInt1, paramInt2);
    this.results.add(new FutureResult(localClient));
    return getResponse(BuilderFactory.TUPLE_ZSET);
  }

  public Response<Long> zcard(String paramString)
  {
    Client localClient = getClient(paramString);
    localClient.zcard(paramString);
    this.results.add(new FutureResult(localClient));
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Double> zscore(String paramString1, String paramString2)
  {
    Client localClient = getClient(paramString1);
    localClient.zscore(paramString1, paramString2);
    this.results.add(new FutureResult(localClient));
    return getResponse(BuilderFactory.DOUBLE);
  }

  public Response<Double> sort(String paramString)
  {
    Client localClient = getClient(paramString);
    localClient.sort(paramString);
    this.results.add(new FutureResult(localClient));
    return getResponse(BuilderFactory.DOUBLE);
  }

  public Response<List<String>> sort(String paramString, SortingParams paramSortingParams)
  {
    Client localClient = getClient(paramString);
    localClient.sort(paramString, paramSortingParams);
    this.results.add(new FutureResult(localClient));
    return getResponse(BuilderFactory.STRING_LIST);
  }

  public Response<Long> zcount(String paramString, double paramDouble1, double paramDouble2)
  {
    Client localClient = getClient(paramString);
    localClient.zcount(paramString, paramDouble1, paramDouble2);
    this.results.add(new FutureResult(localClient));
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Set<String>> zrangeByScore(String paramString, double paramDouble1, double paramDouble2)
  {
    Client localClient = getClient(paramString);
    localClient.zrangeByScore(paramString, paramDouble1, paramDouble2);
    this.results.add(new FutureResult(localClient));
    return getResponse(BuilderFactory.STRING_ZSET);
  }

  public Response<Set<String>> zrangeByScore(String paramString, double paramDouble1, double paramDouble2, int paramInt1, int paramInt2)
  {
    Client localClient = getClient(paramString);
    localClient.zrangeByScore(paramString, paramDouble1, paramDouble2, paramInt1, paramInt2);
    this.results.add(new FutureResult(localClient));
    return getResponse(BuilderFactory.STRING_ZSET);
  }

  public Response<Set<Tuple>> zrangeByScoreWithScores(String paramString, double paramDouble1, double paramDouble2)
  {
    Client localClient = getClient(paramString);
    localClient.zrangeByScoreWithScores(paramString, paramDouble1, paramDouble2);
    this.results.add(new FutureResult(localClient));
    return getResponse(BuilderFactory.TUPLE_ZSET);
  }

  public Response<Set<Tuple>> zrangeByScoreWithScores(String paramString, double paramDouble1, double paramDouble2, int paramInt1, int paramInt2)
  {
    Client localClient = getClient(paramString);
    localClient.zrangeByScoreWithScores(paramString, paramDouble1, paramDouble2, paramInt1, paramInt2);
    this.results.add(new FutureResult(localClient));
    return getResponse(BuilderFactory.TUPLE_ZSET);
  }

  public Response<Long> zremrangeByRank(String paramString, int paramInt1, int paramInt2)
  {
    Client localClient = getClient(paramString);
    localClient.zremrangeByRank(paramString, paramInt1, paramInt2);
    this.results.add(new FutureResult(localClient));
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> zremrangeByScore(String paramString, double paramDouble1, double paramDouble2)
  {
    Client localClient = getClient(paramString);
    localClient.zremrangeByScore(paramString, paramDouble1, paramDouble2);
    this.results.add(new FutureResult(localClient));
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> linsert(String paramString1, BinaryClient.LIST_POSITION paramLIST_POSITION, String paramString2, String paramString3)
  {
    Client localClient = getClient(paramString1);
    localClient.linsert(paramString1, paramLIST_POSITION, paramString2, paramString3);
    this.results.add(new FutureResult(localClient));
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Boolean> getbit(String paramString, long paramLong)
  {
    Client localClient = getClient(paramString);
    localClient.getbit(paramString, paramLong);
    this.results.add(new FutureResult(localClient));
    return getResponse(BuilderFactory.BOOLEAN);
  }

  public Response<Boolean> setbit(String paramString, long paramLong, boolean paramBoolean)
  {
    Client localClient = getClient(paramString);
    localClient.setbit(paramString, paramLong, paramBoolean);
    this.results.add(new FutureResult(localClient));
    return getResponse(BuilderFactory.BOOLEAN);
  }

  public Response<Long> setrange(String paramString1, long paramLong, String paramString2)
  {
    Client localClient = getClient(paramString1);
    localClient.setrange(paramString1, paramLong, paramString2);
    this.results.add(new FutureResult(localClient));
    return getResponse(BuilderFactory.LONG);
  }

  public Response<Long> getrange(String paramString, long paramLong1, long paramLong2)
  {
    Client localClient = getClient(paramString);
    localClient.getrange(paramString, paramLong1, paramLong2);
    this.results.add(new FutureResult(localClient));
    return getResponse(BuilderFactory.LONG);
  }

  public List<Object> getResults()
  {
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator = this.results.iterator();
    while (localIterator.hasNext())
    {
      FutureResult localFutureResult = (FutureResult)localIterator.next();
      localArrayList.add(localFutureResult.get());
    }
    return localArrayList;
  }

  @Deprecated
  public void execute()
  {
  }

  private Client getClient(String paramString)
  {
    Client localClient = ((Jedis)this.jedis.getShard(paramString)).getClient();
    this.clients.add(localClient);
    return localClient;
  }

  private static class FutureResult
  {
    private Client client;

    public FutureResult(Client paramClient)
    {
      this.client = paramClient;
    }

    public Object get()
    {
      return this.client.getOne();
    }
  }
}