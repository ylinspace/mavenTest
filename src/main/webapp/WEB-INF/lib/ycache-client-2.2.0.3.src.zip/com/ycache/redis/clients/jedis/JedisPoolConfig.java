package com.ycache.redis.clients.jedis;

import org.apache.commons.pool.impl.GenericObjectPool.Config;

public class JedisPoolConfig extends GenericObjectPool.Config
{
  public JedisPoolConfig()
  {
    setTestWhileIdle(true);
    setMinEvictableIdleTimeMillis(60000L);
    setTimeBetweenEvictionRunsMillis(30000L);
    setNumTestsPerEvictionRun(-1);
  }

  public int getMaxIdle()
  {
    return this.maxIdle;
  }

  public void setMaxIdle(int paramInt)
  {
    this.maxIdle = paramInt;
  }

  public int getMinIdle()
  {
    return this.minIdle;
  }

  public void setMinIdle(int paramInt)
  {
    this.minIdle = paramInt;
  }

  public int getMaxActive()
  {
    return this.maxActive;
  }

  public void setMaxActive(int paramInt)
  {
    this.maxActive = paramInt;
  }

  public long getMaxWait()
  {
    return this.maxWait;
  }

  public void setMaxWait(long paramLong)
  {
    this.maxWait = paramLong;
  }

  public byte getWhenExhaustedAction()
  {
    return this.whenExhaustedAction;
  }

  public void setWhenExhaustedAction(byte paramByte)
  {
    this.whenExhaustedAction = paramByte;
  }

  public boolean isTestOnBorrow()
  {
    return this.testOnBorrow;
  }

  public void setTestOnBorrow(boolean paramBoolean)
  {
    this.testOnBorrow = paramBoolean;
  }

  public boolean isTestOnReturn()
  {
    return this.testOnReturn;
  }

  public void setTestOnReturn(boolean paramBoolean)
  {
    this.testOnReturn = paramBoolean;
  }

  public boolean isTestWhileIdle()
  {
    return this.testWhileIdle;
  }

  public void setTestWhileIdle(boolean paramBoolean)
  {
    this.testWhileIdle = paramBoolean;
  }

  public long getTimeBetweenEvictionRunsMillis()
  {
    return this.timeBetweenEvictionRunsMillis;
  }

  public void setTimeBetweenEvictionRunsMillis(long paramLong)
  {
    this.timeBetweenEvictionRunsMillis = paramLong;
  }

  public int getNumTestsPerEvictionRun()
  {
    return this.numTestsPerEvictionRun;
  }

  public void setNumTestsPerEvictionRun(int paramInt)
  {
    this.numTestsPerEvictionRun = paramInt;
  }

  public long getMinEvictableIdleTimeMillis()
  {
    return this.minEvictableIdleTimeMillis;
  }

  public void setMinEvictableIdleTimeMillis(long paramLong)
  {
    this.minEvictableIdleTimeMillis = paramLong;
  }

  public long getSoftMinEvictableIdleTimeMillis()
  {
    return this.softMinEvictableIdleTimeMillis;
  }

  public void setSoftMinEvictableIdleTimeMillis(long paramLong)
  {
    this.softMinEvictableIdleTimeMillis = paramLong;
  }
}