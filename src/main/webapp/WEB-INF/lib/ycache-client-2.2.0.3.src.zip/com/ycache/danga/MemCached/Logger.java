package com.ycache.danga.MemCached;

import java.io.PrintStream;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class Logger
{
  public static final int LEVEL_DEBUG = 0;
  public static final int LEVEL_INFO = 1;
  public static final int LEVEL_WARN = 2;
  public static final int LEVEL_ERROR = 3;
  public static final int LEVEL_FATAL = 4;
  private static Map<String, Logger> loggers = new HashMap();
  private String name;
  private int level;
  private boolean initialized = false;

  public void setLevel(int paramInt)
  {
    this.level = paramInt;
  }

  public int getLevel()
  {
    return this.level;
  }

  protected Logger(String paramString, int paramInt)
  {
    this.name = paramString;
    this.level = paramInt;
    this.initialized = true;
  }

  protected Logger(String paramString)
  {
    this.name = paramString;
    this.level = 3;
    this.initialized = true;
  }

  public static synchronized Logger getLogger(String paramString, int paramInt)
  {
    Logger localLogger = getLogger(paramString);
    if (localLogger.getLevel() != paramInt)
      localLogger.setLevel(paramInt);
    return localLogger;
  }

  public static synchronized Logger getLogger(String paramString)
  {
    Logger localLogger = null;
    if (loggers.containsKey(paramString))
    {
      localLogger = (Logger)loggers.get(paramString);
    }
    else
    {
      localLogger = new Logger(paramString);
      loggers.put(paramString, localLogger);
    }
    return localLogger;
  }

  private void log(String paramString, Throwable paramThrowable)
  {
    System.out.println(this.name + " " + new Date() + " - " + paramString);
    if (paramThrowable != null)
      paramThrowable.printStackTrace(System.out);
  }

  public void debug(String paramString, Throwable paramThrowable)
  {
    if (this.level > 0)
      return;
    log(paramString, paramThrowable);
  }

  public void debug(String paramString)
  {
    debug(paramString, null);
  }

  public boolean isDebugEnabled()
  {
    return (this.level <= 0);
  }

  public void info(String paramString, Throwable paramThrowable)
  {
    if (this.level > 1)
      return;
    log(paramString, paramThrowable);
  }

  public void info(String paramString)
  {
    info(paramString, null);
  }

  public boolean isInfoEnabled()
  {
    return (this.level <= 1);
  }

  public void warn(String paramString, Throwable paramThrowable)
  {
    if (this.level > 2)
      return;
    log(paramString, paramThrowable);
  }

  public void warn(String paramString)
  {
    warn(paramString, null);
  }

  public void error(String paramString, Throwable paramThrowable)
  {
    if (this.level > 3)
      return;
    log(paramString, paramThrowable);
  }

  public void error(String paramString)
  {
    error(paramString, null);
  }

  public void fatal(String paramString, Throwable paramThrowable)
  {
    if (this.level > 4)
      return;
    log(paramString, paramThrowable);
  }

  public void fatal(String paramString)
  {
    fatal(paramString, null);
  }
}