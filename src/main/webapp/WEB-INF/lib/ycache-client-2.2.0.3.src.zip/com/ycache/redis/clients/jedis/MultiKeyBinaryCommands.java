package com.ycache.redis.clients.jedis;

import java.util.List;
import java.util.Set;

public abstract interface MultiKeyBinaryCommands
{
  public abstract Long del(byte[][] paramArrayOfByte);

  public abstract List<byte[]> blpop(int paramInt, byte[][] paramArrayOfByte);

  public abstract List<byte[]> brpop(int paramInt, byte[][] paramArrayOfByte);

  public abstract List<byte[]> blpop(byte[][] paramArrayOfByte);

  public abstract List<byte[]> brpop(byte[][] paramArrayOfByte);

  public abstract Set<byte[]> keys(byte[] paramArrayOfByte);

  public abstract List<byte[]> mget(byte[][] paramArrayOfByte);

  public abstract String mset(byte[][] paramArrayOfByte);

  public abstract Long msetnx(byte[][] paramArrayOfByte);

  public abstract String rename(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);

  public abstract Long renamenx(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);

  public abstract byte[] rpoplpush(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);

  public abstract Set<byte[]> sdiff(byte[][] paramArrayOfByte);

  public abstract Long sdiffstore(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1);

  public abstract Set<byte[]> sinter(byte[][] paramArrayOfByte);

  public abstract Long sinterstore(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1);

  public abstract Long smove(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3);

  public abstract Long sort(byte[] paramArrayOfByte1, SortingParams paramSortingParams, byte[] paramArrayOfByte2);

  public abstract Long sort(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);

  public abstract Set<byte[]> sunion(byte[][] paramArrayOfByte);

  public abstract Long sunionstore(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1);

  public abstract String watch(byte[][] paramArrayOfByte);

  public abstract String unwatch();

  public abstract Long zinterstore(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1);

  public abstract Long zinterstore(byte[] paramArrayOfByte, ZParams paramZParams, byte[][] paramArrayOfByte1);

  public abstract Long zunionstore(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1);

  public abstract Long zunionstore(byte[] paramArrayOfByte, ZParams paramZParams, byte[][] paramArrayOfByte1);

  public abstract byte[] brpoplpush(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, int paramInt);

  public abstract Long publish(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);

  public abstract void subscribe(BinaryJedisPubSub paramBinaryJedisPubSub, byte[][] paramArrayOfByte);

  public abstract void psubscribe(BinaryJedisPubSub paramBinaryJedisPubSub, byte[][] paramArrayOfByte);

  public abstract byte[] randomBinaryKey();

  public abstract Long bitop(BitOP paramBitOP, byte[] paramArrayOfByte, byte[][] paramArrayOfByte1);
}