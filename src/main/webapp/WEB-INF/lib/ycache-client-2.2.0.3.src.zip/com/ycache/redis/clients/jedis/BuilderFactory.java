package com.ycache.redis.clients.jedis;

import com.ycache.redis.clients.util.SafeEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class BuilderFactory
{
  public static final Builder<Double> DOUBLE = new Builder()
  {
    public Double build(Object paramObject)
    {
      String str = (String)BuilderFactory.STRING.build(paramObject);
      return ((str == null) ? null : Double.valueOf(str));
    }

    public String toString()
    {
      return "double";
    }
  };
  public static final Builder<Boolean> BOOLEAN = new Builder()
  {
    public Boolean build(Object paramObject)
    {
      return Boolean.valueOf(((Long)paramObject).longValue() == -6318800197052792831L);
    }

    public String toString()
    {
      return "boolean";
    }
  };
  public static final Builder<byte[]> BYTE_ARRAY = new Builder()
  {
    public byte[] build(Object paramObject)
    {
      return ((byte[])(byte[])paramObject);
    }

    public String toString()
    {
      return "byte[]";
    }
  };
  public static final Builder<Long> LONG = new Builder()
  {
    public Long build(Object paramObject)
    {
      return ((Long)paramObject);
    }

    public String toString()
    {
      return "long";
    }
  };
  public static final Builder<String> STRING = new Builder()
  {
    public String build(Object paramObject)
    {
      return ((paramObject == null) ? null : SafeEncoder.encode((byte[])(byte[])paramObject));
    }

    public String toString()
    {
      return "string";
    }
  };
  public static final Builder<List<String>> STRING_LIST = new Builder()
  {
    public List<String> build(Object paramObject)
    {
      if (null == paramObject)
        return null;
      List localList = (List)paramObject;
      ArrayList localArrayList = new ArrayList(localList.size());
      Iterator localIterator = localList.iterator();
      while (localIterator.hasNext())
      {
        byte[] arrayOfByte = (byte[])localIterator.next();
        if (arrayOfByte == null)
          localArrayList.add(null);
        else
          localArrayList.add(SafeEncoder.encode(arrayOfByte));
      }
      return localArrayList;
    }

    public String toString()
    {
      return "List<String>";
    }
  };
  public static final Builder<Map<String, String>> STRING_MAP = new Builder()
  {
    public Map<String, String> build(Object paramObject)
    {
      List localList = (List)paramObject;
      HashMap localHashMap = new HashMap();
      Iterator localIterator = localList.iterator();
      while (localIterator.hasNext())
        localHashMap.put(SafeEncoder.encode((byte[])localIterator.next()), SafeEncoder.encode((byte[])localIterator.next()));
      return localHashMap;
    }

    public String toString()
    {
      return "Map<String, String>";
    }
  };
  public static final Builder<Set<String>> STRING_SET = new Builder()
  {
    public Set<String> build(Object paramObject)
    {
      if (null == paramObject)
        return null;
      List localList = (List)paramObject;
      HashSet localHashSet = new HashSet(localList.size());
      Iterator localIterator = localList.iterator();
      while (localIterator.hasNext())
      {
        byte[] arrayOfByte = (byte[])localIterator.next();
        if (arrayOfByte == null)
          localHashSet.add(null);
        else
          localHashSet.add(SafeEncoder.encode(arrayOfByte));
      }
      return localHashSet;
    }

    public String toString()
    {
      return "Set<String>";
    }
  };
  public static final Builder<List<byte[]>> BYTE_ARRAY_LIST = new Builder()
  {
    public List<byte[]> build(Object paramObject)
    {
      if (null == paramObject)
        return null;
      List localList = (List)paramObject;
      return localList;
    }

    public String toString()
    {
      return "List<byte[]>";
    }
  };
  public static final Builder<Set<byte[]>> BYTE_ARRAY_ZSET = new Builder()
  {
    public Set<byte[]> build(Object paramObject)
    {
      if (null == paramObject)
        return null;
      List localList = (List)paramObject;
      LinkedHashSet localLinkedHashSet = new LinkedHashSet(localList);
      Iterator localIterator = localList.iterator();
      while (localIterator.hasNext())
      {
        byte[] arrayOfByte = (byte[])localIterator.next();
        if (arrayOfByte == null)
          localLinkedHashSet.add(null);
        else
          localLinkedHashSet.add(arrayOfByte);
      }
      return localLinkedHashSet;
    }

    public String toString()
    {
      return "ZSet<byte[]>";
    }
  };
  public static final Builder<Map<byte[], byte[]>> BYTE_ARRAY_MAP = new Builder()
  {
    public Map<byte[], byte[]> build(Object paramObject)
    {
      List localList = (List)paramObject;
      HashMap localHashMap = new HashMap();
      Iterator localIterator = localList.iterator();
      while (localIterator.hasNext())
        localHashMap.put(localIterator.next(), localIterator.next());
      return localHashMap;
    }

    public String toString()
    {
      return "Map<byte[], byte[]>";
    }
  };
  public static final Builder<Set<String>> STRING_ZSET = new Builder()
  {
    public Set<String> build(Object paramObject)
    {
      if (null == paramObject)
        return null;
      List localList = (List)paramObject;
      LinkedHashSet localLinkedHashSet = new LinkedHashSet(localList.size());
      Iterator localIterator = localList.iterator();
      while (localIterator.hasNext())
      {
        byte[] arrayOfByte = (byte[])localIterator.next();
        if (arrayOfByte == null)
          localLinkedHashSet.add(null);
        else
          localLinkedHashSet.add(SafeEncoder.encode(arrayOfByte));
      }
      return localLinkedHashSet;
    }

    public String toString()
    {
      return "ZSet<String>";
    }
  };
  public static final Builder<Set<Tuple>> TUPLE_ZSET = new Builder()
  {
    public Set<Tuple> build(Object paramObject)
    {
      if (null == paramObject)
        return null;
      List localList = (List)paramObject;
      LinkedHashSet localLinkedHashSet = new LinkedHashSet(localList.size());
      Iterator localIterator = localList.iterator();
      while (localIterator.hasNext())
        localLinkedHashSet.add(new Tuple(SafeEncoder.encode((byte[])localIterator.next()), Double.valueOf(SafeEncoder.encode((byte[])localIterator.next()))));
      return localLinkedHashSet;
    }

    public String toString()
    {
      return "ZSet<Tuple>";
    }
  };
  public static final Builder<Set<Tuple>> TUPLE_ZSET_BINARY = new Builder()
  {
    public Set<Tuple> build(Object paramObject)
    {
      if (null == paramObject)
        return null;
      List localList = (List)paramObject;
      LinkedHashSet localLinkedHashSet = new LinkedHashSet(localList.size());
      Iterator localIterator = localList.iterator();
      while (localIterator.hasNext())
        localLinkedHashSet.add(new Tuple((byte[])localIterator.next(), Double.valueOf(SafeEncoder.encode((byte[])localIterator.next()))));
      return localLinkedHashSet;
    }

    public String toString()
    {
      return "ZSet<Tuple>";
    }
  };
}