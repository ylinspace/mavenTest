package com.ycache.redis.clients.jedis;

import [B;
import com.ycache.redis.clients.util.SafeEncoder;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class BinaryClient extends Connection
{
  private boolean isInMulti;
  private java.lang.String password;
  private long db;

  public boolean isInMulti()
  {
    return this.isInMulti;
  }

  public BinaryClient(java.lang.String paramString)
  {
    super(paramString);
  }

  public BinaryClient(java.lang.String paramString, int paramInt)
  {
    super(paramString, paramInt);
  }

  private byte[][] joinParameters(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1)
  {
    [B[] arrayOf[B = new byte[paramArrayOfByte1.length + 1][];
    arrayOf[B[0] = paramArrayOfByte;
    for (int i = 0; i < paramArrayOfByte1.length; ++i)
      arrayOf[B[(i + 1)] = paramArrayOfByte1[i];
    return arrayOf[B;
  }

  public void setPassword(java.lang.String paramString)
  {
    this.password = paramString;
  }

  public void connect()
  {
    if (!(isConnected()))
    {
      super.connect();
      if (this.password != null)
      {
        auth(this.password);
        getStatusCodeReply();
      }
      if (this.db > -6318801794780626944L)
      {
        select(Long.valueOf(this.db).intValue());
        getStatusCodeReply();
      }
    }
  }

  public void ping()
  {
    sendCommand(Protocol.Command.PING);
  }

  public void set(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    sendCommand(Protocol.Command.SET, new byte[][] { paramArrayOfByte1, paramArrayOfByte2 });
  }

  public void set(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3, byte[] paramArrayOfByte4, long paramLong)
  {
    sendCommand(Protocol.Command.SET, new byte[][] { paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3, paramArrayOfByte4, Protocol.toByteArray(paramLong) });
  }

  public void get(byte[] paramArrayOfByte)
  {
    sendCommand(Protocol.Command.GET, new byte[][] { paramArrayOfByte });
  }

  public void quit()
  {
    this.db = -6318802138378010624L;
    sendCommand(Protocol.Command.QUIT);
  }

  public void exists(byte[] paramArrayOfByte)
  {
    sendCommand(Protocol.Command.EXISTS, new byte[][] { paramArrayOfByte });
  }

  public void del(byte[][] paramArrayOfByte)
  {
    sendCommand(Protocol.Command.DEL, paramArrayOfByte);
  }

  public void type(byte[] paramArrayOfByte)
  {
    sendCommand(Protocol.Command.TYPE, new byte[][] { paramArrayOfByte });
  }

  public void flushDB()
  {
    sendCommand(Protocol.Command.FLUSHDB);
  }

  public void keys(byte[] paramArrayOfByte)
  {
    sendCommand(Protocol.Command.KEYS, new byte[][] { paramArrayOfByte });
  }

  public void randomKey()
  {
    sendCommand(Protocol.Command.RANDOMKEY);
  }

  public void rename(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    sendCommand(Protocol.Command.RENAME, new byte[][] { paramArrayOfByte1, paramArrayOfByte2 });
  }

  public void renamenx(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    sendCommand(Protocol.Command.RENAMENX, new byte[][] { paramArrayOfByte1, paramArrayOfByte2 });
  }

  public void dbSize()
  {
    sendCommand(Protocol.Command.DBSIZE);
  }

  public void expire(byte[] paramArrayOfByte, int paramInt)
  {
    sendCommand(Protocol.Command.EXPIRE, new byte[][] { paramArrayOfByte, Protocol.toByteArray(paramInt) });
  }

  public void expireAt(byte[] paramArrayOfByte, long paramLong)
  {
    sendCommand(Protocol.Command.EXPIREAT, new byte[][] { paramArrayOfByte, Protocol.toByteArray(paramLong) });
  }

  public void ttl(byte[] paramArrayOfByte)
  {
    sendCommand(Protocol.Command.TTL, new byte[][] { paramArrayOfByte });
  }

  public void select(int paramInt)
  {
    this.db = paramInt;
    sendCommand(Protocol.Command.SELECT, new byte[][] { Protocol.toByteArray(paramInt) });
  }

  public void move(byte[] paramArrayOfByte, int paramInt)
  {
    sendCommand(Protocol.Command.MOVE, new byte[][] { paramArrayOfByte, Protocol.toByteArray(paramInt) });
  }

  public void flushAll()
  {
    sendCommand(Protocol.Command.FLUSHALL);
  }

  public void getSet(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    sendCommand(Protocol.Command.GETSET, new byte[][] { paramArrayOfByte1, paramArrayOfByte2 });
  }

  public void mget(byte[][] paramArrayOfByte)
  {
    sendCommand(Protocol.Command.MGET, paramArrayOfByte);
  }

  public void setnx(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    sendCommand(Protocol.Command.SETNX, new byte[][] { paramArrayOfByte1, paramArrayOfByte2 });
  }

  public void setex(byte[] paramArrayOfByte1, int paramInt, byte[] paramArrayOfByte2)
  {
    sendCommand(Protocol.Command.SETEX, new byte[][] { paramArrayOfByte1, Protocol.toByteArray(paramInt), paramArrayOfByte2 });
  }

  public void mset(byte[][] paramArrayOfByte)
  {
    sendCommand(Protocol.Command.MSET, paramArrayOfByte);
  }

  public void msetnx(byte[][] paramArrayOfByte)
  {
    sendCommand(Protocol.Command.MSETNX, paramArrayOfByte);
  }

  public void decrBy(byte[] paramArrayOfByte, long paramLong)
  {
    sendCommand(Protocol.Command.DECRBY, new byte[][] { paramArrayOfByte, Protocol.toByteArray(paramLong) });
  }

  public void decr(byte[] paramArrayOfByte)
  {
    sendCommand(Protocol.Command.DECR, new byte[][] { paramArrayOfByte });
  }

  public void incrBy(byte[] paramArrayOfByte, long paramLong)
  {
    sendCommand(Protocol.Command.INCRBY, new byte[][] { paramArrayOfByte, Protocol.toByteArray(paramLong) });
  }

  public void incr(byte[] paramArrayOfByte)
  {
    sendCommand(Protocol.Command.INCR, new byte[][] { paramArrayOfByte });
  }

  public void append(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    sendCommand(Protocol.Command.APPEND, new byte[][] { paramArrayOfByte1, paramArrayOfByte2 });
  }

  public void substr(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    sendCommand(Protocol.Command.SUBSTR, new byte[][] { paramArrayOfByte, Protocol.toByteArray(paramInt1), Protocol.toByteArray(paramInt2) });
  }

  public void hset(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
  {
    sendCommand(Protocol.Command.HSET, new byte[][] { paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3 });
  }

  public void hget(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    sendCommand(Protocol.Command.HGET, new byte[][] { paramArrayOfByte1, paramArrayOfByte2 });
  }

  public void hsetnx(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
  {
    sendCommand(Protocol.Command.HSETNX, new byte[][] { paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3 });
  }

  public void hmset(byte[] paramArrayOfByte, Map<byte[], byte[]> paramMap)
  {
    ArrayList localArrayList = new ArrayList();
    localArrayList.add(paramArrayOfByte);
    Iterator localIterator = paramMap.entrySet().iterator();
    while (localIterator.hasNext())
    {
      Map.Entry localEntry = (Map.Entry)localIterator.next();
      localArrayList.add(localEntry.getKey());
      localArrayList.add(localEntry.getValue());
    }
    sendCommand(Protocol.Command.HMSET, (byte[][])localArrayList.toArray(new byte[localArrayList.size()][]));
  }

  public void hmget(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1)
  {
    [B[] arrayOf[B = new byte[paramArrayOfByte1.length + 1][];
    arrayOf[B[0] = paramArrayOfByte;
    System.arraycopy(paramArrayOfByte1, 0, arrayOf[B, 1, paramArrayOfByte1.length);
    sendCommand(Protocol.Command.HMGET, arrayOf[B);
  }

  public void hincrBy(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, long paramLong)
  {
    sendCommand(Protocol.Command.HINCRBY, new byte[][] { paramArrayOfByte1, paramArrayOfByte2, Protocol.toByteArray(paramLong) });
  }

  public void hexists(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    sendCommand(Protocol.Command.HEXISTS, new byte[][] { paramArrayOfByte1, paramArrayOfByte2 });
  }

  public void hdel(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1)
  {
    sendCommand(Protocol.Command.HDEL, joinParameters(paramArrayOfByte, paramArrayOfByte1));
  }

  public void hlen(byte[] paramArrayOfByte)
  {
    sendCommand(Protocol.Command.HLEN, new byte[][] { paramArrayOfByte });
  }

  public void hkeys(byte[] paramArrayOfByte)
  {
    sendCommand(Protocol.Command.HKEYS, new byte[][] { paramArrayOfByte });
  }

  public void hvals(byte[] paramArrayOfByte)
  {
    sendCommand(Protocol.Command.HVALS, new byte[][] { paramArrayOfByte });
  }

  public void hgetAll(byte[] paramArrayOfByte)
  {
    sendCommand(Protocol.Command.HGETALL, new byte[][] { paramArrayOfByte });
  }

  public void rpush(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1)
  {
    sendCommand(Protocol.Command.RPUSH, joinParameters(paramArrayOfByte, paramArrayOfByte1));
  }

  public void lpush(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1)
  {
    sendCommand(Protocol.Command.LPUSH, joinParameters(paramArrayOfByte, paramArrayOfByte1));
  }

  public void llen(byte[] paramArrayOfByte)
  {
    sendCommand(Protocol.Command.LLEN, new byte[][] { paramArrayOfByte });
  }

  public void lrange(byte[] paramArrayOfByte, long paramLong1, long paramLong2)
  {
    sendCommand(Protocol.Command.LRANGE, new byte[][] { paramArrayOfByte, Protocol.toByteArray(paramLong1), Protocol.toByteArray(paramLong2) });
  }

  public void ltrim(byte[] paramArrayOfByte, long paramLong1, long paramLong2)
  {
    sendCommand(Protocol.Command.LTRIM, new byte[][] { paramArrayOfByte, Protocol.toByteArray(paramLong1), Protocol.toByteArray(paramLong2) });
  }

  public void lindex(byte[] paramArrayOfByte, long paramLong)
  {
    sendCommand(Protocol.Command.LINDEX, new byte[][] { paramArrayOfByte, Protocol.toByteArray(paramLong) });
  }

  public void lset(byte[] paramArrayOfByte1, long paramLong, byte[] paramArrayOfByte2)
  {
    sendCommand(Protocol.Command.LSET, new byte[][] { paramArrayOfByte1, Protocol.toByteArray(paramLong), paramArrayOfByte2 });
  }

  public void lrem(byte[] paramArrayOfByte1, long paramLong, byte[] paramArrayOfByte2)
  {
    sendCommand(Protocol.Command.LREM, new byte[][] { paramArrayOfByte1, Protocol.toByteArray(paramLong), paramArrayOfByte2 });
  }

  public void lpop(byte[] paramArrayOfByte)
  {
    sendCommand(Protocol.Command.LPOP, new byte[][] { paramArrayOfByte });
  }

  public void rpop(byte[] paramArrayOfByte)
  {
    sendCommand(Protocol.Command.RPOP, new byte[][] { paramArrayOfByte });
  }

  public void rpoplpush(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    sendCommand(Protocol.Command.RPOPLPUSH, new byte[][] { paramArrayOfByte1, paramArrayOfByte2 });
  }

  public void sadd(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1)
  {
    sendCommand(Protocol.Command.SADD, joinParameters(paramArrayOfByte, paramArrayOfByte1));
  }

  public void smembers(byte[] paramArrayOfByte)
  {
    sendCommand(Protocol.Command.SMEMBERS, new byte[][] { paramArrayOfByte });
  }

  public void srem(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1)
  {
    sendCommand(Protocol.Command.SREM, joinParameters(paramArrayOfByte, paramArrayOfByte1));
  }

  public void spop(byte[] paramArrayOfByte)
  {
    sendCommand(Protocol.Command.SPOP, new byte[][] { paramArrayOfByte });
  }

  public void smove(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
  {
    sendCommand(Protocol.Command.SMOVE, new byte[][] { paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3 });
  }

  public void scard(byte[] paramArrayOfByte)
  {
    sendCommand(Protocol.Command.SCARD, new byte[][] { paramArrayOfByte });
  }

  public void sismember(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    sendCommand(Protocol.Command.SISMEMBER, new byte[][] { paramArrayOfByte1, paramArrayOfByte2 });
  }

  public void sinter(byte[][] paramArrayOfByte)
  {
    sendCommand(Protocol.Command.SINTER, paramArrayOfByte);
  }

  public void sinterstore(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1)
  {
    [B[] arrayOf[B = new byte[paramArrayOfByte1.length + 1][];
    arrayOf[B[0] = paramArrayOfByte;
    System.arraycopy(paramArrayOfByte1, 0, arrayOf[B, 1, paramArrayOfByte1.length);
    sendCommand(Protocol.Command.SINTERSTORE, arrayOf[B);
  }

  public void sunion(byte[][] paramArrayOfByte)
  {
    sendCommand(Protocol.Command.SUNION, paramArrayOfByte);
  }

  public void sunionstore(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1)
  {
    [B[] arrayOf[B = new byte[paramArrayOfByte1.length + 1][];
    arrayOf[B[0] = paramArrayOfByte;
    System.arraycopy(paramArrayOfByte1, 0, arrayOf[B, 1, paramArrayOfByte1.length);
    sendCommand(Protocol.Command.SUNIONSTORE, arrayOf[B);
  }

  public void sdiff(byte[][] paramArrayOfByte)
  {
    sendCommand(Protocol.Command.SDIFF, paramArrayOfByte);
  }

  public void sdiffstore(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1)
  {
    [B[] arrayOf[B = new byte[paramArrayOfByte1.length + 1][];
    arrayOf[B[0] = paramArrayOfByte;
    System.arraycopy(paramArrayOfByte1, 0, arrayOf[B, 1, paramArrayOfByte1.length);
    sendCommand(Protocol.Command.SDIFFSTORE, arrayOf[B);
  }

  public void srandmember(byte[] paramArrayOfByte)
  {
    sendCommand(Protocol.Command.SRANDMEMBER, new byte[][] { paramArrayOfByte });
  }

  public void zadd(byte[] paramArrayOfByte1, double paramDouble, byte[] paramArrayOfByte2)
  {
    sendCommand(Protocol.Command.ZADD, new byte[][] { paramArrayOfByte1, Protocol.toByteArray(paramDouble), paramArrayOfByte2 });
  }

  public void zaddBinary(byte[] paramArrayOfByte, Map<Double, byte[]> paramMap)
  {
    ArrayList localArrayList = new ArrayList(paramMap.size() * 2 + 1);
    localArrayList.add(paramArrayOfByte);
    Object localObject = paramMap.entrySet().iterator();
    while (((Iterator)localObject).hasNext())
    {
      Map.Entry localEntry = (Map.Entry)((Iterator)localObject).next();
      localArrayList.add(Protocol.toByteArray(((Double)localEntry.getKey()).doubleValue()));
      localArrayList.add(localEntry.getValue());
    }
    localObject = new byte[localArrayList.size()][];
    localArrayList.toArray(localObject);
    sendCommand(Protocol.Command.ZADD, localObject);
  }

  public void zrange(byte[] paramArrayOfByte, long paramLong1, long paramLong2)
  {
    sendCommand(Protocol.Command.ZRANGE, new byte[][] { paramArrayOfByte, Protocol.toByteArray(paramLong1), Protocol.toByteArray(paramLong2) });
  }

  public void zrem(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1)
  {
    sendCommand(Protocol.Command.ZREM, joinParameters(paramArrayOfByte, paramArrayOfByte1));
  }

  public void zincrby(byte[] paramArrayOfByte1, double paramDouble, byte[] paramArrayOfByte2)
  {
    sendCommand(Protocol.Command.ZINCRBY, new byte[][] { paramArrayOfByte1, Protocol.toByteArray(paramDouble), paramArrayOfByte2 });
  }

  public void zrank(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    sendCommand(Protocol.Command.ZRANK, new byte[][] { paramArrayOfByte1, paramArrayOfByte2 });
  }

  public void zrevrank(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    sendCommand(Protocol.Command.ZREVRANK, new byte[][] { paramArrayOfByte1, paramArrayOfByte2 });
  }

  public void zrevrange(byte[] paramArrayOfByte, long paramLong1, long paramLong2)
  {
    sendCommand(Protocol.Command.ZREVRANGE, new byte[][] { paramArrayOfByte, Protocol.toByteArray(paramLong1), Protocol.toByteArray(paramLong2) });
  }

  public void zrangeWithScores(byte[] paramArrayOfByte, long paramLong1, long paramLong2)
  {
    sendCommand(Protocol.Command.ZRANGE, new byte[][] { paramArrayOfByte, Protocol.toByteArray(paramLong1), Protocol.toByteArray(paramLong2), Protocol.Keyword.WITHSCORES.raw });
  }

  public void zrevrangeWithScores(byte[] paramArrayOfByte, long paramLong1, long paramLong2)
  {
    sendCommand(Protocol.Command.ZREVRANGE, new byte[][] { paramArrayOfByte, Protocol.toByteArray(paramLong1), Protocol.toByteArray(paramLong2), Protocol.Keyword.WITHSCORES.raw });
  }

  public void zcard(byte[] paramArrayOfByte)
  {
    sendCommand(Protocol.Command.ZCARD, new byte[][] { paramArrayOfByte });
  }

  public void zscore(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    sendCommand(Protocol.Command.ZSCORE, new byte[][] { paramArrayOfByte1, paramArrayOfByte2 });
  }

  public void multi()
  {
    sendCommand(Protocol.Command.MULTI);
    this.isInMulti = true;
  }

  public void discard()
  {
    sendCommand(Protocol.Command.DISCARD);
    this.isInMulti = false;
  }

  public void exec()
  {
    sendCommand(Protocol.Command.EXEC);
    this.isInMulti = false;
  }

  public void watch(byte[][] paramArrayOfByte)
  {
    sendCommand(Protocol.Command.WATCH, paramArrayOfByte);
  }

  public void unwatch()
  {
    sendCommand(Protocol.Command.UNWATCH);
  }

  public void sort(byte[] paramArrayOfByte)
  {
    sendCommand(Protocol.Command.SORT, new byte[][] { paramArrayOfByte });
  }

  public void sort(byte[] paramArrayOfByte, SortingParams paramSortingParams)
  {
    ArrayList localArrayList = new ArrayList();
    localArrayList.add(paramArrayOfByte);
    localArrayList.addAll(paramSortingParams.getParams());
    sendCommand(Protocol.Command.SORT, (byte[][])localArrayList.toArray(new byte[localArrayList.size()][]));
  }

  public void blpop(byte[][] paramArrayOfByte)
  {
    sendCommand(Protocol.Command.BLPOP, paramArrayOfByte);
  }

  public void blpop(int paramInt, byte[][] paramArrayOfByte)
  {
    ArrayList localArrayList = new ArrayList();
    byte[][] arrayOfByte = paramArrayOfByte;
    int i = arrayOfByte.length;
    for (int j = 0; j < i; ++j)
    {
      byte[] arrayOfByte1 = arrayOfByte[j];
      localArrayList.add(arrayOfByte1);
    }
    localArrayList.add(Protocol.toByteArray(paramInt));
    blpop((byte[][])localArrayList.toArray(new byte[localArrayList.size()][]));
  }

  public void sort(byte[] paramArrayOfByte1, SortingParams paramSortingParams, byte[] paramArrayOfByte2)
  {
    ArrayList localArrayList = new ArrayList();
    localArrayList.add(paramArrayOfByte1);
    localArrayList.addAll(paramSortingParams.getParams());
    localArrayList.add(Protocol.Keyword.STORE.raw);
    localArrayList.add(paramArrayOfByte2);
    sendCommand(Protocol.Command.SORT, (byte[][])localArrayList.toArray(new byte[localArrayList.size()][]));
  }

  public void sort(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    sendCommand(Protocol.Command.SORT, new byte[][] { paramArrayOfByte1, Protocol.Keyword.STORE.raw, paramArrayOfByte2 });
  }

  public void brpop(byte[][] paramArrayOfByte)
  {
    sendCommand(Protocol.Command.BRPOP, paramArrayOfByte);
  }

  public void brpop(int paramInt, byte[][] paramArrayOfByte)
  {
    ArrayList localArrayList = new ArrayList();
    byte[][] arrayOfByte = paramArrayOfByte;
    int i = arrayOfByte.length;
    for (int j = 0; j < i; ++j)
    {
      byte[] arrayOfByte1 = arrayOfByte[j];
      localArrayList.add(arrayOfByte1);
    }
    localArrayList.add(Protocol.toByteArray(paramInt));
    brpop((byte[][])localArrayList.toArray(new byte[localArrayList.size()][]));
  }

  public void auth(java.lang.String paramString)
  {
    setPassword(paramString);
    sendCommand(Protocol.Command.AUTH, new java.lang.String[] { paramString });
  }

  public void subscribe(byte[][] paramArrayOfByte)
  {
    sendCommand(Protocol.Command.SUBSCRIBE, paramArrayOfByte);
  }

  public void publish(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    sendCommand(Protocol.Command.PUBLISH, new byte[][] { paramArrayOfByte1, paramArrayOfByte2 });
  }

  public void unsubscribe()
  {
    sendCommand(Protocol.Command.UNSUBSCRIBE);
  }

  public void unsubscribe(byte[][] paramArrayOfByte)
  {
    sendCommand(Protocol.Command.UNSUBSCRIBE, paramArrayOfByte);
  }

  public void psubscribe(byte[][] paramArrayOfByte)
  {
    sendCommand(Protocol.Command.PSUBSCRIBE, paramArrayOfByte);
  }

  public void punsubscribe()
  {
    sendCommand(Protocol.Command.PUNSUBSCRIBE);
  }

  public void punsubscribe(byte[][] paramArrayOfByte)
  {
    sendCommand(Protocol.Command.PUNSUBSCRIBE, paramArrayOfByte);
  }

  public void zcount(byte[] paramArrayOfByte, double paramDouble1, double paramDouble2)
  {
    byte[] arrayOfByte1 = (paramDouble1 == (-1.0D / 0.0D)) ? "-inf".getBytes() : Protocol.toByteArray(paramDouble1);
    byte[] arrayOfByte2 = (paramDouble2 == (1.0D / 0.0D)) ? "+inf".getBytes() : Protocol.toByteArray(paramDouble2);
    sendCommand(Protocol.Command.ZCOUNT, new byte[][] { paramArrayOfByte, arrayOfByte1, arrayOfByte2 });
  }

  public void zcount(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
  {
    sendCommand(Protocol.Command.ZCOUNT, new byte[][] { paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3 });
  }

  public void zcount(byte[] paramArrayOfByte, java.lang.String paramString1, java.lang.String paramString2)
  {
    sendCommand(Protocol.Command.ZCOUNT, new byte[][] { paramArrayOfByte, paramString1.getBytes(), paramString2.getBytes() });
  }

  public void zrangeByScore(byte[] paramArrayOfByte, double paramDouble1, double paramDouble2)
  {
    byte[] arrayOfByte1 = (paramDouble1 == (-1.0D / 0.0D)) ? "-inf".getBytes() : Protocol.toByteArray(paramDouble1);
    byte[] arrayOfByte2 = (paramDouble2 == (1.0D / 0.0D)) ? "+inf".getBytes() : Protocol.toByteArray(paramDouble2);
    sendCommand(Protocol.Command.ZRANGEBYSCORE, new byte[][] { paramArrayOfByte, arrayOfByte1, arrayOfByte2 });
  }

  public void zrangeByScore(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
  {
    sendCommand(Protocol.Command.ZRANGEBYSCORE, new byte[][] { paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3 });
  }

  public void zrangeByScore(byte[] paramArrayOfByte, java.lang.String paramString1, java.lang.String paramString2)
  {
    sendCommand(Protocol.Command.ZRANGEBYSCORE, new byte[][] { paramArrayOfByte, paramString1.getBytes(), paramString2.getBytes() });
  }

  public void zrevrangeByScore(byte[] paramArrayOfByte, double paramDouble1, double paramDouble2)
  {
    byte[] arrayOfByte1 = (paramDouble2 == (-1.0D / 0.0D)) ? "-inf".getBytes() : Protocol.toByteArray(paramDouble2);
    byte[] arrayOfByte2 = (paramDouble1 == (1.0D / 0.0D)) ? "+inf".getBytes() : Protocol.toByteArray(paramDouble1);
    sendCommand(Protocol.Command.ZREVRANGEBYSCORE, new byte[][] { paramArrayOfByte, arrayOfByte2, arrayOfByte1 });
  }

  public void zrevrangeByScore(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
  {
    sendCommand(Protocol.Command.ZREVRANGEBYSCORE, new byte[][] { paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3 });
  }

  public void zrevrangeByScore(byte[] paramArrayOfByte, java.lang.String paramString1, java.lang.String paramString2)
  {
    sendCommand(Protocol.Command.ZREVRANGEBYSCORE, new byte[][] { paramArrayOfByte, paramString1.getBytes(), paramString2.getBytes() });
  }

  public void zrangeByScore(byte[] paramArrayOfByte, double paramDouble1, double paramDouble2, int paramInt1, int paramInt2)
  {
    byte[] arrayOfByte1 = (paramDouble1 == (-1.0D / 0.0D)) ? "-inf".getBytes() : Protocol.toByteArray(paramDouble1);
    byte[] arrayOfByte2 = (paramDouble2 == (1.0D / 0.0D)) ? "+inf".getBytes() : Protocol.toByteArray(paramDouble2);
    sendCommand(Protocol.Command.ZRANGEBYSCORE, new byte[][] { paramArrayOfByte, arrayOfByte1, arrayOfByte2, Protocol.Keyword.LIMIT.raw, Protocol.toByteArray(paramInt1), Protocol.toByteArray(paramInt2) });
  }

  public void zrangeByScore(byte[] paramArrayOfByte, java.lang.String paramString1, java.lang.String paramString2, int paramInt1, int paramInt2)
  {
    sendCommand(Protocol.Command.ZRANGEBYSCORE, new byte[][] { paramArrayOfByte, paramString1.getBytes(), paramString2.getBytes(), Protocol.Keyword.LIMIT.raw, Protocol.toByteArray(paramInt1), Protocol.toByteArray(paramInt2) });
  }

  public void zrevrangeByScore(byte[] paramArrayOfByte, double paramDouble1, double paramDouble2, int paramInt1, int paramInt2)
  {
    byte[] arrayOfByte1 = (paramDouble2 == (-1.0D / 0.0D)) ? "-inf".getBytes() : Protocol.toByteArray(paramDouble2);
    byte[] arrayOfByte2 = (paramDouble1 == (1.0D / 0.0D)) ? "+inf".getBytes() : Protocol.toByteArray(paramDouble1);
    sendCommand(Protocol.Command.ZREVRANGEBYSCORE, new byte[][] { paramArrayOfByte, arrayOfByte2, arrayOfByte1, Protocol.Keyword.LIMIT.raw, Protocol.toByteArray(paramInt1), Protocol.toByteArray(paramInt2) });
  }

  public void zrevrangeByScore(byte[] paramArrayOfByte, java.lang.String paramString1, java.lang.String paramString2, int paramInt1, int paramInt2)
  {
    sendCommand(Protocol.Command.ZREVRANGEBYSCORE, new byte[][] { paramArrayOfByte, paramString1.getBytes(), paramString2.getBytes(), Protocol.Keyword.LIMIT.raw, Protocol.toByteArray(paramInt1), Protocol.toByteArray(paramInt2) });
  }

  public void zrangeByScoreWithScores(byte[] paramArrayOfByte, double paramDouble1, double paramDouble2)
  {
    byte[] arrayOfByte1 = (paramDouble1 == (-1.0D / 0.0D)) ? "-inf".getBytes() : Protocol.toByteArray(paramDouble1);
    byte[] arrayOfByte2 = (paramDouble2 == (1.0D / 0.0D)) ? "+inf".getBytes() : Protocol.toByteArray(paramDouble2);
    sendCommand(Protocol.Command.ZRANGEBYSCORE, new byte[][] { paramArrayOfByte, arrayOfByte1, arrayOfByte2, Protocol.Keyword.WITHSCORES.raw });
  }

  public void zrangeByScoreWithScores(byte[] paramArrayOfByte, java.lang.String paramString1, java.lang.String paramString2)
  {
    sendCommand(Protocol.Command.ZRANGEBYSCORE, new byte[][] { paramArrayOfByte, paramString1.getBytes(), paramString2.getBytes(), Protocol.Keyword.WITHSCORES.raw });
  }

  public void zrevrangeByScoreWithScores(byte[] paramArrayOfByte, double paramDouble1, double paramDouble2)
  {
    byte[] arrayOfByte1 = (paramDouble2 == (-1.0D / 0.0D)) ? "-inf".getBytes() : Protocol.toByteArray(paramDouble2);
    byte[] arrayOfByte2 = (paramDouble1 == (1.0D / 0.0D)) ? "+inf".getBytes() : Protocol.toByteArray(paramDouble1);
    sendCommand(Protocol.Command.ZREVRANGEBYSCORE, new byte[][] { paramArrayOfByte, arrayOfByte2, arrayOfByte1, Protocol.Keyword.WITHSCORES.raw });
  }

  public void zrevrangeByScoreWithScores(byte[] paramArrayOfByte, java.lang.String paramString1, java.lang.String paramString2)
  {
    sendCommand(Protocol.Command.ZREVRANGEBYSCORE, new byte[][] { paramArrayOfByte, paramString1.getBytes(), paramString2.getBytes(), Protocol.Keyword.WITHSCORES.raw });
  }

  public void zrangeByScoreWithScores(byte[] paramArrayOfByte, double paramDouble1, double paramDouble2, int paramInt1, int paramInt2)
  {
    byte[] arrayOfByte1 = (paramDouble1 == (-1.0D / 0.0D)) ? "-inf".getBytes() : Protocol.toByteArray(paramDouble1);
    byte[] arrayOfByte2 = (paramDouble2 == (1.0D / 0.0D)) ? "+inf".getBytes() : Protocol.toByteArray(paramDouble2);
    sendCommand(Protocol.Command.ZRANGEBYSCORE, new byte[][] { paramArrayOfByte, arrayOfByte1, arrayOfByte2, Protocol.Keyword.LIMIT.raw, Protocol.toByteArray(paramInt1), Protocol.toByteArray(paramInt2), Protocol.Keyword.WITHSCORES.raw });
  }

  public void zrangeByScoreWithScores(byte[] paramArrayOfByte, java.lang.String paramString1, java.lang.String paramString2, int paramInt1, int paramInt2)
  {
    sendCommand(Protocol.Command.ZRANGEBYSCORE, new byte[][] { paramArrayOfByte, paramString1.getBytes(), paramString2.getBytes(), Protocol.Keyword.LIMIT.raw, Protocol.toByteArray(paramInt1), Protocol.toByteArray(paramInt2), Protocol.Keyword.WITHSCORES.raw });
  }

  public void zrevrangeByScoreWithScores(byte[] paramArrayOfByte, double paramDouble1, double paramDouble2, int paramInt1, int paramInt2)
  {
    byte[] arrayOfByte1 = (paramDouble2 == (-1.0D / 0.0D)) ? "-inf".getBytes() : Protocol.toByteArray(paramDouble2);
    byte[] arrayOfByte2 = (paramDouble1 == (1.0D / 0.0D)) ? "+inf".getBytes() : Protocol.toByteArray(paramDouble1);
    sendCommand(Protocol.Command.ZREVRANGEBYSCORE, new byte[][] { paramArrayOfByte, arrayOfByte2, arrayOfByte1, Protocol.Keyword.LIMIT.raw, Protocol.toByteArray(paramInt1), Protocol.toByteArray(paramInt2), Protocol.Keyword.WITHSCORES.raw });
  }

  public void zrevrangeByScoreWithScores(byte[] paramArrayOfByte, java.lang.String paramString1, java.lang.String paramString2, int paramInt1, int paramInt2)
  {
    sendCommand(Protocol.Command.ZREVRANGEBYSCORE, new byte[][] { paramArrayOfByte, paramString1.getBytes(), paramString2.getBytes(), Protocol.Keyword.LIMIT.raw, Protocol.toByteArray(paramInt1), Protocol.toByteArray(paramInt2), Protocol.Keyword.WITHSCORES.raw });
  }

  public void zrangeByScore(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3, int paramInt1, int paramInt2)
  {
    sendCommand(Protocol.Command.ZRANGEBYSCORE, new byte[][] { paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3, Protocol.Keyword.LIMIT.raw, Protocol.toByteArray(paramInt1), Protocol.toByteArray(paramInt2) });
  }

  public void zrevrangeByScore(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3, int paramInt1, int paramInt2)
  {
    sendCommand(Protocol.Command.ZREVRANGEBYSCORE, new byte[][] { paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3, Protocol.Keyword.LIMIT.raw, Protocol.toByteArray(paramInt1), Protocol.toByteArray(paramInt2) });
  }

  public void zrangeByScoreWithScores(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
  {
    sendCommand(Protocol.Command.ZRANGEBYSCORE, new byte[][] { paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3, Protocol.Keyword.WITHSCORES.raw });
  }

  public void zrevrangeByScoreWithScores(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
  {
    sendCommand(Protocol.Command.ZREVRANGEBYSCORE, new byte[][] { paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3, Protocol.Keyword.WITHSCORES.raw });
  }

  public void zrangeByScoreWithScores(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3, int paramInt1, int paramInt2)
  {
    sendCommand(Protocol.Command.ZRANGEBYSCORE, new byte[][] { paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3, Protocol.Keyword.LIMIT.raw, Protocol.toByteArray(paramInt1), Protocol.toByteArray(paramInt2), Protocol.Keyword.WITHSCORES.raw });
  }

  public void zrevrangeByScoreWithScores(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3, int paramInt1, int paramInt2)
  {
    sendCommand(Protocol.Command.ZREVRANGEBYSCORE, new byte[][] { paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3, Protocol.Keyword.LIMIT.raw, Protocol.toByteArray(paramInt1), Protocol.toByteArray(paramInt2), Protocol.Keyword.WITHSCORES.raw });
  }

  public void zremrangeByRank(byte[] paramArrayOfByte, long paramLong1, long paramLong2)
  {
    sendCommand(Protocol.Command.ZREMRANGEBYRANK, new byte[][] { paramArrayOfByte, Protocol.toByteArray(paramLong1), Protocol.toByteArray(paramLong2) });
  }

  public void zremrangeByScore(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
  {
    sendCommand(Protocol.Command.ZREMRANGEBYSCORE, new byte[][] { paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3 });
  }

  public void zremrangeByScore(byte[] paramArrayOfByte, java.lang.String paramString1, java.lang.String paramString2)
  {
    sendCommand(Protocol.Command.ZREMRANGEBYSCORE, new byte[][] { paramArrayOfByte, paramString1.getBytes(), paramString2.getBytes() });
  }

  public void zunionstore(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1)
  {
    [B[] arrayOf[B = new byte[paramArrayOfByte1.length + 2][];
    arrayOf[B[0] = paramArrayOfByte;
    arrayOf[B[1] = Protocol.toByteArray(paramArrayOfByte1.length);
    System.arraycopy(paramArrayOfByte1, 0, arrayOf[B, 2, paramArrayOfByte1.length);
    sendCommand(Protocol.Command.ZUNIONSTORE, arrayOf[B);
  }

  public void zunionstore(byte[] paramArrayOfByte, ZParams paramZParams, byte[][] paramArrayOfByte1)
  {
    ArrayList localArrayList = new ArrayList();
    localArrayList.add(paramArrayOfByte);
    localArrayList.add(Protocol.toByteArray(paramArrayOfByte1.length));
    byte[][] arrayOfByte = paramArrayOfByte1;
    int i = arrayOfByte.length;
    for (int j = 0; j < i; ++j)
    {
      byte[] arrayOfByte1 = arrayOfByte[j];
      localArrayList.add(arrayOfByte1);
    }
    localArrayList.addAll(paramZParams.getParams());
    sendCommand(Protocol.Command.ZUNIONSTORE, (byte[][])localArrayList.toArray(new byte[localArrayList.size()][]));
  }

  public void zinterstore(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1)
  {
    [B[] arrayOf[B = new byte[paramArrayOfByte1.length + 2][];
    arrayOf[B[0] = paramArrayOfByte;
    arrayOf[B[1] = Protocol.toByteArray(paramArrayOfByte1.length);
    System.arraycopy(paramArrayOfByte1, 0, arrayOf[B, 2, paramArrayOfByte1.length);
    sendCommand(Protocol.Command.ZINTERSTORE, arrayOf[B);
  }

  public void zinterstore(byte[] paramArrayOfByte, ZParams paramZParams, byte[][] paramArrayOfByte1)
  {
    ArrayList localArrayList = new ArrayList();
    localArrayList.add(paramArrayOfByte);
    localArrayList.add(Protocol.toByteArray(paramArrayOfByte1.length));
    byte[][] arrayOfByte = paramArrayOfByte1;
    int i = arrayOfByte.length;
    for (int j = 0; j < i; ++j)
    {
      byte[] arrayOfByte1 = arrayOfByte[j];
      localArrayList.add(arrayOfByte1);
    }
    localArrayList.addAll(paramZParams.getParams());
    sendCommand(Protocol.Command.ZINTERSTORE, (byte[][])localArrayList.toArray(new byte[localArrayList.size()][]));
  }

  public void save()
  {
    sendCommand(Protocol.Command.SAVE);
  }

  public void bgsave()
  {
    sendCommand(Protocol.Command.BGSAVE);
  }

  public void bgrewriteaof()
  {
    sendCommand(Protocol.Command.BGREWRITEAOF);
  }

  public void lastsave()
  {
    sendCommand(Protocol.Command.LASTSAVE);
  }

  public void shutdown()
  {
    sendCommand(Protocol.Command.SHUTDOWN);
  }

  public void info()
  {
    sendCommand(Protocol.Command.INFO);
  }

  public void info(java.lang.String paramString)
  {
    sendCommand(Protocol.Command.INFO, new java.lang.String[] { paramString });
  }

  public void monitor()
  {
    sendCommand(Protocol.Command.MONITOR);
  }

  public void slaveof(java.lang.String paramString, int paramInt)
  {
    sendCommand(Protocol.Command.SLAVEOF, new java.lang.String[] { paramString, java.lang.String.valueOf(paramInt) });
  }

  public void slaveofNoOne()
  {
    sendCommand(Protocol.Command.SLAVEOF, new byte[][] { Protocol.Keyword.NO.raw, Protocol.Keyword.ONE.raw });
  }

  public void configGet(byte[] paramArrayOfByte)
  {
    sendCommand(Protocol.Command.CONFIG, new byte[][] { Protocol.Keyword.GET.raw, paramArrayOfByte });
  }

  public void configSet(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    sendCommand(Protocol.Command.CONFIG, new byte[][] { Protocol.Keyword.SET.raw, paramArrayOfByte1, paramArrayOfByte2 });
  }

  public void strlen(byte[] paramArrayOfByte)
  {
    sendCommand(Protocol.Command.STRLEN, new byte[][] { paramArrayOfByte });
  }

  public void sync()
  {
    sendCommand(Protocol.Command.SYNC);
  }

  public void lpushx(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1)
  {
    sendCommand(Protocol.Command.LPUSHX, joinParameters(paramArrayOfByte, paramArrayOfByte1));
  }

  public void persist(byte[] paramArrayOfByte)
  {
    sendCommand(Protocol.Command.PERSIST, new byte[][] { paramArrayOfByte });
  }

  public void rpushx(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1)
  {
    sendCommand(Protocol.Command.RPUSHX, joinParameters(paramArrayOfByte, paramArrayOfByte1));
  }

  public void echo(byte[] paramArrayOfByte)
  {
    sendCommand(Protocol.Command.ECHO, new byte[][] { paramArrayOfByte });
  }

  public void linsert(byte[] paramArrayOfByte1, LIST_POSITION paramLIST_POSITION, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
  {
    sendCommand(Protocol.Command.LINSERT, new byte[][] { paramArrayOfByte1, paramLIST_POSITION.raw, paramArrayOfByte2, paramArrayOfByte3 });
  }

  public void debug(DebugParams paramDebugParams)
  {
    sendCommand(Protocol.Command.DEBUG, paramDebugParams.getCommand());
  }

  public void brpoplpush(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, int paramInt)
  {
    sendCommand(Protocol.Command.BRPOPLPUSH, new byte[][] { paramArrayOfByte1, paramArrayOfByte2, Protocol.toByteArray(paramInt) });
  }

  public void configResetStat()
  {
    sendCommand(Protocol.Command.CONFIG, new java.lang.String[] { Protocol.Keyword.RESETSTAT.name() });
  }

  public void setbit(byte[] paramArrayOfByte1, long paramLong, byte[] paramArrayOfByte2)
  {
    sendCommand(Protocol.Command.SETBIT, new byte[][] { paramArrayOfByte1, Protocol.toByteArray(paramLong), paramArrayOfByte2 });
  }

  public void setbit(byte[] paramArrayOfByte, long paramLong, boolean paramBoolean)
  {
    sendCommand(Protocol.Command.SETBIT, new byte[][] { paramArrayOfByte, Protocol.toByteArray(paramLong), Protocol.toByteArray(paramBoolean) });
  }

  public void getbit(byte[] paramArrayOfByte, long paramLong)
  {
    sendCommand(Protocol.Command.GETBIT, new byte[][] { paramArrayOfByte, Protocol.toByteArray(paramLong) });
  }

  public void setrange(byte[] paramArrayOfByte1, long paramLong, byte[] paramArrayOfByte2)
  {
    sendCommand(Protocol.Command.SETRANGE, new byte[][] { paramArrayOfByte1, Protocol.toByteArray(paramLong), paramArrayOfByte2 });
  }

  public void getrange(byte[] paramArrayOfByte, long paramLong1, long paramLong2)
  {
    sendCommand(Protocol.Command.GETRANGE, new byte[][] { paramArrayOfByte, Protocol.toByteArray(paramLong1), Protocol.toByteArray(paramLong2) });
  }

  public Long getDB()
  {
    return Long.valueOf(this.db);
  }

  public void disconnect()
  {
    this.db = -6318802138378010624L;
    super.disconnect();
  }

  private void sendEvalCommand(Protocol.Command paramCommand, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[][] paramArrayOfByte)
  {
    [B[] arrayOf[B = new byte[paramArrayOfByte.length + 2][];
    arrayOf[B[0] = paramArrayOfByte1;
    arrayOf[B[1] = paramArrayOfByte2;
    for (int i = 0; i < paramArrayOfByte.length; ++i)
      arrayOf[B[(i + 2)] = paramArrayOfByte[i];
    sendCommand(paramCommand, arrayOf[B);
  }

  public void eval(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[][] paramArrayOfByte)
  {
    sendEvalCommand(Protocol.Command.EVAL, paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte);
  }

  public void eval(byte[] paramArrayOfByte, int paramInt, byte[][] paramArrayOfByte1)
  {
    eval(paramArrayOfByte, Protocol.toByteArray(paramInt), paramArrayOfByte1);
  }

  public void evalsha(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[][] paramArrayOfByte)
  {
    sendEvalCommand(Protocol.Command.EVALSHA, paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte);
  }

  public void evalsha(byte[] paramArrayOfByte, int paramInt, byte[][] paramArrayOfByte1)
  {
    sendEvalCommand(Protocol.Command.EVALSHA, paramArrayOfByte, Protocol.toByteArray(paramInt), paramArrayOfByte1);
  }

  public void scriptFlush()
  {
    sendCommand(Protocol.Command.SCRIPT, new byte[][] { Protocol.Keyword.FLUSH.raw });
  }

  public void scriptExists(byte[][] paramArrayOfByte)
  {
    [B[] arrayOf[B = new byte[paramArrayOfByte.length + 1][];
    arrayOf[B[0] = Protocol.Keyword.EXISTS.raw;
    for (int i = 0; i < paramArrayOfByte.length; ++i)
      arrayOf[B[(i + 1)] = paramArrayOfByte[i];
    sendCommand(Protocol.Command.SCRIPT, arrayOf[B);
  }

  public void scriptLoad(byte[] paramArrayOfByte)
  {
    sendCommand(Protocol.Command.SCRIPT, new byte[][] { Protocol.Keyword.LOAD.raw, paramArrayOfByte });
  }

  public void scriptKill()
  {
    sendCommand(Protocol.Command.SCRIPT, new byte[][] { Protocol.Keyword.KILL.raw });
  }

  public void slowlogGet()
  {
    sendCommand(Protocol.Command.SLOWLOG, new byte[][] { Protocol.Keyword.GET.raw });
  }

  public void slowlogGet(long paramLong)
  {
    sendCommand(Protocol.Command.SLOWLOG, new byte[][] { Protocol.Keyword.GET.raw, Protocol.toByteArray(paramLong) });
  }

  public void slowlogReset()
  {
    sendCommand(Protocol.Command.SLOWLOG, new byte[][] { Protocol.Keyword.RESET.raw });
  }

  public void slowlogLen()
  {
    sendCommand(Protocol.Command.SLOWLOG, new byte[][] { Protocol.Keyword.LEN.raw });
  }

  public void objectRefcount(byte[] paramArrayOfByte)
  {
    sendCommand(Protocol.Command.OBJECT, new byte[][] { Protocol.Keyword.REFCOUNT.raw, paramArrayOfByte });
  }

  public void objectIdletime(byte[] paramArrayOfByte)
  {
    sendCommand(Protocol.Command.OBJECT, new byte[][] { Protocol.Keyword.IDLETIME.raw, paramArrayOfByte });
  }

  public void objectEncoding(byte[] paramArrayOfByte)
  {
    sendCommand(Protocol.Command.OBJECT, new byte[][] { Protocol.Keyword.ENCODING.raw, paramArrayOfByte });
  }

  public void bitcount(byte[] paramArrayOfByte)
  {
    sendCommand(Protocol.Command.BITCOUNT, new byte[][] { paramArrayOfByte });
  }

  public void bitcount(byte[] paramArrayOfByte, long paramLong1, long paramLong2)
  {
    sendCommand(Protocol.Command.BITCOUNT, new byte[][] { paramArrayOfByte, Protocol.toByteArray(paramLong1), Protocol.toByteArray(paramLong2) });
  }

  public void bitop(BitOP paramBitOP, byte[] paramArrayOfByte, byte[][] paramArrayOfByte1)
  {
    Protocol.Keyword localKeyword = Protocol.Keyword.AND;
    int i = paramArrayOfByte1.length;
    switch (1.$SwitchMap$com$ycache$redis$clients$jedis$BitOP[paramBitOP.ordinal()])
    {
    case 1:
      localKeyword = Protocol.Keyword.AND;
      break;
    case 2:
      localKeyword = Protocol.Keyword.OR;
      break;
    case 3:
      localKeyword = Protocol.Keyword.XOR;
      break;
    case 4:
      localKeyword = Protocol.Keyword.NOT;
      i = Math.min(1, i);
    }
    [B[] arrayOf[B = new byte[i + 2][];
    arrayOf[B[0] = localKeyword.raw;
    arrayOf[B[1] = paramArrayOfByte;
    for (int j = 0; j < i; ++j)
      arrayOf[B[(j + 2)] = paramArrayOfByte1[j];
    sendCommand(Protocol.Command.BITOP, arrayOf[B);
  }

  public void sentinel(byte[][] paramArrayOfByte)
  {
    sendCommand(Protocol.Command.SENTINEL, paramArrayOfByte);
  }

  public void dump(byte[] paramArrayOfByte)
  {
    sendCommand(Protocol.Command.DUMP, new byte[][] { paramArrayOfByte });
  }

  public void restore(byte[] paramArrayOfByte1, int paramInt, byte[] paramArrayOfByte2)
  {
    sendCommand(Protocol.Command.RESTORE, new byte[][] { paramArrayOfByte1, Protocol.toByteArray(paramInt), paramArrayOfByte2 });
  }

  public void pexpire(byte[] paramArrayOfByte, int paramInt)
  {
    sendCommand(Protocol.Command.PEXPIRE, new byte[][] { paramArrayOfByte, Protocol.toByteArray(paramInt) });
  }

  public void pexpireAt(byte[] paramArrayOfByte, long paramLong)
  {
    sendCommand(Protocol.Command.PEXPIREAT, new byte[][] { paramArrayOfByte, Protocol.toByteArray(paramLong) });
  }

  public void pttl(byte[] paramArrayOfByte)
  {
    sendCommand(Protocol.Command.PTTL, new byte[][] { paramArrayOfByte });
  }

  public void incrByFloat(byte[] paramArrayOfByte, double paramDouble)
  {
    sendCommand(Protocol.Command.INCRBYFLOAT, new byte[][] { paramArrayOfByte, Protocol.toByteArray(paramDouble) });
  }

  public void psetex(byte[] paramArrayOfByte1, int paramInt, byte[] paramArrayOfByte2)
  {
    sendCommand(Protocol.Command.PSETEX, new byte[][] { paramArrayOfByte1, Protocol.toByteArray(paramInt), paramArrayOfByte2 });
  }

  public void set(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
  {
    sendCommand(Protocol.Command.SET, new byte[][] { paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3 });
  }

  public void set(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3, byte[] paramArrayOfByte4, int paramInt)
  {
    sendCommand(Protocol.Command.SET, new byte[][] { paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3, paramArrayOfByte4, Protocol.toByteArray(paramInt) });
  }

  public void srandmember(byte[] paramArrayOfByte, int paramInt)
  {
    sendCommand(Protocol.Command.SRANDMEMBER, new byte[][] { paramArrayOfByte, Protocol.toByteArray(paramInt) });
  }

  public void clientKill(byte[] paramArrayOfByte)
  {
    sendCommand(Protocol.Command.CLIENT, new byte[][] { Protocol.Keyword.KILL.raw, paramArrayOfByte });
  }

  public void clientGetname()
  {
    sendCommand(Protocol.Command.CLIENT, new byte[][] { Protocol.Keyword.GETNAME.raw });
  }

  public void clientList()
  {
    sendCommand(Protocol.Command.CLIENT, new byte[][] { Protocol.Keyword.LIST.raw });
  }

  public void clientSetname(byte[] paramArrayOfByte)
  {
    sendCommand(Protocol.Command.CLIENT, new byte[][] { Protocol.Keyword.SETNAME.raw, paramArrayOfByte });
  }

  public void time()
  {
    sendCommand(Protocol.Command.TIME);
  }

  public void migrate(byte[] paramArrayOfByte1, int paramInt1, byte[] paramArrayOfByte2, int paramInt2, int paramInt3)
  {
    sendCommand(Protocol.Command.MIGRATE, new byte[][] { paramArrayOfByte1, Protocol.toByteArray(paramInt1), paramArrayOfByte2, Protocol.toByteArray(paramInt2), Protocol.toByteArray(paramInt3) });
  }

  public void hincrByFloat(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, double paramDouble)
  {
    sendCommand(Protocol.Command.HINCRBYFLOAT, new byte[][] { paramArrayOfByte1, paramArrayOfByte2, Protocol.toByteArray(paramDouble) });
  }

  public static enum LIST_POSITION
  {
    BEFORE, AFTER;

    public final byte[] raw = SafeEncoder.encode(name());
  }
}