package com.ycache.redis.clients.jedis;

import com.ycache.redis.clients.jedis.exceptions.JedisDataException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Pipeline extends MultiKeyPipelineBase
{
  private MultiResponseBuilder currentMulti;

  protected <T> Response<T> getResponse(Builder<T> paramBuilder)
  {
    if (this.currentMulti != null)
    {
      super.getResponse(BuilderFactory.STRING);
      Response localResponse = new Response(paramBuilder);
      this.currentMulti.addResponse(localResponse);
      return localResponse;
    }
    return super.getResponse(paramBuilder);
  }

  public void setClient(Client paramClient)
  {
    this.client = paramClient;
  }

  protected Client getClient(byte[] paramArrayOfByte)
  {
    return this.client;
  }

  protected Client getClient(String paramString)
  {
    return this.client;
  }

  public void sync()
  {
    List localList = this.client.getAll();
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      Object localObject = localIterator.next();
      generateResponse(localObject);
    }
  }

  public List<Object> syncAndReturnAll()
  {
    List localList = this.client.getAll();
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      Object localObject = localIterator.next();
      try
      {
        localArrayList.add(generateResponse(localObject).get());
      }
      catch (JedisDataException localJedisDataException)
      {
        localArrayList.add(localJedisDataException);
      }
    }
    return localArrayList;
  }

  public Response<String> discard()
  {
    this.client.discard();
    this.currentMulti = null;
    return getResponse(BuilderFactory.STRING);
  }

  public Response<List<Object>> exec()
  {
    this.client.exec();
    Response localResponse = super.getResponse(this.currentMulti);
    this.currentMulti = null;
    return localResponse;
  }

  public Response<String> multi()
  {
    this.client.multi();
    Response localResponse = getResponse(BuilderFactory.STRING);
    this.currentMulti = new MultiResponseBuilder(this, null);
    return localResponse;
  }

  private class MultiResponseBuilder extends Builder<List<Object>>
  {
    private List<Response<?>> responses = new ArrayList();

    public List<Object> build()
    {
      List localList = (List)paramObject;
      ArrayList localArrayList = new ArrayList();
      if (localList.size() != this.responses.size())
        throw new JedisDataException("Expected data size " + this.responses.size() + " but was " + localList.size());
      for (int i = 0; i < localList.size(); ++i)
      {
        Response localResponse = (Response)this.responses.get(i);
        localResponse.set(localList.get(i));
        localArrayList.add(localResponse.get());
      }
      return localArrayList;
    }

    public void addResponse()
    {
      this.responses.add(paramResponse);
    }
  }
}