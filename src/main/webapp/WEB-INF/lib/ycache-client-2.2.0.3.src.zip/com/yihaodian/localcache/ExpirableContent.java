package com.yihaodian.localcache;

import java.util.Date;

public class ExpirableContent
{
  private Object content;
  private Date expireDate;
  public static final long MAX_EXPIRED_DAYS = 2592000L;

  public ExpirableContent()
  {
    this.expireDate = new Date(-6318801365283897344L);
  }

  public ExpirableContent(Object paramObject, Date paramDate)
  {
    this.content = paramObject;
    this.expireDate = paramDate;
  }

  public boolean isExpired()
  {
    int i = 0;
    if ((this.expireDate != null) && (this.expireDate.compareTo(new Date(-6318800386031353856L)) != 0) && (this.expireDate.before(new Date())))
      i = 1;
    return i;
  }

  public Object getContent()
  {
    return this.content;
  }

  public void setContent(Object paramObject)
  {
    this.content = paramObject;
  }

  public Date getExpireDate()
  {
    return this.expireDate;
  }

  public void setExpireDate(Date paramDate)
  {
    this.expireDate = paramDate;
  }
}