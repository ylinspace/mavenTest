package com.yihaodian.common.idc;

import com.yihaodian.common.ycache.memcache.MemcacheInterceptor;
import com.yihaodian.common.ycache.util.YMemcachedProxyUtil;
import com.yihaodian.configcentre.client.utils.YccGlobalPropertyConfigurer;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class IDCSyncInterceptorMemcacheProxy extends IDCInterceptorMemcacheProxy
{
  protected Log logger = LogFactory.getLog(getClass());
  private String masterPoolName;
  private String masterIDC = null;
  private int syncTime;
  private static String localIDC = null;

  public IDCSyncInterceptorMemcacheProxy(String paramString, MemcacheInterceptor paramMemcacheInterceptor)
  {
    super(paramString, paramMemcacheInterceptor);
  }

  public IDCSyncInterceptorMemcacheProxy(String paramString1, MemcacheInterceptor paramMemcacheInterceptor, String paramString2, int paramInt)
  {
    super(paramString1, paramMemcacheInterceptor);
    this.masterPoolName = YMemcachedProxyUtil.generateMasterPoolName(paramString1, paramString2);
    this.masterIDC = paramString2;
    this.syncTime = ((paramInt == 0) ? 10 : paramInt);
    if (localIDC == null)
      localIDC = parseLocalIDC();
    this.logger.info("masterIDC >> " + this.masterIDC);
    this.logger.info("localIDC >> " + localIDC);
    this.logger.info("syncTIme >> " + this.syncTime);
  }

  public boolean put(String paramString, Object paramObject)
  {
    boolean bool1 = super.put(paramString, paramObject);
    if (!(localIDC.equals(this.masterIDC)))
    {
      boolean bool2 = getHeadInterceptor().handlePut(this.masterPoolName, paramString, paramObject);
      return ((bool1) || (bool2));
    }
    return bool1;
  }

  public boolean put(String paramString, Object paramObject, int paramInt)
  {
    boolean bool1 = super.put(paramString, paramObject, paramInt);
    if (!(localIDC.equals(this.masterIDC)))
    {
      boolean bool2 = getHeadInterceptor().handlePut(this.masterPoolName, paramString, paramObject, paramInt);
      return ((bool1) || (bool2));
    }
    return bool1;
  }

  public boolean putString(String paramString1, String paramString2)
  {
    return put(paramString1, paramString2);
  }

  public boolean putString(String paramString1, String paramString2, int paramInt)
  {
    return put(paramString1, paramString2, paramInt);
  }

  public Object get(String paramString)
  {
    Object localObject = super.get(paramString);
    if ((!(localIDC.equals(this.masterIDC))) && (localObject == null))
    {
      localObject = getHeadInterceptor().handleGet(this.masterPoolName, paramString);
      if (localObject != null)
        super.put(paramString, localObject, this.syncTime);
    }
    return localObject;
  }

  private String parseLocalIDC()
  {
    String str1 = YccGlobalPropertyConfigurer.getMainGroupId();
    String str2 = YccGlobalPropertyConfigurer.getMainPoolId();
    if ((StringUtils.isNotBlank(str2)) && (StringUtils.isNotBlank(str1)))
    {
      if (str2.indexOf("/") != -1)
        str2 = str2.replaceAll("\\/", "_");
      String str3 = str1.substring(str1.indexOf(str2) + str2.length());
      if ("".equals(str3))
        return "nh";
      return str3.substring(1);
    }
    return "nh";
  }
}