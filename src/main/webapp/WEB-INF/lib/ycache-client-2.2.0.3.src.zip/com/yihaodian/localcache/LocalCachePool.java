package com.yihaodian.localcache;

import com.opensymphony.oscache.base.Config;
import com.opensymphony.oscache.general.GeneralCacheAdministrator;
import java.util.Properties;
import org.apache.log4j.Logger;

public class LocalCachePool
{
  public static Logger LOG = Logger.getLogger(LocalCacheClient.class);
  private static final String PROPERTIES_FILENAME = "/oscache.properties";
  private static final int DEF_CAPACITY = 100;
  private static GeneralCacheAdministrator cache = null;
  private static LocalCachePool localCachePool;
  private static Object lock = new Object();

  private LocalCachePool()
  {
    init();
  }

  public GeneralCacheAdministrator getCache()
  {
    return cache;
  }

  public static LocalCachePool getLocalCache()
  {
    synchronized (lock)
    {
      if (localCachePool == null)
        localCachePool = new LocalCachePool();
    }
    return localCachePool;
  }

  public void init()
  {
    if (cache == null)
    {
      LOG.debug("initing OSCache...");
      Properties localProperties = Config.loadProperties("/oscache.properties", super.getClass().getName());
      if (localProperties.isEmpty())
      {
        cache = new GeneralCacheAdministrator();
        cache.setOverflowPersistence(false);
        cache.setCacheCapacity(100);
      }
      else
      {
        cache = new GeneralCacheAdministrator(localProperties);
      }
      LOG.debug("OSCache inited.");
    }
    else
    {
      LOG.warn("Tried to init OSCache, which is already running.");
    }
  }
}