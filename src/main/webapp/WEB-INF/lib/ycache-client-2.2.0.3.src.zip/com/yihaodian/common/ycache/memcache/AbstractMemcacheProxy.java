package com.yihaodian.common.ycache.memcache;

import com.ycache.danga.MemCached.MemCachedClient;
import com.yihaodian.common.ycache.CacheProxy;
import com.yihaodian.common.ycache.memcache.conf.MemcachePoolConfig;
import com.yihaodian.common.ycache.util.CurrentVersionUtil;
import com.yihaodian.common.ycache.util.MD5Support;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public abstract class AbstractMemcacheProxy
  implements CacheProxy
{
  protected static Log logger = LogFactory.getLog(AbstractMemcacheProxy.class);
  protected MemCachedClient client;
  protected MemcachePoolConfig poolConfig;

  public AbstractMemcacheProxy(MemcachePoolConfig paramMemcachePoolConfig)
  {
    this.client = new MemCachedClient(paramMemcachePoolConfig.getPoolName());
    this.client.setCompressEnable(paramMemcachePoolConfig.isCompressEnable());
    this.client.setJDK(paramMemcachePoolConfig.isJDK());
    this.client.setCompressThreshold(paramMemcachePoolConfig.getCompressThreshold());
    this.client.setSendEmailInterval(paramMemcachePoolConfig.getSendEmailInterval());
    this.poolConfig = paramMemcachePoolConfig;
  }

  public String getGoodKey(String paramString)
  {
    int i = 0;
    StringBuffer localStringBuffer = new StringBuffer(paramString);
    String str1 = "";
    String str2 = null;
    try
    {
      if (this.poolConfig == null)
      {
        str2 = CurrentVersionUtil.getCurrentVersion();
        logger.error("poolConfig is null! please check the memcached config xml in your configcenter. ");
      }
      else if (!(this.poolConfig.isVersionEnable()))
      {
        str2 = "0";
      }
      else if (this.poolConfig.getPoolVersion() != null)
      {
        str2 = this.poolConfig.getPoolVersion();
      }
      else
      {
        str2 = CurrentVersionUtil.getCurrentVersion();
      }
      if (StringUtils.isNotEmpty(str2))
        paramString = localStringBuffer.append("_").append(str2).toString();
      str1 = URLEncoder.encode(paramString, "UTF-8");
    }
    catch (Exception localException1)
    {
      try
      {
        str1 = URLEncoder.encode(paramString, "UTF-8");
      }
      catch (UnsupportedEncodingException localUnsupportedEncodingException)
      {
        str1 = paramString;
        logger.error("old key can't covent to utf-8 || " + localUnsupportedEncodingException.getMessage());
      }
    }
    try
    {
      i = str1.length();
      if ((i > 240) || (paramString.indexOf(" ") > -1))
      {
        logger.debug("this key is too long or have space :" + paramString + "||  MD5 to 32 bit length!!");
        String str3 = null;
        if (str1.length() >= 48)
          str3 = str1.substring(0, 48);
        else
          str3 = str1;
        return str3 + "_" + MD5Support.MD5(paramString) + "_" + str2;
      }
      return paramString;
    }
    catch (Exception localException2)
    {
      logger.error(localException2);
    }
    return paramString;
  }

  protected String getGoodKeyWithCurrentVersion(String paramString1, String paramString2)
  {
    int i = 0;
    StringBuffer localStringBuffer = new StringBuffer(paramString1);
    String str1 = "";
    try
    {
      if (StringUtils.isNotEmpty(paramString2))
        paramString1 = localStringBuffer.append("_").append(paramString2).toString();
      str1 = URLEncoder.encode(paramString1, "UTF-8");
    }
    catch (Exception localException1)
    {
      try
      {
        str1 = URLEncoder.encode(paramString1, "UTF-8");
      }
      catch (UnsupportedEncodingException localUnsupportedEncodingException)
      {
        str1 = paramString1;
        logger.error("old key can't covent to utf-8 || " + localUnsupportedEncodingException.getMessage());
      }
    }
    try
    {
      i = str1.length();
      if ((i > 240) || (paramString1.indexOf(" ") > -1))
      {
        logger.debug("this key is too long or have space :" + paramString1 + "||  MD5 to 32 bit length!!");
        String str2 = null;
        if (str1.length() >= 48)
          str2 = str1.substring(0, 48);
        else
          str2 = str1;
        return str2 + "_" + MD5Support.MD5(paramString1) + "_" + CurrentVersionUtil.getCurrentVersion();
      }
      return paramString1;
    }
    catch (Exception localException2)
    {
      logger.error(localException2);
    }
    return paramString1;
  }

  public MemcachePoolConfig getPoolConfig()
  {
    return this.poolConfig;
  }
}