package com.yihaodian.common.ycache.memcache.impl;

import com.yihaodian.common.ycache.CacheProxy;
import com.yihaodian.common.ycache.memcache.MemcacheInterceptor;
import java.util.Date;
import java.util.Map;

public class InterceptorMemcacheProxy
  implements CacheProxy
{
  private MemcacheInterceptor headInterceptor;
  protected String poolName;

  public InterceptorMemcacheProxy(String paramString, MemcacheInterceptor paramMemcacheInterceptor)
  {
    this.poolName = paramString;
    this.headInterceptor = paramMemcacheInterceptor;
  }

  public Object get(String paramString)
  {
    return this.headInterceptor.handleGet(this.poolName, paramString);
  }

  public Object get(String paramString1, String paramString2)
  {
    return this.headInterceptor.handleGet(this.poolName, paramString1, paramString2);
  }

  public String getString(String paramString)
  {
    return ((String)this.headInterceptor.handleGet(this.poolName, paramString));
  }

  public String getString(String paramString1, String paramString2)
  {
    return ((String)this.headInterceptor.handleGet(this.poolName, paramString1, paramString2));
  }

  public Map<String, Object> getMulti(String[] paramArrayOfString)
  {
    return this.headInterceptor.handleGetMulti(this.poolName, paramArrayOfString);
  }

  public boolean put(String paramString, Object paramObject)
  {
    return this.headInterceptor.handlePut(this.poolName, paramString, paramObject);
  }

  public boolean put(String paramString, Object paramObject, int paramInt)
  {
    return this.headInterceptor.handlePut(this.poolName, paramString, paramObject, paramInt);
  }

  public boolean put(String paramString, Object paramObject, Date paramDate)
  {
    return this.headInterceptor.handlePut(this.poolName, paramString, paramObject, paramDate);
  }

  public boolean putWithSecond(String paramString, Object paramObject, long paramLong)
  {
    return this.headInterceptor.handlePut(this.poolName, paramString, paramObject, paramLong);
  }

  public boolean remove(String paramString)
  {
    return this.headInterceptor.handleRemove(this.poolName, paramString);
  }

  public boolean remove(String paramString1, String paramString2)
  {
    return this.headInterceptor.handleRemove(this.poolName, paramString1, paramString2);
  }

  public boolean putString(String paramString1, String paramString2)
  {
    return this.headInterceptor.handlePut(this.poolName, paramString1, paramString2);
  }

  public boolean putString(String paramString1, String paramString2, int paramInt)
  {
    return this.headInterceptor.handlePut(this.poolName, paramString1, paramString2, paramInt);
  }

  public boolean putStringWithSecond(String paramString1, String paramString2, long paramLong)
  {
    return this.headInterceptor.handlePut(this.poolName, paramString1, paramString2, paramLong);
  }

  public boolean putString(String paramString, Object paramObject, Date paramDate)
  {
    return this.headInterceptor.handlePut(this.poolName, paramString, paramObject, paramDate);
  }

  public boolean add(String paramString, Object paramObject)
  {
    return this.headInterceptor.handleAdd(this.poolName, paramString, paramObject);
  }

  public boolean add(String paramString, Object paramObject, int paramInt)
  {
    return this.headInterceptor.handleAdd(this.poolName, paramString, paramObject, paramInt);
  }

  public boolean add(String paramString, Object paramObject, Date paramDate)
  {
    return this.headInterceptor.handleAdd(this.poolName, paramString, paramObject, paramDate);
  }

  public boolean addWithSecond(String paramString, Object paramObject, long paramLong)
  {
    return this.headInterceptor.handleAdd(this.poolName, paramString, paramObject, paramLong);
  }

  public long incr(String paramString, long paramLong)
  {
    return this.headInterceptor.incr(this.poolName, paramString, paramLong);
  }

  public long decr(String paramString, long paramLong)
  {
    return this.headInterceptor.decr(this.poolName, paramString, paramLong);
  }

  public boolean storeCounter(String paramString, long paramLong)
  {
    return this.headInterceptor.storeCounter(this.poolName, paramString, paramLong);
  }

  public boolean storeCounter(String paramString, long paramLong, int paramInt)
  {
    return this.headInterceptor.storeCounter(this.poolName, paramString, paramLong, paramInt);
  }

  public long getCounter(String paramString)
  {
    return this.headInterceptor.getCounter(this.poolName, paramString);
  }

  public long addOrIncr(String paramString, long paramLong)
  {
    return this.headInterceptor.addOrIncr(this.poolName, paramString, paramLong);
  }

  public long addOrDecr(String paramString, long paramLong)
  {
    return this.headInterceptor.addOrDecr(this.poolName, paramString, paramLong);
  }

  public boolean replace(String paramString, Object paramObject)
  {
    return this.headInterceptor.handleReplace(this.poolName, paramString, paramObject);
  }

  public boolean replace(String paramString, Object paramObject, int paramInt)
  {
    return this.headInterceptor.handleReplace(this.poolName, paramString, paramObject, paramInt);
  }

  public boolean replaceWithSecond(String paramString, Object paramObject, long paramLong)
  {
    return this.headInterceptor.handleReplace(this.poolName, paramString, paramObject, paramLong);
  }

  public boolean replace(String paramString, Object paramObject, Date paramDate)
  {
    return this.headInterceptor.handleReplace(this.poolName, paramString, paramObject, paramDate);
  }

  public String getPoolName()
  {
    return this.poolName;
  }

  public MemcacheInterceptor getHeadInterceptor()
  {
    return this.headInterceptor;
  }
}