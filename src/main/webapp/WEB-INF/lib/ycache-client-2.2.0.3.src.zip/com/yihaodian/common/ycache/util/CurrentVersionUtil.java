package com.yihaodian.common.ycache.util;

import com.yihaodian.common.ycache.CacheProxy;
import com.yihaodian.common.ycache.memcache.YmemcacheProxyFactory;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class CurrentVersionUtil
{
  private static Log log = LogFactory.getLog(CurrentVersionUtil.class);
  public static String YCACHE_YHD_CURRENAT_VERSION__CACHE_KEY = "ycache.currentVersion.yhd";
  private static String YCACHE_CURRENTVERSION = null;

  public static void flushCurrentVersion()
  {
  }

  // ERROR //
  public static void initCurrentVersion()
  {
    // Byte code:
    //   0: ldc_w 2
    //   3: ldc 3
    //   5: invokevirtual 4	java/lang/Class:getResource	(Ljava/lang/String;)Ljava/net/URL;
    //   8: invokevirtual 5	java/net/URL:getPath	()Ljava/lang/String;
    //   11: astore_0
    //   12: new 6	java/io/File
    //   15: dup
    //   16: aload_0
    //   17: invokespecial 7	java/io/File:<init>	(Ljava/lang/String;)V
    //   20: astore_1
    //   21: aload_0
    //   22: ldc 8
    //   24: invokevirtual 9	java/lang/String:indexOf	(Ljava/lang/String;)I
    //   27: iconst_m1
    //   28: if_icmpeq +206 -> 234
    //   31: aload_1
    //   32: invokevirtual 10	java/io/File:getParentFile	()Ljava/io/File;
    //   35: astore_2
    //   36: aload_2
    //   37: invokevirtual 11	java/io/File:exists	()Z
    //   40: ifeq +194 -> 234
    //   43: aload_2
    //   44: invokevirtual 10	java/io/File:getParentFile	()Ljava/io/File;
    //   47: astore_3
    //   48: aload_2
    //   49: invokevirtual 11	java/io/File:exists	()Z
    //   52: ifeq +182 -> 234
    //   55: new 6	java/io/File
    //   58: dup
    //   59: aload_3
    //   60: ldc 12
    //   62: invokespecial 13	java/io/File:<init>	(Ljava/io/File;Ljava/lang/String;)V
    //   65: astore 4
    //   67: aload 4
    //   69: invokevirtual 11	java/io/File:exists	()Z
    //   72: ifeq +162 -> 234
    //   75: aconst_null
    //   76: astore 5
    //   78: new 14	java/io/BufferedReader
    //   81: dup
    //   82: new 15	java/io/FileReader
    //   85: dup
    //   86: aload 4
    //   88: invokespecial 16	java/io/FileReader:<init>	(Ljava/io/File;)V
    //   91: invokespecial 17	java/io/BufferedReader:<init>	(Ljava/io/Reader;)V
    //   94: astore 5
    //   96: aconst_null
    //   97: astore 6
    //   99: aload 5
    //   101: invokevirtual 18	java/io/BufferedReader:readLine	()Ljava/lang/String;
    //   104: dup
    //   105: astore 6
    //   107: ifnull +64 -> 171
    //   110: aload 6
    //   112: ldc 19
    //   114: invokevirtual 20	java/lang/String:startsWith	(Ljava/lang/String;)Z
    //   117: ifne -18 -> 99
    //   120: aload 6
    //   122: invokevirtual 21	java/lang/String:trim	()Ljava/lang/String;
    //   125: astore 7
    //   127: aload 7
    //   129: ldc 22
    //   131: invokevirtual 20	java/lang/String:startsWith	(Ljava/lang/String;)Z
    //   134: ifeq +34 -> 168
    //   137: aload 7
    //   139: ldc 23
    //   141: invokevirtual 24	java/lang/String:split	(Ljava/lang/String;)[Ljava/lang/String;
    //   144: iconst_1
    //   145: aaload
    //   146: invokevirtual 21	java/lang/String:trim	()Ljava/lang/String;
    //   149: putstatic 25	com/yihaodian/common/ycache/util/CurrentVersionUtil:YCACHE_CURRENTVERSION	Ljava/lang/String;
    //   152: aload 5
    //   154: ifnull +13 -> 167
    //   157: aload 5
    //   159: invokevirtual 26	java/io/BufferedReader:close	()V
    //   162: goto +5 -> 167
    //   165: astore 8
    //   167: return
    //   168: goto -69 -> 99
    //   171: aload 5
    //   173: ifnull +61 -> 234
    //   176: aload 5
    //   178: invokevirtual 26	java/io/BufferedReader:close	()V
    //   181: goto +53 -> 234
    //   184: astore 6
    //   186: goto +48 -> 234
    //   189: astore 6
    //   191: aload 6
    //   193: invokevirtual 29	java/lang/Exception:printStackTrace	()V
    //   196: aload 5
    //   198: ifnull +36 -> 234
    //   201: aload 5
    //   203: invokevirtual 26	java/io/BufferedReader:close	()V
    //   206: goto +28 -> 234
    //   209: astore 6
    //   211: goto +23 -> 234
    //   214: astore 9
    //   216: aload 5
    //   218: ifnull +13 -> 231
    //   221: aload 5
    //   223: invokevirtual 26	java/io/BufferedReader:close	()V
    //   226: goto +5 -> 231
    //   229: astore 10
    //   231: aload 9
    //   233: athrow
    //   234: aconst_null
    //   235: astore_2
    //   236: ldc_w 30
    //   239: ldc 31
    //   241: invokevirtual 32	java/lang/Class:getResourceAsStream	(Ljava/lang/String;)Ljava/io/InputStream;
    //   244: astore_2
    //   245: aload_2
    //   246: ifnull +55 -> 301
    //   249: new 33	java/util/Properties
    //   252: dup
    //   253: invokespecial 34	java/util/Properties:<init>	()V
    //   256: astore_3
    //   257: aload_3
    //   258: aload_2
    //   259: invokevirtual 35	java/util/Properties:load	(Ljava/io/InputStream;)V
    //   262: aload_3
    //   263: ldc 36
    //   265: invokevirtual 37	java/util/Properties:getProperty	(Ljava/lang/String;)Ljava/lang/String;
    //   268: astore 4
    //   270: aload 4
    //   272: ifnull +29 -> 301
    //   275: aload 4
    //   277: invokestatic 38	java/lang/Long:parseLong	(Ljava/lang/String;)J
    //   280: lstore 5
    //   282: lload 5
    //   284: invokestatic 39	java/lang/Long:toString	(J)Ljava/lang/String;
    //   287: putstatic 25	com/yihaodian/common/ycache/util/CurrentVersionUtil:YCACHE_CURRENTVERSION	Ljava/lang/String;
    //   290: aload_2
    //   291: ifnull +7 -> 298
    //   294: aload_2
    //   295: invokestatic 40	org/apache/commons/io/IOUtils:closeQuietly	(Ljava/io/InputStream;)V
    //   298: return
    //   299: astore 5
    //   301: aload_2
    //   302: ifnull +45 -> 347
    //   305: aload_2
    //   306: invokestatic 40	org/apache/commons/io/IOUtils:closeQuietly	(Ljava/io/InputStream;)V
    //   309: goto +38 -> 347
    //   312: astore_3
    //   313: getstatic 42	com/yihaodian/common/ycache/util/CurrentVersionUtil:log	Lorg/apache/commons/logging/Log;
    //   316: aload_3
    //   317: aload_3
    //   318: invokeinterface 43 3 0
    //   323: aload_2
    //   324: ifnull +23 -> 347
    //   327: aload_2
    //   328: invokestatic 40	org/apache/commons/io/IOUtils:closeQuietly	(Ljava/io/InputStream;)V
    //   331: goto +16 -> 347
    //   334: astore 11
    //   336: aload_2
    //   337: ifnull +7 -> 344
    //   340: aload_2
    //   341: invokestatic 40	org/apache/commons/io/IOUtils:closeQuietly	(Ljava/io/InputStream;)V
    //   344: aload 11
    //   346: athrow
    //   347: ldc 44
    //   349: putstatic 25	com/yihaodian/common/ycache/util/CurrentVersionUtil:YCACHE_CURRENTVERSION	Ljava/lang/String;
    //   352: return
    //
    // Exception table:
    //   from	to	target	type
    //   157	162	165	java/io/IOException
    //   176	181	184	java/io/IOException
    //   78	152	189	java/lang/Exception
    //   168	171	189	java/lang/Exception
    //   201	206	209	java/io/IOException
    //   78	152	214	finally
    //   168	171	214	finally
    //   189	196	214	finally
    //   214	216	214	finally
    //   221	226	229	java/io/IOException
    //   275	290	299	java/lang/NumberFormatException
    //   236	290	312	java/io/IOException
    //   299	301	312	java/io/IOException
    //   236	290	334	finally
    //   299	301	334	finally
    //   312	323	334	finally
    //   334	336	334	finally
  }

  public static String getCurrentVersion()
  {
    return YCACHE_CURRENTVERSION;
  }

  public static void setCurrentVersion(String paramString)
  {
    YCACHE_CURRENTVERSION = paramString;
  }

  public static void putYHDCurrentVersion2Memcache(String paramString)
  {
    CacheProxy localCacheProxy = YmemcacheProxyFactory.getClient("session_pool");
    localCacheProxy.put(YCACHE_YHD_CURRENAT_VERSION__CACHE_KEY, paramString);
  }

  public static String getYHDCurrentVersionFromMemcache()
  {
    CacheProxy localCacheProxy = YmemcacheProxyFactory.getClient("session_pool");
    Object localObject = localCacheProxy.get(YCACHE_YHD_CURRENAT_VERSION__CACHE_KEY);
    if (localObject == null)
      return getCurrentVersion();
    return ((String)localObject);
  }

  static
  {
    initCurrentVersion();
  }
}