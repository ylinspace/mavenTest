package com.yihaodian.common.yredis.client;

import com.ycache.redis.clients.jedis.BinaryClient.LIST_POSITION;
import com.ycache.redis.clients.jedis.Jedis;
import com.ycache.redis.clients.jedis.JedisPubSub;
import com.ycache.redis.clients.jedis.ShardedJedisPipelineUtils;
import java.util.List;
import java.util.Map;
import java.util.Set;

public abstract interface RedisInterceptor
{
  public abstract RedisInterceptor getNextHandler();

  public abstract void setNextHandler(RedisInterceptor paramRedisInterceptor);

  public abstract ShardedJedisPipelineUtils buildPipelineUtils(String paramString);

  public abstract long rpush(String paramString1, String paramString2, String paramString3);

  public abstract long rpush(String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);

  public abstract long lpush(String paramString1, String paramString2, String paramString3);

  public abstract long lpush(String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);

  public abstract long rpushx(String paramString1, String paramString2, String paramString3);

  public abstract long rpushx(String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);

  public abstract long lpushx(String paramString1, String paramString2, String paramString3);

  public abstract long lpushx(String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);

  public abstract long sadd(String paramString1, String paramString2, String[] paramArrayOfString);

  public abstract long sadd(String paramString, byte[] paramArrayOfByte, byte[][] paramArrayOfByte1);

  public abstract String lpop(String paramString1, String paramString2);

  public abstract byte[] lpop(String paramString, byte[] paramArrayOfByte);

  public abstract String rpop(String paramString1, String paramString2);

  public abstract byte[] rpop(String paramString, byte[] paramArrayOfByte);

  public abstract String lindex(String paramString1, String paramString2, long paramLong);

  public abstract byte[] lindex(String paramString, byte[] paramArrayOfByte, long paramLong);

  public abstract Long linsert(String paramString1, String paramString2, BinaryClient.LIST_POSITION paramLIST_POSITION, String paramString3, String paramString4);

  public abstract Long linsert(String paramString, byte[] paramArrayOfByte1, BinaryClient.LIST_POSITION paramLIST_POSITION, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3);

  public abstract String lset(String paramString1, String paramString2, long paramLong, String paramString3);

  public abstract String lset(String paramString, byte[] paramArrayOfByte1, long paramLong, byte[] paramArrayOfByte2);

  public abstract long llen(String paramString1, String paramString2);

  public abstract long llen(String paramString, byte[] paramArrayOfByte);

  public abstract long lrem(String paramString1, String paramString2, long paramLong, String paramString3);

  public abstract long lrem(String paramString, byte[] paramArrayOfByte1, long paramLong, byte[] paramArrayOfByte2);

  public abstract String ltrim(String paramString1, String paramString2, long paramLong1, long paramLong2);

  public abstract String ltrim(String paramString, byte[] paramArrayOfByte, long paramLong1, long paramLong2);

  public abstract List<String> lrange(String paramString1, String paramString2, long paramLong1, long paramLong2);

  public abstract List<byte[]> lrange(String paramString, byte[] paramArrayOfByte, long paramLong1, long paramLong2);

  public abstract Long hset(String paramString1, String paramString2, String paramString3, String paramString4);

  public abstract Long hset(String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3);

  public abstract String set(String paramString1, String paramString2, String paramString3);

  public abstract String get(String paramString1, String paramString2);

  public abstract String set(String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);

  public abstract byte[] get(String paramString, byte[] paramArrayOfByte);

  public abstract String compressSet(String paramString1, String paramString2, String paramString3);

  public abstract String compressGet(String paramString1, String paramString2);

  public abstract String compressSet(String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);

  public abstract byte[] compressGet(String paramString, byte[] paramArrayOfByte);

  public abstract long ttl(String paramString1, String paramString2);

  public abstract long ttl(String paramString, byte[] paramArrayOfByte);

  public abstract long del(String paramString1, String paramString2);

  public abstract long del(String paramString, byte[] paramArrayOfByte);

  public abstract String hmset(String paramString1, String paramString2, Map<String, String> paramMap);

  public abstract String hmset(String paramString, byte[] paramArrayOfByte, Map<byte[], byte[]> paramMap);

  public abstract String setex(String paramString1, String paramString2, int paramInt, String paramString3);

  public abstract String setex(String paramString, byte[] paramArrayOfByte1, int paramInt, byte[] paramArrayOfByte2);

  public abstract long setnx(String paramString1, String paramString2, String paramString3);

  public abstract long setnx(String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);

  public abstract String compressSetex(String paramString1, String paramString2, int paramInt, String paramString3);

  public abstract String compressSetex(String paramString, byte[] paramArrayOfByte1, int paramInt, byte[] paramArrayOfByte2);

  public abstract long compressSetnx(String paramString1, String paramString2, String paramString3);

  public abstract long compressSetnx(String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);

  public abstract Long expire(String paramString1, String paramString2, int paramInt);

  public abstract Long expire(String paramString, byte[] paramArrayOfByte, int paramInt);

  public abstract Long expireAt(String paramString1, String paramString2, long paramLong);

  public abstract Long expireAt(String paramString, byte[] paramArrayOfByte, long paramLong);

  public abstract boolean exists(String paramString1, String paramString2);

  public abstract boolean exists(String paramString, byte[] paramArrayOfByte);

  public abstract String type(String paramString1, String paramString2);

  public abstract String type(String paramString, byte[] paramArrayOfByte);

  public abstract String hget(String paramString1, String paramString2, String paramString3);

  public abstract byte[] hget(String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);

  public abstract Map<String, String> hgetAll(String paramString1, String paramString2);

  public abstract Map<byte[], byte[]> hgetAll(String paramString, byte[] paramArrayOfByte);

  public abstract Map<String, String> hgetAll(String paramString1, String paramString2, boolean paramBoolean);

  public abstract Map<byte[], byte[]> hgetAll(String paramString, byte[] paramArrayOfByte, boolean paramBoolean);

  public abstract Map<String, String> hgetAllToLinkedHashMap(String paramString1, String paramString2);

  public abstract Map<byte[], byte[]> hgetAllToLinkedHashMap(String paramString, byte[] paramArrayOfByte);

  public abstract Set<String> smembers(String paramString1, String paramString2);

  public abstract Set<byte[]> smembers(String paramString, byte[] paramArrayOfByte);

  public abstract Long srem(String paramString1, String paramString2, String[] paramArrayOfString);

  public abstract Long srem(String paramString, byte[] paramArrayOfByte, byte[][] paramArrayOfByte1);

  public abstract Long scard(String paramString1, String paramString2);

  public abstract Long scard(String paramString, byte[] paramArrayOfByte);

  public abstract String spop(String paramString1, String paramString2);

  public abstract byte[] spop(String paramString, byte[] paramArrayOfByte);

  public abstract String srandmember(String paramString1, String paramString2);

  public abstract byte[] srandmember(String paramString, byte[] paramArrayOfByte);

  public abstract boolean sismember(String paramString1, String paramString2, String paramString3);

  public abstract boolean sismember(String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);

  public abstract Long append(String paramString1, String paramString2, String paramString3);

  public abstract Long append(String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);

  public abstract Long decr(String paramString1, String paramString2);

  public abstract Long decr(String paramString, byte[] paramArrayOfByte);

  public abstract Long decrBy(String paramString1, String paramString2, Integer paramInteger);

  public abstract Long decrBy(String paramString, byte[] paramArrayOfByte, Integer paramInteger);

  public abstract String getrange(String paramString1, String paramString2, int paramInt1, int paramInt2);

  public abstract byte[] getrange(String paramString, byte[] paramArrayOfByte, int paramInt1, int paramInt2);

  public abstract String getSet(String paramString1, String paramString2, String paramString3);

  public abstract byte[] getSet(String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);

  public abstract String compressGetSet(String paramString1, String paramString2, String paramString3);

  public abstract byte[] compressGetSet(String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);

  public abstract Long hdel(String paramString1, String paramString2, String[] paramArrayOfString);

  public abstract Long hdel(String paramString, byte[] paramArrayOfByte, byte[][] paramArrayOfByte1);

  public abstract Boolean hexists(String paramString1, String paramString2, String paramString3);

  public abstract Boolean hexists(String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);

  public abstract Long hincrBy(String paramString1, String paramString2, String paramString3, int paramInt);

  public abstract Long hincrBy(String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, int paramInt);

  public abstract Set<String> hkeys(String paramString1, String paramString2);

  public abstract Set<byte[]> hkeys(String paramString, byte[] paramArrayOfByte);

  public abstract Long hlen(String paramString, byte[] paramArrayOfByte);

  public abstract Long hlen(String paramString1, String paramString2);

  public abstract List<String> hmget(String paramString1, String paramString2, String[] paramArrayOfString);

  public abstract List<byte[]> hmget(String paramString, byte[] paramArrayOfByte, byte[][] paramArrayOfByte1);

  public abstract Long hsetnx(String paramString1, String paramString2, String paramString3, String paramString4);

  public abstract Long hsetnx(String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3);

  public abstract List<String> hvals(String paramString1, String paramString2);

  public abstract List<byte[]> hvals(String paramString, byte[] paramArrayOfByte);

  public abstract Long incr(String paramString1, String paramString2);

  public abstract Long incr(String paramString, byte[] paramArrayOfByte);

  public abstract boolean electioneer(String paramString1, String paramString2, String paramString3, int paramInt);

  public abstract boolean electioneer(String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, int paramInt);

  public abstract Long incrBy(String paramString1, String paramString2, int paramInt);

  public abstract Long incrBy(String paramString, byte[] paramArrayOfByte, int paramInt);

  public abstract void subscribe(String paramString1, String paramString2, JedisPubSub paramJedisPubSub, String[] paramArrayOfString);

  public abstract void subscribe(String paramString, byte[] paramArrayOfByte, JedisPubSub paramJedisPubSub, String[] paramArrayOfString);

  public abstract void publish(String paramString1, String paramString2, String paramString3, String paramString4);

  public abstract void publish(String paramString1, byte[] paramArrayOfByte, String paramString2, String paramString3);

  public abstract Jedis getJedisByShardKey(String paramString1, String paramString2);

  public abstract Jedis getJedisByShardKey(String paramString, byte[] paramArrayOfByte);

  public abstract int getShardIndex(String paramString1, String paramString2);

  public abstract int getShardIndex(String paramString, byte[] paramArrayOfByte);
}