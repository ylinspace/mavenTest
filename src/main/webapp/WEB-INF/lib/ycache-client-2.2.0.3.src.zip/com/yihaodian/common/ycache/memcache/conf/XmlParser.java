package com.yihaodian.common.ycache.memcache.conf;

import com.yihaodian.common.ycache.memcache.exception.MemcacheInitException;
import org.apache.commons.lang.StringUtils;
import org.dom4j.Element;

public class XmlParser
{
  public static Integer parseIntAttr(Element paramElement, String paramString)
    throws MemcacheInitException
  {
    String str = paramElement.attributeValue(paramString);
    checkRequiedAttr(paramString, str);
    return Integer.valueOf(trimToNull(str));
  }

  public static Long parseLongAttr(Element paramElement, String paramString)
    throws MemcacheInitException
  {
    String str = paramElement.attributeValue(paramString);
    checkRequiedAttr(paramString, str);
    return Long.valueOf(trimToNull(str));
  }

  public static boolean parseBooleanAttr(Element paramElement, String paramString)
    throws MemcacheInitException
  {
    String str = paramElement.attributeValue(paramString);
    checkRequiedAttr(paramString, str);
    return Boolean.valueOf(trimToNull(str)).booleanValue();
  }

  public static String parseAttr(Element paramElement, String paramString)
    throws MemcacheInitException
  {
    String str = paramElement.attributeValue(paramString);
    checkRequiedAttr(paramString, str);
    return trimToNull(str);
  }

  private static void checkRequiedAttr(String paramString1, String paramString2)
    throws MemcacheInitException
  {
    if (StringUtils.isEmpty(paramString2))
      throw new MemcacheInitException("memcache configure file error: attribute " + paramString1 + " is required!");
  }

  private static String trimToNull(String paramString)
  {
    return StringUtils.trimToNull(paramString);
  }
}