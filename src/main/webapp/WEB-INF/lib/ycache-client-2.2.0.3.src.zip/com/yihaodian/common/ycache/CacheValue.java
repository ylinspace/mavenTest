package com.yihaodian.common.ycache;

public class CacheValue
{
  private Object value;
  private Long versionId;

  public Object getValue()
  {
    return this.value;
  }

  public void setValue(Object paramObject)
  {
    this.value = paramObject;
  }

  public Long getVersionId()
  {
    return this.versionId;
  }

  public void setVersionId(Long paramLong)
  {
    this.versionId = paramLong;
  }
}