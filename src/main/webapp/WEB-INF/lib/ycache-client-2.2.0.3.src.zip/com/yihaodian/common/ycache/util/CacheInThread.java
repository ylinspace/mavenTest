package com.yihaodian.common.ycache.util;

import java.util.HashMap;
import java.util.Map;

public final class CacheInThread
{
  private static final ThreadLocal<Map<Object, Object>> threadCache = new ThreadLocal();
  private static final ThreadLocal<Map<String, Long>> threadVersion = new ThreadLocal()
  {
    protected Map<String, Long> initialValue()
    {
      return new HashMap();
    }
  };

  public static Object getResult(Object paramObject)
  {
    if (threadCache.get() == null)
      return null;
    return ((Map)threadCache.get()).get(paramObject);
  }

  public static Object setResult(Object paramObject1, Object paramObject2)
  {
    Object localObject = (Map)threadCache.get();
    if (localObject == null)
    {
      localObject = new HashMap();
      threadCache.set(localObject);
    }
    return ((Map)localObject).put(paramObject1, paramObject2);
  }

  public static void removeResult(Object paramObject)
  {
    Map localMap = (Map)threadCache.get();
    if (localMap != null)
      localMap.remove(paramObject);
  }

  public static void setVersion(String paramString, Long paramLong)
  {
    ((Map)threadVersion.get()).put(paramString, paramLong);
  }

  public static Long getVersion(String paramString)
  {
    if (threadVersion.get() == null)
      return null;
    return ((Long)((Map)threadVersion.get()).get(paramString));
  }

  public static void removeVersion(String paramString)
  {
    if (threadVersion.get() != null)
      ((Map)threadVersion.get()).remove(paramString);
  }

  public static void reset()
  {
    if (threadCache.get() != null)
      ((Map)threadCache.get()).clear();
    if (threadVersion.get() != null)
      ((Map)threadVersion.get()).clear();
  }
}