package com.yihaodian.common.ycache.memcache.impl;

import com.ycache.danga.MemCached.MemCachedClient;
import com.yihaodian.common.ycache.memcache.AbstractMemcacheProxy;
import com.yihaodian.common.ycache.memcache.conf.MemcachePoolConfig;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map<Ljava.lang.String;Ljava.lang.Object;>;
import java.util.Set;
import org.apache.commons.logging.Log;

public class BaseMemcacheProxy extends AbstractMemcacheProxy
{
  public BaseMemcacheProxy(MemcachePoolConfig paramMemcachePoolConfig)
  {
    super(paramMemcachePoolConfig);
  }

  public boolean put(String paramString, Object paramObject)
  {
    return put(paramString, paramObject, this.poolConfig.getDefaultExpiryMinutes());
  }

  public boolean put(String paramString, Object paramObject, int paramInt)
  {
    boolean bool = false;
    if (paramObject != null)
    {
      long l = -6318801330924158976L;
      if (paramInt <= 0)
        paramInt = 30;
      l = 60000L * paramInt;
      paramString = getGoodKey(paramString);
      bool = this.client.set(paramString, paramObject, new Date(l));
    }
    else
    {
      try
      {
        throw new Exception("Memcache value is null error! The key is :" + paramString);
      }
      catch (Exception localException)
      {
        localException.printStackTrace();
      }
    }
    return bool;
  }

  public boolean put(String paramString, Object paramObject, Date paramDate)
  {
    boolean bool = false;
    if (paramObject != null)
    {
      paramString = getGoodKey(paramString);
      bool = this.client.set(paramString, paramObject, paramDate);
    }
    else
    {
      try
      {
        throw new Exception("Memcache value is null error! The key is :" + paramString);
      }
      catch (Exception localException)
      {
        localException.printStackTrace();
      }
    }
    return bool;
  }

  public boolean putWithSecond(String paramString, Object paramObject, long paramLong)
  {
    boolean bool = false;
    if (paramObject != null)
    {
      long l = -6318801330924158976L;
      if (paramLong <= -6318801674521542656L)
        paramLong = 30L;
      l = 1000L * paramLong;
      paramString = getGoodKey(paramString);
      bool = this.client.set(paramString, paramObject, new Date(l));
    }
    else
    {
      try
      {
        throw new Exception("Memcache value is null error! The key is :" + paramString);
      }
      catch (Exception localException)
      {
        localException.printStackTrace();
      }
    }
    return bool;
  }

  public Object get(String paramString)
  {
    Object localObject = this.client.get(getGoodKey(paramString));
    return localObject;
  }

  public Map<String, Object> getMulti(String[] paramArrayOfString)
  {
    HashMap localHashMap1 = new HashMap();
    if ((paramArrayOfString != null) && (paramArrayOfString.length > 0))
    {
      Object localObject;
      String[] arrayOfString = new String[paramArrayOfString.length];
      HashMap localHashMap2 = new HashMap();
      for (int i = 0; i < paramArrayOfString.length; ++i)
      {
        localObject = getGoodKey(paramArrayOfString[i]);
        localHashMap2.put(localObject, paramArrayOfString[i]);
        arrayOfString[i] = localObject;
      }
      Map localMap = this.client.getMulti(arrayOfString);
      if (!(localMap.isEmpty()))
      {
        localObject = localMap.keySet().iterator();
        while (((Iterator)localObject).hasNext())
        {
          String str1 = (String)((Iterator)localObject).next();
          String str2 = (String)localHashMap2.get(str1);
          localHashMap1.put(str2, localMap.get(str1));
        }
      }
    }
    return ((Map<String, Object>)localHashMap1);
  }

  public boolean remove(String paramString)
  {
    return this.client.delete(getGoodKey(paramString));
  }

  public boolean remove(String paramString1, String paramString2)
  {
    return this.client.delete(getGoodKeyWithCurrentVersion(paramString1, paramString2));
  }

  public long incr(String paramString, long paramLong)
  {
    return this.client.incr(getGoodKey(paramString), paramLong);
  }

  public long decr(String paramString, long paramLong)
  {
    return this.client.decr(getGoodKey(paramString), paramLong);
  }

  public boolean storeCounter(String paramString, long paramLong)
  {
    return this.client.storeCounter(getGoodKey(paramString), paramLong);
  }

  public boolean storeCounter(String paramString, long paramLong, int paramInt)
  {
    long l = -6318801846320234496L;
    if (paramInt <= 0)
      paramInt = 30;
    l = 60000L * paramInt;
    return this.client.storeCounter(getGoodKey(paramString), paramLong, new Date(l));
  }

  public long getCounter(String paramString)
  {
    return this.client.getCounter(getGoodKey(paramString));
  }

  public long addOrIncr(String paramString, long paramLong)
  {
    return this.client.addOrIncr(getGoodKey(paramString), paramLong);
  }

  public long addOrDecr(String paramString, long paramLong)
  {
    return this.client.addOrDecr(getGoodKey(paramString), paramLong);
  }

  public String getString(String paramString)
  {
    Object localObject = get(paramString);
    return ((String)localObject);
  }

  public Object get(String paramString1, String paramString2)
  {
    Object localObject = this.client.get(getGoodKeyWithCurrentVersion(paramString1, paramString2));
    return localObject;
  }

  public String getString(String paramString1, String paramString2)
  {
    Object localObject = get(paramString1, paramString2);
    return ((String)localObject);
  }

  public boolean putString(String paramString1, String paramString2)
  {
    return put(paramString1, paramString2);
  }

  public boolean putString(String paramString1, String paramString2, int paramInt)
  {
    return put(paramString1, paramString2, paramInt);
  }

  public boolean putString(String paramString, Object paramObject, Date paramDate)
  {
    return put(paramString, paramObject, paramDate);
  }

  public boolean putStringWithSecond(String paramString1, String paramString2, long paramLong)
  {
    return putWithSecond(paramString1, paramString2, paramLong);
  }

  public boolean add(String paramString, Object paramObject)
  {
    return add(paramString, paramObject, this.poolConfig.getDefaultExpiryMinutes());
  }

  public boolean add(String paramString, Object paramObject, int paramInt)
  {
    if (!(checkNotNull(paramString, paramObject)))
      return false;
    paramString = getGoodKey(paramString);
    paramInt = (paramInt <= 0) ? 30 : paramInt;
    long l = 60000L * paramInt;
    boolean bool = this.client.add(paramString, paramObject, new Date(l));
    return bool;
  }

  public boolean add(String paramString, Object paramObject, Date paramDate)
  {
    if (!(checkNotNull(paramString, paramObject)))
      return false;
    paramString = getGoodKey(paramString);
    boolean bool = this.client.add(paramString, paramObject, paramDate);
    return bool;
  }

  public boolean addWithSecond(String paramString, Object paramObject, long paramLong)
  {
    if (!(checkNotNull(paramString, paramObject)))
      return false;
    paramString = getGoodKey(paramString);
    paramLong = (paramLong <= -6318801451183243264L) ? 30L : paramLong;
    long l = 1000L * paramLong;
    boolean bool = this.client.add(paramString, paramObject, new Date(l));
    return bool;
  }

  public boolean replace(String paramString, Object paramObject)
  {
    return replace(paramString, paramObject, this.poolConfig.getDefaultExpiryMinutes());
  }

  public boolean replace(String paramString, Object paramObject, int paramInt)
  {
    if (!(checkNotNull(paramString, paramObject)))
      return false;
    paramString = getGoodKey(paramString);
    paramInt = (paramInt <= 0) ? 30 : paramInt;
    long l = 60000L * paramInt;
    boolean bool = this.client.replace(paramString, paramObject, new Date(l));
    return bool;
  }

  public boolean replace(String paramString, Object paramObject, Date paramDate)
  {
    if (!(checkNotNull(paramString, paramObject)))
      return false;
    paramString = getGoodKey(paramString);
    boolean bool = this.client.replace(paramString, paramObject, paramDate);
    return bool;
  }

  public boolean replaceWithSecond(String paramString, Object paramObject, long paramLong)
  {
    if (!(checkNotNull(paramString, paramObject)))
      return false;
    paramString = getGoodKey(paramString);
    paramLong = (paramLong <= -6318801451183243264L) ? 30L : paramLong;
    long l = 1000L * paramLong;
    boolean bool = this.client.replace(paramString, paramObject, new Date(l));
    return bool;
  }

  private boolean checkNotNull(String paramString, Object paramObject)
  {
    if (paramString == null)
      return false;
    if (paramObject == null)
    {
      logger.warn("Saving null memcached value! The key is :" + paramString);
      return false;
    }
    return true;
  }

  public MemCachedClient getClient()
  {
    return this.client;
  }
}