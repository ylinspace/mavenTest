package com.yihaodian.common.ycache.monitor;

import com.ycache.danga.MemCached.YcacheHealthCheck;
import com.yihaodian.common.ycache.stats.StatsLocalCache;
import com.yihaodian.common.ycache.stats.StatsLocalCacheManager;
import com.yihaodian.configcentre.client.utils.YccGlobalPropertyConfigurer;
import com.yihaodian.configcentre.utils.AppUtils;
import com.yihaodian.monitor.dto.YcacheAnalyse;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TimerTask;

public class DetectorTimerTask extends TimerTask
{
  private static YcacheHealthCheck ycacheHealthCheck = null;
  private static final String JUMPER_TOPIC_NAME = "ycachequeue";
  private static final String appHost = AppUtils.getHostAddress();
  private static final String appCode = YccGlobalPropertyConfigurer.getMainPoolId();

  public void run()
  {
    Object localObject = new HashMap();
    ycacheHealthCheck = YcacheHealthCheck.getInstance();
    localObject = ycacheHealthCheck.getCacheMap();
    Iterator localIterator = ((Map)localObject).entrySet().iterator();
    while (localIterator.hasNext())
    {
      Map.Entry localEntry = (Map.Entry)localIterator.next();
      YcacheAnalyse localYcacheAnalyse = new YcacheAnalyse();
      String str = (String)localEntry.getKey();
      localYcacheAnalyse.setAppCode(appCode);
      localYcacheAnalyse.setAppHost(appHost);
      localYcacheAnalyse.setCacheHost(str);
      int i = 0;
      int j = 0;
      int k = 0;
      int l = 0;
      localYcacheAnalyse.setHitCounts(Integer.valueOf(i + j));
      localYcacheAnalyse.setFailedCounts(Integer.valueOf(l));
      localYcacheAnalyse.setSuccessedCounts(Integer.valueOf(i + j + k));
      localYcacheAnalyse.setCalledCounts(Integer.valueOf(i + j + k + l));
      localYcacheAnalyse.setIntervalTime(Integer.valueOf(60));
      Date localDate = new Date();
      localYcacheAnalyse.setGmtCreate(localDate);
      localYcacheAnalyse.setEndTime(localDate);
      localYcacheAnalyse.setMemo("");
    }
  }

  private synchronized Object getAndPutNull(String paramString)
  {
    StatsLocalCache localStatsLocalCache = StatsLocalCacheManager.getContent(paramString);
    if (localStatsLocalCache != null)
      return localStatsLocalCache.getValue();
    return null;
  }

  private String cacheInRequestKey(String paramString1, String paramString2)
  {
    return paramString1 + "_" + paramString2;
  }
}