package com.yihaodian.common.idc;

import com.yihaodian.common.yredis.RedisProxy;

public abstract interface IDCRedisProxy
{
}