package com.yihaodian.common.ycache.memcache;

import com.ycache.danga.MemCached.YcacheHealthCheck;
import com.yihaodian.common.ycache.CacheProxy;
import com.yihaodian.common.ycache.memcache.exception.MemcacheException;
import com.yihaodian.common.ycache.memcache.exception.MemcacheInitException;
import com.yihaodian.common.ycache.memcache.impl.InterceptorMemcacheProxy;
import com.yihaodian.common.ycache.memcache.interceptor.CoreInterceptor;
import com.yihaodian.common.ycache.memcache.interceptor.EmptyInterceptor;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class YmemcacheProxyFactory
{
  protected static Log logger = LogFactory.getLog(YmemcacheProxyFactory.class);
  protected static YmemcacheProxyFactory singletonFactory = null;
  protected static final Object initLock = new Object();
  protected static YcacheHealthCheck ycacheHealthCheck = null;
  protected Map<String, CacheProxy> proxyPool = new HashMap();
  protected MemcacheInterceptor headInterceptor;
  protected boolean interceptorInitFlag = false;
  protected static String configureFilePath;

  public static YmemcacheProxyFactory configure(String paramString)
    throws MemcacheInitException
  {
    if (singletonFactory == null)
      synchronized (initLock)
      {
        if (singletonFactory == null)
          singletonFactory = new YmemcacheProxyFactory(paramString);
        else
          add(paramString);
      }
    else
      add(paramString);
    return singletonFactory;
  }

  public static synchronized void destroy()
  {
    if (singletonFactory != null)
    {
      singletonFactory.close();
      singletonFactory = null;
    }
  }

  public static CacheProxy getClient(String paramString)
  {
    CacheProxy localCacheProxy = singletonFactory.findClient(paramString);
    ycacheHealthCheck = YcacheHealthCheck.getInstance();
    ycacheHealthCheck.getCacheMap().put(paramString, localCacheProxy);
    return localCacheProxy;
  }

  public YmemcacheProxyFactory(String paramString)
    throws MemcacheInitException
  {
    init(paramString);
  }

  protected CacheProxy findClient(String paramString)
  {
    if (this.proxyPool.containsKey(paramString))
      return ((CacheProxy)this.proxyPool.get(paramString));
    synchronized (this.proxyPool)
    {
      if (!(this.proxyPool.containsKey(paramString)))
        break label63;
      return ((CacheProxy)this.proxyPool.get(paramString));
      label63: if (MemcacheAdmin.getInstance().containPool(paramString))
        break label115;
      logger.warn("can't find memcache pool:" + paramString + " make sure it is configured in file " + configureFilePath);
      return null;
      label115: InterceptorMemcacheProxy localInterceptorMemcacheProxy = new InterceptorMemcacheProxy(paramString, this.headInterceptor);
      this.proxyPool.put(paramString, localInterceptorMemcacheProxy);
    }
    return ((CacheProxy)this.proxyPool.get(paramString));
  }

  synchronized void init(String paramString)
    throws MemcacheInitException
  {
    configureFilePath = paramString.trim();
    logger.info("Load memcache configure from path: " + configureFilePath);
    Object localObject1 = null;
    try
    {
      String[] arrayOfString;
      if (configureFilePath.startsWith("file:"))
      {
        arrayOfString = configureFilePath.split("file:");
        localObject1 = new FileInputStream(arrayOfString[1]);
      }
      else if (configureFilePath.startsWith("classpath:"))
      {
        arrayOfString = configureFilePath.split("classpath:");
        localObject1 = YmemcacheProxyFactory.class.getClassLoader().getResourceAsStream(arrayOfString[1]);
      }
      else
      {
        localObject1 = YmemcacheProxyFactory.class.getClassLoader().getResourceAsStream(configureFilePath);
      }
      MemcacheAdmin.init((InputStream)localObject1);
      this.headInterceptor = new EmptyInterceptor();
      this.headInterceptor.setNextHandler(new CoreInterceptor());
    }
    catch (FileNotFoundException localFileNotFoundException)
    {
      throw new MemcacheInitException("MemcacheProxyFactory#init() file=" + configureFilePath + " error:", localFileNotFoundException);
    }
    catch (Exception localException)
    {
      throw new MemcacheInitException("MemcacheProxyFactory#init() file=" + configureFilePath + " error:", localException);
    }
    finally
    {
      if (localObject1 != null)
        try
        {
          ((InputStream)localObject1).close();
        }
        catch (IOException localIOException2)
        {
          logger.error(localIOException2, localIOException2);
        }
    }
  }

  static synchronized void add(String paramString)
    throws MemcacheInitException
  {
    configureFilePath = paramString.trim();
    logger.info("Add memcache configure from path: " + configureFilePath);
    Object localObject1 = null;
    try
    {
      String[] arrayOfString;
      if (configureFilePath.startsWith("file:"))
      {
        arrayOfString = configureFilePath.split("file:");
        localObject1 = new FileInputStream(arrayOfString[1]);
      }
      else if (configureFilePath.startsWith("classpath:"))
      {
        arrayOfString = configureFilePath.split("classpath:");
        localObject1 = YmemcacheProxyFactory.class.getClassLoader().getResourceAsStream(arrayOfString[1]);
      }
      else
      {
        localObject1 = YmemcacheProxyFactory.class.getClassLoader().getResourceAsStream(configureFilePath);
      }
      MemcacheAdmin.add((InputStream)localObject1);
    }
    catch (FileNotFoundException localFileNotFoundException)
    {
    }
    catch (Exception localException)
    {
    }
    finally
    {
      if (localObject1 != null)
        try
        {
          ((InputStream)localObject1).close();
        }
        catch (IOException localIOException2)
        {
          logger.error(localIOException2, localIOException2);
        }
    }
  }

  public synchronized void setInterceptors(List<String> paramList)
  {
    if (this.interceptorInitFlag)
    {
      logger.warn("headInterceptor has been aready initialized!");
      return;
    }
    MemcacheInterceptor localMemcacheInterceptor1 = this.headInterceptor.getNextHandler();
    Object localObject = this.headInterceptor;
    if (paramList != null)
    {
      Iterator localIterator = paramList.iterator();
      while (localIterator.hasNext())
      {
        String str = (String)localIterator.next();
        try
        {
          MemcacheInterceptor localMemcacheInterceptor2 = (MemcacheInterceptor)Class.forName(str).newInstance();
          ((MemcacheInterceptor)localObject).setNextHandler(localMemcacheInterceptor2);
          localObject = localMemcacheInterceptor2;
        }
        catch (Exception localException)
        {
          throw new MemcacheException("interceptor initialize fail: interceptorClass=" + str, localException);
        }
      }
    }
    ((MemcacheInterceptor)localObject).setNextHandler(localMemcacheInterceptor1);
    this.interceptorInitFlag = true;
  }

  public void close()
  {
    this.proxyPool.clear();
    this.headInterceptor = null;
    this.interceptorInitFlag = false;
    configureFilePath = null;
    MemcacheAdmin.getInstance().close();
  }
}