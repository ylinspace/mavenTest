package com.yihaodian.common.idc;

import com.ycache.danga.MemCached.MemCachedClient;
import com.yihaodian.common.ycache.memcache.conf.MemcachePoolConfig;
import com.yihaodian.common.ycache.memcache.impl.BaseMemcacheProxy;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class IDCBaseMemcacheProxy extends BaseMemcacheProxy
{
  protected Log logger = LogFactory.getLog(getClass());

  public IDCBaseMemcacheProxy(MemcachePoolConfig paramMemcachePoolConfig)
  {
    super(paramMemcachePoolConfig);
  }

  public MemCachedClient getClien()
  {
    return this.client;
  }
}