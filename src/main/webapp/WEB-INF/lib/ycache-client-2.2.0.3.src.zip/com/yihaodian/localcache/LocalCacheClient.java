package com.yihaodian.localcache;

import com.opensymphony.oscache.general.GeneralCacheAdministrator;
import java.util.Date;
import org.apache.log4j.Logger;

public class LocalCacheClient
{
  public static Logger LOG = Logger.getLogger(LocalCacheClient.class);
  private int refreshPeriod = -1;
  private String[] groups;
  private static GeneralCacheAdministrator cache;

  public LocalCacheClient()
  {
    cache = LocalCachePool.getLocalCache().getCache();
  }

  public LocalCacheClient(String paramString)
  {
    cache = LocalCachePool.getLocalCache().getCache();
    this.groups = { paramString };
  }

  public void setCacheCapacity(int paramInt)
  {
    cache.setCacheCapacity(paramInt);
  }

  public void shutdown()
  {
    if (cache != null)
    {
      LOG.debug("shutdowning OSCache...");
      cache.destroy();
      cache = null;
      LOG.debug("OSCache shutdowned.");
    }
  }

  public Object get(String paramString)
  {
    Object localObject = null;
    try
    {
      ExpirableContent localExpirableContent = (ExpirableContent)cache.getFromCache(paramString, this.refreshPeriod);
      if (localExpirableContent != null)
        if (localExpirableContent.isExpired())
          cache.flushEntry(paramString);
        else
          localObject = localExpirableContent.getContent();
    }
    catch (Exception localException)
    {
      cache.cancelUpdate(paramString);
    }
    return localObject;
  }

  public void put(String paramString, Object paramObject, Date paramDate)
  {
    cache.putInCache(paramString, new ExpirableContent(paramObject, paramDate), this.groups);
  }

  public void remove(String paramString)
  {
    cache.removeEntry(paramString);
  }

  public void clear()
  {
    cache.flushAll();
  }
}