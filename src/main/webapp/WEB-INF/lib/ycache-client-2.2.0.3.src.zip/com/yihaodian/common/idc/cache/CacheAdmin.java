package com.yihaodian.common.idc.cache;

import com.yihaodian.common.idc.IDCCommandUtil;
import com.yihaodian.common.ycache.memcache.IDCMemcacheProxyFactory;
import com.yihaodian.common.ycache.memcache.MemcacheAdmin;
import com.yihaodian.common.ycache.memcache.conf.MemcacheConfig;
import com.yihaodian.common.ycache.memcache.conf.MemcachePoolConfig;
import com.yihaodian.common.ycache.memcache.exception.MemcacheInitException;
import com.yihaodian.common.ycache.memcache.impl.BaseMemcacheProxy;
import com.yihaodian.common.yredis.client.RedisAdmin;
import com.yihaodian.common.yredis.client.YredisProxyFactory;
import com.yihaodian.common.yredis.client.conf.RedisConfig;
import com.yihaodian.common.yredis.client.conf.RedisPoolConfig;
import com.yihaodian.common.yredis.client.exception.RedisInitException;
import com.yihaodian.common.yredis.client.impl.BaseRedisProxy;
import com.yihaodian.configcentre.client.utils.YccGlobalPropertyConfigurer;
import com.yihaodian.configcentre.listener.YConfigurationDynamicBean;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class CacheAdmin
{
  private static Log logger = LogFactory.getLog(CacheAdmin.class);
  private static CacheAdmin instance = new CacheAdmin();
  Map<String, Future<BaseMemcacheProxy>> initMemcacheMap = new ConcurrentHashMap();
  Map<String, Future<BaseRedisProxy>> initRedisMap = new ConcurrentHashMap();
  Map<String, BaseMemcacheProxy> memcacheMap = new ConcurrentHashMap();
  Map<String, BaseRedisProxy> redisMap = new ConcurrentHashMap();
  MemcachePoolConfig defaultMemcachePoolConfig;
  RedisPoolConfig defaultRedisPoolConfig;
  static ExecutorService executorService = Executors.newSingleThreadExecutor();
  YConfigurationDynamicBean memcacheTemplateConfigurationDynamicBean;
  YConfigurationDynamicBean redisTemplateConfigurationDynamicBean;
  String memcacheConfigureTemplatePath;
  String redisConfigureTemplatePath;
  static Hashtable<String, String> IDCCommonProperties = null;

  public static void setDefaultConfig()
  {
  }

  public static CacheAdmin getInstance()
  {
    return instance;
  }

  public BaseMemcacheProxy getMemcacheProxy(String paramString)
  {
    BaseMemcacheProxy localBaseMemcacheProxy = (BaseMemcacheProxy)this.memcacheMap.get(paramString);
    if (localBaseMemcacheProxy == null)
      synchronized (this.memcacheMap)
      {
        localBaseMemcacheProxy = (BaseMemcacheProxy)this.memcacheMap.get(paramString);
        if (localBaseMemcacheProxy != null)
          break label67;
        label67: return ((BaseMemcacheProxy)createCacheProxy(paramString, this.memcacheMap, new Callable(this, paramString)
        {
          public BaseMemcacheProxy call()
            throws Exception
          {
            return this.this$0.createMemcacheConnection(this.val$poolName);
          }
        }));
      }
    return localBaseMemcacheProxy;
  }

  public BaseRedisProxy getRedisProxy(String paramString)
  {
    BaseRedisProxy localBaseRedisProxy = (BaseRedisProxy)this.redisMap.get(paramString);
    if (localBaseRedisProxy == null)
      synchronized (this.memcacheMap)
      {
        localBaseRedisProxy = (BaseRedisProxy)this.redisMap.get(paramString);
        if (localBaseRedisProxy != null)
          break label67;
        label67: return ((BaseRedisProxy)createCacheProxy(paramString, this.redisMap, new Callable(this, paramString)
        {
          public BaseRedisProxy call()
            throws Exception
          {
            return this.this$0.createRedisConnection(this.val$poolName);
          }
        }));
      }
    return localBaseRedisProxy;
  }

  public <T> T createCacheProxy(String paramString, Map<String, T> paramMap, Callable<T> paramCallable)
  {
    logger.info("start cacheProxy ,poolName is " + paramString);
    try
    {
      Object localObject = paramCallable.call();
      if (localObject != null)
      {
        paramMap.put(paramString, localObject);
        return localObject;
      }
    }
    catch (Exception localException)
    {
    }
    return null;
  }

  protected BaseMemcacheProxy createMemcacheConnection(String paramString)
  {
    MemcachePoolConfig localMemcachePoolConfig = null;
    try
    {
      localMemcachePoolConfig = (MemcachePoolConfig)BeanUtils.cloneBean(this.defaultMemcachePoolConfig);
    }
    catch (Exception localException)
    {
      logger.error("init default config fail. " + localException);
    }
    localMemcachePoolConfig.setPoolName(paramString);
    if (null == MemcacheAdmin.getInstance())
      IDCMemcacheProxyFactory.configure();
    MemcacheAdmin.addByConfig(localMemcachePoolConfig);
    IDCCommandUtil.setCommand_queue_size(MemcacheAdmin.getPoolConfig(paramString).getInvalidQueueSize());
    IDCCommandUtil.setCommand_add_key_timeout(MemcacheAdmin.getPoolConfig(paramString).getInvalidQueueTimeOut());
    IDCCommandUtil.setCommand_send_key_timeout(MemcacheAdmin.getPoolConfig(paramString).getInvalidBatchSendTimeOut());
    IDCCommandUtil.setCommand_batch_send_size(MemcacheAdmin.getPoolConfig(paramString).getInvaldiBatchSize());
    return MemcacheAdmin.getBaseProxy(paramString);
  }

  protected BaseRedisProxy createRedisConnection(String paramString)
    throws Exception
  {
    RedisPoolConfig localRedisPoolConfig = null;
    try
    {
      localRedisPoolConfig = (RedisPoolConfig)BeanUtils.cloneBean(this.defaultRedisPoolConfig);
    }
    catch (Exception localException)
    {
      logger.error(localException);
    }
    localRedisPoolConfig.setPoolName(paramString);
    logger.info("initializing pool " + paramString + "...");
    if (null == RedisAdmin.getInstance())
      YredisProxyFactory.configure();
    RedisAdmin.addByConfig(localRedisPoolConfig);
    IDCCommandUtil.setCommand_queue_size(RedisAdmin.getPoolConfig(paramString).getInvalidQueueSize());
    IDCCommandUtil.setCommand_add_key_timeout(RedisAdmin.getPoolConfig(paramString).getInvalidQueueTimeOut());
    IDCCommandUtil.setCommand_send_key_timeout(RedisAdmin.getPoolConfig(paramString).getInvalidBatchSendTimeOut());
    IDCCommandUtil.setCommand_batch_send_size(RedisAdmin.getPoolConfig(paramString).getInvaldiBatchSize());
    return new BaseRedisProxy(RedisAdmin.getBaseProxy(paramString));
  }

  public void reInitAll(String paramString1, String paramString2)
    throws MemcacheInitException, RedisInitException
  {
    logger.info("start reinit cache");
    shuddownAll();
    this.memcacheConfigureTemplatePath = paramString1;
    this.redisConfigureTemplatePath = paramString2;
    String str1 = YccGlobalPropertyConfigurer.loadConfigString("yihaodian/common", "idc_common.properties");
    IDCCommonProperties = YccGlobalPropertyConfigurer.loadProperties(str1);
    String str2 = (String)IDCCommonProperties.get("master_idc_invalid_no_ttl");
    if ((null != str2) && (str2.trim().equals("true")))
    {
      IDCCommandUtil.setInvalidNoTTL_master(true);
      logger.warn("enable setInvalidNoTTL_master");
    }
    initMemcacheConfig();
    initRedisConfig();
    logger.info("finish start reinit cache");
  }

  public static int getWeight(String paramString)
  {
    String str;
    if (IDCCommonProperties != null)
    {
      str = new String("weight_" + paramString);
      if (IDCCommonProperties.containsKey(str));
    }
    try
    {
      logger.warn(paramString + " set weight: " + ((String)IDCCommonProperties.get(str)));
      return Integer.parseInt((String)IDCCommonProperties.get(str));
    }
    catch (Exception localException)
    {
      logger.error(paramString + " get weight error. " + localException);
      logger.warn(paramString + " set default weight: 1");
    }
    return 1;
  }

  void initMemcacheConfig()
    throws MemcacheInitException, RedisInitException
  {
    logger.info("start reinit memcache");
    this.defaultMemcachePoolConfig = null;
    this.memcacheConfigureTemplatePath = this.memcacheConfigureTemplatePath.trim();
    logger.info("Load memcache configure from path: " + this.memcacheConfigureTemplatePath);
    try
    {
      Object localObject1;
      if (this.memcacheConfigureTemplatePath.startsWith("file:"))
      {
        localObject2 = this.memcacheConfigureTemplatePath.split("file:");
        localObject1 = new FileInputStream(localObject2[1]);
      }
      else if (this.memcacheConfigureTemplatePath.startsWith("classpath:"))
      {
        localObject2 = this.memcacheConfigureTemplatePath.split("classpath:");
        localObject1 = super.getClass().getClassLoader().getResourceAsStream(localObject2[1]);
      }
      else
      {
        localObject1 = super.getClass().getClassLoader().getResourceAsStream(this.memcacheConfigureTemplatePath);
      }
      Object localObject2 = MemcacheConfig.parseXmlConfig((InputStream)localObject1);
      this.defaultMemcachePoolConfig = ((MemcachePoolConfig)((MemcacheConfig)localObject2).getPoolConfigs().get(0));
    }
    catch (FileNotFoundException localFileNotFoundException)
    {
      logger.error(localFileNotFoundException);
      throw new MemcacheInitException("MemcacheProxyFactory#init() error:", localFileNotFoundException);
    }
    catch (Exception localException)
    {
      logger.error(localException);
      throw new MemcacheInitException("MemcacheProxyFactory#init() error:", localException);
    }
    if (this.memcacheTemplateConfigurationDynamicBean == null);
    logger.info("finish start reinit memcache");
  }

  void initRedisConfig()
    throws MemcacheInitException, RedisInitException
  {
    logger.info("start reinit rediscache");
    this.defaultRedisPoolConfig = null;
    this.redisConfigureTemplatePath = this.redisConfigureTemplatePath.trim();
    logger.info("Load redis configure from path: " + this.redisConfigureTemplatePath);
    try
    {
      Object localObject1;
      if (this.redisConfigureTemplatePath.startsWith("file:"))
      {
        localObject2 = this.redisConfigureTemplatePath.split("file:");
        localObject1 = new FileInputStream(localObject2[1]);
      }
      else if (this.redisConfigureTemplatePath.startsWith("classpath:"))
      {
        localObject2 = this.redisConfigureTemplatePath.split("classpath:");
        localObject1 = super.getClass().getClassLoader().getResourceAsStream(localObject2[1]);
      }
      else
      {
        localObject1 = super.getClass().getClassLoader().getResourceAsStream(this.redisConfigureTemplatePath);
      }
      Object localObject2 = RedisConfig.parseXmlConfig((InputStream)localObject1);
      this.defaultRedisPoolConfig = ((RedisPoolConfig)((RedisConfig)localObject2).getPoolConfigs().get(0));
      logger.info("End to init redis pools<<----");
    }
    catch (FileNotFoundException localFileNotFoundException)
    {
      logger.error(localFileNotFoundException);
      throw new RedisInitException("RedisProxyFactory#init() error:", localFileNotFoundException);
    }
    catch (Exception localException)
    {
      logger.error(localException);
      throw new RedisInitException("RedisProxyFactory#init() error:", localException);
    }
    if (this.redisTemplateConfigurationDynamicBean == null);
    logger.info("finish start reinit rediscache");
  }

  public void shuddownAll()
  {
    logger.info("finish stop  all cache ");
  }
}