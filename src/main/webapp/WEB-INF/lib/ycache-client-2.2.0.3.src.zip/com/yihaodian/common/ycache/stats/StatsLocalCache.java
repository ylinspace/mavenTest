package com.yihaodian.common.ycache.stats;

public class StatsLocalCache
{
  private String key;
  private Object value;
  private long timeOut;
  private boolean expired;

  public StatsLocalCache()
  {
  }

  public StatsLocalCache(String paramString1, String paramString2, long paramLong, boolean paramBoolean)
  {
    this.key = paramString1;
    this.value = paramString2;
    this.timeOut = paramLong;
    this.expired = paramBoolean;
  }

  public String getKey()
  {
    return this.key;
  }

  public long getTimeOut()
  {
    return this.timeOut;
  }

  public Object getValue()
  {
    return this.value;
  }

  public void setKey(String paramString)
  {
    this.key = paramString;
  }

  public void setTimeOut(long paramLong)
  {
    this.timeOut = paramLong;
  }

  public void setValue(Object paramObject)
  {
    this.value = paramObject;
  }

  public boolean isExpired()
  {
    return this.expired;
  }

  public void setExpired(boolean paramBoolean)
  {
    this.expired = paramBoolean;
  }
}