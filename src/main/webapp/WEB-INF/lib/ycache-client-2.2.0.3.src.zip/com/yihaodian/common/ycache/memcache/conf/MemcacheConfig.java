package com.yihaodian.common.ycache.memcache.conf;

import com.yihaodian.common.ycache.memcache.exception.MemcacheInitException;
import com.yihaodian.common.ycache.util.YMemcachedProxyUtil;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

public class MemcacheConfig
{
  protected static Log logger = LogFactory.getLog(MemcacheConfig.class);
  List<MemcachePoolConfig> poolConfigs = new ArrayList();
  private static Map<String, String> masterIDCMap = new ConcurrentHashMap();

  public static MemcacheConfig parseXmlConfig(InputStream paramInputStream)
    throws MemcacheInitException
  {
    MemcacheConfig localMemcacheConfig = new MemcacheConfig();
    SAXReader localSAXReader = new SAXReader();
    try
    {
      Document localDocument = localSAXReader.read(paramInputStream);
      Element localElement = localDocument.getRootElement();
      Iterator localIterator = localElement.elementIterator("pool");
      while (localIterator.hasNext())
      {
        MemcachePoolConfig localMemcachePoolConfig = parseXmlPoolNode((Element)localIterator.next(), localMemcacheConfig);
        localMemcacheConfig.addPoolConfig(localMemcachePoolConfig);
      }
    }
    catch (DocumentException localDocumentException)
    {
      throw new MemcacheInitException("memcache config document parse error:" + localDocumentException);
    }
    catch (Exception localException)
    {
      throw new MemcacheInitException("memcache config parse error:" + localException);
    }
    return localMemcacheConfig;
  }

  private static MemcachePoolConfig parseXmlPoolNode(Element paramElement, MemcacheConfig paramMemcacheConfig)
    throws MemcacheInitException
  {
    MemcachePoolConfig localMemcachePoolConfig = new MemcachePoolConfig();
    try
    {
      localMemcachePoolConfig.setMasterIDC(XmlParser.parseAttr(paramElement, "masterIDC"));
    }
    catch (Exception localException1)
    {
      localMemcachePoolConfig.setMasterIDC(null);
    }
    String str1 = XmlParser.parseAttr(paramElement, "id");
    if (StringUtils.isNotBlank(localMemcachePoolConfig.getMasterIDC()))
    {
      localMemcachePoolConfig.setPoolName(YMemcachedProxyUtil.generateMasterPoolName(str1, localMemcachePoolConfig.getMasterIDC()));
      masterIDCMap.put(str1, localMemcachePoolConfig.getMasterIDC());
    }
    else
    {
      localMemcachePoolConfig.setPoolName(str1);
    }
    localMemcachePoolConfig.setInitConn(XmlParser.parseIntAttr(paramElement, "initConn").intValue());
    localMemcachePoolConfig.setMinConn(XmlParser.parseIntAttr(paramElement, "minConn").intValue());
    localMemcachePoolConfig.setMaxConn(XmlParser.parseIntAttr(paramElement, "maxConn").intValue());
    localMemcachePoolConfig.setMaintSleep(XmlParser.parseLongAttr(paramElement, "maintSleep").longValue());
    localMemcachePoolConfig.setSocketTo(XmlParser.parseIntAttr(paramElement, "socketTO").intValue());
    localMemcachePoolConfig.setSocketConnTo(XmlParser.parseIntAttr(paramElement, "socketConnectTO").intValue());
    localMemcachePoolConfig.setDefaultExpiryMinutes(XmlParser.parseIntAttr(paramElement, "defaultExpiryMinutes").intValue());
    localMemcachePoolConfig.setCompressEnable(XmlParser.parseBooleanAttr(paramElement, "compressEnable"));
    try
    {
      localMemcachePoolConfig.setVersionEnable(XmlParser.parseBooleanAttr(paramElement, "versionEnable"));
    }
    catch (Exception localException2)
    {
      localMemcachePoolConfig.setVersionEnable(true);
    }
    try
    {
      localMemcachePoolConfig.setJDK(XmlParser.parseBooleanAttr(paramElement, "isJDK"));
    }
    catch (Exception localException3)
    {
      localMemcachePoolConfig.setJDK(false);
    }
    localMemcachePoolConfig.setCompressThreshold(XmlParser.parseIntAttr(paramElement, "compressThreshold").intValue());
    try
    {
      String str2 = paramElement.attributeValue("maxBusyTime");
      if ((str2 == null) || (str2.equalsIgnoreCase("")))
        localMemcachePoolConfig.setMaxBusyTime(30000L);
      else
        localMemcachePoolConfig.setMaxBusyTime(XmlParser.parseLongAttr(paramElement, "maxBusyTime").longValue());
    }
    catch (Exception localException4)
    {
      localMemcachePoolConfig.setMaxBusyTime(30000L);
    }
    try
    {
      localMemcachePoolConfig.setInvalidAuto(XmlParser.parseBooleanAttr(paramElement, "invalidAuto"));
    }
    catch (Exception localException5)
    {
    }
    try
    {
      localMemcachePoolConfig.setInvalidTTLMillisecond(XmlParser.parseIntAttr(paramElement, "invalidTTL").intValue());
    }
    catch (Exception localException6)
    {
    }
    try
    {
      localMemcachePoolConfig.setInvalidQueueTimeOut(XmlParser.parseIntAttr(paramElement, "invalidQueueTimeOut").intValue());
    }
    catch (Exception localException7)
    {
    }
    try
    {
      localMemcachePoolConfig.setNoreply(XmlParser.parseBooleanAttr(paramElement, "noreply"));
    }
    catch (Exception localException8)
    {
    }
    try
    {
      localMemcachePoolConfig.setSyncTime(XmlParser.parseIntAttr(paramElement, "syncTime").intValue());
    }
    catch (Exception localException9)
    {
    }
    try
    {
      localMemcachePoolConfig.setPoolVersion(XmlParser.parseAttr(paramElement, "poolVersion"));
    }
    catch (Exception localException10)
    {
    }
    try
    {
      localMemcachePoolConfig.setSendEmailInterval(XmlParser.parseIntAttr(paramElement, "sendEmailInterval").intValue());
    }
    catch (Exception localException11)
    {
    }
    try
    {
      localMemcachePoolConfig.setInvalidQueueTimeOut(XmlParser.parseIntAttr(paramElement, "invalidQueueTimeOut").intValue());
    }
    catch (Exception localException12)
    {
    }
    try
    {
      localMemcachePoolConfig.setInvalidQueueSize(XmlParser.parseIntAttr(paramElement, "invalidQueueSize").intValue());
    }
    catch (Exception localException13)
    {
    }
    try
    {
      localMemcachePoolConfig.setInvaldiBatchSize(XmlParser.parseIntAttr(paramElement, "invaldiBatchSize").intValue());
    }
    catch (Exception localException14)
    {
    }
    try
    {
      localMemcachePoolConfig.setInvalidBatchSendTimeOut(XmlParser.parseIntAttr(paramElement, "invalidBatchSendTimeOut").intValue());
    }
    catch (Exception localException15)
    {
    }
    try
    {
      localMemcachePoolConfig.setZkGroup(XmlParser.parseAttr(paramElement, "zkGroup"));
    }
    catch (Exception localException16)
    {
    }
    if (localMemcachePoolConfig.getMinConn() > 5)
      logger.warn("The mini connect number is too large, we suggest less than 5!");
    if (localMemcachePoolConfig.isVersionEnable())
      logger.warn("The version affixed is enabled, make sure u know what u r doing.!");
    if (localMemcachePoolConfig.getSocketTo() < 1000)
      logger.warn("The socket time out is less than 1s, make sure u know what u r doing.!");
    if (localMemcachePoolConfig.getSocketConnTo() < 1000)
      logger.warn("The socket connect time out is less than 1s, make sure u know what u r doing.!");
    if (localMemcachePoolConfig.isNoreply())
      logger.warn("The no reply mode is enabled for memcached, make sure u know what u r doing.!");
    if (localMemcachePoolConfig.isInvalidAuto())
      logger.warn("The auto invalid mode is enabled, make sure u know what u r doing.!");
    if (StringUtils.isNotBlank(localMemcachePoolConfig.getZkGroup()))
      logger.warn("The zookeeper group is changed, make sure u know what u r doing.!");
    if (StringUtils.isNotBlank(localMemcachePoolConfig.getMasterIDC()))
      logger.warn("The master idc is specified, make sure u know what u r doing.!");
    return localMemcachePoolConfig;
  }

  public List<MemcachePoolConfig> getPoolConfigs()
  {
    return this.poolConfigs;
  }

  public MemcachePoolConfig getPoolConfig(String paramString)
  {
    Iterator localIterator = this.poolConfigs.iterator();
    while (localIterator.hasNext())
    {
      MemcachePoolConfig localMemcachePoolConfig = (MemcachePoolConfig)localIterator.next();
      if (localMemcachePoolConfig.getPoolName().equals(paramString))
        return localMemcachePoolConfig;
    }
    return null;
  }

  public void addPoolConfig(MemcachePoolConfig paramMemcachePoolConfig)
  {
    this.poolConfigs.add(paramMemcachePoolConfig);
  }

  public static Map<String, String> getMasterIDCMap()
  {
    return masterIDCMap;
  }
}