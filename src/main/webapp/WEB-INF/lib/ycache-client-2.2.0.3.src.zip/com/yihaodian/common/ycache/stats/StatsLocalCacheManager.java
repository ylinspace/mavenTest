package com.yihaodian.common.ycache.stats;

import java.util.Date;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class StatsLocalCacheManager
{
  private static Map<String, StatsLocalCache> cacheMap = new ConcurrentHashMap();

  private static StatsLocalCache getCache(String paramString)
  {
    return ((StatsLocalCache)cacheMap.get(paramString));
  }

  private static boolean hasCache(String paramString)
  {
    return cacheMap.containsKey(paramString);
  }

  public static void invalidateAll()
  {
    cacheMap.clear();
  }

  public static void invalidate(String paramString)
  {
    cacheMap.remove(paramString);
  }

  private static void putCache(String paramString, StatsLocalCache paramStatsLocalCache)
  {
    cacheMap.put(paramString, paramStatsLocalCache);
  }

  public static StatsLocalCache getContent(String paramString)
  {
    if (hasCache(paramString))
    {
      StatsLocalCache localStatsLocalCache = getCache(paramString);
      if (cacheExpired(localStatsLocalCache))
      {
        invalidate(paramString);
        return null;
      }
      return localStatsLocalCache;
    }
    return null;
  }

  public static void putContent(String paramString, Object paramObject, long paramLong)
  {
    StatsLocalCache localStatsLocalCache = new StatsLocalCache();
    localStatsLocalCache.setKey(paramString);
    localStatsLocalCache.setValue(paramObject);
    localStatsLocalCache.setTimeOut(paramLong + new Date().getTime());
    localStatsLocalCache.setExpired(false);
    putCache(paramString, localStatsLocalCache);
  }

  private static boolean cacheExpired(StatsLocalCache paramStatsLocalCache)
  {
    if (paramStatsLocalCache == null)
      return false;
    long l1 = new Date().getTime();
    long l2 = paramStatsLocalCache.getTimeOut();
    if (l2 < -6318802602234478592L)
      return false;
    return (l1 >= l2);
  }
}