package com.yihaodian.common.yredis.client.conf;

import com.yihaodian.arc.cache.zk.ZKRedisProxy;
import java.util.HashMap;
import java.util.Map;

public class RedisPoolConfig
{
  private String poolName;
  private int maxActive;
  private int maxWait;
  private int maxIdle;
  private int minIdle;
  private boolean testOnBorrow = true;
  private boolean testOnReturn = true;
  private int defaultExpiryMinutes;
  private boolean versionEnable = true;
  public Map<String, Integer> servers = new HashMap();
  private String zkGroup;
  private boolean noreply = false;
  private boolean invalidAuto = false;
  private int invalidTTLMillisecond = 2000;
  private int invalidQueueTimeOut = 10;
  private int invalidQueueSize = 10000;
  private int invalidBatchSendTimeOut = 100;
  private int invaldiBatchSize = 10;
  public ZKRedisProxy zkClient = null;
  public static final int NOTEXIST = 0;
  public static final int NORMAL = 1;
  public static final int SLAVE = 2;
  public static final int DISCONNECT = 3;

  public int getDefaultExpiryMinutes()
  {
    return this.defaultExpiryMinutes;
  }

  public void setDefaultExpiryMinutes(int paramInt)
  {
    this.defaultExpiryMinutes = paramInt;
  }

  public boolean isVersionEnable()
  {
    return this.versionEnable;
  }

  public void setVersionEnable(boolean paramBoolean)
  {
    this.versionEnable = paramBoolean;
  }

  public String getPoolName()
  {
    return this.poolName;
  }

  public void setPoolName(String paramString)
  {
    this.poolName = paramString;
  }

  public int getMaxActive()
  {
    return this.maxActive;
  }

  public void setMaxActive(int paramInt)
  {
    this.maxActive = paramInt;
  }

  public int getMaxWait()
  {
    return this.maxWait;
  }

  public void setMaxWait(int paramInt)
  {
    this.maxWait = paramInt;
  }

  public int getMaxIdle()
  {
    return this.maxIdle;
  }

  public void setMaxIdle(int paramInt)
  {
    this.maxIdle = paramInt;
  }

  public int getMinIdle()
  {
    return this.minIdle;
  }

  public void setMinIdle(int paramInt)
  {
    this.minIdle = paramInt;
  }

  public boolean isTestOnBorrow()
  {
    return this.testOnBorrow;
  }

  public void setTestOnBorrow(boolean paramBoolean)
  {
    this.testOnBorrow = paramBoolean;
  }

  public boolean isTestOnReturn()
  {
    return this.testOnReturn;
  }

  public void setTestOnReturn(boolean paramBoolean)
  {
    this.testOnReturn = paramBoolean;
  }

  public String getZkGroup()
  {
    return this.zkGroup;
  }

  public void setZkGroup(String paramString)
  {
    this.zkGroup = paramString;
  }

  public Map<String, Integer> getServers()
  {
    return this.servers;
  }

  public void addServers(String paramString, int paramInt1, int paramInt2)
  {
    this.servers.put(paramString + ":" + paramInt1, Integer.valueOf(paramInt2));
  }

  public void addServers(String paramString, int paramInt)
  {
    this.servers.put(paramString, Integer.valueOf(paramInt));
  }

  public void delServers(String paramString, int paramInt)
  {
    if (this.servers.containsKey(paramString + ":" + paramInt))
      this.servers.remove(paramString + ":" + paramInt);
  }

  public int getServersStatus(String paramString, int paramInt)
  {
    if (this.servers.containsKey(paramString + ":" + paramInt))
      return ((Integer)this.servers.get(paramString + ":" + paramInt)).intValue();
    return 0;
  }

  public boolean isInvalidAuto()
  {
    return this.invalidAuto;
  }

  public void setInvalidAuto(boolean paramBoolean)
  {
    this.invalidAuto = paramBoolean;
  }

  public int getInvalidTTLMillisecond()
  {
    return this.invalidTTLMillisecond;
  }

  public void setInvalidTTLMillisecond(int paramInt)
  {
    this.invalidTTLMillisecond = paramInt;
  }

  public int getInvalidQueueTimeOut()
  {
    return this.invalidQueueTimeOut;
  }

  public void setInvalidQueueTimeOut(int paramInt)
  {
    this.invalidQueueTimeOut = paramInt;
  }

  public int getInvalidQueueSize()
  {
    return this.invalidQueueSize;
  }

  public void setInvalidQueueSize(int paramInt)
  {
    this.invalidQueueSize = paramInt;
  }

  public int getInvaldiBatchSize()
  {
    return this.invaldiBatchSize;
  }

  public void setInvaldiBatchSize(int paramInt)
  {
    this.invaldiBatchSize = paramInt;
  }

  public int getInvalidBatchSendTimeOut()
  {
    return this.invalidBatchSendTimeOut;
  }

  public void setInvalidBatchSendTimeOut(int paramInt)
  {
    this.invalidBatchSendTimeOut = paramInt;
  }
}