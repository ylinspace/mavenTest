package com.yihaodian.arc.cache.zk;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.apache.commons.lang.StringUtils;

public class NutcrackerConfigParser
{
  private static final String BLANK = " ";
  private static final String COLON = ":";
  public static final String ENTER = "\n";
  private static final String SHARP = "#";
  private static final String MINUS = "-";
  private Map<String, Set<String>> pools = new HashMap();

  public void parse(String paramString)
  {
    if (StringUtils.isNotBlank(paramString))
    {
      String[] arrayOfString1 = StringUtils.split(paramString, "\n");
      int i = 0;
      Object localObject = null;
      String str1 = "";
      String[] arrayOfString2 = arrayOfString1;
      int j = arrayOfString2.length;
      for (int k = 0; k < j; ++k)
      {
        String str2 = arrayOfString2[k];
        if (StringUtils.isNotBlank(str2))
        {
          if ((!(StringUtils.startsWith(str2, " "))) && (StringUtils.startsWith(str2, "#")))
            i = 1;
          else if (!(StringUtils.startsWith(str2, " ")))
            i = 0;
          if (i != 0)
            break label229:
          if (!(StringUtils.startsWith(str2, " ")))
          {
            str1 = StringUtils.trim(StringUtils.substringBefore(str2, ":"));
            localObject = (Set)this.pools.get(str1);
            if (localObject == null)
            {
              localObject = new HashSet();
              label229: this.pools.put(str1, localObject);
            }
          }
          else
          {
            str2 = StringUtils.trim(str2);
            if (StringUtils.startsWith(str2, "-"))
            {
              str2 = StringUtils.substringAfter(str2, "-");
              str2 = StringUtils.substringBeforeLast(str2, ":");
              str2 = StringUtils.trim(str2);
              if (StringUtils.isNotBlank(str2))
                ((Set)localObject).add(str2);
            }
          }
        }
      }
    }
  }

  public List<String> getServerAddr(String paramString)
  {
    ArrayList localArrayList = new ArrayList();
    Set localSet = (Set)this.pools.get(paramString);
    if (localSet != null)
      localArrayList.addAll(localSet);
    return localArrayList;
  }
}