package com.yihaodian.common.ycache.util;

import java.security.MessageDigest;

public class MD5Support
{
  private static char[] hexDigits = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f' };

  public static final String MD5(String paramString)
  {
    byte[] arrayOfByte1;
    try
    {
      arrayOfByte1 = paramString.getBytes("UTF-8");
      MessageDigest localMessageDigest = MessageDigest.getInstance("MD5");
      localMessageDigest.update(arrayOfByte1);
      byte[] arrayOfByte2 = localMessageDigest.digest();
      int i = arrayOfByte2.length;
      char[] arrayOfChar = new char[i * 2];
      int j = 0;
      for (int k = 0; k < i; ++k)
      {
        int l = arrayOfByte2[k];
        arrayOfChar[(j++)] = hexDigits[(l >>> 4 & 0xF)];
        arrayOfChar[(j++)] = hexDigits[(l & 0xF)];
      }
      return new String(arrayOfChar);
    }
    catch (Exception localException)
    {
    }
    return null;
  }

  public static final String MD5(String paramString1, String paramString2)
  {
    try
    {
      byte[] arrayOfByte1;
      if (paramString2 != null)
        arrayOfByte1 = paramString1.getBytes(paramString2);
      else
        arrayOfByte1 = paramString1.getBytes();
      MessageDigest localMessageDigest = MessageDigest.getInstance("MD5");
      localMessageDigest.update(arrayOfByte1);
      byte[] arrayOfByte2 = localMessageDigest.digest();
      int i = arrayOfByte2.length;
      char[] arrayOfChar = new char[i * 2];
      int j = 0;
      for (int k = 0; k < i; ++k)
      {
        int l = arrayOfByte2[k];
        arrayOfChar[(j++)] = hexDigits[(l >>> 4 & 0xF)];
        arrayOfChar[(j++)] = hexDigits[(l & 0xF)];
      }
      return new String(arrayOfChar);
    }
    catch (Exception localException)
    {
    }
    return null;
  }
}