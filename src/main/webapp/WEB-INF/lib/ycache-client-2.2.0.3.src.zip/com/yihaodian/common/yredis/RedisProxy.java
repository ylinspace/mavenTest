package com.yihaodian.common.yredis;

import com.ycache.redis.clients.jedis.BinaryClient.LIST_POSITION;
import com.ycache.redis.clients.jedis.Jedis;
import com.ycache.redis.clients.jedis.JedisPubSub;
import com.ycache.redis.clients.jedis.ShardedJedisPipelineUtils;
import java.util.List;
import java.util.Map;
import java.util.Set;

public abstract interface RedisProxy
{
  public abstract ShardedJedisPipelineUtils buildPipelineUtils();

  public abstract long rpush(String paramString1, String paramString2);

  public abstract long rpush(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);

  public abstract long lpush(String paramString1, String paramString2);

  public abstract long lpush(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);

  public abstract long rpushx(String paramString1, String paramString2);

  public abstract long rpushx(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);

  public abstract long lpushx(String paramString1, String paramString2);

  public abstract long lpushx(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);

  public abstract long sadd(String paramString, String[] paramArrayOfString);

  public abstract long sadd(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1);

  public abstract String lpop(String paramString);

  public abstract byte[] lpop(byte[] paramArrayOfByte);

  public abstract String rpop(String paramString);

  public abstract byte[] rpop(byte[] paramArrayOfByte);

  public abstract String lindex(String paramString, long paramLong);

  public abstract byte[] lindex(byte[] paramArrayOfByte, long paramLong);

  public abstract Long linsert(String paramString1, BinaryClient.LIST_POSITION paramLIST_POSITION, String paramString2, String paramString3);

  public abstract Long linsert(byte[] paramArrayOfByte1, BinaryClient.LIST_POSITION paramLIST_POSITION, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3);

  public abstract String lset(String paramString1, long paramLong, String paramString2);

  public abstract String lset(byte[] paramArrayOfByte1, long paramLong, byte[] paramArrayOfByte2);

  public abstract long llen(String paramString);

  public abstract long llen(byte[] paramArrayOfByte);

  public abstract long lrem(String paramString1, long paramLong, String paramString2);

  public abstract long lrem(byte[] paramArrayOfByte1, long paramLong, byte[] paramArrayOfByte2);

  public abstract String ltrim(String paramString, long paramLong1, long paramLong2);

  public abstract String ltrim(byte[] paramArrayOfByte, long paramLong1, long paramLong2);

  public abstract List<String> lrange(String paramString, long paramLong1, long paramLong2);

  public abstract List<byte[]> lrange(byte[] paramArrayOfByte, long paramLong1, long paramLong2);

  public abstract Long hset(String paramString1, String paramString2, String paramString3);

  public abstract Long hset(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3);

  public abstract String set(String paramString1, String paramString2);

  public abstract String get(String paramString);

  public abstract String set(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);

  public abstract byte[] get(byte[] paramArrayOfByte);

  public abstract String compressSet(String paramString1, String paramString2);

  public abstract String compressGet(String paramString);

  public abstract String compressSet(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);

  public abstract byte[] compressGet(byte[] paramArrayOfByte);

  public abstract long ttl(String paramString);

  public abstract long ttl(byte[] paramArrayOfByte);

  public abstract long del(String paramString);

  public abstract long del(byte[] paramArrayOfByte);

  public abstract String hmset(String paramString, Map<String, String> paramMap);

  public abstract String hmset(byte[] paramArrayOfByte, Map<byte[], byte[]> paramMap);

  public abstract String setex(String paramString1, int paramInt, String paramString2);

  public abstract String setex(byte[] paramArrayOfByte1, int paramInt, byte[] paramArrayOfByte2);

  public abstract long setnx(String paramString1, String paramString2);

  public abstract long setnx(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);

  public abstract String compressSetex(String paramString1, int paramInt, String paramString2);

  public abstract String compressSetex(byte[] paramArrayOfByte1, int paramInt, byte[] paramArrayOfByte2);

  public abstract long compressSetnx(String paramString1, String paramString2);

  public abstract long compressSetnx(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);

  public abstract Long expire(String paramString, int paramInt);

  public abstract Long expire(byte[] paramArrayOfByte, int paramInt);

  public abstract Long expireAt(String paramString, long paramLong);

  public abstract Long expireAt(byte[] paramArrayOfByte, long paramLong);

  public abstract boolean exists(String paramString);

  public abstract boolean exists(byte[] paramArrayOfByte);

  public abstract String type(String paramString);

  public abstract String type(byte[] paramArrayOfByte);

  public abstract String hget(String paramString1, String paramString2);

  public abstract byte[] hget(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);

  public abstract Map<String, String> hgetAll(String paramString);

  public abstract Map<byte[], byte[]> hgetAll(byte[] paramArrayOfByte);

  public abstract Map<String, String> hgetAll(String paramString, boolean paramBoolean);

  public abstract Map<byte[], byte[]> hgetAll(byte[] paramArrayOfByte, boolean paramBoolean);

  public abstract Map<String, String> hgetAllToLinkedHashMap(String paramString);

  public abstract Map<byte[], byte[]> hgetAllToLinkedHashMap(byte[] paramArrayOfByte);

  public abstract Set<String> smembers(String paramString);

  public abstract Set<byte[]> smembers(byte[] paramArrayOfByte);

  public abstract Long srem(String paramString, String[] paramArrayOfString);

  public abstract Long srem(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1);

  public abstract Long scard(String paramString);

  public abstract Long scard(byte[] paramArrayOfByte);

  public abstract String spop(String paramString);

  public abstract byte[] spop(byte[] paramArrayOfByte);

  public abstract String srandmember(String paramString);

  public abstract byte[] srandmember(byte[] paramArrayOfByte);

  public abstract boolean sismember(String paramString1, String paramString2);

  public abstract boolean sismember(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);

  public abstract Long append(String paramString1, String paramString2);

  public abstract Long append(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);

  public abstract Long decr(String paramString);

  public abstract Long decr(byte[] paramArrayOfByte);

  public abstract Long decrBy(String paramString, Integer paramInteger);

  public abstract Long decrBy(byte[] paramArrayOfByte, Integer paramInteger);

  public abstract String getrange(String paramString, int paramInt1, int paramInt2);

  public abstract byte[] getrange(byte[] paramArrayOfByte, int paramInt1, int paramInt2);

  public abstract String getSet(String paramString1, String paramString2);

  public abstract byte[] getSet(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);

  public abstract String compressGetSet(String paramString1, String paramString2);

  public abstract byte[] compressGetSet(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);

  public abstract Long hdel(String paramString, String[] paramArrayOfString);

  public abstract Long hdel(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1);

  public abstract Boolean hexists(String paramString1, String paramString2);

  public abstract Boolean hexists(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);

  public abstract Long hincrBy(String paramString1, String paramString2, int paramInt);

  public abstract Long hincrBy(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, int paramInt);

  public abstract Set<String> hkeys(String paramString);

  public abstract Set<byte[]> hkeys(byte[] paramArrayOfByte);

  public abstract Long hlen(String paramString);

  public abstract Long hlen(byte[] paramArrayOfByte);

  public abstract List<String> hmget(String paramString, String[] paramArrayOfString);

  public abstract List<byte[]> hmget(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1);

  public abstract Long hsetnx(String paramString1, String paramString2, String paramString3);

  public abstract Long hsetnx(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3);

  public abstract List<String> hvals(String paramString);

  public abstract List<byte[]> hvals(byte[] paramArrayOfByte);

  public abstract Long incr(String paramString);

  public abstract Long incr(byte[] paramArrayOfByte);

  public abstract boolean electioneer(String paramString1, String paramString2, int paramInt);

  public abstract boolean electioneer(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, int paramInt);

  public abstract Long incrBy(String paramString, int paramInt);

  public abstract Long incrBy(byte[] paramArrayOfByte, int paramInt);

  public abstract void subscribe(String paramString, JedisPubSub paramJedisPubSub, String[] paramArrayOfString);

  public abstract void subscribe(byte[] paramArrayOfByte, JedisPubSub paramJedisPubSub, String[] paramArrayOfString);

  public abstract void publish(String paramString1, String paramString2, String paramString3);

  public abstract void publish(byte[] paramArrayOfByte, String paramString1, String paramString2);

  public abstract Jedis getJedisByShardKey(String paramString);

  public abstract Jedis getJedisByShardKey(byte[] paramArrayOfByte);

  public abstract int getShardIndex(String paramString1, String paramString2);

  public abstract int getShardIndex(String paramString, byte[] paramArrayOfByte);
}