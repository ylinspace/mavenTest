package com.yihaodian.common.yredis.client.interceptor;

import com.ycache.redis.clients.jedis.BinaryClient.LIST_POSITION;
import com.ycache.redis.clients.jedis.Builder;
import com.ycache.redis.clients.jedis.Client;
import com.ycache.redis.clients.jedis.Jedis;
import com.ycache.redis.clients.jedis.JedisPubSub;
import com.ycache.redis.clients.jedis.JedisShardInfo;
import com.ycache.redis.clients.jedis.ShardedJedis;
import com.ycache.redis.clients.jedis.ShardedJedisPipelineUtils;
import com.ycache.redis.clients.jedis.ShardedJedisPool;
import com.ycache.redis.clients.jedis.exceptions.JedisDataException;
import com.ycache.redis.clients.jedis.exceptions.JedisException;
import com.ycache.redis.clients.util.Hashing;
import com.ycache.redis.clients.util.SafeEncoder;
import com.yihaodian.common.ycache.stats.StatsLocalCache;
import com.yihaodian.common.ycache.stats.StatsLocalCacheManager;
import com.yihaodian.common.yredis.client.RedisAdmin;
import com.yihaodian.common.yredis.client.RedisInterceptor;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;
import org.apache.log4j.Logger;

public class RedisCoreInterceptor
  implements RedisInterceptor
{
  private static final Logger log = Logger.getLogger(RedisCoreInterceptor.class);
  public static final Builder<Map<byte[], byte[]>> BYTE_LINKEDHASHMAP = new Builder()
  {
    public Map<byte[], byte[]> build(Object paramObject)
    {
      List localList = (List)paramObject;
      LinkedHashMap localLinkedHashMap = new LinkedHashMap();
      Iterator localIterator = localList.iterator();
      while (localIterator.hasNext())
        localLinkedHashMap.put(localIterator.next(), localIterator.next());
      return localLinkedHashMap;
    }

    public String toString()
    {
      return "Map<byte[], byte[]>";
    }
  };
  public static final Builder<Map<String, String>> STRING_LINKEDHASHMAP = new Builder()
  {
    public Map<String, String> build(Object paramObject)
    {
      List localList = (List)paramObject;
      LinkedHashMap localLinkedHashMap = new LinkedHashMap();
      Iterator localIterator = localList.iterator();
      while (localIterator.hasNext())
        localLinkedHashMap.put(SafeEncoder.encode((byte[])localIterator.next()), SafeEncoder.encode((byte[])localIterator.next()));
      return localLinkedHashMap;
    }

    public String toString()
    {
      return "Map<String, String>";
    }
  };

  public RedisInterceptor getNextHandler()
  {
    return null;
  }

  public void setNextHandler(RedisInterceptor paramRedisInterceptor)
  {
  }

  protected ShardedJedisPool getShardedJedisPool(String paramString)
  {
    return RedisAdmin.getBaseProxy(paramString);
  }

  public synchronized void incrCounter(String paramString, int paramInt)
  {
    StatsLocalCache localStatsLocalCache = StatsLocalCacheManager.getContent(paramString);
    if (localStatsLocalCache != null)
    {
      Integer localInteger = (Integer)localStatsLocalCache.getValue();
      localInteger = Integer.valueOf(localInteger.intValue() + paramInt);
      localStatsLocalCache.setValue(localInteger);
    }
  }

  public ShardedJedisPipelineUtils buildPipelineUtils(String paramString)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString);
    if (localShardedJedisPool == null)
      return null;
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    ShardedJedisPipelineUtils localShardedJedisPipelineUtils = new ShardedJedisPipelineUtils(localShardedJedisPool, localShardedJedis);
    return localShardedJedisPipelineUtils;
  }

  public void returnResource(ShardedJedisPool paramShardedJedisPool, ShardedJedis paramShardedJedis)
  {
    if (paramShardedJedis == null)
      return;
    try
    {
      paramShardedJedisPool.returnResource(paramShardedJedis);
    }
    catch (Exception localException)
    {
      log.error(localException.getMessage(), localException);
    }
  }

  public void returnBrokenResource(ShardedJedisPool paramShardedJedisPool, ShardedJedis paramShardedJedis)
  {
    if (paramShardedJedis == null)
      return;
    try
    {
      paramShardedJedisPool.returnBrokenResource(paramShardedJedis);
    }
    catch (Exception localException)
    {
      log.error(localException.getMessage(), localException);
    }
    finally
    {
      RedisAdmin.fastFix(paramShardedJedisPool.getPoolName());
    }
  }

  public long rpush(String paramString1, String paramString2, String paramString3)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString1);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    long l = -6318801846320234496L;
    try
    {
      l = localShardedJedis.rpush(paramString2, new String[] { paramString3 }).longValue();
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return l;
  }

  public long rpush(String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    long l = -6318801846320234496L;
    try
    {
      l = localShardedJedis.rpush(paramArrayOfByte1, new byte[][] { paramArrayOfByte2 }).longValue();
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return l;
  }

  public long lpush(String paramString1, String paramString2, String paramString3)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString1);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    long l = -6318801846320234496L;
    try
    {
      l = localShardedJedis.lpush(paramString2, new String[] { paramString3 }).longValue();
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return l;
  }

  public long lpush(String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    long l = -6318801846320234496L;
    try
    {
      l = localShardedJedis.lpush(paramArrayOfByte1, new byte[][] { paramArrayOfByte2 }).longValue();
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return l;
  }

  public long rpushx(String paramString1, String paramString2, String paramString3)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString1);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    long l = -6318801846320234496L;
    try
    {
      l = localShardedJedis.rpushx(paramString2, new String[] { paramString3 }).longValue();
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return l;
  }

  public long rpushx(String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    long l = -6318801846320234496L;
    try
    {
      l = localShardedJedis.rpushx(paramArrayOfByte1, new byte[][] { paramArrayOfByte2 }).longValue();
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return l;
  }

  public long lpushx(String paramString1, String paramString2, String paramString3)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString1);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    long l = -6318801846320234496L;
    try
    {
      l = localShardedJedis.lpushx(paramString2, new String[] { paramString3 }).longValue();
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return l;
  }

  public long lpushx(String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    long l = -6318801846320234496L;
    try
    {
      l = localShardedJedis.lpushx(paramArrayOfByte1, new byte[][] { paramArrayOfByte2 }).longValue();
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return l;
  }

  public long sadd(String paramString1, String paramString2, String[] paramArrayOfString)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString1);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    long l = -6318801846320234496L;
    try
    {
      l = localShardedJedis.sadd(paramString2, paramArrayOfString).longValue();
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return l;
  }

  public long sadd(String paramString, byte[] paramArrayOfByte, byte[][] paramArrayOfByte1)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    long l = -6318801846320234496L;
    try
    {
      l = localShardedJedis.sadd(paramArrayOfByte, paramArrayOfByte1).longValue();
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return l;
  }

  public String lpop(String paramString1, String paramString2)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString1);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    String str = "";
    try
    {
      str = localShardedJedis.lpop(paramString2);
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return str;
  }

  public byte[] lpop(String paramString, byte[] paramArrayOfByte)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    byte[] arrayOfByte = null;
    try
    {
      arrayOfByte = localShardedJedis.lpop(paramArrayOfByte);
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return arrayOfByte;
  }

  public String rpop(String paramString1, String paramString2)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString1);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    String str = "";
    try
    {
      str = localShardedJedis.rpop(paramString2);
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return str;
  }

  public byte[] rpop(String paramString, byte[] paramArrayOfByte)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    byte[] arrayOfByte = null;
    try
    {
      arrayOfByte = localShardedJedis.rpop(paramArrayOfByte);
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return arrayOfByte;
  }

  public String lindex(String paramString1, String paramString2, long paramLong)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString1);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    String str = "";
    try
    {
      str = localShardedJedis.lindex(paramString2, paramLong);
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return str;
  }

  public byte[] lindex(String paramString, byte[] paramArrayOfByte, long paramLong)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    byte[] arrayOfByte = null;
    try
    {
      arrayOfByte = localShardedJedis.lindex(paramArrayOfByte, paramLong);
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return arrayOfByte;
  }

  public Long linsert(String paramString1, String paramString2, BinaryClient.LIST_POSITION paramLIST_POSITION, String paramString3, String paramString4)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString1);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    long l = -6318801846320234496L;
    try
    {
      l = localShardedJedis.linsert(paramString2, paramLIST_POSITION, paramString3, paramString4).longValue();
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return Long.valueOf(l);
  }

  public Long linsert(String paramString, byte[] paramArrayOfByte1, BinaryClient.LIST_POSITION paramLIST_POSITION, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    long l = -6318801846320234496L;
    try
    {
      l = localShardedJedis.linsert(paramArrayOfByte1, paramLIST_POSITION, paramArrayOfByte2, paramArrayOfByte3).longValue();
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return Long.valueOf(l);
  }

  public String lset(String paramString1, String paramString2, long paramLong, String paramString3)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString1);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    String str = "";
    try
    {
      str = localShardedJedis.lset(paramString2, paramLong, paramString3);
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return str;
  }

  public String lset(String paramString, byte[] paramArrayOfByte1, long paramLong, byte[] paramArrayOfByte2)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    String str = "";
    try
    {
      str = localShardedJedis.lset(paramArrayOfByte1, paramLong, paramArrayOfByte2);
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return str;
  }

  public long llen(String paramString1, String paramString2)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString1);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    long l = -6318801846320234496L;
    try
    {
      l = localShardedJedis.llen(paramString2).longValue();
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return l;
  }

  public long llen(String paramString, byte[] paramArrayOfByte)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    long l = -6318801846320234496L;
    try
    {
      l = localShardedJedis.llen(paramArrayOfByte).longValue();
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return l;
  }

  public long lrem(String paramString1, String paramString2, long paramLong, String paramString3)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString1);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    long l = -6318801846320234496L;
    try
    {
      l = localShardedJedis.lrem(paramString2, paramLong, paramString3).longValue();
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return l;
  }

  public long lrem(String paramString, byte[] paramArrayOfByte1, long paramLong, byte[] paramArrayOfByte2)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    long l = -6318801846320234496L;
    try
    {
      l = localShardedJedis.lrem(paramArrayOfByte1, paramLong, paramArrayOfByte2).longValue();
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return l;
  }

  public String ltrim(String paramString1, String paramString2, long paramLong1, long paramLong2)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString1);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    String str = "";
    try
    {
      str = localShardedJedis.ltrim(paramString2, paramLong1, paramLong2);
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return str;
  }

  public String ltrim(String paramString, byte[] paramArrayOfByte, long paramLong1, long paramLong2)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    String str = "";
    try
    {
      str = localShardedJedis.ltrim(paramArrayOfByte, paramLong1, paramLong2);
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return str;
  }

  public List<String> lrange(String paramString1, String paramString2, long paramLong1, long paramLong2)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString1);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    List localList = null;
    try
    {
      localList = localShardedJedis.lrange(paramString2, paramLong1, paramLong2);
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return localList;
  }

  public List<byte[]> lrange(String paramString, byte[] paramArrayOfByte, long paramLong1, long paramLong2)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    List localList = null;
    try
    {
      localList = localShardedJedis.lrange(paramArrayOfByte, paramLong1, paramLong2);
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return localList;
  }

  public Long hset(String paramString1, String paramString2, String paramString3, String paramString4)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString1);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    long l = -1L;
    try
    {
      l = localShardedJedis.hset(paramString2, paramString3, paramString4).longValue();
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return Long.valueOf(l);
  }

  public Long hset(String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    long l = -1L;
    try
    {
      l = localShardedJedis.hset(paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3).longValue();
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return Long.valueOf(l);
  }

  public String set(String paramString1, String paramString2, String paramString3)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString1);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    String str = "";
    try
    {
      str = localShardedJedis.set(paramString2, paramString3);
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return str;
  }

  public String get(String paramString1, String paramString2)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString1);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    String str = "";
    try
    {
      str = localShardedJedis.get(paramString2);
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return str;
  }

  public String set(String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    String str = "";
    try
    {
      str = localShardedJedis.set(paramArrayOfByte1, paramArrayOfByte2);
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return str;
  }

  public byte[] get(String paramString, byte[] paramArrayOfByte)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    byte[] arrayOfByte = null;
    try
    {
      arrayOfByte = localShardedJedis.get(paramArrayOfByte);
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return arrayOfByte;
  }

  public String compressSet(String paramString1, String paramString2, String paramString3)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString1);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    String str = "";
    try
    {
      str = localShardedJedis.set(str2byte(paramString2), str2zipByte(paramString3));
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return str;
  }

  public String compressGet(String paramString1, String paramString2)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString1);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    String str = "";
    try
    {
      byte[] arrayOfByte = localShardedJedis.get(str2byte(paramString2));
      str = zipByte2str(arrayOfByte);
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return str;
  }

  public String compressSet(String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    String str = "";
    try
    {
      paramArrayOfByte2 = byte2zipByte(paramArrayOfByte2);
      str = localShardedJedis.set(paramArrayOfByte1, paramArrayOfByte2);
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return str;
  }

  public byte[] compressGet(String paramString, byte[] paramArrayOfByte)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    byte[] arrayOfByte = null;
    try
    {
      arrayOfByte = localShardedJedis.get(paramArrayOfByte);
      arrayOfByte = zipByte2byte(arrayOfByte);
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return arrayOfByte;
  }

  public long ttl(String paramString1, String paramString2)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString1);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    long l = -6318801846320234496L;
    try
    {
      l = localShardedJedis.ttl(paramString2).longValue();
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return l;
  }

  public long ttl(String paramString, byte[] paramArrayOfByte)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    long l = -6318801846320234496L;
    try
    {
      l = localShardedJedis.ttl(paramArrayOfByte).longValue();
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return l;
  }

  public long del(String paramString1, String paramString2)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString1);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    long l = -6318801846320234496L;
    try
    {
      l = localShardedJedis.del(paramString2).longValue();
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return l;
  }

  public long del(String paramString, byte[] paramArrayOfByte)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    long l = -6318801846320234496L;
    try
    {
      l = localShardedJedis.del(paramArrayOfByte).longValue();
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return l;
  }

  public String hmset(String paramString1, String paramString2, Map<String, String> paramMap)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString1);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    String str = "";
    try
    {
      str = localShardedJedis.hmset(paramString2, paramMap);
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return str;
  }

  public String hmset(String paramString, byte[] paramArrayOfByte, Map<byte[], byte[]> paramMap)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    String str = "";
    try
    {
      str = localShardedJedis.hmset(paramArrayOfByte, paramMap);
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return str;
  }

  public String setex(String paramString1, String paramString2, int paramInt, String paramString3)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString1);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    String str = "";
    try
    {
      str = localShardedJedis.setex(paramString2, paramInt, paramString3);
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return str;
  }

  public String setex(String paramString, byte[] paramArrayOfByte1, int paramInt, byte[] paramArrayOfByte2)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    String str = "";
    try
    {
      str = localShardedJedis.setex(paramArrayOfByte1, paramInt, paramArrayOfByte2);
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return str;
  }

  public long setnx(String paramString1, String paramString2, String paramString3)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString1);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    long l = -6318801846320234496L;
    try
    {
      l = localShardedJedis.setnx(paramString2, paramString3).longValue();
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return l;
  }

  public long setnx(String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    long l = -6318801846320234496L;
    try
    {
      l = localShardedJedis.setnx(paramArrayOfByte1, paramArrayOfByte2).longValue();
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return l;
  }

  public String compressSetex(String paramString1, String paramString2, int paramInt, String paramString3)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString1);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    String str = "";
    try
    {
      str = localShardedJedis.setex(str2byte(paramString2), paramInt, str2zipByte(paramString3));
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return str;
  }

  public String compressSetex(String paramString, byte[] paramArrayOfByte1, int paramInt, byte[] paramArrayOfByte2)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    String str = "";
    try
    {
      str = localShardedJedis.setex(paramArrayOfByte1, paramInt, byte2zipByte(paramArrayOfByte2));
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return str;
  }

  public long compressSetnx(String paramString1, String paramString2, String paramString3)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString1);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    long l = -6318801846320234496L;
    try
    {
      l = localShardedJedis.setnx(str2byte(paramString2), str2zipByte(paramString3)).longValue();
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return l;
  }

  public long compressSetnx(String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    long l = -6318801846320234496L;
    try
    {
      l = localShardedJedis.setnx(paramArrayOfByte1, byte2zipByte(paramArrayOfByte2)).longValue();
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return l;
  }

  public Long expire(String paramString1, String paramString2, int paramInt)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString1);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    long l = -6318801846320234496L;
    try
    {
      l = localShardedJedis.expire(paramString2, paramInt).longValue();
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return Long.valueOf(l);
  }

  public Long expire(String paramString, byte[] paramArrayOfByte, int paramInt)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    long l = -6318801846320234496L;
    try
    {
      l = localShardedJedis.expire(paramArrayOfByte, paramInt).longValue();
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return Long.valueOf(l);
  }

  public Long expireAt(String paramString1, String paramString2, long paramLong)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString1);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    long l = -6318801846320234496L;
    try
    {
      l = localShardedJedis.expireAt(paramString2, paramLong).longValue();
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return Long.valueOf(l);
  }

  public Long expireAt(String paramString, byte[] paramArrayOfByte, long paramLong)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    long l = -6318801846320234496L;
    try
    {
      l = localShardedJedis.expireAt(paramArrayOfByte, paramLong).longValue();
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return Long.valueOf(l);
  }

  public boolean exists(String paramString1, String paramString2)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString1);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    boolean bool = false;
    try
    {
      bool = localShardedJedis.exists(paramString2).booleanValue();
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return bool;
  }

  public boolean exists(String paramString, byte[] paramArrayOfByte)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    boolean bool = false;
    try
    {
      bool = localShardedJedis.exists(paramArrayOfByte).booleanValue();
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return bool;
  }

  public String type(String paramString1, String paramString2)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString1);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    String str = "";
    try
    {
      str = localShardedJedis.type(paramString2);
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return str;
  }

  public String type(String paramString, byte[] paramArrayOfByte)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    String str = "";
    try
    {
      str = localShardedJedis.type(paramArrayOfByte);
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return str;
  }

  public String hget(String paramString1, String paramString2, String paramString3)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString1);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    String str = "";
    try
    {
      str = localShardedJedis.hget(paramString2, paramString3);
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return str;
  }

  public byte[] hget(String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    byte[] arrayOfByte = null;
    try
    {
      arrayOfByte = localShardedJedis.hget(paramArrayOfByte1, paramArrayOfByte2);
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return arrayOfByte;
  }

  public Map<String, String> hgetAll(String paramString1, String paramString2)
  {
    return hgetAll(paramString1, paramString2, false);
  }

  public Map<byte[], byte[]> hgetAll(String paramString, byte[] paramArrayOfByte)
  {
    return hgetAll(paramString, paramArrayOfByte, false);
  }

  public Map<String, String> hgetAll(String paramString1, String paramString2, boolean paramBoolean)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString1);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    Map localMap = null;
    try
    {
      if (paramBoolean)
      {
        Jedis localJedis = (Jedis)localShardedJedis.getShard(paramString2);
        if (localJedis.getClient().isInMulti())
          throw new JedisDataException("Cannot use Jedis when in Multi. Please use JedisTransaction instead.");
        localJedis.getClient().hgetAll(paramString2);
        localMap = (Map)STRING_LINKEDHASHMAP.build(localJedis.getClient().getBinaryMultiBulkReply());
      }
      else
      {
        localMap = localShardedJedis.hgetAll(paramString2);
      }
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return localMap;
  }

  public Map<byte[], byte[]> hgetAll(String paramString, byte[] paramArrayOfByte, boolean paramBoolean)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    Map localMap = null;
    try
    {
      if (paramBoolean)
      {
        Jedis localJedis = (Jedis)localShardedJedis.getShard(paramArrayOfByte);
        if (localJedis.getClient().isInMulti())
          throw new JedisDataException("Cannot use Jedis when in Multi. Please use JedisTransaction instead.");
        localJedis.getClient().hgetAll(paramArrayOfByte);
        localMap = (Map)BYTE_LINKEDHASHMAP.build(localJedis.getClient().getBinaryMultiBulkReply());
      }
      else
      {
        localMap = localShardedJedis.hgetAll(paramArrayOfByte);
      }
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return localMap;
  }

  public Map<String, String> hgetAllToLinkedHashMap(String paramString1, String paramString2)
  {
    return hgetAll(paramString1, paramString2, true);
  }

  public Map<byte[], byte[]> hgetAllToLinkedHashMap(String paramString, byte[] paramArrayOfByte)
  {
    return hgetAll(paramString, paramArrayOfByte, true);
  }

  public Set<String> smembers(String paramString1, String paramString2)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString1);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    Set localSet = null;
    try
    {
      localSet = localShardedJedis.smembers(paramString2);
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return localSet;
  }

  public Set<byte[]> smembers(String paramString, byte[] paramArrayOfByte)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    Set localSet = null;
    try
    {
      localSet = localShardedJedis.smembers(paramArrayOfByte);
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return localSet;
  }

  public Long srem(String paramString1, String paramString2, String[] paramArrayOfString)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString1);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    long l = -6318801846320234496L;
    try
    {
      l = localShardedJedis.srem(paramString2, paramArrayOfString).longValue();
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return Long.valueOf(l);
  }

  public Long srem(String paramString, byte[] paramArrayOfByte, byte[][] paramArrayOfByte1)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    long l = -6318801846320234496L;
    try
    {
      l = localShardedJedis.srem(paramArrayOfByte, paramArrayOfByte1).longValue();
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return Long.valueOf(l);
  }

  public Long scard(String paramString1, String paramString2)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString1);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    long l = -6318801846320234496L;
    try
    {
      l = localShardedJedis.scard(paramString2).longValue();
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return Long.valueOf(l);
  }

  public Long scard(String paramString, byte[] paramArrayOfByte)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    long l = -6318801846320234496L;
    try
    {
      l = localShardedJedis.scard(paramArrayOfByte).longValue();
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return Long.valueOf(l);
  }

  public String spop(String paramString1, String paramString2)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString1);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    String str = "";
    try
    {
      str = localShardedJedis.spop(paramString2);
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return str;
  }

  public byte[] spop(String paramString, byte[] paramArrayOfByte)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    byte[] arrayOfByte = null;
    try
    {
      arrayOfByte = localShardedJedis.spop(paramArrayOfByte);
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return arrayOfByte;
  }

  public String srandmember(String paramString1, String paramString2)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString1);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    String str = "";
    try
    {
      str = localShardedJedis.srandmember(paramString2);
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return str;
  }

  public byte[] srandmember(String paramString, byte[] paramArrayOfByte)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    byte[] arrayOfByte = null;
    try
    {
      arrayOfByte = localShardedJedis.srandmember(paramArrayOfByte);
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return arrayOfByte;
  }

  public boolean sismember(String paramString1, String paramString2, String paramString3)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString1);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    boolean bool = false;
    try
    {
      bool = localShardedJedis.sismember(paramString2, paramString3).booleanValue();
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return bool;
  }

  public boolean sismember(String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    boolean bool = false;
    try
    {
      bool = localShardedJedis.sismember(paramArrayOfByte1, paramArrayOfByte2).booleanValue();
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return bool;
  }

  public Long append(String paramString1, String paramString2, String paramString3)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString1);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    long l = -6318801846320234496L;
    try
    {
      l = localShardedJedis.append(paramString2, paramString3).longValue();
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return Long.valueOf(l);
  }

  public Long append(String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    long l = -6318801846320234496L;
    try
    {
      l = localShardedJedis.append(paramArrayOfByte1, paramArrayOfByte2).longValue();
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return Long.valueOf(l);
  }

  public Long decr(String paramString1, String paramString2)
  {
    long l;
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString1);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    try
    {
      l = localShardedJedis.decr(paramString2).longValue();
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return Long.valueOf(l);
  }

  public Long decr(String paramString, byte[] paramArrayOfByte)
  {
    long l;
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    try
    {
      l = localShardedJedis.decr(paramArrayOfByte).longValue();
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return Long.valueOf(l);
  }

  public Long decrBy(String paramString1, String paramString2, Integer paramInteger)
  {
    long l;
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString1);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    try
    {
      l = localShardedJedis.decrBy(paramString2, paramInteger.intValue()).longValue();
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return Long.valueOf(l);
  }

  public Long decrBy(String paramString, byte[] paramArrayOfByte, Integer paramInteger)
  {
    long l;
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    try
    {
      l = localShardedJedis.decrBy(paramArrayOfByte, paramInteger.intValue()).longValue();
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return Long.valueOf(l);
  }

  public String getrange(String paramString1, String paramString2, int paramInt1, int paramInt2)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString1);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    String str = "";
    try
    {
      str = localShardedJedis.getrange(paramString2, paramInt1, paramInt2);
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return str;
  }

  public byte[] getrange(String paramString, byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    byte[] arrayOfByte = null;
    try
    {
      arrayOfByte = localShardedJedis.getrange(paramArrayOfByte, paramInt1, paramInt2);
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return arrayOfByte;
  }

  public String getSet(String paramString1, String paramString2, String paramString3)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString1);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    String str = "";
    try
    {
      str = localShardedJedis.getSet(paramString2, paramString3);
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return str;
  }

  public byte[] getSet(String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    byte[] arrayOfByte = null;
    try
    {
      arrayOfByte = localShardedJedis.getSet(paramArrayOfByte1, paramArrayOfByte2);
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return arrayOfByte;
  }

  public String compressGetSet(String paramString1, String paramString2, String paramString3)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString1);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    String str = "";
    try
    {
      byte[] arrayOfByte = localShardedJedis.getSet(str2byte(paramString2), str2zipByte(paramString3));
      str = zipByte2str(arrayOfByte);
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return str;
  }

  public byte[] compressGetSet(String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    byte[] arrayOfByte1 = null;
    try
    {
      byte[] arrayOfByte2 = localShardedJedis.getSet(paramArrayOfByte1, byte2zipByte(paramArrayOfByte2));
      arrayOfByte1 = zipByte2byte(arrayOfByte2);
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return arrayOfByte1;
  }

  public Long hdel(String paramString1, String paramString2, String[] paramArrayOfString)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString1);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    long l = -6318801846320234496L;
    try
    {
      l = localShardedJedis.hdel(paramString2, paramArrayOfString).longValue();
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return Long.valueOf(l);
  }

  public Long hdel(String paramString, byte[] paramArrayOfByte, byte[][] paramArrayOfByte1)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    long l = -6318801846320234496L;
    try
    {
      l = localShardedJedis.hdel(paramArrayOfByte, paramArrayOfByte1).longValue();
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return Long.valueOf(l);
  }

  public Boolean hexists(String paramString1, String paramString2, String paramString3)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString1);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    boolean bool = false;
    try
    {
      bool = localShardedJedis.hexists(paramString2, paramString3).booleanValue();
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return Boolean.valueOf(bool);
  }

  public Boolean hexists(String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    boolean bool = false;
    try
    {
      bool = localShardedJedis.hexists(paramArrayOfByte1, paramArrayOfByte2).booleanValue();
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return Boolean.valueOf(bool);
  }

  public Long hincrBy(String paramString1, String paramString2, String paramString3, int paramInt)
  {
    long l;
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString1);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    try
    {
      l = localShardedJedis.hincrBy(paramString2, paramString3, paramInt).longValue();
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return Long.valueOf(l);
  }

  public Long hincrBy(String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, int paramInt)
  {
    long l;
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    try
    {
      l = localShardedJedis.hincrBy(paramArrayOfByte1, paramArrayOfByte2, paramInt).longValue();
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return Long.valueOf(l);
  }

  public Set<String> hkeys(String paramString1, String paramString2)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString1);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    Set localSet = null;
    try
    {
      localSet = localShardedJedis.hkeys(paramString2);
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return localSet;
  }

  public Set<byte[]> hkeys(String paramString, byte[] paramArrayOfByte)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    Set localSet = null;
    try
    {
      localSet = localShardedJedis.hkeys(paramArrayOfByte);
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return localSet;
  }

  public Long hlen(String paramString1, String paramString2)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString1);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    long l = -6318801846320234496L;
    try
    {
      l = localShardedJedis.hlen(paramString2).longValue();
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return Long.valueOf(l);
  }

  public Long hlen(String paramString, byte[] paramArrayOfByte)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    long l = -6318801846320234496L;
    try
    {
      l = localShardedJedis.hlen(paramArrayOfByte).longValue();
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return Long.valueOf(l);
  }

  public List<String> hmget(String paramString1, String paramString2, String[] paramArrayOfString)
  {
    List localList;
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString1);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    try
    {
      localList = localShardedJedis.hmget(paramString2, paramArrayOfString);
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return localList;
  }

  public List<byte[]> hmget(String paramString, byte[] paramArrayOfByte, byte[][] paramArrayOfByte1)
  {
    List localList;
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    try
    {
      localList = localShardedJedis.hmget(paramArrayOfByte, paramArrayOfByte1);
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return localList;
  }

  public Long hsetnx(String paramString1, String paramString2, String paramString3, String paramString4)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString1);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    long l = -1L;
    try
    {
      l = localShardedJedis.hsetnx(paramString2, paramString3, paramString4).longValue();
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return Long.valueOf(l);
  }

  public Long hsetnx(String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    long l = -1L;
    try
    {
      l = localShardedJedis.hsetnx(paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3).longValue();
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return Long.valueOf(l);
  }

  public List<String> hvals(String paramString1, String paramString2)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString1);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    List localList = null;
    try
    {
      localList = localShardedJedis.hvals(paramString2);
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return localList;
  }

  public List<byte[]> hvals(String paramString, byte[] paramArrayOfByte)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    List localList = null;
    try
    {
      localList = (List)localShardedJedis.hvals(paramArrayOfByte);
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return localList;
  }

  public Long incr(String paramString1, String paramString2)
  {
    long l;
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString1);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    try
    {
      l = localShardedJedis.incr(paramString2).longValue();
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return Long.valueOf(l);
  }

  public Long incr(String paramString, byte[] paramArrayOfByte)
  {
    long l;
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    try
    {
      l = localShardedJedis.incr(paramArrayOfByte).longValue();
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return Long.valueOf(l);
  }

  public boolean electioneer(String paramString1, String paramString2, String paramString3, int paramInt)
  {
    int i;
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString1);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    try
    {
      i = 0;
      int j = localShardedJedis.setnx(paramString2, paramString3).intValue();
      if (j == 1)
      {
        localShardedJedis.expire(paramString2, paramInt);
        i = 1;
      }
      else
      {
        String str = localShardedJedis.get(paramString2);
        if ((str != null) && (str.equals(paramString3)))
        {
          localShardedJedis.expire(paramString2, paramInt);
          i = 1;
        }
      }
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return i;
  }

  public boolean electioneer(String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, int paramInt)
  {
    int i;
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    try
    {
      i = 0;
      int j = localShardedJedis.setnx(paramArrayOfByte1, paramArrayOfByte2).intValue();
      if (j == 1)
      {
        localShardedJedis.expire(paramArrayOfByte1, paramInt);
        i = 1;
      }
      else
      {
        byte[] arrayOfByte = localShardedJedis.get(paramArrayOfByte1);
        if ((arrayOfByte != null) && (arrayOfByte.equals(paramArrayOfByte2)))
        {
          localShardedJedis.expire(paramArrayOfByte1, paramInt);
          i = 1;
        }
      }
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return i;
  }

  public Long incrBy(String paramString1, String paramString2, int paramInt)
  {
    long l;
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString1);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    try
    {
      l = localShardedJedis.incrBy(paramString2, paramInt).longValue();
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return Long.valueOf(l);
  }

  public Long incrBy(String paramString, byte[] paramArrayOfByte, int paramInt)
  {
    long l;
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    try
    {
      l = localShardedJedis.incrBy(paramArrayOfByte, paramInt).longValue();
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
    return Long.valueOf(l);
  }

  public void subscribe(String paramString1, String paramString2, JedisPubSub paramJedisPubSub, String[] paramArrayOfString)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString1);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    try
    {
      ((Jedis)localShardedJedis.getShard(paramString2)).subscribe(paramJedisPubSub, paramArrayOfString);
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
  }

  public void subscribe(String paramString, byte[] paramArrayOfByte, JedisPubSub paramJedisPubSub, String[] paramArrayOfString)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    try
    {
      ((Jedis)localShardedJedis.getShard(paramArrayOfByte)).subscribe(paramJedisPubSub, paramArrayOfString);
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
  }

  public void publish(String paramString1, String paramString2, String paramString3, String paramString4)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString1);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    try
    {
      ((Jedis)localShardedJedis.getShard(paramString2)).publish(paramString3, paramString4);
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
  }

  public void publish(String paramString1, byte[] paramArrayOfByte, String paramString2, String paramString3)
  {
    ShardedJedisPool localShardedJedisPool = RedisAdmin.getBaseProxy(paramString1);
    ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
    try
    {
      ((Jedis)localShardedJedis.getShard(paramArrayOfByte)).publish(paramString2, paramString3);
    }
    catch (Exception localException)
    {
      returnBrokenResource(localShardedJedisPool, localShardedJedis);
      log.error(localException);
      throw new JedisException(localException);
    }
    returnResource(localShardedJedisPool, localShardedJedis);
  }

  public Jedis getJedisByShardKey(String paramString1, String paramString2)
  {
    ShardedJedisPool localShardedJedisPool;
    try
    {
      localShardedJedisPool = RedisAdmin.getBaseProxy(paramString1);
      ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
      return ((Jedis)localShardedJedis.getShard(paramString2));
    }
    catch (Exception localException)
    {
      log.error(localException);
      throw new JedisException(localException);
    }
  }

  public Jedis getJedisByShardKey(String paramString, byte[] paramArrayOfByte)
  {
    ShardedJedisPool localShardedJedisPool;
    try
    {
      localShardedJedisPool = RedisAdmin.getBaseProxy(paramString);
      ShardedJedis localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
      return ((Jedis)localShardedJedis.getShard(paramArrayOfByte));
    }
    catch (Exception localException)
    {
      log.error(localException);
      throw new JedisException(localException);
    }
  }

  public int getShardIndex(String paramString1, String paramString2)
  {
    ArrayList localArrayList = new ArrayList();
    Object localObject1 = paramString1.split(",");
    int i = localObject1.length;
    for (int j = 0; j < i; ++j)
    {
      Object localObject2 = localObject1[j];
      JedisShardInfo localJedisShardInfo2 = new JedisShardInfo(localObject2.split(":")[0], Integer.parseInt(localObject2.split(":")[1]));
      localArrayList.add(localJedisShardInfo2);
    }
    localObject1 = new TreeMap();
    for (i = 0; i != localArrayList.size(); ++i)
    {
      localJedisShardInfo1 = (JedisShardInfo)localArrayList.get(i);
      if (localJedisShardInfo1.getName() == null)
        for (k = 0; k < 160 * localJedisShardInfo1.getWeight(); ++k)
          ((TreeMap)localObject1).put(Long.valueOf(Hashing.MURMUR_HASH.hash("SHARD-" + i + "-NODE-" + k)), localJedisShardInfo1);
      else
        for (k = 0; k < 160 * localJedisShardInfo1.getWeight(); ++k)
          ((TreeMap)localObject1).put(Long.valueOf(Hashing.MURMUR_HASH.hash(localJedisShardInfo1.getName() + "*" + localJedisShardInfo1.getWeight() + k)), localJedisShardInfo1);
    }
    SortedMap localSortedMap = ((TreeMap)localObject1).tailMap(Long.valueOf(Hashing.MURMUR_HASH.hash(SafeEncoder.encode(paramString2))));
    JedisShardInfo localJedisShardInfo1 = null;
    if (localSortedMap.size() == 0)
      localJedisShardInfo1 = (JedisShardInfo)((TreeMap)localObject1).get(((TreeMap)localObject1).firstKey());
    else
      localJedisShardInfo1 = (JedisShardInfo)localSortedMap.get(localSortedMap.firstKey());
    System.out.println(paramString2 + " saved " + localJedisShardInfo1);
    for (int k = 0; k < localArrayList.size(); ++k)
      if (((JedisShardInfo)localArrayList.get(k)).equals(localJedisShardInfo1))
        return k;
    return -1;
  }

  public int getShardIndex(String paramString, byte[] paramArrayOfByte)
  {
    ArrayList localArrayList = new ArrayList();
    Object localObject1 = paramString.split(",");
    int i = localObject1.length;
    for (int j = 0; j < i; ++j)
    {
      Object localObject2 = localObject1[j];
      JedisShardInfo localJedisShardInfo2 = new JedisShardInfo(localObject2.split(":")[0], Integer.parseInt(localObject2.split(":")[1]));
      localArrayList.add(localJedisShardInfo2);
    }
    localObject1 = new TreeMap();
    for (i = 0; i != localArrayList.size(); ++i)
    {
      localJedisShardInfo1 = (JedisShardInfo)localArrayList.get(i);
      if (localJedisShardInfo1.getName() == null)
        for (k = 0; k < 160 * localJedisShardInfo1.getWeight(); ++k)
          ((TreeMap)localObject1).put(Long.valueOf(Hashing.MURMUR_HASH.hash("SHARD-" + i + "-NODE-" + k)), localJedisShardInfo1);
      else
        for (k = 0; k < 160 * localJedisShardInfo1.getWeight(); ++k)
          ((TreeMap)localObject1).put(Long.valueOf(Hashing.MURMUR_HASH.hash(localJedisShardInfo1.getName() + "*" + localJedisShardInfo1.getWeight() + k)), localJedisShardInfo1);
    }
    SortedMap localSortedMap = ((TreeMap)localObject1).tailMap(Long.valueOf(Hashing.MURMUR_HASH.hash(SafeEncoder.encode(paramArrayOfByte))));
    JedisShardInfo localJedisShardInfo1 = null;
    if (localSortedMap.size() == 0)
      localJedisShardInfo1 = (JedisShardInfo)((TreeMap)localObject1).get(((TreeMap)localObject1).firstKey());
    else
      localJedisShardInfo1 = (JedisShardInfo)localSortedMap.get(localSortedMap.firstKey());
    System.out.println(paramArrayOfByte + " saved " + localJedisShardInfo1);
    for (int k = 0; k < localArrayList.size(); ++k)
      if (((JedisShardInfo)localArrayList.get(k)).equals(localJedisShardInfo1))
        return k;
    return -1;
  }

  public byte[] str2zipByte(String paramString)
    throws IOException
  {
    byte[] arrayOfByte1 = null;
    if ((paramString != null) && (paramString.length() > 0))
    {
      byte[] arrayOfByte2 = paramString.getBytes("UTF-8");
      ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
      GZIPOutputStream localGZIPOutputStream = new GZIPOutputStream(localByteArrayOutputStream);
      localGZIPOutputStream.write(arrayOfByte2, 0, arrayOfByte2.length);
      localGZIPOutputStream.finish();
      arrayOfByte1 = localByteArrayOutputStream.toByteArray();
      localGZIPOutputStream.close();
      localByteArrayOutputStream.close();
    }
    return arrayOfByte1;
  }

  public byte[] str2byte(String paramString)
    throws UnsupportedEncodingException
  {
    if (paramString != null)
      return paramString.getBytes("UTF-8");
    return null;
  }

  public String byte2str(byte[] paramArrayOfByte)
    throws UnsupportedEncodingException
  {
    if (paramArrayOfByte != null)
      return new String(paramArrayOfByte, "UTF-8");
    return null;
  }

  public String zipByte2str(byte[] paramArrayOfByte)
    throws IOException
  {
    String str = null;
    if ((paramArrayOfByte != null) && (paramArrayOfByte.length > 0))
    {
      GZIPInputStream localGZIPInputStream = new GZIPInputStream(new ByteArrayInputStream(paramArrayOfByte));
      ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream(paramArrayOfByte.length);
      byte[] arrayOfByte = new byte[2048];
      while ((i = localGZIPInputStream.read(arrayOfByte)) != -1)
      {
        int i;
        localByteArrayOutputStream.write(arrayOfByte, 0, i);
      }
      paramArrayOfByte = localByteArrayOutputStream.toByteArray();
      str = new String(paramArrayOfByte, "UTF-8");
      localGZIPInputStream.close();
      localByteArrayOutputStream.close();
    }
    return str;
  }

  public byte[] zipByte2byte(byte[] paramArrayOfByte)
    throws IOException
  {
    byte[] arrayOfByte1 = null;
    if ((paramArrayOfByte != null) && (paramArrayOfByte.length > 0))
    {
      GZIPInputStream localGZIPInputStream = new GZIPInputStream(new ByteArrayInputStream(paramArrayOfByte));
      ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream(paramArrayOfByte.length);
      byte[] arrayOfByte2 = new byte[2048];
      while ((i = localGZIPInputStream.read(arrayOfByte2)) != -1)
      {
        int i;
        localByteArrayOutputStream.write(arrayOfByte2, 0, i);
      }
      arrayOfByte1 = localByteArrayOutputStream.toByteArray();
      localGZIPInputStream.close();
      localByteArrayOutputStream.close();
    }
    return arrayOfByte1;
  }

  public byte[] byte2zipByte(byte[] paramArrayOfByte)
    throws IOException
  {
    byte[] arrayOfByte = null;
    if ((paramArrayOfByte != null) && (paramArrayOfByte.length > 0))
    {
      ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream(paramArrayOfByte.length);
      GZIPOutputStream localGZIPOutputStream = new GZIPOutputStream(localByteArrayOutputStream);
      localGZIPOutputStream.write(paramArrayOfByte, 0, paramArrayOfByte.length);
      localGZIPOutputStream.finish();
      arrayOfByte = localByteArrayOutputStream.toByteArray();
      localByteArrayOutputStream.close();
      localGZIPOutputStream.close();
    }
    return arrayOfByte;
  }
}