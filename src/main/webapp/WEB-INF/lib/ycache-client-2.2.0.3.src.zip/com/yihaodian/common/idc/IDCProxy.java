package com.yihaodian.common.idc;

public abstract interface IDCProxy
{
  public abstract boolean invalid(String paramString);

  public abstract boolean invalid(String paramString, int paramInt);

  public abstract int getTTL(String paramString);

  public abstract boolean deleteTTL(String paramString);
}