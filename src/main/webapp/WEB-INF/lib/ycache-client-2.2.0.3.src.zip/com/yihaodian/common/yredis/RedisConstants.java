package com.yihaodian.common.yredis;

public class RedisConstants
{
  public static final int DEFAULT_EXPIRE_TIME = 20;
  public static final int EXPIRE_30MIN = 30;
  public static final int EXPIRE_1H = 60;
  public static final int EXPIRE_2H = 120;
  public static final int EXPIRE_6H = 360;
  public static final int EXPIRE_12H = 720;
  public static final int EXPIRE_24H = 1440;
  public static final int EXPIRE_48H = 2880;
}