package com.yihaodian.common.idc;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.atomic.AtomicInteger;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class IDCExecutorService
{
  protected static Log logger = LogFactory.getLog(IDCExecutorService.class);
  static int THREADS = Runtime.getRuntime().availableProcessors() * 2;
  static int taskMaxSize = THREADS + 1;
  private static Map<String, AtomicInteger> MapCurrTaskNum = new ConcurrentHashMap();
  private static Map<String, AtomicInteger> taskRealRunningNum = new ConcurrentHashMap();
  static IDCExecutorService instance;
  Executor executor;
  static Map<String, BlockingQueue<Runnable>> MapTaskQueue = new ConcurrentHashMap();
  private static Map<String, Integer> MapPoolWeight = new ConcurrentHashMap();
  static int pos = 0;

  IDCExecutorService(int paramInt1, int paramInt2)
  {
    if (paramInt2 > 0)
      THREADS = paramInt2;
    if (paramInt1 > 0)
      taskMaxSize = paramInt1;
    this.executor = Executors.newFixedThreadPool(THREADS);
    if (logger.isInfoEnabled())
      logger.info("Invalid thread number=" + THREADS);
    if (logger.isInfoEnabled())
      logger.info("Invalid task max nuber for each pool=" + taskMaxSize);
  }

  private synchronized void scheduler(String paramString)
  {
    String[] arrayOfString = (String[])MapTaskQueue.keySet().toArray(new String[0]);
    for (int i = 0; i < arrayOfString.length; ++i)
    {
      int j = (i + pos) % arrayOfString.length;
      int k = ((AtomicInteger)MapCurrTaskNum.get(arrayOfString[j])).get();
      if ((k < ((BlockingQueue)MapTaskQueue.get(arrayOfString[j])).size()) && (k <= getSchedulerTaskNumber() * getWeight(arrayOfString[j]) / getTotalActiveWeight()) && (((AtomicInteger)taskRealRunningNum.get(arrayOfString[j])).get() <= getTaskRealRunningNum() * getWeight(arrayOfString[j]) / getTotalActiveWeight()))
      {
        if (k > THREADS + 1)
          break label282:
        synchronized (MapCurrTaskNum)
        {
          ((AtomicInteger)MapCurrTaskNum.get(arrayOfString[j])).incrementAndGet();
        }
        if (logger.isInfoEnabled())
          logger.info(arrayOfString[j] + " add task. curr task " + ((AtomicInteger)MapCurrTaskNum.get(arrayOfString[j])).get());
        label282: this.executor.execute(new RunTask(this, arrayOfString[j]));
      }
    }
    pos += 1;
  }

  public static IDCExecutorService getInstance(int paramInt1, int paramInt2)
  {
    if (instance == null)
      synchronized (IDCExecutorService.class)
      {
        if (instance == null)
          instance = new IDCExecutorService(paramInt1, paramInt2);
      }
    return instance;
  }

  public static IDCExecutorService getInstance()
  {
    return getInstance(taskMaxSize, THREADS);
  }

  public static IDCExecutorService getInstance(int paramInt)
  {
    return getInstance(paramInt, THREADS);
  }

  public int getTaskNumber(String paramString)
  {
    if (null != MapTaskQueue.get(paramString))
      return ((BlockingQueue)MapTaskQueue.get(paramString)).size();
    return 0;
  }

  public int getTaskNumber()
  {
    int i = 0;
    Iterator localIterator = MapTaskQueue.keySet().iterator();
    while (localIterator.hasNext())
    {
      String str = (String)localIterator.next();
      i += ((BlockingQueue)MapTaskQueue.get(str)).size();
    }
    return i;
  }

  public int getActivePoolNumber()
  {
    int i = 0;
    Iterator localIterator = MapTaskQueue.keySet().iterator();
    while (localIterator.hasNext())
    {
      String str = (String)localIterator.next();
      i += ((((BlockingQueue)MapTaskQueue.get(str)).size() > 0) ? 1 : 0);
    }
    return i;
  }

  private int getSchedulerTaskNumber(String paramString)
  {
    if (MapCurrTaskNum.containsKey(paramString))
      return ((AtomicInteger)MapCurrTaskNum.get(paramString)).get();
    return 0;
  }

  private int getSchedulerTaskNumber()
  {
    int i = 0;
    Iterator localIterator = MapCurrTaskNum.keySet().iterator();
    while (localIterator.hasNext())
    {
      String str = (String)localIterator.next();
      i += ((AtomicInteger)MapCurrTaskNum.get(str)).get();
    }
    return i;
  }

  public static Map<String, Integer> getAllPoolTaskNumber()
  {
    HashMap localHashMap = new HashMap();
    Iterator localIterator = MapTaskQueue.keySet().iterator();
    while (localIterator.hasNext())
    {
      String str = (String)localIterator.next();
      localHashMap.put(str, Integer.valueOf(((BlockingQueue)MapTaskQueue.get(str)).size()));
    }
    return localHashMap;
  }

  public static int getTaskRealRunningNum(String paramString)
  {
    if (taskRealRunningNum.containsKey(paramString))
      return ((AtomicInteger)taskRealRunningNum.get(paramString)).get();
    return 0;
  }

  private int getTaskRealRunningNum()
  {
    int i = 0;
    Iterator localIterator = taskRealRunningNum.keySet().iterator();
    while (localIterator.hasNext())
    {
      String str = (String)localIterator.next();
      i += ((AtomicInteger)taskRealRunningNum.get(str)).get();
    }
    return i;
  }

  public int getWeight(String paramString)
  {
    return ((MapPoolWeight.containsKey(paramString)) ? ((Integer)MapPoolWeight.get(paramString)).intValue() : 1);
  }

  public void setWeight(String paramString, int paramInt)
  {
    if (paramInt > 0)
      MapPoolWeight.put(paramString, Integer.valueOf(paramInt));
  }

  private int getTotalActiveWeight()
  {
    int i = 0;
    Iterator localIterator = MapPoolWeight.keySet().iterator();
    while (localIterator.hasNext())
    {
      String str = (String)localIterator.next();
      if (getTaskNumber(str) > taskMaxSize)
        i += ((Integer)MapPoolWeight.get(str)).intValue();
    }
    return ((i > 0) ? i : 1);
  }

  public boolean isAcceptTask(String paramString)
  {
    return ((getTaskNumber(paramString) <= taskMaxSize) && (getTaskNumber(paramString) <= getTaskNumber() * getWeight(paramString) / getTotalActiveWeight()));
  }

  public void submitTask(Runnable paramRunnable, String paramString)
  {
    if (!(MapTaskQueue.containsKey(paramString)))
      synchronized (MapTaskQueue)
      {
        if (!(MapTaskQueue.containsKey(paramString)))
        {
          MapTaskQueue.put(paramString, new LinkedBlockingQueue(taskMaxSize));
          if (!(MapCurrTaskNum.containsKey(paramString)))
            MapCurrTaskNum.put(paramString, new AtomicInteger());
          if (!(taskRealRunningNum.containsKey(paramString)))
            taskRealRunningNum.put(paramString, new AtomicInteger());
          if (!(MapPoolWeight.containsKey(paramString)))
            MapPoolWeight.put(paramString, Integer.valueOf(1));
          logger.warn(paramString + " is new pool to scheduler. weight:" + getWeight(paramString) + " all active pool weight:" + getTotalActiveWeight());
        }
      }
    if (logger.isInfoEnabled())
      logger.info(paramString + " Invalid task number=" + getTaskNumber(paramString) + " max for this pool:" + taskMaxSize + " all task number:" + getTaskNumber());
    if (!(isAcceptTask(paramString)))
      logger.info(paramString + " Invalid tasks number reached the max:" + getTaskNumber(paramString));
    else if (paramRunnable != null)
      ((BlockingQueue)MapTaskQueue.get(paramString)).offer(paramRunnable);
    scheduler(paramString);
  }

  private void processTask(String paramString)
    throws InterruptedException
  {
    Runnable localRunnable = (Runnable)((BlockingQueue)MapTaskQueue.get(paramString)).poll();
    if (localRunnable == null)
      return;
    localRunnable.run();
  }

  public static String showStatus()
  {
    return new String("\r\n IDCExecutorService status:\r\n threads=" + THREADS + " taskMaxSize=" + taskMaxSize + "\r\n taskRealRunningNum=" + taskRealRunningNum.toString() + "\r\n MapCurrTaskNum=" + MapCurrTaskNum.toString() + "\r\n queue tasks=" + getAllPoolTaskNumber().toString() + "\r\n weights=" + MapPoolWeight.toString());
  }

  private class RunTask
  implements Runnable
  {
    private String poolName;

    RunTask(, String paramString)
    {
      this.poolName = paramString;
    }

    public void run()
    {
      long l = -6318801313744289792L;
      if (IDCExecutorService.logger.isInfoEnabled())
        l = System.currentTimeMillis();
      try
      {
        ((AtomicInteger)IDCExecutorService.access$000().get(this.poolName)).incrementAndGet();
        IDCExecutorService.access$100(this.this$0, this.poolName);
      }
      catch (Exception j)
      {
        int i;
        localException.printStackTrace();
        IDCExecutorService.logger.error(localException);
      }
      finally
      {
        int j;
        int k;
        if (IDCExecutorService.logger.isInfoEnabled())
          IDCExecutorService.logger.info(this.poolName + " task used time(ms) " + (System.currentTimeMillis() - l));
        ((AtomicInteger)IDCExecutorService.access$000().get(this.poolName)).decrementAndGet();
        synchronized (IDCExecutorService.access$200())
        {
          k = ((AtomicInteger)IDCExecutorService.access$200().get(this.poolName)).decrementAndGet();
        }
        if (k <= 0)
          IDCExecutorService.access$300(this.this$0, this.poolName);
      }
      if (IDCExecutorService.logger.isInfoEnabled())
        IDCExecutorService.logger.info(this.poolName + " task total number =" + ((BlockingQueue)IDCExecutorService.MapTaskQueue.get(this.poolName)).size() + " task running number =" + ((AtomicInteger)IDCExecutorService.access$200().get(this.poolName)).get());
    }
  }
}