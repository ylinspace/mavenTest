package com.yihaodian.common.ycache.memcache;

import java.util.Date;
import java.util.Map;

public abstract interface MemcacheInterceptor
{
  public abstract boolean handlePut(String paramString1, String paramString2, Object paramObject);

  public abstract boolean handlePut(String paramString1, String paramString2, Object paramObject, int paramInt);

  public abstract boolean handlePut(String paramString1, String paramString2, Object paramObject, long paramLong);

  public abstract boolean handlePut(String paramString1, String paramString2, Object paramObject, Date paramDate);

  public abstract Object handleGet(String paramString1, String paramString2);

  public abstract Object handleGet(String paramString1, String paramString2, String paramString3);

  public abstract Map<String, Object> handleGetMulti(String paramString, String[] paramArrayOfString);

  public abstract boolean handleRemove(String paramString1, String paramString2);

  public abstract boolean handleRemove(String paramString1, String paramString2, String paramString3);

  public abstract boolean handleAdd(String paramString1, String paramString2, Object paramObject);

  public abstract boolean handleAdd(String paramString1, String paramString2, Object paramObject, int paramInt);

  public abstract boolean handleAdd(String paramString1, String paramString2, Object paramObject, long paramLong);

  public abstract boolean handleAdd(String paramString1, String paramString2, Object paramObject, Date paramDate);

  public abstract boolean handleReplace(String paramString1, String paramString2, Object paramObject);

  public abstract boolean handleReplace(String paramString1, String paramString2, Object paramObject, int paramInt);

  public abstract boolean handleReplace(String paramString1, String paramString2, Object paramObject, Date paramDate);

  public abstract boolean handleReplace(String paramString1, String paramString2, Object paramObject, long paramLong);

  public abstract MemcacheInterceptor getNextHandler();

  public abstract void setNextHandler(MemcacheInterceptor paramMemcacheInterceptor);

  public abstract long incr(String paramString1, String paramString2, long paramLong);

  public abstract long decr(String paramString1, String paramString2, long paramLong);

  public abstract boolean storeCounter(String paramString1, String paramString2, long paramLong);

  public abstract boolean storeCounter(String paramString1, String paramString2, long paramLong, int paramInt);

  public abstract long getCounter(String paramString1, String paramString2);

  public abstract long addOrIncr(String paramString1, String paramString2, long paramLong);

  public abstract long addOrDecr(String paramString1, String paramString2, long paramLong);
}