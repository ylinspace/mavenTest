package com.yihaodian.arc.cache.zk;

import com.ycache.danga.MemCached.SockIOPool;
import com.yihaodian.architecture.zkclient.IZkChildListener;
import com.yihaodian.architecture.zkclient.IZkDataListener;
import com.yihaodian.architecture.zkclient.ZkClient;
import com.yihaodian.common.ycache.util.PropertiesUtil;
import com.yihaodian.configcentre.client.utils.YccGlobalPropertyConfigurer;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

public class ZKProxy
{
  public static Logger logger = Logger.getLogger(ZKProxy.class);
  private static final String POOL_ZK_PATH_NCADDR = "/ycache/pools";
  private static final String POOL_ZK_PATH_MEM = "/nutcracker/config";
  private static final String POOL_NAME = "yihaodian/common";
  private static final String CONF_FILE_NAME = "zookeeper-ycache.properties";
  private static final String ZK_NC_ADDR = "zk-servers";
  private ZkClient client;
  private String zkListenPath;
  private static int DEFAULT_TIMEOUT = 30000;

  public ZKProxy(SockIOPool paramSockIOPool)
    throws Exception
  {
    Properties localProperties = YccGlobalPropertyConfigurer.loadConfigProperties("yihaodian/common", "zookeeper-ycache.properties", false);
    String str = localProperties.getProperty("zk-servers");
    if ((str == null) || (str.equalsIgnoreCase("")))
      throw new Exception("zkAddrs is null");
    this.client = new ZkClient(str);
    PoolDataChangedWatcher localPoolDataChangedWatcher = new PoolDataChangedWatcher(this, paramSockIOPool);
    this.client.subscribeChildChanges("/ycache/pools", localPoolDataChangedWatcher);
    this.client.subscribeDataChanges("/nutcracker/config", localPoolDataChangedWatcher);
  }

  public ZKProxy(SockIOPool paramSockIOPool, String paramString1, String paramString2)
    throws Exception
  {
    Properties localProperties = null;
    if (StringUtils.isNotBlank(paramString2))
      localProperties = PropertiesUtil.loadConfigProperties(paramString2, "zookeeper-ycache.properties", false);
    else
      localProperties = YccGlobalPropertyConfigurer.loadConfigProperties("yihaodian/common", "zookeeper-ycache.properties", false);
    String str = localProperties.getProperty("zk-servers");
    if ((str == null) || (str.equalsIgnoreCase("")))
      throw new Exception("zkAddrs is null");
    this.client = new ZkClient(str, DEFAULT_TIMEOUT);
    this.zkListenPath = "/ycache/pools/" + paramString1;
    PoolDataChangedWatcher localPoolDataChangedWatcher = new PoolDataChangedWatcher(this, paramSockIOPool);
    this.client.subscribeDataChanges(this.zkListenPath, localPoolDataChangedWatcher);
  }

  public List<String> getServerConnects(String paramString)
  {
    ArrayList localArrayList = new ArrayList();
    List localList = getNCServerConnections();
    if (localList.size() > 0)
    {
      Iterator localIterator = localList.iterator();
      while (localIterator.hasNext())
      {
        String str = (String)localIterator.next();
        localArrayList.add(StringUtils.trim(str));
      }
    }
    else
    {
      localArrayList.addAll(getMCServerConnections(paramString));
    }
    return localArrayList;
  }

  public List<String> getNCServerConnections()
  {
    ArrayList localArrayList = new ArrayList();
    List localList = this.client.getChildren("/ycache/pools");
    if ((localList != null) && (localList.size() > 0))
    {
      Iterator localIterator = localList.iterator();
      while (localIterator.hasNext())
      {
        String str = (String)localIterator.next();
        localArrayList.add(StringUtils.trim(str));
      }
    }
    return localArrayList;
  }

  public List<String> getMCServerConnections(String paramString)
  {
    ArrayList localArrayList = new ArrayList();
    byte[] arrayOfByte = this.client.readRawData(this.zkListenPath, true);
    if (arrayOfByte != null)
    {
      String str1 = new String(arrayOfByte);
      String[] arrayOfString1 = StringUtils.split(str1, "\n");
      String[] arrayOfString2 = arrayOfString1;
      int i = arrayOfString2.length;
      for (int j = 0; j < i; ++j)
      {
        String str2 = arrayOfString2[j];
        localArrayList.add(str2);
      }
    }
    return localArrayList;
  }

  public void close()
  {
    if (this.client != null)
      this.client.close();
  }

  class PoolDataChangedWatcher
  implements IZkChildListener, IZkDataListener
  {
    private SockIOPool sockIOPool;

    public PoolDataChangedWatcher(, SockIOPool paramSockIOPool)
    {
      this.sockIOPool = paramSockIOPool;
    }

    public void handleChildChange(, List<String> paramList)
      throws Exception
    {
    }

    public void handleDataChange(, Object paramObject)
      throws Exception
    {
      reInitPool();
    }

    public void handleDataDeleted()
      throws Exception
    {
      reInitPool();
    }

    private void reInitPool()
    {
      try
      {
        this.sockIOPool.reInitialize();
      }
      catch (Exception localException)
      {
        ZKProxy.logger.error("", localException);
      }
    }
  }
}