package com.yihaodian.common.yredis.client.interceptor;

import com.ycache.redis.clients.jedis.BinaryClient.LIST_POSITION;
import com.ycache.redis.clients.jedis.Jedis;
import com.ycache.redis.clients.jedis.JedisPubSub;
import com.ycache.redis.clients.jedis.ShardedJedisPipelineUtils;
import com.yihaodian.common.yredis.client.RedisInterceptor;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class RedisEmptyInterceptor
  implements RedisInterceptor
{
  protected RedisInterceptor nextHandler;

  public RedisInterceptor getNextHandler()
  {
    return this.nextHandler;
  }

  public void setNextHandler(RedisInterceptor paramRedisInterceptor)
  {
    this.nextHandler = paramRedisInterceptor;
  }

  public ShardedJedisPipelineUtils buildPipelineUtils(String paramString)
  {
    return getNextHandler().buildPipelineUtils(paramString);
  }

  public long rpush(String paramString1, String paramString2, String paramString3)
  {
    return getNextHandler().rpush(paramString1, paramString2, paramString3);
  }

  public long rpush(String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    return getNextHandler().rpush(paramString, paramArrayOfByte1, paramArrayOfByte2);
  }

  public long sadd(String paramString1, String paramString2, String[] paramArrayOfString)
  {
    return getNextHandler().sadd(paramString1, paramString2, paramArrayOfString);
  }

  public long sadd(String paramString, byte[] paramArrayOfByte, byte[][] paramArrayOfByte1)
  {
    return getNextHandler().sadd(paramString, paramArrayOfByte, paramArrayOfByte1);
  }

  public String lpop(String paramString1, String paramString2)
  {
    return getNextHandler().lpop(paramString1, paramString2);
  }

  public byte[] lpop(String paramString, byte[] paramArrayOfByte)
  {
    return getNextHandler().lpop(paramString, paramArrayOfByte);
  }

  public String rpop(String paramString1, String paramString2)
  {
    return getNextHandler().rpop(paramString1, paramString2);
  }

  public byte[] rpop(String paramString, byte[] paramArrayOfByte)
  {
    return getNextHandler().rpop(paramString, paramArrayOfByte);
  }

  public long llen(String paramString1, String paramString2)
  {
    return getNextHandler().llen(paramString1, paramString2);
  }

  public long llen(String paramString, byte[] paramArrayOfByte)
  {
    return getNextHandler().llen(paramString, paramArrayOfByte);
  }

  public long lrem(String paramString1, String paramString2, long paramLong, String paramString3)
  {
    return getNextHandler().lrem(paramString1, paramString2, paramLong, paramString3);
  }

  public long lrem(String paramString, byte[] paramArrayOfByte1, long paramLong, byte[] paramArrayOfByte2)
  {
    return getNextHandler().lrem(paramString, paramArrayOfByte1, paramLong, paramArrayOfByte2);
  }

  public String ltrim(String paramString1, String paramString2, long paramLong1, long paramLong2)
  {
    return getNextHandler().ltrim(paramString1, paramString2, paramLong1, paramLong2);
  }

  public String ltrim(String paramString, byte[] paramArrayOfByte, long paramLong1, long paramLong2)
  {
    return getNextHandler().ltrim(paramString, paramArrayOfByte, paramLong1, paramLong2);
  }

  public List<String> lrange(String paramString1, String paramString2, long paramLong1, long paramLong2)
  {
    return getNextHandler().lrange(paramString1, paramString2, paramLong1, paramLong2);
  }

  public List<byte[]> lrange(String paramString, byte[] paramArrayOfByte, long paramLong1, long paramLong2)
  {
    return getNextHandler().lrange(paramString, paramArrayOfByte, paramLong1, paramLong2);
  }

  public Long hset(String paramString1, String paramString2, String paramString3, String paramString4)
  {
    return getNextHandler().hset(paramString1, paramString2, paramString3, paramString4);
  }

  public Long hset(String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
  {
    return getNextHandler().hset(paramString, paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3);
  }

  public String set(String paramString1, String paramString2, String paramString3)
  {
    return getNextHandler().set(paramString1, paramString2, paramString3);
  }

  public String get(String paramString1, String paramString2)
  {
    return getNextHandler().get(paramString1, paramString2);
  }

  public String set(String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    return getNextHandler().set(paramString, paramArrayOfByte1, paramArrayOfByte2);
  }

  public byte[] get(String paramString, byte[] paramArrayOfByte)
  {
    return getNextHandler().get(paramString, paramArrayOfByte);
  }

  public String compressSet(String paramString1, String paramString2, String paramString3)
  {
    return getNextHandler().compressSet(paramString1, paramString2, paramString3);
  }

  public String compressGet(String paramString1, String paramString2)
  {
    return getNextHandler().compressGet(paramString1, paramString2);
  }

  public String compressSet(String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    return getNextHandler().compressSet(paramString, paramArrayOfByte1, paramArrayOfByte2);
  }

  public byte[] compressGet(String paramString, byte[] paramArrayOfByte)
  {
    return getNextHandler().compressGet(paramString, paramArrayOfByte);
  }

  public long del(String paramString1, String paramString2)
  {
    return getNextHandler().del(paramString1, paramString2);
  }

  public long del(String paramString, byte[] paramArrayOfByte)
  {
    return getNextHandler().del(paramString, paramArrayOfByte);
  }

  public String hmset(String paramString1, String paramString2, Map<String, String> paramMap)
  {
    return getNextHandler().hmset(paramString1, paramString2, paramMap);
  }

  public String hmset(String paramString, byte[] paramArrayOfByte, Map<byte[], byte[]> paramMap)
  {
    return getNextHandler().hmset(paramString, paramArrayOfByte, paramMap);
  }

  public String setex(String paramString1, String paramString2, int paramInt, String paramString3)
  {
    return getNextHandler().setex(paramString1, paramString2, paramInt, paramString3);
  }

  public String setex(String paramString, byte[] paramArrayOfByte1, int paramInt, byte[] paramArrayOfByte2)
  {
    return getNextHandler().setex(paramString, paramArrayOfByte1, paramInt, paramArrayOfByte2);
  }

  public long setnx(String paramString1, String paramString2, String paramString3)
  {
    return getNextHandler().setnx(paramString1, paramString2, paramString3);
  }

  public long setnx(String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    return getNextHandler().setnx(paramString, paramArrayOfByte1, paramArrayOfByte2);
  }

  public String compressSetex(String paramString1, String paramString2, int paramInt, String paramString3)
  {
    return getNextHandler().compressSetex(paramString1, paramString2, paramInt, paramString3);
  }

  public String compressSetex(String paramString, byte[] paramArrayOfByte1, int paramInt, byte[] paramArrayOfByte2)
  {
    return getNextHandler().compressSetex(paramString, paramArrayOfByte1, paramInt, paramArrayOfByte2);
  }

  public long compressSetnx(String paramString1, String paramString2, String paramString3)
  {
    return getNextHandler().compressSetnx(paramString1, paramString2, paramString3);
  }

  public long compressSetnx(String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    return getNextHandler().compressSetnx(paramString, paramArrayOfByte1, paramArrayOfByte2);
  }

  public Long expire(String paramString1, String paramString2, int paramInt)
  {
    return getNextHandler().expire(paramString1, paramString2, paramInt);
  }

  public Long expire(String paramString, byte[] paramArrayOfByte, int paramInt)
  {
    return getNextHandler().expire(paramString, paramArrayOfByte, paramInt);
  }

  public boolean exists(String paramString1, String paramString2)
  {
    return getNextHandler().exists(paramString1, paramString2);
  }

  public boolean exists(String paramString, byte[] paramArrayOfByte)
  {
    return getNextHandler().exists(paramString, paramArrayOfByte);
  }

  public String type(String paramString1, String paramString2)
  {
    return getNextHandler().type(paramString1, paramString2);
  }

  public String type(String paramString, byte[] paramArrayOfByte)
  {
    return getNextHandler().type(paramString, paramArrayOfByte);
  }

  public String hget(String paramString1, String paramString2, String paramString3)
  {
    return getNextHandler().hget(paramString1, paramString2, paramString3);
  }

  public byte[] hget(String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    return getNextHandler().hget(paramString, paramArrayOfByte1, paramArrayOfByte2);
  }

  public Map<String, String> hgetAll(String paramString1, String paramString2)
  {
    return getNextHandler().hgetAll(paramString1, paramString2);
  }

  public Map<byte[], byte[]> hgetAll(String paramString, byte[] paramArrayOfByte)
  {
    return getNextHandler().hgetAll(paramString, paramArrayOfByte);
  }

  public Map<String, String> hgetAll(String paramString1, String paramString2, boolean paramBoolean)
  {
    return getNextHandler().hgetAll(paramString1, paramString2, paramBoolean);
  }

  public Map<byte[], byte[]> hgetAll(String paramString, byte[] paramArrayOfByte, boolean paramBoolean)
  {
    return getNextHandler().hgetAll(paramString, paramArrayOfByte, paramBoolean);
  }

  public Map<String, String> hgetAllToLinkedHashMap(String paramString1, String paramString2)
  {
    return getNextHandler().hgetAllToLinkedHashMap(paramString1, paramString2);
  }

  public Map<byte[], byte[]> hgetAllToLinkedHashMap(String paramString, byte[] paramArrayOfByte)
  {
    return getNextHandler().hgetAllToLinkedHashMap(paramString, paramArrayOfByte);
  }

  public Set<String> smembers(String paramString1, String paramString2)
  {
    return getNextHandler().smembers(paramString1, paramString2);
  }

  public Set<byte[]> smembers(String paramString, byte[] paramArrayOfByte)
  {
    return getNextHandler().smembers(paramString, paramArrayOfByte);
  }

  public Long srem(String paramString1, String paramString2, String[] paramArrayOfString)
  {
    return getNextHandler().srem(paramString1, paramString2, paramArrayOfString);
  }

  public Long srem(String paramString, byte[] paramArrayOfByte, byte[][] paramArrayOfByte1)
  {
    return getNextHandler().srem(paramString, paramArrayOfByte, paramArrayOfByte1);
  }

  public boolean sismember(String paramString1, String paramString2, String paramString3)
  {
    return getNextHandler().sismember(paramString1, paramString2, paramString3);
  }

  public boolean sismember(String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    return getNextHandler().sismember(paramString, paramArrayOfByte1, paramArrayOfByte2);
  }

  public Long append(String paramString1, String paramString2, String paramString3)
  {
    return getNextHandler().append(paramString1, paramString2, paramString3);
  }

  public Long append(String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    return getNextHandler().append(paramString, paramArrayOfByte1, paramArrayOfByte2);
  }

  public Long decr(String paramString1, String paramString2)
  {
    return getNextHandler().decr(paramString1, paramString2);
  }

  public Long decr(String paramString, byte[] paramArrayOfByte)
  {
    return getNextHandler().decr(paramString, paramArrayOfByte);
  }

  public Long decrBy(String paramString1, String paramString2, Integer paramInteger)
  {
    return getNextHandler().decrBy(paramString1, paramString2, paramInteger);
  }

  public Long decrBy(String paramString, byte[] paramArrayOfByte, Integer paramInteger)
  {
    return getNextHandler().decrBy(paramString, paramArrayOfByte, paramInteger);
  }

  public String getrange(String paramString1, String paramString2, int paramInt1, int paramInt2)
  {
    return getNextHandler().getrange(paramString1, paramString2, paramInt1, paramInt2);
  }

  public byte[] getrange(String paramString, byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    return getNextHandler().getrange(paramString, paramArrayOfByte, paramInt1, paramInt2);
  }

  public String getSet(String paramString1, String paramString2, String paramString3)
  {
    return getNextHandler().getSet(paramString1, paramString2, paramString3);
  }

  public byte[] getSet(String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    return getNextHandler().getSet(paramString, paramArrayOfByte1, paramArrayOfByte2);
  }

  public String compressGetSet(String paramString1, String paramString2, String paramString3)
  {
    return getNextHandler().compressGetSet(paramString1, paramString2, paramString3);
  }

  public byte[] compressGetSet(String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    return getNextHandler().compressGetSet(paramString, paramArrayOfByte1, paramArrayOfByte2);
  }

  public Long hdel(String paramString1, String paramString2, String[] paramArrayOfString)
  {
    return getNextHandler().hdel(paramString1, paramString2, paramArrayOfString);
  }

  public Long hdel(String paramString, byte[] paramArrayOfByte, byte[][] paramArrayOfByte1)
  {
    return getNextHandler().hdel(paramString, paramArrayOfByte, paramArrayOfByte1);
  }

  public Boolean hexists(String paramString1, String paramString2, String paramString3)
  {
    return getNextHandler().hexists(paramString1, paramString2, paramString3);
  }

  public Boolean hexists(String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    return getNextHandler().hexists(paramString, paramArrayOfByte1, paramArrayOfByte2);
  }

  public Long hincrBy(String paramString1, String paramString2, String paramString3, int paramInt)
  {
    return getNextHandler().hincrBy(paramString1, paramString2, paramString3, paramInt);
  }

  public Long hincrBy(String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, int paramInt)
  {
    return getNextHandler().hincrBy(paramString, paramArrayOfByte1, paramArrayOfByte2, paramInt);
  }

  public Set<String> hkeys(String paramString1, String paramString2)
  {
    return getNextHandler().hkeys(paramString1, paramString2);
  }

  public Set<byte[]> hkeys(String paramString, byte[] paramArrayOfByte)
  {
    return getNextHandler().hkeys(paramString, paramArrayOfByte);
  }

  public Long hlen(String paramString1, String paramString2)
  {
    return getNextHandler().hlen(paramString1, paramString2);
  }

  public Long hlen(String paramString, byte[] paramArrayOfByte)
  {
    return getNextHandler().hlen(paramString, paramArrayOfByte);
  }

  public List<String> hmget(String paramString1, String paramString2, String[] paramArrayOfString)
  {
    return getNextHandler().hmget(paramString1, paramString2, paramArrayOfString);
  }

  public List<byte[]> hmget(String paramString, byte[] paramArrayOfByte, byte[][] paramArrayOfByte1)
  {
    return getNextHandler().hmget(paramString, paramArrayOfByte, paramArrayOfByte1);
  }

  public Long hsetnx(String paramString1, String paramString2, String paramString3, String paramString4)
  {
    return getNextHandler().hsetnx(paramString1, paramString2, paramString3, paramString4);
  }

  public Long hsetnx(String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
  {
    return getNextHandler().hsetnx(paramString, paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3);
  }

  public List<String> hvals(String paramString1, String paramString2)
  {
    return getNextHandler().hvals(paramString1, paramString2);
  }

  public List<byte[]> hvals(String paramString, byte[] paramArrayOfByte)
  {
    return getNextHandler().hvals(paramString, paramArrayOfByte);
  }

  public Long incr(String paramString1, String paramString2)
  {
    return getNextHandler().incr(paramString1, paramString2);
  }

  public Long incr(String paramString, byte[] paramArrayOfByte)
  {
    return getNextHandler().incr(paramString, paramArrayOfByte);
  }

  public boolean electioneer(String paramString1, String paramString2, String paramString3, int paramInt)
  {
    return getNextHandler().electioneer(paramString1, paramString2, paramString3, paramInt);
  }

  public boolean electioneer(String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, int paramInt)
  {
    return getNextHandler().electioneer(paramString, paramArrayOfByte1, paramArrayOfByte2, paramInt);
  }

  public Long incrBy(String paramString1, String paramString2, int paramInt)
  {
    return getNextHandler().incrBy(paramString1, paramString2, paramInt);
  }

  public Long incrBy(String paramString, byte[] paramArrayOfByte, int paramInt)
  {
    return getNextHandler().incrBy(paramString, paramArrayOfByte, paramInt);
  }

  public void subscribe(String paramString1, String paramString2, JedisPubSub paramJedisPubSub, String[] paramArrayOfString)
  {
    getNextHandler().subscribe(paramString1, paramString2, paramJedisPubSub, paramArrayOfString);
  }

  public void subscribe(String paramString, byte[] paramArrayOfByte, JedisPubSub paramJedisPubSub, String[] paramArrayOfString)
  {
    getNextHandler().subscribe(paramString, paramArrayOfByte, paramJedisPubSub, paramArrayOfString);
  }

  public void publish(String paramString1, String paramString2, String paramString3, String paramString4)
  {
    getNextHandler().publish(paramString1, paramString2, paramString3, paramString4);
  }

  public void publish(String paramString1, byte[] paramArrayOfByte, String paramString2, String paramString3)
  {
    getNextHandler().publish(paramString1, paramArrayOfByte, paramString2, paramString3);
  }

  public Jedis getJedisByShardKey(String paramString1, String paramString2)
  {
    return getNextHandler().getJedisByShardKey(paramString1, paramString2);
  }

  public Jedis getJedisByShardKey(String paramString, byte[] paramArrayOfByte)
  {
    return getNextHandler().getJedisByShardKey(paramString, paramArrayOfByte);
  }

  public int getShardIndex(String paramString1, String paramString2)
  {
    return getNextHandler().getShardIndex(paramString1, paramString2);
  }

  public int getShardIndex(String paramString, byte[] paramArrayOfByte)
  {
    return getNextHandler().getShardIndex(paramString, paramArrayOfByte);
  }

  public long lpush(String paramString1, String paramString2, String paramString3)
  {
    return getNextHandler().lpush(paramString1, paramString2, paramString3);
  }

  public long lpush(String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    return getNextHandler().lpush(paramString, paramArrayOfByte1, paramArrayOfByte2);
  }

  public long rpushx(String paramString1, String paramString2, String paramString3)
  {
    return getNextHandler().rpushx(paramString1, paramString2, paramString3);
  }

  public long rpushx(String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    return getNextHandler().rpushx(paramString, paramArrayOfByte1, paramArrayOfByte2);
  }

  public long lpushx(String paramString1, String paramString2, String paramString3)
  {
    return getNextHandler().lpushx(paramString1, paramString2, paramString3);
  }

  public long lpushx(String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    return getNextHandler().lpushx(paramString, paramArrayOfByte1, paramArrayOfByte2);
  }

  public String lindex(String paramString1, String paramString2, long paramLong)
  {
    return getNextHandler().lindex(paramString1, paramString2, paramLong);
  }

  public byte[] lindex(String paramString, byte[] paramArrayOfByte, long paramLong)
  {
    return getNextHandler().lindex(paramString, paramArrayOfByte, paramLong);
  }

  public Long linsert(String paramString, byte[] paramArrayOfByte1, BinaryClient.LIST_POSITION paramLIST_POSITION, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
  {
    return getNextHandler().linsert(paramString, paramArrayOfByte1, paramLIST_POSITION, paramArrayOfByte2, paramArrayOfByte3);
  }

  public Long linsert(String paramString1, String paramString2, BinaryClient.LIST_POSITION paramLIST_POSITION, String paramString3, String paramString4)
  {
    return getNextHandler().linsert(paramString1, paramString2, paramLIST_POSITION, paramString3, paramString4);
  }

  public String lset(String paramString1, String paramString2, long paramLong, String paramString3)
  {
    return getNextHandler().lset(paramString1, paramString2, paramLong, paramString3);
  }

  public String lset(String paramString, byte[] paramArrayOfByte1, long paramLong, byte[] paramArrayOfByte2)
  {
    return getNextHandler().lset(paramString, paramArrayOfByte1, paramLong, paramArrayOfByte2);
  }

  public long ttl(String paramString1, String paramString2)
  {
    return getNextHandler().ttl(paramString1, paramString2);
  }

  public long ttl(String paramString, byte[] paramArrayOfByte)
  {
    return getNextHandler().ttl(paramString, paramArrayOfByte);
  }

  public Long expireAt(String paramString1, String paramString2, long paramLong)
  {
    return getNextHandler().expireAt(paramString1, paramString2, paramLong);
  }

  public Long expireAt(String paramString, byte[] paramArrayOfByte, long paramLong)
  {
    return getNextHandler().expireAt(paramString, paramArrayOfByte, paramLong);
  }

  public Long scard(String paramString1, String paramString2)
  {
    return getNextHandler().scard(paramString1, paramString2);
  }

  public Long scard(String paramString, byte[] paramArrayOfByte)
  {
    return getNextHandler().scard(paramString, paramArrayOfByte);
  }

  public String spop(String paramString1, String paramString2)
  {
    return getNextHandler().spop(paramString1, paramString2);
  }

  public byte[] spop(String paramString, byte[] paramArrayOfByte)
  {
    return getNextHandler().spop(paramString, paramArrayOfByte);
  }

  public String srandmember(String paramString1, String paramString2)
  {
    return getNextHandler().srandmember(paramString1, paramString2);
  }

  public byte[] srandmember(String paramString, byte[] paramArrayOfByte)
  {
    return getNextHandler().srandmember(paramString, paramArrayOfByte);
  }
}