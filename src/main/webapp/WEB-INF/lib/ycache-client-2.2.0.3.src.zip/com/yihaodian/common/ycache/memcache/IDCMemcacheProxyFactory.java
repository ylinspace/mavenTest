package com.yihaodian.common.ycache.memcache;

import com.ycache.danga.MemCached.SockIOPool;
import com.yihaodian.common.idc.IDCCommandUtil;
import com.yihaodian.common.idc.IDCInterceptorMemcacheProxy;
import com.yihaodian.common.idc.IDCMemcacheProxy;
import com.yihaodian.common.idc.IDCSyncInterceptorMemcacheProxy;
import com.yihaodian.common.ycache.CacheProxy;
import com.yihaodian.common.ycache.memcache.conf.MemcacheConfig;
import com.yihaodian.common.ycache.memcache.conf.MemcachePoolConfig;
import com.yihaodian.common.ycache.memcache.exception.MemcacheInitException;
import com.yihaodian.common.ycache.util.YMemcachedProxyUtil;
import com.yihaodian.configcentre.client.utils.YccGlobalPropertyConfigurer;
import com.yihaodian.configcentre.listener.ConfigureTargetListener;
import com.yihaodian.configcentre.listener.YConfigurationDynamicBean;
import java.io.File;
import java.util.Hashtable;
import java.util.Map;
import java.util.concurrent.Executor;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class IDCMemcacheProxyFactory extends YmemcacheProxyFactory
{
  static Log logger = LogFactory.getLog(IDCMemcacheProxyFactory.class);

  public static YmemcacheProxyFactory configure(String paramString)
    throws MemcacheInitException
  {
    if (singletonFactory == null)
      synchronized (initLock)
      {
        if (singletonFactory == null)
          singletonFactory = new IDCMemcacheProxyFactory(paramString);
        else
          add(paramString);
      }
    else
      add(paramString);
    return singletonFactory;
  }

  public static YmemcacheProxyFactory configure()
  {
    File localFile = YccGlobalPropertyConfigurer.loadConfigFile("yihaodian/common", "memcached_empty_config.xml");
    try
    {
      configure("file:" + localFile.getAbsolutePath());
    }
    catch (MemcacheInitException localMemcacheInitException)
    {
      logger.error("inital IDC proxy fail. config file=memcached_empty_config.xml");
    }
    return null;
  }

  IDCMemcacheProxyFactory(String paramString)
    throws MemcacheInitException
  {
    super(paramString);
    reInitIDCYCache();
    YConfigurationDynamicBean localYConfigurationDynamicBean = new YConfigurationDynamicBean("yihaodian/common", "idc_common.properties");
    localYConfigurationDynamicBean.addListener(this, new YmemcacheConfigurationChangeListener(this, null));
    localYConfigurationDynamicBean.startListeners();
    localYConfigurationDynamicBean = new YConfigurationDynamicBean("yihaodian/common", "idc_ycache_memcache.xml");
    localYConfigurationDynamicBean.addListener(this, new YmemcacheConfigurationChangeListener(this, null));
    localYConfigurationDynamicBean.startListeners();
  }

  public static void reInitIDCYCache()
  {
    String str1 = YccGlobalPropertyConfigurer.loadConfigString("yihaodian/common", "idc_common.properties");
    Hashtable localHashtable = YccGlobalPropertyConfigurer.loadProperties(str1);
    String str2 = (String)localHashtable.get("idc_ycache_poolName_list");
    String str3 = (String)localHashtable.get("slave_idc_invalid_local");
    if ((str2 == null) || (str2.trim().length() == 0))
      logger.error("idc_common.properties 文件缺少值idc_ycache_poolName_list");
    if ((str3 != null) && (str3.trim().equals("true")))
    {
      IDCCommandUtil.setInvalidLocal_slave(true);
      logger.warn("enable InvalidLocal_slave");
    }
    String[] arrayOfString = IDCCommandUtil.getOtherIDCPoolNames();
    if (arrayOfString != null)
    {
      localObject = arrayOfString;
      int i = localObject.length;
      for (int j = 0; j < i; ++j)
      {
        String str4 = localObject[j];
        SockIOPool localSockIOPool = SockIOPool.getInstance(str4);
        if ((localSockIOPool != null) && (localSockIOPool.isInitialized()))
          localSockIOPool.shutDown();
      }
    }
    arrayOfString = str2.split(",");
    IDCCommandUtil.setOtherIDCPoolNames(arrayOfString);
    Object localObject = YccGlobalPropertyConfigurer.loadConfigFile("yihaodian/common", "idc_ycache_memcache.xml");
    try
    {
      YmemcacheProxyFactory.add("file:" + ((File)localObject).getAbsolutePath());
    }
    catch (MemcacheInitException localMemcacheInitException)
    {
      logger.error("init IDC memcache fail idc_ycache_memcache.xmlERROR:" + localMemcacheInitException);
    }
  }

  public static IDCMemcacheProxy getClient(String paramString)
  {
    CacheProxy localCacheProxy = YmemcacheProxyFactory.getClient(paramString);
    if (localCacheProxy instanceof IDCMemcacheProxy)
      return ((IDCMemcacheProxy)localCacheProxy);
    logger.error("没有找到 IDCMemcacheProxy ，通过poolName=" + paramString);
    return null;
  }

  protected CacheProxy findClient(String paramString)
  {
    if (this.proxyPool.containsKey(paramString))
      return ((CacheProxy)this.proxyPool.get(paramString));
    synchronized (this.proxyPool)
    {
      if (!(this.proxyPool.containsKey(paramString)))
        break label63;
      return ((CacheProxy)this.proxyPool.get(paramString));
      label63: if (MemcacheAdmin.getInstance().containPool(paramString))
        break label115;
      logger.warn("can't find memcache pool:" + paramString + " make sure it is configured in file " + configureFilePath);
      return null;
      label115: String str1 = (String)MemcacheConfig.getMasterIDCMap().get(paramString);
      Object localObject1 = null;
      if (!(StringUtils.isBlank(str1)))
        break label155;
      localObject1 = new IDCInterceptorMemcacheProxy(paramString, this.headInterceptor);
      break label189:
      label155: String str2 = YMemcachedProxyUtil.generateMasterPoolName(paramString, str1);
      MemcachePoolConfig localMemcachePoolConfig = MemcacheAdmin.getPoolConfig(str2);
      localObject1 = new IDCSyncInterceptorMemcacheProxy(paramString, this.headInterceptor, str1, localMemcachePoolConfig.getSyncTime());
      label189: this.proxyPool.put(paramString, localObject1);
      IDCCommandUtil.setCommand_queue_size(MemcacheAdmin.getPoolConfig(paramString).getInvalidQueueSize());
      IDCCommandUtil.setCommand_add_key_timeout(MemcacheAdmin.getPoolConfig(paramString).getInvalidQueueTimeOut());
      IDCCommandUtil.setCommand_send_key_timeout(MemcacheAdmin.getPoolConfig(paramString).getInvalidBatchSendTimeOut());
      IDCCommandUtil.setCommand_batch_send_size(MemcacheAdmin.getPoolConfig(paramString).getInvaldiBatchSize());
    }
    return ((CacheProxy)(CacheProxy)this.proxyPool.get(paramString));
  }

  public static void main(String[] paramArrayOfString)
    throws MemcacheInitException
  {
    IDCMemcacheProxyFactory localIDCMemcacheProxyFactory = new IDCMemcacheProxyFactory("");
  }

  private class YmemcacheConfigurationChangeListener
  implements ConfigureTargetListener
  {
    public void setTargetObject()
    {
    }

    public Executor getExecutor()
    {
      return null;
    }

    public void receiveConfigInfo()
    {
      IDCMemcacheProxyFactory.logger.info("idc_ycache_memcache.xml文件发生了变化，重新初始化！");
      IDCMemcacheProxyFactory.reInitIDCYCache();
    }
  }
}