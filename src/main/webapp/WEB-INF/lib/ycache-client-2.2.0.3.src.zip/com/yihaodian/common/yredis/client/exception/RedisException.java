package com.yihaodian.common.yredis.client.exception;

public class RedisException extends RuntimeException
{
  private static final long serialVersionUID = 1L;

  public RedisException(String paramString)
  {
    super(paramString);
  }

  public RedisException(String paramString, Throwable paramThrowable)
  {
    super(paramString, paramThrowable);
  }
}