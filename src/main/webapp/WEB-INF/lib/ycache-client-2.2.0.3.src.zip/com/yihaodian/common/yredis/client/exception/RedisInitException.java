package com.yihaodian.common.yredis.client.exception;

public class RedisInitException extends Exception
{
  private static final long serialVersionUID = 1L;

  public RedisInitException(String paramString, Throwable paramThrowable)
  {
    super(paramString, paramThrowable);
  }

  public RedisInitException(String paramString)
  {
    super(paramString);
  }
}