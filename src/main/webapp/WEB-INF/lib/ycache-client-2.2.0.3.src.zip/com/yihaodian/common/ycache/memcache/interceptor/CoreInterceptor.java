package com.yihaodian.common.ycache.memcache.interceptor;

import com.yihaodian.common.ycache.CacheProxy;
import com.yihaodian.common.ycache.memcache.MemcacheAdmin;
import com.yihaodian.common.ycache.memcache.MemcacheInterceptor;
import com.yihaodian.common.ycache.memcache.impl.BaseMemcacheProxy;
import com.yihaodian.common.ycache.stats.StatsLocalCache;
import com.yihaodian.common.ycache.stats.StatsLocalCacheManager;
import java.util.Date;
import java.util.Map;

public class CoreInterceptor
  implements MemcacheInterceptor
{
  public Object handleGet(String paramString1, String paramString2)
  {
    Object localObject = null;
    try
    {
      BaseMemcacheProxy localBaseMemcacheProxy = MemcacheAdmin.getBaseProxy(paramString1);
      localObject = localBaseMemcacheProxy.get(paramString2);
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return localObject;
  }

  public Object handleGet(String paramString1, String paramString2, String paramString3)
  {
    Object localObject = null;
    try
    {
      BaseMemcacheProxy localBaseMemcacheProxy = MemcacheAdmin.getBaseProxy(paramString1);
      localObject = localBaseMemcacheProxy.get(paramString2, paramString3);
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return localObject;
  }

  public boolean handlePut(String paramString1, String paramString2, Object paramObject)
  {
    boolean bool = false;
    try
    {
      BaseMemcacheProxy localBaseMemcacheProxy = MemcacheAdmin.getBaseProxy(paramString1);
      bool = localBaseMemcacheProxy.put(paramString2, paramObject);
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return bool;
  }

  public boolean handlePut(String paramString1, String paramString2, Object paramObject, long paramLong)
  {
    boolean bool = false;
    try
    {
      BaseMemcacheProxy localBaseMemcacheProxy = MemcacheAdmin.getBaseProxy(paramString1);
      bool = localBaseMemcacheProxy.putWithSecond(paramString2, paramObject, paramLong);
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return bool;
  }

  public boolean handlePut(String paramString1, String paramString2, Object paramObject, Date paramDate)
  {
    boolean bool = false;
    try
    {
      BaseMemcacheProxy localBaseMemcacheProxy = MemcacheAdmin.getBaseProxy(paramString1);
      bool = localBaseMemcacheProxy.put(paramString2, paramObject, paramDate);
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return bool;
  }

  public Map<String, Object> handleGetMulti(String paramString, String[] paramArrayOfString)
  {
    Map localMap = null;
    try
    {
      BaseMemcacheProxy localBaseMemcacheProxy = MemcacheAdmin.getBaseProxy(paramString);
      localMap = localBaseMemcacheProxy.getMulti(paramArrayOfString);
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return localMap;
  }

  public boolean handlePut(String paramString1, String paramString2, Object paramObject, int paramInt)
  {
    boolean bool = false;
    try
    {
      BaseMemcacheProxy localBaseMemcacheProxy = MemcacheAdmin.getBaseProxy(paramString1);
      bool = localBaseMemcacheProxy.put(paramString2, paramObject, paramInt);
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return bool;
  }

  public boolean handleRemove(String paramString1, String paramString2)
  {
    boolean bool = false;
    try
    {
      BaseMemcacheProxy localBaseMemcacheProxy = MemcacheAdmin.getBaseProxy(paramString1);
      bool = localBaseMemcacheProxy.remove(paramString2);
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return bool;
  }

  public boolean handleRemove(String paramString1, String paramString2, String paramString3)
  {
    boolean bool = false;
    try
    {
      BaseMemcacheProxy localBaseMemcacheProxy = MemcacheAdmin.getBaseProxy(paramString1);
      bool = localBaseMemcacheProxy.remove(paramString2, paramString3);
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return bool;
  }

  public boolean handleAdd(String paramString1, String paramString2, Object paramObject)
  {
    boolean bool = false;
    try
    {
      BaseMemcacheProxy localBaseMemcacheProxy = MemcacheAdmin.getBaseProxy(paramString1);
      bool = localBaseMemcacheProxy.add(paramString2, paramObject);
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return bool;
  }

  public boolean handleAdd(String paramString1, String paramString2, Object paramObject, int paramInt)
  {
    boolean bool = false;
    try
    {
      BaseMemcacheProxy localBaseMemcacheProxy = MemcacheAdmin.getBaseProxy(paramString1);
      bool = localBaseMemcacheProxy.add(paramString2, paramObject, paramInt);
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return bool;
  }

  public boolean handleAdd(String paramString1, String paramString2, Object paramObject, Date paramDate)
  {
    boolean bool = false;
    try
    {
      BaseMemcacheProxy localBaseMemcacheProxy = MemcacheAdmin.getBaseProxy(paramString1);
      bool = localBaseMemcacheProxy.add(paramString2, paramObject, paramDate);
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return bool;
  }

  public boolean handleAdd(String paramString1, String paramString2, Object paramObject, long paramLong)
  {
    boolean bool = false;
    try
    {
      BaseMemcacheProxy localBaseMemcacheProxy = MemcacheAdmin.getBaseProxy(paramString1);
      bool = localBaseMemcacheProxy.addWithSecond(paramString2, paramObject, paramLong);
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return bool;
  }

  public MemcacheInterceptor getNextHandler()
  {
    return null;
  }

  public void setNextHandler(MemcacheInterceptor paramMemcacheInterceptor)
  {
  }

  public synchronized void incrCounter(String paramString, int paramInt)
  {
    StatsLocalCache localStatsLocalCache = StatsLocalCacheManager.getContent(paramString);
    if (localStatsLocalCache != null)
    {
      Integer localInteger = (Integer)localStatsLocalCache.getValue();
      localInteger = Integer.valueOf(localInteger.intValue() + paramInt);
      localStatsLocalCache.setValue(localInteger);
    }
  }

  public long incr(String paramString1, String paramString2, long paramLong)
  {
    long l = -6318801846320234496L;
    try
    {
      BaseMemcacheProxy localBaseMemcacheProxy = MemcacheAdmin.getBaseProxy(paramString1);
      l = localBaseMemcacheProxy.incr(paramString2, paramLong);
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return l;
  }

  public long decr(String paramString1, String paramString2, long paramLong)
  {
    long l = -6318801846320234496L;
    try
    {
      BaseMemcacheProxy localBaseMemcacheProxy = MemcacheAdmin.getBaseProxy(paramString1);
      l = localBaseMemcacheProxy.decr(paramString2, paramLong);
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return l;
  }

  public boolean storeCounter(String paramString1, String paramString2, long paramLong)
  {
    boolean bool = false;
    try
    {
      BaseMemcacheProxy localBaseMemcacheProxy = MemcacheAdmin.getBaseProxy(paramString1);
      bool = localBaseMemcacheProxy.storeCounter(paramString2, paramLong);
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return bool;
  }

  public boolean storeCounter(String paramString1, String paramString2, long paramLong, int paramInt)
  {
    boolean bool = false;
    try
    {
      BaseMemcacheProxy localBaseMemcacheProxy = MemcacheAdmin.getBaseProxy(paramString1);
      bool = localBaseMemcacheProxy.storeCounter(paramString2, paramLong, paramInt);
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return bool;
  }

  public long getCounter(String paramString1, String paramString2)
  {
    long l = -6318801846320234496L;
    try
    {
      BaseMemcacheProxy localBaseMemcacheProxy = MemcacheAdmin.getBaseProxy(paramString1);
      l = localBaseMemcacheProxy.getCounter(paramString2);
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return l;
  }

  public long addOrIncr(String paramString1, String paramString2, long paramLong)
  {
    long l = -6318801846320234496L;
    try
    {
      BaseMemcacheProxy localBaseMemcacheProxy = MemcacheAdmin.getBaseProxy(paramString1);
      l = localBaseMemcacheProxy.addOrIncr(paramString2, paramLong);
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return l;
  }

  public long addOrDecr(String paramString1, String paramString2, long paramLong)
  {
    long l = -6318801846320234496L;
    try
    {
      BaseMemcacheProxy localBaseMemcacheProxy = MemcacheAdmin.getBaseProxy(paramString1);
      l = localBaseMemcacheProxy.addOrDecr(paramString2, paramLong);
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return l;
  }

  public boolean handleReplace(String paramString1, String paramString2, Object paramObject)
  {
    boolean bool = false;
    try
    {
      BaseMemcacheProxy localBaseMemcacheProxy = MemcacheAdmin.getBaseProxy(paramString1);
      bool = localBaseMemcacheProxy.replace(paramString2, paramObject);
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return bool;
  }

  public boolean handleReplace(String paramString1, String paramString2, Object paramObject, int paramInt)
  {
    boolean bool = false;
    try
    {
      BaseMemcacheProxy localBaseMemcacheProxy = MemcacheAdmin.getBaseProxy(paramString1);
      bool = localBaseMemcacheProxy.replace(paramString2, paramObject, paramInt);
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return bool;
  }

  public boolean handleReplace(String paramString1, String paramString2, Object paramObject, Date paramDate)
  {
    boolean bool = false;
    try
    {
      BaseMemcacheProxy localBaseMemcacheProxy = MemcacheAdmin.getBaseProxy(paramString1);
      bool = localBaseMemcacheProxy.replace(paramString2, paramObject, paramDate);
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return bool;
  }

  public boolean handleReplace(String paramString1, String paramString2, Object paramObject, long paramLong)
  {
    boolean bool = false;
    try
    {
      BaseMemcacheProxy localBaseMemcacheProxy = MemcacheAdmin.getBaseProxy(paramString1);
      bool = localBaseMemcacheProxy.replaceWithSecond(paramString2, paramObject, paramLong);
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return bool;
  }
}