package com.yihaodian.common.yredis.client;

import com.yihaodian.common.idc.IDCCommandUtil;
import com.yihaodian.common.idc.IDCInterceptorRedisProxy;
import com.yihaodian.common.idc.IDCRedisProxy;
import com.yihaodian.common.ycache.memcache.IDCMemcacheProxyFactory;
import com.yihaodian.common.yredis.RedisProxy;
import com.yihaodian.common.yredis.client.conf.RedisPoolConfig;
import com.yihaodian.common.yredis.client.exception.RedisInitException;
import java.util.Map;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class IDCRedisProxyFactory extends YredisProxyFactory
{
  static Log logger = LogFactory.getLog(IDCRedisProxyFactory.class);

  public static YredisProxyFactory configure(String paramString)
    throws RedisInitException
  {
    if (singletonFactory == null)
      synchronized (initRedisLock)
      {
        if (singletonFactory == null)
          singletonFactory = new IDCRedisProxyFactory(paramString);
        else
          add(paramString);
      }
    else
      add(paramString);
    return singletonFactory;
  }

  IDCRedisProxyFactory(String paramString)
    throws RedisInitException
  {
    super(paramString);
    IDCMemcacheProxyFactory.configure();
  }

  private void reInitIDCYCache()
  {
    IDCMemcacheProxyFactory.reInitIDCYCache();
  }

  public static IDCRedisProxy getClient(String paramString)
  {
    RedisProxy localRedisProxy = YredisProxyFactory.getClient(paramString);
    if (localRedisProxy instanceof IDCRedisProxy)
      return ((IDCRedisProxy)localRedisProxy);
    logger.error("没有找到 IDCRedisProxy ，通过poolName=" + paramString);
    return null;
  }

  protected RedisProxy findClient(String paramString)
  {
    if (this.proxyPool.containsKey(paramString))
      return ((RedisProxy)this.proxyPool.get(paramString));
    synchronized (this.proxyPool)
    {
      if (!(this.proxyPool.containsKey(paramString)))
        break label63;
      return ((RedisProxy)this.proxyPool.get(paramString));
      label63: if (RedisAdmin.getInstance().containPool(paramString))
        break label115;
      logger.warn("can't find redis pool:" + paramString + " make sure it is configured in file " + configureFilePath);
      return null;
      label115: IDCInterceptorRedisProxy localIDCInterceptorRedisProxy = new IDCInterceptorRedisProxy(paramString, this.headInterceptor);
      this.proxyPool.put(paramString, localIDCInterceptorRedisProxy);
      IDCCommandUtil.setCommand_queue_size(RedisAdmin.getPoolConfig(paramString).getInvalidQueueSize());
      IDCCommandUtil.setCommand_add_key_timeout(RedisAdmin.getPoolConfig(paramString).getInvalidQueueTimeOut());
      IDCCommandUtil.setCommand_send_key_timeout(RedisAdmin.getPoolConfig(paramString).getInvalidBatchSendTimeOut());
      IDCCommandUtil.setCommand_batch_send_size(RedisAdmin.getPoolConfig(paramString).getInvaldiBatchSize());
    }
    return ((RedisProxy)this.proxyPool.get(paramString));
  }
}