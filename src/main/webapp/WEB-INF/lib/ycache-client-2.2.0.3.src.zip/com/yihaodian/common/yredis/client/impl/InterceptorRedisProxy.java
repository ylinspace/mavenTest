package com.yihaodian.common.yredis.client.impl;

import com.ycache.redis.clients.jedis.BinaryClient.LIST_POSITION;
import com.ycache.redis.clients.jedis.Jedis;
import com.ycache.redis.clients.jedis.JedisPubSub;
import com.ycache.redis.clients.jedis.ShardedJedisPipelineUtils;
import com.yihaodian.common.yredis.RedisProxy;
import com.yihaodian.common.yredis.client.RedisInterceptor;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class InterceptorRedisProxy
  implements RedisProxy
{
  private RedisInterceptor headInterceptor;
  protected String poolName;

  public InterceptorRedisProxy(String paramString, RedisInterceptor paramRedisInterceptor)
  {
    this.poolName = paramString;
    this.headInterceptor = paramRedisInterceptor;
  }

  public ShardedJedisPipelineUtils buildPipelineUtils()
  {
    return this.headInterceptor.buildPipelineUtils(this.poolName);
  }

  public long rpush(String paramString1, String paramString2)
  {
    return this.headInterceptor.rpush(this.poolName, paramString1, paramString2);
  }

  public long rpush(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    return this.headInterceptor.rpush(this.poolName, paramArrayOfByte1, paramArrayOfByte2);
  }

  public long sadd(String paramString, String[] paramArrayOfString)
  {
    return this.headInterceptor.sadd(this.poolName, paramString, paramArrayOfString);
  }

  public long sadd(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1)
  {
    return this.headInterceptor.sadd(this.poolName, paramArrayOfByte, paramArrayOfByte1);
  }

  public String lpop(String paramString)
  {
    return this.headInterceptor.lpop(this.poolName, paramString);
  }

  public byte[] lpop(byte[] paramArrayOfByte)
  {
    return this.headInterceptor.lpop(this.poolName, paramArrayOfByte);
  }

  public String rpop(String paramString)
  {
    return this.headInterceptor.rpop(this.poolName, paramString);
  }

  public byte[] rpop(byte[] paramArrayOfByte)
  {
    return this.headInterceptor.rpop(this.poolName, paramArrayOfByte);
  }

  public long llen(String paramString)
  {
    return this.headInterceptor.llen(this.poolName, paramString);
  }

  public long llen(byte[] paramArrayOfByte)
  {
    return this.headInterceptor.llen(this.poolName, paramArrayOfByte);
  }

  public long lrem(String paramString1, long paramLong, String paramString2)
  {
    return this.headInterceptor.lrem(this.poolName, paramString1, paramLong, paramString2);
  }

  public long lrem(byte[] paramArrayOfByte1, long paramLong, byte[] paramArrayOfByte2)
  {
    return this.headInterceptor.lrem(this.poolName, paramArrayOfByte1, paramLong, paramArrayOfByte2);
  }

  public String ltrim(String paramString, long paramLong1, long paramLong2)
  {
    return this.headInterceptor.ltrim(this.poolName, paramString, paramLong1, paramLong2);
  }

  public String ltrim(byte[] paramArrayOfByte, long paramLong1, long paramLong2)
  {
    return this.headInterceptor.ltrim(this.poolName, paramArrayOfByte, paramLong1, paramLong2);
  }

  public List<String> lrange(String paramString, long paramLong1, long paramLong2)
  {
    return this.headInterceptor.lrange(this.poolName, paramString, paramLong1, paramLong2);
  }

  public List<byte[]> lrange(byte[] paramArrayOfByte, long paramLong1, long paramLong2)
  {
    return this.headInterceptor.lrange(this.poolName, paramArrayOfByte, paramLong1, paramLong2);
  }

  public Long hset(String paramString1, String paramString2, String paramString3)
  {
    return this.headInterceptor.hset(this.poolName, paramString1, paramString2, paramString3);
  }

  public Long hset(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
  {
    return this.headInterceptor.hset(this.poolName, paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3);
  }

  public String set(String paramString1, String paramString2)
  {
    return this.headInterceptor.set(this.poolName, paramString1, paramString2);
  }

  public String get(String paramString)
  {
    return this.headInterceptor.get(this.poolName, paramString);
  }

  public String set(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    return this.headInterceptor.set(this.poolName, paramArrayOfByte1, paramArrayOfByte2);
  }

  public byte[] get(byte[] paramArrayOfByte)
  {
    return this.headInterceptor.get(this.poolName, paramArrayOfByte);
  }

  public String compressSet(String paramString1, String paramString2)
  {
    return this.headInterceptor.compressSet(this.poolName, paramString1, paramString2);
  }

  public String compressGet(String paramString)
  {
    return this.headInterceptor.compressGet(this.poolName, paramString);
  }

  public String compressSet(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    return this.headInterceptor.compressSet(this.poolName, paramArrayOfByte1, paramArrayOfByte2);
  }

  public byte[] compressGet(byte[] paramArrayOfByte)
  {
    return this.headInterceptor.compressGet(this.poolName, paramArrayOfByte);
  }

  public long del(String paramString)
  {
    return this.headInterceptor.del(this.poolName, paramString);
  }

  public long del(byte[] paramArrayOfByte)
  {
    return this.headInterceptor.del(this.poolName, paramArrayOfByte);
  }

  public String hmset(String paramString, Map<String, String> paramMap)
  {
    return this.headInterceptor.hmset(this.poolName, paramString, paramMap);
  }

  public String hmset(byte[] paramArrayOfByte, Map<byte[], byte[]> paramMap)
  {
    return this.headInterceptor.hmset(this.poolName, paramArrayOfByte, paramMap);
  }

  public String setex(String paramString1, int paramInt, String paramString2)
  {
    return this.headInterceptor.setex(this.poolName, paramString1, paramInt, paramString2);
  }

  public String setex(byte[] paramArrayOfByte1, int paramInt, byte[] paramArrayOfByte2)
  {
    return this.headInterceptor.setex(this.poolName, paramArrayOfByte1, paramInt, paramArrayOfByte2);
  }

  public long setnx(String paramString1, String paramString2)
  {
    return this.headInterceptor.setnx(this.poolName, paramString1, paramString2);
  }

  public long setnx(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    return this.headInterceptor.setnx(this.poolName, paramArrayOfByte1, paramArrayOfByte2);
  }

  public String compressSetex(String paramString1, int paramInt, String paramString2)
  {
    return this.headInterceptor.compressSetex(this.poolName, paramString1, paramInt, paramString2);
  }

  public String compressSetex(byte[] paramArrayOfByte1, int paramInt, byte[] paramArrayOfByte2)
  {
    return this.headInterceptor.compressSetex(this.poolName, paramArrayOfByte1, paramInt, paramArrayOfByte2);
  }

  public long compressSetnx(String paramString1, String paramString2)
  {
    return this.headInterceptor.compressSetnx(this.poolName, paramString1, paramString2);
  }

  public long compressSetnx(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    return this.headInterceptor.compressSetnx(this.poolName, paramArrayOfByte1, paramArrayOfByte2);
  }

  public Long expire(String paramString, int paramInt)
  {
    return this.headInterceptor.expire(this.poolName, paramString, paramInt);
  }

  public Long expire(byte[] paramArrayOfByte, int paramInt)
  {
    return this.headInterceptor.expire(this.poolName, paramArrayOfByte, paramInt);
  }

  public boolean exists(String paramString)
  {
    return this.headInterceptor.exists(this.poolName, paramString);
  }

  public boolean exists(byte[] paramArrayOfByte)
  {
    return this.headInterceptor.exists(this.poolName, paramArrayOfByte);
  }

  public String type(String paramString)
  {
    return this.headInterceptor.type(this.poolName, paramString);
  }

  public String type(byte[] paramArrayOfByte)
  {
    return this.headInterceptor.type(this.poolName, paramArrayOfByte);
  }

  public String hget(String paramString1, String paramString2)
  {
    return this.headInterceptor.hget(this.poolName, paramString1, paramString2);
  }

  public byte[] hget(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    return this.headInterceptor.hget(this.poolName, paramArrayOfByte1, paramArrayOfByte2);
  }

  public Map<String, String> hgetAll(String paramString)
  {
    return this.headInterceptor.hgetAll(this.poolName, paramString);
  }

  public Map<byte[], byte[]> hgetAll(byte[] paramArrayOfByte)
  {
    return this.headInterceptor.hgetAll(this.poolName, paramArrayOfByte);
  }

  public Map<String, String> hgetAll(String paramString, boolean paramBoolean)
  {
    return this.headInterceptor.hgetAll(this.poolName, paramString, paramBoolean);
  }

  public Map<byte[], byte[]> hgetAll(byte[] paramArrayOfByte, boolean paramBoolean)
  {
    return this.headInterceptor.hgetAll(this.poolName, paramArrayOfByte, paramBoolean);
  }

  public Map<String, String> hgetAllToLinkedHashMap(String paramString)
  {
    return this.headInterceptor.hgetAllToLinkedHashMap(this.poolName, paramString);
  }

  public Map<byte[], byte[]> hgetAllToLinkedHashMap(byte[] paramArrayOfByte)
  {
    return this.headInterceptor.hgetAllToLinkedHashMap(this.poolName, paramArrayOfByte);
  }

  public Set<String> smembers(String paramString)
  {
    return this.headInterceptor.smembers(this.poolName, paramString);
  }

  public Set<byte[]> smembers(byte[] paramArrayOfByte)
  {
    return this.headInterceptor.smembers(this.poolName, paramArrayOfByte);
  }

  public Long srem(String paramString, String[] paramArrayOfString)
  {
    return this.headInterceptor.srem(this.poolName, paramString, paramArrayOfString);
  }

  public Long srem(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1)
  {
    return this.headInterceptor.srem(this.poolName, paramArrayOfByte, paramArrayOfByte1);
  }

  public boolean sismember(String paramString1, String paramString2)
  {
    return this.headInterceptor.sismember(this.poolName, paramString1, paramString2);
  }

  public boolean sismember(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    return this.headInterceptor.sismember(this.poolName, paramArrayOfByte1, paramArrayOfByte2);
  }

  public Long append(String paramString1, String paramString2)
  {
    return this.headInterceptor.append(this.poolName, paramString1, paramString2);
  }

  public Long append(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    return this.headInterceptor.append(this.poolName, paramArrayOfByte1, paramArrayOfByte2);
  }

  public Long decr(String paramString)
  {
    return this.headInterceptor.decr(this.poolName, paramString);
  }

  public Long decr(byte[] paramArrayOfByte)
  {
    return this.headInterceptor.decr(this.poolName, paramArrayOfByte);
  }

  public Long decrBy(String paramString, Integer paramInteger)
  {
    return this.headInterceptor.decrBy(this.poolName, paramString, paramInteger);
  }

  public Long decrBy(byte[] paramArrayOfByte, Integer paramInteger)
  {
    return this.headInterceptor.decrBy(this.poolName, paramArrayOfByte, paramInteger);
  }

  public String getrange(String paramString, int paramInt1, int paramInt2)
  {
    return this.headInterceptor.getrange(this.poolName, paramString, paramInt1, paramInt2);
  }

  public byte[] getrange(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    return this.headInterceptor.getrange(this.poolName, paramArrayOfByte, paramInt1, paramInt2);
  }

  public String getSet(String paramString1, String paramString2)
  {
    return this.headInterceptor.getSet(this.poolName, paramString1, paramString2);
  }

  public byte[] getSet(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    return this.headInterceptor.getSet(this.poolName, paramArrayOfByte1, paramArrayOfByte2);
  }

  public String compressGetSet(String paramString1, String paramString2)
  {
    return this.headInterceptor.compressGetSet(this.poolName, paramString1, paramString2);
  }

  public byte[] compressGetSet(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    return this.headInterceptor.compressGetSet(this.poolName, paramArrayOfByte1, paramArrayOfByte2);
  }

  public Long hdel(String paramString, String[] paramArrayOfString)
  {
    return this.headInterceptor.hdel(this.poolName, paramString, paramArrayOfString);
  }

  public Long hdel(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1)
  {
    return this.headInterceptor.hdel(this.poolName, paramArrayOfByte, paramArrayOfByte1);
  }

  public Boolean hexists(String paramString1, String paramString2)
  {
    return this.headInterceptor.hexists(this.poolName, paramString1, paramString2);
  }

  public Boolean hexists(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    return this.headInterceptor.hexists(this.poolName, paramArrayOfByte1, paramArrayOfByte2);
  }

  public Long hincrBy(String paramString1, String paramString2, int paramInt)
  {
    return this.headInterceptor.hincrBy(this.poolName, paramString1, paramString2, paramInt);
  }

  public Long hincrBy(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, int paramInt)
  {
    return this.headInterceptor.hincrBy(this.poolName, paramArrayOfByte1, paramArrayOfByte2, paramInt);
  }

  public Set<String> hkeys(String paramString)
  {
    return this.headInterceptor.hkeys(this.poolName, paramString);
  }

  public Set<byte[]> hkeys(byte[] paramArrayOfByte)
  {
    return this.headInterceptor.hkeys(this.poolName, paramArrayOfByte);
  }

  public Long hlen(String paramString)
  {
    return this.headInterceptor.hlen(this.poolName, paramString);
  }

  public Long hlen(byte[] paramArrayOfByte)
  {
    return this.headInterceptor.hlen(this.poolName, paramArrayOfByte);
  }

  public List<String> hmget(String paramString, String[] paramArrayOfString)
  {
    return this.headInterceptor.hmget(this.poolName, paramString, paramArrayOfString);
  }

  public List<byte[]> hmget(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1)
  {
    return this.headInterceptor.hmget(this.poolName, paramArrayOfByte, paramArrayOfByte1);
  }

  public Long hsetnx(String paramString1, String paramString2, String paramString3)
  {
    return this.headInterceptor.hsetnx(this.poolName, paramString1, paramString2, paramString3);
  }

  public Long hsetnx(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
  {
    return this.headInterceptor.hsetnx(this.poolName, paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3);
  }

  public List<String> hvals(String paramString)
  {
    return this.headInterceptor.hvals(this.poolName, paramString);
  }

  public List<byte[]> hvals(byte[] paramArrayOfByte)
  {
    return this.headInterceptor.hvals(this.poolName, paramArrayOfByte);
  }

  public Long incr(String paramString)
  {
    return this.headInterceptor.incr(this.poolName, paramString);
  }

  public Long incr(byte[] paramArrayOfByte)
  {
    return this.headInterceptor.incr(this.poolName, paramArrayOfByte);
  }

  public boolean electioneer(String paramString1, String paramString2, int paramInt)
  {
    return this.headInterceptor.electioneer(this.poolName, paramString1, paramString2, paramInt);
  }

  public boolean electioneer(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, int paramInt)
  {
    return this.headInterceptor.electioneer(this.poolName, paramArrayOfByte1, paramArrayOfByte2, paramInt);
  }

  public Long incrBy(String paramString, int paramInt)
  {
    return this.headInterceptor.incrBy(this.poolName, paramString, paramInt);
  }

  public Long incrBy(byte[] paramArrayOfByte, int paramInt)
  {
    return this.headInterceptor.incrBy(this.poolName, paramArrayOfByte, paramInt);
  }

  public void subscribe(String paramString, JedisPubSub paramJedisPubSub, String[] paramArrayOfString)
  {
    this.headInterceptor.subscribe(this.poolName, paramString, paramJedisPubSub, paramArrayOfString);
  }

  public void subscribe(byte[] paramArrayOfByte, JedisPubSub paramJedisPubSub, String[] paramArrayOfString)
  {
    this.headInterceptor.subscribe(this.poolName, paramArrayOfByte, paramJedisPubSub, paramArrayOfString);
  }

  public void publish(String paramString1, String paramString2, String paramString3)
  {
    this.headInterceptor.publish(this.poolName, paramString1, paramString2, paramString3);
  }

  public void publish(byte[] paramArrayOfByte, String paramString1, String paramString2)
  {
    this.headInterceptor.publish(this.poolName, paramArrayOfByte, paramString1, paramString2);
  }

  public Jedis getJedisByShardKey(String paramString)
  {
    return this.headInterceptor.getJedisByShardKey(this.poolName, paramString);
  }

  public Jedis getJedisByShardKey(byte[] paramArrayOfByte)
  {
    return this.headInterceptor.getJedisByShardKey(this.poolName, paramArrayOfByte);
  }

  public int getShardIndex(String paramString1, String paramString2)
  {
    return this.headInterceptor.getShardIndex(paramString1, paramString2);
  }

  public int getShardIndex(String paramString, byte[] paramArrayOfByte)
  {
    return this.headInterceptor.getShardIndex(paramString, paramArrayOfByte);
  }

  public long lpush(String paramString1, String paramString2)
  {
    return this.headInterceptor.lpush(this.poolName, paramString1, paramString2);
  }

  public long lpush(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    return this.headInterceptor.lpush(this.poolName, paramArrayOfByte1, paramArrayOfByte2);
  }

  public long rpushx(String paramString1, String paramString2)
  {
    return this.headInterceptor.rpushx(this.poolName, paramString1, paramString2);
  }

  public long rpushx(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    return this.headInterceptor.rpushx(this.poolName, paramArrayOfByte1, paramArrayOfByte2);
  }

  public long lpushx(String paramString1, String paramString2)
  {
    return this.headInterceptor.lpushx(this.poolName, paramString1, paramString2);
  }

  public long lpushx(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    return this.headInterceptor.lpushx(this.poolName, paramArrayOfByte1, paramArrayOfByte2);
  }

  public String lindex(String paramString, long paramLong)
  {
    return this.headInterceptor.lindex(this.poolName, paramString, paramLong);
  }

  public byte[] lindex(byte[] paramArrayOfByte, long paramLong)
  {
    return this.headInterceptor.lindex(this.poolName, paramArrayOfByte, paramLong);
  }

  public Long linsert(String paramString1, BinaryClient.LIST_POSITION paramLIST_POSITION, String paramString2, String paramString3)
  {
    return this.headInterceptor.linsert(this.poolName, paramString1, paramLIST_POSITION, paramString2, paramString3);
  }

  public Long linsert(byte[] paramArrayOfByte1, BinaryClient.LIST_POSITION paramLIST_POSITION, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
  {
    return this.headInterceptor.linsert(this.poolName, paramArrayOfByte1, paramLIST_POSITION, paramArrayOfByte2, paramArrayOfByte3);
  }

  public String lset(String paramString1, long paramLong, String paramString2)
  {
    return this.headInterceptor.lset(this.poolName, paramString1, paramLong, paramString2);
  }

  public String lset(byte[] paramArrayOfByte1, long paramLong, byte[] paramArrayOfByte2)
  {
    return this.headInterceptor.lset(this.poolName, paramArrayOfByte1, paramLong, paramArrayOfByte2);
  }

  public long ttl(String paramString)
  {
    return this.headInterceptor.ttl(this.poolName, paramString);
  }

  public long ttl(byte[] paramArrayOfByte)
  {
    return this.headInterceptor.ttl(this.poolName, paramArrayOfByte);
  }

  public Long expireAt(String paramString, long paramLong)
  {
    return this.headInterceptor.expireAt(this.poolName, paramString, paramLong);
  }

  public Long expireAt(byte[] paramArrayOfByte, long paramLong)
  {
    return this.headInterceptor.expireAt(this.poolName, paramArrayOfByte, paramLong);
  }

  public Long scard(String paramString)
  {
    return this.headInterceptor.scard(this.poolName, paramString);
  }

  public Long scard(byte[] paramArrayOfByte)
  {
    return this.headInterceptor.scard(this.poolName, paramArrayOfByte);
  }

  public String spop(String paramString)
  {
    return this.headInterceptor.spop(this.poolName, paramString);
  }

  public byte[] spop(byte[] paramArrayOfByte)
  {
    return this.headInterceptor.spop(this.poolName, paramArrayOfByte);
  }

  public String srandmember(String paramString)
  {
    return this.headInterceptor.srandmember(this.poolName, paramString);
  }

  public byte[] srandmember(byte[] paramArrayOfByte)
  {
    return this.headInterceptor.srandmember(this.poolName, paramArrayOfByte);
  }

  public String getPoolName()
  {
    return this.poolName;
  }

  public RedisInterceptor getHeadInterceptor()
  {
    return this.headInterceptor;
  }
}