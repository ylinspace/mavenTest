package com.yihaodian.common.ycache.util;

import com.yihaodian.configcentre.client.cache.ConfigCache;
import com.yihaodian.configcentre.client.utils.YccGlobalPropertyConfigurer;
import com.yihaodian.configcentre.manager.ManagerListener;
import com.yihaodian.configcentre.manager.YccManager;
import com.yihaodian.configcentre.manager.impl.DefaultYccManager;
import java.util.Properties;
import java.util.concurrent.Executor;
import org.apache.commons.lang.StringUtils;

public class PropertiesUtil
{
  public static Properties loadConfigProperties(String paramString1, String paramString2, boolean paramBoolean)
  {
    if (StringUtils.isNotBlank(paramString2))
    {
      YccGlobalPropertyConfigurer.init(paramString1, paramBoolean);
      Properties localProperties = YccGlobalPropertyConfigurer.getPropertiesByDataId(paramString1, paramString2);
      if (localProperties == null)
      {
        DefaultYccManager localDefaultYccManager = new DefaultYccManager(paramString1, paramString2, new ManagerListener()
        {
          public Executor getExecutor()
          {
            return null;
          }

          public void receiveConfigInfo(String paramString)
          {
          }
        });
        String str = localDefaultYccManager.getAvailableConfigureInfomation(4000L);
        if (str != null)
        {
          ConfigCache.addString(paramString1, paramString2, str);
          localProperties = YccGlobalPropertyConfigurer.loadPropertiesFromString(str);
          ConfigCache.addProperties(paramString1, paramString2, localProperties);
        }
      }
      return localProperties;
    }
    return new Properties();
  }
}