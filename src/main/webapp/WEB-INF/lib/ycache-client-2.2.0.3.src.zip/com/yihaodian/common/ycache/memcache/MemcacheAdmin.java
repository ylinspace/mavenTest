package com.yihaodian.common.ycache.memcache;

import com.ycache.danga.MemCached.SockIOPool;
import com.yihaodian.common.ycache.memcache.conf.MemcacheConfig;
import com.yihaodian.common.ycache.memcache.conf.MemcachePoolConfig;
import com.yihaodian.common.ycache.memcache.exception.MemcacheInitException;
import com.yihaodian.common.ycache.memcache.impl.BaseMemcacheProxy;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.util.CollectionUtils;

public class MemcacheAdmin
{
  protected static Log logger = LogFactory.getLog(MemcacheAdmin.class);
  private static MemcacheConfig config;
  private static Map<String, BaseMemcacheProxy> mcMap = new HashMap();
  private static MemcacheAdmin instance;

  public static MemcacheAdmin getInstance()
  {
    return instance;
  }

  public static BaseMemcacheProxy getBaseProxy(String paramString)
  {
    return instance.getBaseCient(paramString);
  }

  public static synchronized void init(InputStream paramInputStream)
    throws MemcacheInitException
  {
    MemcacheConfig localMemcacheConfig = MemcacheConfig.parseXmlConfig(paramInputStream);
    init(localMemcacheConfig);
  }

  static synchronized void init(MemcacheConfig paramMemcacheConfig)
  {
    if (instance != null)
      return;
    synchronized (MemcacheAdmin.class)
    {
      if (instance == null)
        break label22;
      return;
      label22: instance = new MemcacheAdmin(paramMemcacheConfig);
    }
  }

  MemcacheAdmin(MemcacheConfig paramMemcacheConfig)
  {
    config = paramMemcacheConfig;
    init();
  }

  public static void addByConfig(MemcachePoolConfig paramMemcachePoolConfig)
  {
    String str = paramMemcachePoolConfig.getPoolName();
    logger.info("    initializing pool:" + str + " ...");
    SockIOPool localSockIOPool = SockIOPool.getInstance(str);
    localSockIOPool.setServers(paramMemcachePoolConfig.getServers());
    localSockIOPool.setMaxBusyTime(paramMemcachePoolConfig.getMaxBusyTime());
    localSockIOPool.setInitConn(paramMemcachePoolConfig.getInitConn());
    localSockIOPool.setMinConn(paramMemcachePoolConfig.getMinConn());
    localSockIOPool.setMaxConn(paramMemcachePoolConfig.getMaxConn());
    localSockIOPool.setMaintSleep(paramMemcachePoolConfig.getMaintSleep());
    localSockIOPool.setNagle(paramMemcachePoolConfig.isNagle());
    localSockIOPool.setFailover(true);
    localSockIOPool.setSocketTO(paramMemcachePoolConfig.getSocketTo());
    localSockIOPool.setSocketConnectTO(paramMemcachePoolConfig.getSocketConnTo());
    localSockIOPool.setHashingAlg(3);
    localSockIOPool.setNoreply(paramMemcachePoolConfig.isNoreply());
    localSockIOPool.setMasterIDC(paramMemcachePoolConfig.getMasterIDC());
    localSockIOPool.setZkGroup(paramMemcachePoolConfig.getZkGroup());
    localSockIOPool.initialize();
    if (mcMap.get(str) == null)
    {
      BaseMemcacheProxy localBaseMemcacheProxy = new BaseMemcacheProxy(paramMemcachePoolConfig);
      mcMap.put(str, localBaseMemcacheProxy);
    }
    if (config.getPoolConfig(str) == null)
      config.addPoolConfig(paramMemcachePoolConfig);
  }

  private void init()
  {
    logger.info("---->>start to init memcache pools:");
    Iterator localIterator = config.getPoolConfigs().iterator();
    while (localIterator.hasNext())
    {
      MemcachePoolConfig localMemcachePoolConfig = (MemcachePoolConfig)localIterator.next();
      addByConfig(localMemcachePoolConfig);
    }
    logger.info("End to init memcache pools<<----");
  }

  public static void add(InputStream paramInputStream)
    throws MemcacheInitException
  {
    MemcacheConfig localMemcacheConfig = MemcacheConfig.parseXmlConfig(paramInputStream);
    logger.info("---->>start to init memcache pools:");
    Iterator localIterator = localMemcacheConfig.getPoolConfigs().iterator();
    while (localIterator.hasNext())
    {
      MemcachePoolConfig localMemcachePoolConfig = (MemcachePoolConfig)localIterator.next();
      String str = localMemcachePoolConfig.getPoolName();
      if (!(SockIOPool.getInstance(str).isInitialized()))
        addByConfig(localMemcachePoolConfig);
      logger.info("    Finished Add pool " + localMemcachePoolConfig.getPoolName());
    }
  }

  public void close()
  {
    logger.info("Memcache connections is going to close....");
    if (!(CollectionUtils.isEmpty(mcMap)))
    {
      Set localSet = mcMap.entrySet();
      Iterator localIterator = localSet.iterator();
      while (localIterator.hasNext())
      {
        Map.Entry localEntry = (Map.Entry)localIterator.next();
        String str = (String)localEntry.getKey();
        SockIOPool localSockIOPool = SockIOPool.getInstance(str);
        if (localSockIOPool != null)
        {
          logger.info("    memcache pool: " + str + " is going to close...");
          localSockIOPool.shutDown();
          logger.info("    memcache pool: " + str + " has been closed successfully!");
        }
      }
    }
    logger.info("All memcache connections has been colsed successfully!");
  }

  protected boolean containPool(String paramString)
  {
    return mcMap.containsKey(paramString);
  }

  public MemcacheConfig getConfig()
  {
    return config;
  }

  protected BaseMemcacheProxy getBaseCient(String paramString)
  {
    return ((BaseMemcacheProxy)mcMap.get(paramString));
  }

  public static MemcachePoolConfig getPoolConfig(String paramString)
  {
    return config.getPoolConfig(paramString);
  }
}