package com.yihaodian.common.ycache.memcache.interceptor;

import com.yihaodian.common.ycache.memcache.MemcacheInterceptor;
import java.util.Date;
import java.util.Map;

public class EmptyInterceptor
  implements MemcacheInterceptor
{
  protected MemcacheInterceptor nextHandler;

  public Object handleGet(String paramString1, String paramString2)
  {
    return getNextHandler().handleGet(paramString1, paramString2);
  }

  public Object handleGet(String paramString1, String paramString2, String paramString3)
  {
    return getNextHandler().handleGet(paramString1, paramString2, paramString3);
  }

  public Map<String, Object> handleGetMulti(String paramString, String[] paramArrayOfString)
  {
    return getNextHandler().handleGetMulti(paramString, paramArrayOfString);
  }

  public boolean handlePut(String paramString1, String paramString2, Object paramObject)
  {
    return getNextHandler().handlePut(paramString1, paramString2, paramObject);
  }

  public boolean handlePut(String paramString1, String paramString2, Object paramObject, int paramInt)
  {
    return getNextHandler().handlePut(paramString1, paramString2, paramObject, paramInt);
  }

  public boolean handlePut(String paramString1, String paramString2, Object paramObject, long paramLong)
  {
    return getNextHandler().handlePut(paramString1, paramString2, paramObject, paramLong);
  }

  public boolean handlePut(String paramString1, String paramString2, Object paramObject, Date paramDate)
  {
    return getNextHandler().handlePut(paramString1, paramString2, paramObject, paramDate);
  }

  public boolean handleRemove(String paramString1, String paramString2)
  {
    return getNextHandler().handleRemove(paramString1, paramString2);
  }

  public boolean handleRemove(String paramString1, String paramString2, String paramString3)
  {
    return getNextHandler().handleRemove(paramString1, paramString2, paramString3);
  }

  public boolean handleAdd(String paramString1, String paramString2, Object paramObject)
  {
    return getNextHandler().handleAdd(paramString1, paramString2, paramObject);
  }

  public boolean handleAdd(String paramString1, String paramString2, Object paramObject, int paramInt)
  {
    return getNextHandler().handleAdd(paramString1, paramString2, paramObject, paramInt);
  }

  public boolean handleAdd(String paramString1, String paramString2, Object paramObject, Date paramDate)
  {
    return getNextHandler().handleAdd(paramString1, paramString2, paramObject, paramDate);
  }

  public boolean handleAdd(String paramString1, String paramString2, Object paramObject, long paramLong)
  {
    return getNextHandler().handleAdd(paramString1, paramString2, paramObject, paramLong);
  }

  public MemcacheInterceptor getNextHandler()
  {
    return this.nextHandler;
  }

  public void setNextHandler(MemcacheInterceptor paramMemcacheInterceptor)
  {
    this.nextHandler = paramMemcacheInterceptor;
  }

  public long incr(String paramString1, String paramString2, long paramLong)
  {
    return getNextHandler().incr(paramString1, paramString2, paramLong);
  }

  public long decr(String paramString1, String paramString2, long paramLong)
  {
    return getNextHandler().decr(paramString1, paramString2, paramLong);
  }

  public boolean storeCounter(String paramString1, String paramString2, long paramLong)
  {
    return getNextHandler().storeCounter(paramString1, paramString2, paramLong);
  }

  public boolean storeCounter(String paramString1, String paramString2, long paramLong, int paramInt)
  {
    return getNextHandler().storeCounter(paramString1, paramString2, paramLong, paramInt);
  }

  public long getCounter(String paramString1, String paramString2)
  {
    return getNextHandler().getCounter(paramString1, paramString2);
  }

  public long addOrIncr(String paramString1, String paramString2, long paramLong)
  {
    return getNextHandler().addOrIncr(paramString1, paramString2, paramLong);
  }

  public long addOrDecr(String paramString1, String paramString2, long paramLong)
  {
    return getNextHandler().addOrDecr(paramString1, paramString2, paramLong);
  }

  public boolean handleReplace(String paramString1, String paramString2, Object paramObject)
  {
    return getNextHandler().handleReplace(paramString1, paramString2, paramObject);
  }

  public boolean handleReplace(String paramString1, String paramString2, Object paramObject, int paramInt)
  {
    return getNextHandler().handleReplace(paramString1, paramString2, paramObject, paramInt);
  }

  public boolean handleReplace(String paramString1, String paramString2, Object paramObject, Date paramDate)
  {
    return getNextHandler().handleReplace(paramString1, paramString2, paramObject, paramDate);
  }

  public boolean handleReplace(String paramString1, String paramString2, Object paramObject, long paramLong)
  {
    return getNextHandler().handleReplace(paramString1, paramString2, paramObject, paramLong);
  }
}