package com.yihaodian.common.yredis.client.conf;

import com.yihaodian.common.yredis.client.exception.RedisInitException;
import org.apache.commons.lang.StringUtils;
import org.dom4j.Element;

public class XmlParser
{
  public static Integer parseIntAttr(Element paramElement, String paramString)
    throws RedisInitException
  {
    String str = paramElement.attributeValue(paramString);
    checkRequiedAttr(paramString, str);
    return Integer.valueOf(trimToNull(str));
  }

  public static Long parseLongAttr(Element paramElement, String paramString)
    throws RedisInitException
  {
    String str = paramElement.attributeValue(paramString);
    checkRequiedAttr(paramString, str);
    return Long.valueOf(trimToNull(str));
  }

  public static boolean parseBooleanAttr(Element paramElement, String paramString)
    throws RedisInitException
  {
    String str = paramElement.attributeValue(paramString);
    checkRequiedAttr(paramString, str);
    return Boolean.valueOf(trimToNull(str)).booleanValue();
  }

  public static String parseAttr(Element paramElement, String paramString)
    throws RedisInitException
  {
    String str = paramElement.attributeValue(paramString);
    checkRequiedAttr(paramString, str);
    return trimToNull(str);
  }

  private static void checkRequiedAttr(String paramString1, String paramString2)
    throws RedisInitException
  {
    if (StringUtils.isEmpty(paramString2))
      throw new RedisInitException("memcache/redis configure file error: attribute " + paramString1 + " is required!");
  }

  private static String trimToNull(String paramString)
  {
    return StringUtils.trimToNull(paramString);
  }
}