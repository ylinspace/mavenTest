package com.yihaodian.common.ycache.memcache.conf;

import java.util.Arrays;

public class MemcachePoolConfig
{
  private String poolName;
  private int initConn;
  private int minConn;
  private int maxConn;
  private long maintSleep;
  private boolean nagle = false;
  private boolean failover = true;
  private int socketTo;
  private int socketConnTo;
  private int defaultExpiryMinutes;
  private long maxBusyTime;
  private boolean compressEnable = true;
  private boolean versionEnable = true;
  private String poolVersion;
  private boolean JDK = false;
  private int compressThreshold = 4096;
  private int sendEmailInterval = 10;
  private String[] servers;
  private String zkGroup;
  private boolean noreply = false;
  private boolean invalidAuto = false;
  private int invalidTTLMillisecond = 2000;
  private int invalidQueueTimeOut = 10;
  private int invalidQueueSize = 10000;
  private int invalidBatchSendTimeOut = 100;
  private int invaldiBatchSize = 10;
  private String masterIDC;
  private int syncTime;

  public int getSendEmailInterval()
  {
    return this.sendEmailInterval;
  }

  public void setSendEmailInterval(int paramInt)
  {
    this.sendEmailInterval = paramInt;
  }

  public String getPoolVersion()
  {
    return this.poolVersion;
  }

  public void setPoolVersion(String paramString)
  {
    this.poolVersion = paramString;
  }

  public long getMaxBusyTime()
  {
    return this.maxBusyTime;
  }

  public String getMasterIDC()
  {
    return this.masterIDC;
  }

  public void setMasterIDC(String paramString)
  {
    this.masterIDC = paramString;
  }

  public String getZkGroup()
  {
    return this.zkGroup;
  }

  public void setZkGroup(String paramString)
  {
    this.zkGroup = paramString;
  }

  public int getSyncTime()
  {
    return this.syncTime;
  }

  public void setSyncTime(int paramInt)
  {
    this.syncTime = paramInt;
  }

  public void setMaxBusyTime(long paramLong)
  {
    this.maxBusyTime = paramLong;
  }

  public boolean isCompressEnable()
  {
    return this.compressEnable;
  }

  public void setCompressEnable(boolean paramBoolean)
  {
    this.compressEnable = paramBoolean;
  }

  public boolean isVersionEnable()
  {
    return this.versionEnable;
  }

  public void setVersionEnable(boolean paramBoolean)
  {
    this.versionEnable = paramBoolean;
  }

  public int getCompressThreshold()
  {
    return this.compressThreshold;
  }

  public void setCompressThreshold(int paramInt)
  {
    this.compressThreshold = paramInt;
  }

  public boolean isJDK()
  {
    return this.JDK;
  }

  public void setJDK(boolean paramBoolean)
  {
    this.JDK = paramBoolean;
  }

  public int getDefaultExpiryMinutes()
  {
    return this.defaultExpiryMinutes;
  }

  public void setDefaultExpiryMinutes(int paramInt)
  {
    this.defaultExpiryMinutes = paramInt;
  }

  public boolean isFailover()
  {
    return this.failover;
  }

  public void setFailover(boolean paramBoolean)
  {
    this.failover = paramBoolean;
  }

  public int getSocketTo()
  {
    return this.socketTo;
  }

  public void setSocketTo(int paramInt)
  {
    this.socketTo = paramInt;
  }

  public int getSocketConnTo()
  {
    return this.socketConnTo;
  }

  public void setSocketConnTo(int paramInt)
  {
    this.socketConnTo = paramInt;
  }

  public String getPoolName()
  {
    return this.poolName;
  }

  public void setPoolName(String paramString)
  {
    this.poolName = paramString;
  }

  public int getInitConn()
  {
    return this.initConn;
  }

  public void setInitConn(int paramInt)
  {
    this.initConn = paramInt;
  }

  public int getMinConn()
  {
    return this.minConn;
  }

  public void setMinConn(int paramInt)
  {
    this.minConn = paramInt;
  }

  public int getMaxConn()
  {
    return this.maxConn;
  }

  public void setMaxConn(int paramInt)
  {
    this.maxConn = paramInt;
  }

  public long getMaintSleep()
  {
    return this.maintSleep;
  }

  public void setMaintSleep(long paramLong)
  {
    this.maintSleep = paramLong;
  }

  public boolean isNagle()
  {
    return this.nagle;
  }

  public void setNagle(boolean paramBoolean)
  {
    this.nagle = paramBoolean;
  }

  public String[] getServers()
  {
    return this.servers;
  }

  public void setServers(String[] paramArrayOfString)
  {
    this.servers = paramArrayOfString;
  }

  public boolean isInvalidAuto()
  {
    return this.invalidAuto;
  }

  public void setInvalidAuto(boolean paramBoolean)
  {
    this.invalidAuto = paramBoolean;
  }

  public boolean isNoreply()
  {
    return this.noreply;
  }

  public void setNoreply(boolean paramBoolean)
  {
    this.noreply = paramBoolean;
  }

  public int getInvalidTTLMillisecond()
  {
    return this.invalidTTLMillisecond;
  }

  public void setInvalidTTLMillisecond(int paramInt)
  {
    this.invalidTTLMillisecond = paramInt;
  }

  public int getInvalidQueueTimeOut()
  {
    return this.invalidQueueTimeOut;
  }

  public void setInvalidQueueTimeOut(int paramInt)
  {
    this.invalidQueueTimeOut = paramInt;
  }

  public int getInvalidQueueSize()
  {
    return this.invalidQueueSize;
  }

  public void setInvalidQueueSize(int paramInt)
  {
    this.invalidQueueSize = paramInt;
  }

  public int getInvaldiBatchSize()
  {
    return this.invaldiBatchSize;
  }

  public void setInvaldiBatchSize(int paramInt)
  {
    this.invaldiBatchSize = paramInt;
  }

  public int getInvalidBatchSendTimeOut()
  {
    return this.invalidBatchSendTimeOut;
  }

  public void setInvalidBatchSendTimeOut(int paramInt)
  {
    this.invalidBatchSendTimeOut = paramInt;
  }

  public String toString()
  {
    return "MemcachePoolConfig [poolName=" + this.poolName + ", initConn=" + this.initConn + ", minConn=" + this.minConn + ", maxConn=" + this.maxConn + ", maintSleep=" + this.maintSleep + ", nagle=" + this.nagle + ", failover=" + this.failover + ", socketTo=" + this.socketTo + ", socketConnTo=" + this.socketConnTo + ", defaultExpiryMinutes=" + this.defaultExpiryMinutes + ", maxBusyTime=" + this.maxBusyTime + ", compressEnable=" + this.compressEnable + ", versionEnable=" + this.versionEnable + ", JDK=" + this.JDK + ", compressThreshold=" + this.compressThreshold + ", servers=" + Arrays.toString(this.servers) + ", invalidAuto=" + this.invalidAuto + ", invalidTTLMillisecond=" + this.invalidTTLMillisecond + ", masterIDC=" + this.masterIDC + "]";
  }
}