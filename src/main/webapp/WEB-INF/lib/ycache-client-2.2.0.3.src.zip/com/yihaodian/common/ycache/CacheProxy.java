package com.yihaodian.common.ycache;

import java.util.Date;
import java.util.Map;

public abstract interface CacheProxy
{
  public abstract boolean put(String paramString, Object paramObject);

  public abstract boolean put(String paramString, Object paramObject, int paramInt);

  public abstract boolean put(String paramString, Object paramObject, Date paramDate);

  public abstract boolean putWithSecond(String paramString, Object paramObject, long paramLong);

  public abstract Object get(String paramString);

  public abstract Object get(String paramString1, String paramString2);

  public abstract Map<String, Object> getMulti(String[] paramArrayOfString);

  public abstract boolean remove(String paramString);

  public abstract boolean remove(String paramString1, String paramString2);

  public abstract boolean putStringWithSecond(String paramString1, String paramString2, long paramLong);

  public abstract boolean putString(String paramString1, String paramString2);

  public abstract boolean putString(String paramString1, String paramString2, int paramInt);

  public abstract boolean putString(String paramString, Object paramObject, Date paramDate);

  public abstract String getString(String paramString);

  public abstract String getString(String paramString1, String paramString2);

  public abstract boolean add(String paramString, Object paramObject);

  public abstract boolean add(String paramString, Object paramObject, int paramInt);

  public abstract boolean addWithSecond(String paramString, Object paramObject, long paramLong);

  public abstract boolean add(String paramString, Object paramObject, Date paramDate);

  public abstract long incr(String paramString, long paramLong);

  public abstract long decr(String paramString, long paramLong);

  public abstract boolean storeCounter(String paramString, long paramLong);

  public abstract long getCounter(String paramString);

  public abstract boolean storeCounter(String paramString, long paramLong, int paramInt);

  public abstract long addOrIncr(String paramString, long paramLong);

  public abstract long addOrDecr(String paramString, long paramLong);

  public abstract boolean replace(String paramString, Object paramObject);

  public abstract boolean replace(String paramString, Object paramObject, int paramInt);

  public abstract boolean replaceWithSecond(String paramString, Object paramObject, long paramLong);

  public abstract boolean replace(String paramString, Object paramObject, Date paramDate);
}