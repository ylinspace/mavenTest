package com.yihaodian.common.yredis.client.conf;

import com.yihaodian.common.yredis.client.exception.RedisInitException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

public class RedisConfig
{
  protected static Log logger = LogFactory.getLog(RedisConfig.class);
  List<RedisPoolConfig> poolConfigs = new ArrayList();

  public static RedisConfig parseXmlConfig(InputStream paramInputStream)
    throws RedisInitException
  {
    RedisConfig localRedisConfig = new RedisConfig();
    SAXReader localSAXReader = new SAXReader();
    try
    {
      Document localDocument = localSAXReader.read(paramInputStream);
      Element localElement = localDocument.getRootElement();
      Iterator localIterator = localElement.elementIterator("pool");
      while (localIterator.hasNext())
      {
        RedisPoolConfig localRedisPoolConfig = parseXmlPoolNode((Element)localIterator.next(), localRedisConfig);
        localRedisConfig.addPoolConfig(localRedisPoolConfig);
      }
    }
    catch (DocumentException localDocumentException)
    {
      throw new RedisInitException("redis config document parse error:", localDocumentException);
    }
    catch (Exception localException)
    {
      throw new RedisInitException("redis config parse error:", localException);
    }
    return localRedisConfig;
  }

  private static RedisPoolConfig parseXmlPoolNode(Element paramElement, RedisConfig paramRedisConfig)
    throws RedisInitException
  {
    RedisPoolConfig localRedisPoolConfig = new RedisPoolConfig();
    localRedisPoolConfig.setPoolName(XmlParser.parseAttr(paramElement, "id"));
    localRedisPoolConfig.setMaxActive(XmlParser.parseIntAttr(paramElement, "maxActive").intValue());
    localRedisPoolConfig.setMaxIdle(XmlParser.parseIntAttr(paramElement, "maxIdle").intValue());
    localRedisPoolConfig.setMaxWait(XmlParser.parseIntAttr(paramElement, "maxWait").intValue());
    localRedisPoolConfig.setTestOnBorrow(XmlParser.parseBooleanAttr(paramElement, "testOnBorrow"));
    localRedisPoolConfig.setTestOnReturn(XmlParser.parseBooleanAttr(paramElement, "testOnReturn"));
    try
    {
      localRedisPoolConfig.setInvalidAuto(XmlParser.parseBooleanAttr(paramElement, "invalidAuto"));
    }
    catch (Exception localException1)
    {
    }
    try
    {
      localRedisPoolConfig.setInvalidTTLMillisecond(XmlParser.parseIntAttr(paramElement, "invalidTTL").intValue());
    }
    catch (Exception localException2)
    {
    }
    try
    {
      localRedisPoolConfig.setInvalidQueueTimeOut(XmlParser.parseIntAttr(paramElement, "invalidQueueTimeOut").intValue());
    }
    catch (Exception localException3)
    {
    }
    try
    {
      localRedisPoolConfig.setInvalidQueueSize(XmlParser.parseIntAttr(paramElement, "invalidQueueSize").intValue());
    }
    catch (Exception localException4)
    {
    }
    try
    {
      localRedisPoolConfig.setInvaldiBatchSize(XmlParser.parseIntAttr(paramElement, "invaldiBatchSize").intValue());
    }
    catch (Exception localException5)
    {
    }
    try
    {
      localRedisPoolConfig.setInvalidBatchSendTimeOut(XmlParser.parseIntAttr(paramElement, "invalidBatchSendTimeOut").intValue());
    }
    catch (Exception localException6)
    {
    }
    try
    {
      localRedisPoolConfig.setZkGroup(XmlParser.parseAttr(paramElement, "zkGroup"));
    }
    catch (Exception localException7)
    {
    }
    if (StringUtils.isNotBlank(localRedisPoolConfig.getZkGroup()))
      logger.warn("The zookeeper group is changed, make sure u know what u r doing.!");
    return localRedisPoolConfig;
  }

  public List<RedisPoolConfig> getPoolConfigs()
  {
    return this.poolConfigs;
  }

  public RedisPoolConfig getPoolConfig(String paramString)
  {
    Iterator localIterator = this.poolConfigs.iterator();
    while (localIterator.hasNext())
    {
      RedisPoolConfig localRedisPoolConfig = (RedisPoolConfig)localIterator.next();
      if (localRedisPoolConfig.getPoolName().equals(paramString))
        return localRedisPoolConfig;
    }
    return null;
  }

  public void addPoolConfig(RedisPoolConfig paramRedisPoolConfig)
  {
    this.poolConfigs.add(paramRedisPoolConfig);
  }
}