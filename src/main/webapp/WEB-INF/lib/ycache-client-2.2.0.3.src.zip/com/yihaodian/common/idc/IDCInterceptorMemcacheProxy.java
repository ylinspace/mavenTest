package com.yihaodian.common.idc;

import com.yihaodian.common.ycache.memcache.MemcacheAdmin;
import com.yihaodian.common.ycache.memcache.MemcacheInterceptor;
import com.yihaodian.common.ycache.memcache.conf.MemcachePoolConfig;
import com.yihaodian.common.ycache.memcache.impl.BaseMemcacheProxy;
import com.yihaodian.common.ycache.memcache.impl.InterceptorMemcacheProxy;
import java.util.Date;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class IDCInterceptorMemcacheProxy extends InterceptorMemcacheProxy
  implements IDCMemcacheProxy
{
  protected Log logger = LogFactory.getLog(getClass());

  public IDCInterceptorMemcacheProxy(String paramString, MemcacheInterceptor paramMemcacheInterceptor)
  {
    super(paramString, paramMemcacheInterceptor);
  }

  public boolean remove(String paramString)
  {
    if (MemcacheAdmin.getBaseProxy(this.poolName).getPoolConfig().isInvalidAuto())
      invalid(paramString);
    return super.remove(paramString);
  }

  public boolean put(String paramString, Object paramObject)
  {
    int i = getTTL(paramString);
    if (i > 0)
      return super.put(paramString, paramObject, new Date(i));
    return super.put(paramString, paramObject);
  }

  public boolean put(String paramString, Object paramObject, int paramInt)
  {
    int i = getMinInvalidTTL(paramString, paramInt);
    return super.put(paramString, paramObject, new Date(i));
  }

  public boolean put(String paramString, Object paramObject, Date paramDate)
  {
    Date localDate = getMinInvalidTTL(paramString, paramDate);
    return super.put(paramString, paramObject, localDate);
  }

  public boolean add(String paramString, Object paramObject, Date paramDate)
  {
    Date localDate = getMinInvalidTTL(paramString, paramDate);
    return super.add(paramString, paramObject, localDate);
  }

  public boolean putString(String paramString1, String paramString2)
  {
    return put(paramString1, paramString2);
  }

  public boolean putString(String paramString1, String paramString2, int paramInt)
  {
    return put(paramString1, paramString2, paramInt);
  }

  public boolean replace(String paramString, Object paramObject)
  {
    int i = getTTL(paramString);
    if (i > 0)
    {
      BaseMemcacheProxy localBaseMemcacheProxy = MemcacheAdmin.getBaseProxy(getPoolName());
      return localBaseMemcacheProxy.replace(paramString, paramObject, new Date(i));
    }
    return super.replace(paramString, paramObject);
  }

  public boolean replace(String paramString, Object paramObject, int paramInt)
  {
    int i = getMinInvalidTTL(paramString, paramInt);
    if (i > 0)
    {
      BaseMemcacheProxy localBaseMemcacheProxy = MemcacheAdmin.getBaseProxy(getPoolName());
      return localBaseMemcacheProxy.replace(paramString, paramObject, new Date(i));
    }
    return super.replace(paramString, paramObject, paramInt);
  }

  public boolean invalid(String paramString)
  {
    return invalid(paramString, MemcacheAdmin.getPoolConfig(super.getPoolName()).getInvalidTTLMillisecond());
  }

  public boolean invalid(String paramString, int paramInt)
  {
    IDCCommandUtil.AddKey(paramString, null, this.poolName, "ai", paramInt + "");
    if ((IDCExecutorService.getInstance(10, 2).isAcceptTask(this.poolName)) && (IDCExecutorService.getInstance(10, 2).getTaskNumber(this.poolName) * 100 < IDCCommandUtil.getKeyNumber(this.poolName)))
    {
      Runnable localRunnable = IDCCommandUtil.getInvalidTask("tm", super.getPoolName());
      IDCExecutorService.getInstance(10, 2).submitTask(localRunnable, this.poolName);
    }
    if (IDCCommandUtil.getInvalidLocal_slave())
    {
      this.logger.info("invalid local cache key:" + paramString);
      super.put(IDCCommandUtil.getInvalidTTLKey(paramString), paramInt + "", new Date(paramInt));
    }
    return true;
  }

  public int getTTL(String paramString)
  {
    if (IDCCommandUtil.getInvalidNoTTL_master())
      return -1;
    String str = super.getString(IDCCommandUtil.getInvalidTTLKey(paramString));
    if ((str == null) || ("".equals(str.trim())))
      return -1;
    int i = 0;
    try
    {
      i = (int)Long.parseLong(str);
      if ((i < 0) || (i > 2 * MemcacheAdmin.getBaseProxy(this.poolName).getPoolConfig().getInvalidTTLMillisecond()))
        i = MemcacheAdmin.getBaseProxy(this.poolName).getPoolConfig().getInvalidTTLMillisecond();
    }
    catch (NumberFormatException localNumberFormatException)
    {
      localNumberFormatException.printStackTrace();
    }
    return i;
  }

  public boolean deleteTTL(String paramString)
  {
    return super.remove(IDCCommandUtil.getInvalidTTLKey(paramString));
  }

  int getMinInvalidTTL(String paramString, int paramInt)
  {
    int i = paramInt * 60 * 1000;
    int j = getTTL(paramString);
    if (j <= 0)
      return i;
    if (i > j)
      return j;
    return i;
  }

  Date getMinInvalidTTL(String paramString, Date paramDate)
  {
    int i = getTTL(paramString);
    if (i <= 0)
      return paramDate;
    if (paramDate.getTime() > i)
      return new Date(i);
    return paramDate;
  }
}