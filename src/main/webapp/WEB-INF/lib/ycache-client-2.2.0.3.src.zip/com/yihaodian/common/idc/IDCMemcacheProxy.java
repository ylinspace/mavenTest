package com.yihaodian.common.idc;

import com.yihaodian.common.ycache.CacheProxy;

public abstract interface IDCMemcacheProxy
{
}