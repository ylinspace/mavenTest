package com.yihaodian.common.yredis.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class SerializeUtil
{
  public static byte[] serialize(Object paramObject)
  {
    ObjectOutputStream localObjectOutputStream = null;
    ByteArrayOutputStream localByteArrayOutputStream = null;
    try
    {
      localByteArrayOutputStream = new ByteArrayOutputStream();
      localObjectOutputStream = new ObjectOutputStream(localByteArrayOutputStream);
      localObjectOutputStream.writeObject(paramObject);
      byte[] arrayOfByte = localByteArrayOutputStream.toByteArray();
      return arrayOfByte;
    }
    catch (Exception localException)
    {
    }
    return null;
  }

  public static Object unserialize(byte[] paramArrayOfByte)
  {
    ByteArrayInputStream localByteArrayInputStream = null;
    try
    {
      localByteArrayInputStream = new ByteArrayInputStream(paramArrayOfByte);
      ObjectInputStream localObjectInputStream = new ObjectInputStream(localByteArrayInputStream);
      return localObjectInputStream.readObject();
    }
    catch (Exception localException)
    {
    }
    return null;
  }
}