package com.yihaodian.arc.cache.zk;

import com.yihaodian.architecture.zkclient.IZkChildListener;
import com.yihaodian.architecture.zkclient.IZkDataListener;
import com.yihaodian.architecture.zkclient.ZkClient;
import com.yihaodian.common.yredis.client.RedisAdmin;
import com.yihaodian.common.yredis.client.conf.RedisPoolConfig;
import com.yihaodian.configcentre.client.utils.YccGlobalPropertyConfigurer;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

public class ZKRedisProxy
{
  public static Logger logger = Logger.getLogger(ZKRedisProxy.class);
  private static final String POOL_ZK_PATH_NCADDR = "/redis/pools";
  public static final String POOL_ZK_PATH_SLAVEOF = "/redis/slaveof";
  private static final String POOL_NAME = "yihaodian/common";
  private static final String CONF_FILE_NAME = "zookeeper-ycache.properties";
  private static final String ZK_NC_ADDR = "zk-servers";
  public ZkClient client;
  private String zkListenPath;
  private static int DEFAULT_TIMEOUT = 30000;

  public ZKRedisProxy(String paramString1, String paramString2)
    throws Exception
  {
    Properties localProperties = YccGlobalPropertyConfigurer.loadConfigProperties((StringUtils.isNotBlank(paramString2)) ? paramString2 : "yihaodian/common", "zookeeper-ycache.properties", false);
    String str = localProperties.getProperty("zk-servers");
    if ((str == null) || (str.equalsIgnoreCase("")))
      throw new Exception("zkAddrs is null");
    this.client = new ZkClient(str, DEFAULT_TIMEOUT);
    this.zkListenPath = "/redis/pools/" + paramString1;
    PoolDataChangedWatcher localPoolDataChangedWatcher = new PoolDataChangedWatcher(this, paramString1);
    this.client.subscribeChildChanges("/redis/slaveof", localPoolDataChangedWatcher);
    this.client.subscribeDataChanges(this.zkListenPath, localPoolDataChangedWatcher);
  }

  public List<String> getServerConnects(String paramString)
  {
    ArrayList localArrayList = new ArrayList();
    List localList = getNCServerConnections();
    if (localList.size() > 0)
    {
      Iterator localIterator = localList.iterator();
      while (localIterator.hasNext())
      {
        String str = (String)localIterator.next();
        localArrayList.add(StringUtils.trim(str));
      }
    }
    else
    {
      localArrayList.addAll(getMCServerConnections(paramString));
    }
    return localArrayList;
  }

  public List<String> getNCServerConnections()
  {
    ArrayList localArrayList = new ArrayList();
    List localList = this.client.getChildren("/redis/pools");
    if ((localList != null) && (localList.size() > 0))
    {
      Iterator localIterator = localList.iterator();
      while (localIterator.hasNext())
      {
        String str = (String)localIterator.next();
        localArrayList.add(StringUtils.trim(str));
      }
    }
    return localArrayList;
  }

  public List<String> getMCServerConnections(String paramString)
  {
    ArrayList localArrayList = new ArrayList();
    byte[] arrayOfByte = this.client.readRawData(this.zkListenPath, true);
    if (arrayOfByte != null)
    {
      String str1 = new String(arrayOfByte);
      String[] arrayOfString1 = StringUtils.split(str1, "\n");
      String[] arrayOfString2 = arrayOfString1;
      int i = arrayOfString2.length;
      for (int j = 0; j < i; ++j)
      {
        String str2 = arrayOfString2[j];
        localArrayList.add(str2);
      }
    }
    return localArrayList;
  }

  public void close()
  {
    if (this.client != null)
      this.client.close();
  }

  class PoolDataChangedWatcher
  implements IZkChildListener, IZkDataListener
  {
    private String poolName;

    public PoolDataChangedWatcher(, String paramString)
    {
      this.poolName = paramString;
    }

    public void handleChildChange(, List<String> paramList)
      throws Exception
    {
      ZKRedisProxy.logger.info("zookeeper event: handleChildChange. parentPath " + paramString + " children " + paramList.toString());
      if ((paramString.contains("/redis/slaveof")) && (HasSlaveChange(paramList).booleanValue()))
        reInitPool();
    }

    public void handleDataChange(, Object paramObject)
      throws Exception
    {
      ZKRedisProxy.logger.info("zookeeper event: handleDataChange. path " + paramString + " arg1 " + paramObject.toString());
      if (paramString.contains("/redis/slaveof"))
        return;
      reInitPool();
    }

    public void handleDataDeleted()
      throws Exception
    {
      ZKRedisProxy.logger.info("zookeeper event: handleDataDeleted. arg0 " + paramString.toString());
      if (paramString.contains("/redis/slaveof"))
        return;
      reInitPool();
    }

    private Boolean HasSlaveChange()
    {
      Iterator localIterator = RedisAdmin.getPoolConfig(this.poolName).getServers().entrySet().iterator();
      while (localIterator.hasNext())
      {
        Map.Entry localEntry = (Map.Entry)localIterator.next();
        if ((((Integer)localEntry.getValue()).intValue() == 2) && (!(paramList.contains(localEntry.getKey()))))
          return Boolean.valueOf(true);
        if ((((Integer)localEntry.getValue()).intValue() != 2) && (paramList.contains(localEntry.getKey())))
          return Boolean.valueOf(true);
      }
      return Boolean.valueOf(false);
    }

    private void reInitPool()
    {
      try
      {
        RedisAdmin.reInitialize(this.poolName);
      }
      catch (Exception localException)
      {
        ZKRedisProxy.logger.error("", localException);
      }
    }
  }
}