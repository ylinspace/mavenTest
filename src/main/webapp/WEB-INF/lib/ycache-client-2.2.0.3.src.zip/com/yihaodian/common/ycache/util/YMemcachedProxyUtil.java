package com.yihaodian.common.ycache.util;

import com.yihaodian.common.idc.IDCMemcacheProxy;
import com.yihaodian.common.ycache.memcache.IDCMemcacheProxyFactory;
import com.yihaodian.common.ycache.memcache.exception.MemcacheInitException;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class YMemcachedProxyUtil
{
  protected static Log logger = LogFactory.getLog(YMemcachedProxyUtil.class);
  private static String configurePath;
  private static String poolName;
  private static IDCMemcacheProxy cacheProxy;

  public YMemcachedProxyUtil(String paramString1, String paramString2)
  {
    configurePath = paramString1;
    poolName = paramString2;
    if (cacheProxy == null)
      init();
  }

  private static synchronized void init()
  {
    if (cacheProxy != null)
      return;
    if ((configurePath == null) || (poolName == null))
    {
      String str = "YMemcachedProxyUtil#Erro:Paras[configurePath] or [poolName] is null!";
      throw new RuntimeException(str);
    }
    try
    {
      IDCMemcacheProxyFactory.configure(configurePath);
    }
    catch (MemcacheInitException localMemcacheInitException)
    {
      logger.error("YMemcachedProxyUtil#getCacheProxy() error:", localMemcacheInitException);
      localMemcacheInitException.printStackTrace();
    }
    cacheProxy = IDCMemcacheProxyFactory.getClient(poolName);
  }

  public static IDCMemcacheProxy getCacheProxy()
  {
    if (cacheProxy == null)
      init();
    return cacheProxy;
  }

  public static String generateMasterPoolName(String paramString1, String paramString2)
  {
    if (StringUtils.isNotBlank(paramString2))
      return paramString1 + "_" + paramString2;
    return paramString1;
  }

  public static String getOriginalPoolName(String paramString1, String paramString2)
  {
    return paramString1.substring(0, paramString1.indexOf("_" + paramString2));
  }
}