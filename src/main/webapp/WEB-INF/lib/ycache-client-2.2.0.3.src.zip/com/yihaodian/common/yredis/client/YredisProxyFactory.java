package com.yihaodian.common.yredis.client;

import com.ycache.redis.clients.jedis.YredisHealthCheck;
import com.yihaodian.common.yredis.RedisProxy;
import com.yihaodian.common.yredis.client.exception.RedisInitException;
import com.yihaodian.common.yredis.client.impl.InterceptorRedisProxy;
import com.yihaodian.common.yredis.client.interceptor.RedisCoreInterceptor;
import com.yihaodian.common.yredis.client.interceptor.RedisEmptyInterceptor;
import com.yihaodian.configcentre.client.utils.YccGlobalPropertyConfigurer;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class YredisProxyFactory
{
  protected static Log logger = LogFactory.getLog(YredisProxyFactory.class);
  protected static YredisProxyFactory singletonFactory = null;
  protected static final Object initRedisLock = new Object();
  protected static YredisHealthCheck yredisHealthCheck = null;
  protected Map<String, RedisProxy> proxyPool = new HashMap();
  protected static String configureFilePath;
  protected RedisInterceptor headInterceptor;

  public static YredisProxyFactory configure(String paramString)
    throws RedisInitException
  {
    if (singletonFactory == null)
      synchronized (initRedisLock)
      {
        if (singletonFactory == null)
          singletonFactory = new YredisProxyFactory(paramString);
        else
          add(paramString);
      }
    else
      add(paramString);
    return singletonFactory;
  }

  public static YredisProxyFactory configure()
  {
    File localFile = YccGlobalPropertyConfigurer.loadConfigFile("yihaodian/common", "memcached_empty_config.xml");
    try
    {
      configure("file:" + localFile.getAbsolutePath());
    }
    catch (RedisInitException localRedisInitException)
    {
      logger.error("inital empty redis proxy fail. config file=memcached_empty_config.xml");
    }
    return null;
  }

  public static synchronized void destroy()
  {
    if (singletonFactory != null)
    {
      singletonFactory.close();
      singletonFactory = null;
    }
  }

  public static RedisProxy getClient(String paramString)
  {
    RedisProxy localRedisProxy = singletonFactory.findClient(paramString);
    yredisHealthCheck = YredisHealthCheck.getInstance();
    yredisHealthCheck.getRedisMap().put(paramString, localRedisProxy);
    return localRedisProxy;
  }

  public YredisProxyFactory(String paramString)
    throws RedisInitException
  {
    init(paramString);
  }

  protected RedisProxy findClient(String paramString)
  {
    if (this.proxyPool.containsKey(paramString))
      return ((RedisProxy)this.proxyPool.get(paramString));
    synchronized (this.proxyPool)
    {
      if (!(this.proxyPool.containsKey(paramString)))
        break label63;
      return ((RedisProxy)this.proxyPool.get(paramString));
      label63: if (RedisAdmin.getInstance().containPool(paramString))
        break label115;
      logger.warn("can't find redis pool:" + paramString + " make sure it is configured in file " + configureFilePath);
      return null;
      label115: InterceptorRedisProxy localInterceptorRedisProxy = new InterceptorRedisProxy(paramString, this.headInterceptor);
      this.proxyPool.put(paramString, localInterceptorRedisProxy);
    }
    return ((RedisProxy)this.proxyPool.get(paramString));
  }

  synchronized void init(String paramString)
    throws RedisInitException
  {
    configureFilePath = paramString.trim();
    logger.info("Load redis configure from path: " + configureFilePath);
    try
    {
      Object localObject;
      String[] arrayOfString;
      if (configureFilePath.startsWith("file:"))
      {
        arrayOfString = configureFilePath.split("file:");
        localObject = new FileInputStream(arrayOfString[1]);
      }
      else if (configureFilePath.startsWith("classpath:"))
      {
        arrayOfString = configureFilePath.split("classpath:");
        localObject = YredisProxyFactory.class.getClassLoader().getResourceAsStream(arrayOfString[1]);
      }
      else
      {
        localObject = YredisProxyFactory.class.getClassLoader().getResourceAsStream(configureFilePath);
      }
      RedisAdmin.init((InputStream)localObject);
      this.headInterceptor = new RedisEmptyInterceptor();
      this.headInterceptor.setNextHandler(new RedisCoreInterceptor());
      logger.info("End to init redis pools<<----");
    }
    catch (FileNotFoundException localFileNotFoundException)
    {
      logger.error(localFileNotFoundException);
      throw new RedisInitException("RedisProxyFactory#init() error:", localFileNotFoundException);
    }
    catch (Exception localException)
    {
      logger.error(localException);
      throw new RedisInitException("RedisProxyFactory#init() error:", localException);
    }
  }

  protected static synchronized void add(String paramString)
    throws RedisInitException
  {
    configureFilePath = paramString.trim();
    logger.info("Add redis configure from path: " + configureFilePath);
    try
    {
      Object localObject;
      String[] arrayOfString;
      if (configureFilePath.startsWith("file:"))
      {
        arrayOfString = configureFilePath.split("file:");
        localObject = new FileInputStream(arrayOfString[1]);
      }
      else if (configureFilePath.startsWith("classpath:"))
      {
        arrayOfString = configureFilePath.split("classpath:");
        localObject = YredisProxyFactory.class.getClassLoader().getResourceAsStream(arrayOfString[1]);
      }
      else
      {
        localObject = YredisProxyFactory.class.getClassLoader().getResourceAsStream(configureFilePath);
      }
      RedisAdmin.add((InputStream)localObject);
    }
    catch (FileNotFoundException localFileNotFoundException)
    {
      logger.error(localFileNotFoundException);
      throw new RedisInitException("RedisProxyFactory#init() error:", localFileNotFoundException);
    }
    catch (Exception localException)
    {
      logger.error(localException);
      throw new RedisInitException("RedisProxyFactory#init() error:", localException);
    }
  }

  public void close()
  {
    this.proxyPool.clear();
    configureFilePath = null;
    this.headInterceptor = null;
    RedisAdmin.getInstance().close();
  }
}