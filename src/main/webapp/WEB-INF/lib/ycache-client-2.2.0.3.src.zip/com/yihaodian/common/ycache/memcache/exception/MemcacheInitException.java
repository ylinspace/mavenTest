package com.yihaodian.common.ycache.memcache.exception;

public class MemcacheInitException extends Exception
{
  public MemcacheInitException(String paramString, Throwable paramThrowable)
  {
    super(paramString, paramThrowable);
  }

  public MemcacheInitException(String paramString)
  {
    super(paramString);
  }
}