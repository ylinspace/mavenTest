package com.yihaodian.common.idc;

public class IDCConstants
{
  public static final String IDCPoolName = "yihaodian/common";
  public static final String idc_ycache_memcache = "idc_ycache_memcache.xml";
  public static final String idc_common = "idc_common.properties";
  public static final String IDCCacheIdList = "idc_ycache_poolName_list";
  public static final String empty_config = "memcached_empty_config.xml";
  public static final String isInvalidLocal = "slave_idc_invalid_local";
  public static final String isInvalidOnlyDelete = "master_idc_invalid_no_ttl";
  public static final String Command_global_key = "IDC-";
  public static final Integer Command_Map_key_action = Integer.valueOf(0);
  public static final Integer Command_Map_key_cacheType = Integer.valueOf(1);
  public static final Integer Command_Map_key_poolName = Integer.valueOf(2);
  public static final Integer Command_Map_key_key = Integer.valueOf(3);
  public static final Integer Command_Map_key_value = Integer.valueOf(4);
  public static final Integer Command_Map_key_Invalid_ttlMillisecond = Integer.valueOf(5);
  public static final Integer Command_Map_key_Invalid_ttl_key = Integer.valueOf(6);
  public static final Integer Command_Map_key_version = Integer.valueOf(7);
  public static final String Command_Map_Value_action_invalid = "ai";
  public static final String Command_Map_Value_CacheType_Memcache = "tm";
  public static final String Command_Map_Value_CacheType_redis = "tr";
  public static final String Command_Map_Value_version = "2.0";
  public static final String Invalid_TTL_Key_Suffix = "_ai_ttl";
  public static final String IDC_CONNECTOR = "_";
  public static final String MASTER_CACHE_GROUP_KEY = "master-cache-group";
  public static final String NANHUI_IDC = "nh";
  public static final String IDC_COMMON_POOL = "yihaodian_common";
  public static final int SYNC_EXPIRE_TIME = 10;
}