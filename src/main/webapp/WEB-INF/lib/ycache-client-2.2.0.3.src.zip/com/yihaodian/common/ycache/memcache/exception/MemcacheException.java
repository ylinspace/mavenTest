package com.yihaodian.common.ycache.memcache.exception;

public class MemcacheException extends RuntimeException
{
  public MemcacheException(String paramString)
  {
    super(paramString);
  }

  public MemcacheException(String paramString, Throwable paramThrowable)
  {
    super(paramString, paramThrowable);
  }
}