package com.yihaodian.common.yredis.client.impl;

import com.ycache.redis.clients.jedis.ShardedJedisPool;
import com.yihaodian.common.yredis.client.interceptor.RedisCoreInterceptor;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class BaseRedisProxy extends RedisCoreInterceptor
{
  private Log logger = LogFactory.getLog(getClass());
  ShardedJedisPool shardedJedisPool;

  public BaseRedisProxy(ShardedJedisPool paramShardedJedisPool)
  {
    this.shardedJedisPool = paramShardedJedisPool;
  }

  protected ShardedJedisPool getShardedJedisPool(String paramString)
  {
    return getShardedJedisPool();
  }

  public ShardedJedisPool getShardedJedisPool()
  {
    return this.shardedJedisPool;
  }
}