package com.yihaodian.common.yredis.client;

import com.ycache.redis.clients.jedis.Jedis;
import com.ycache.redis.clients.jedis.JedisPoolConfig;
import com.ycache.redis.clients.jedis.JedisShardInfo;
import com.ycache.redis.clients.jedis.ShardedJedisPool;
import com.yihaodian.arc.cache.zk.ZKRedisProxy;
import com.yihaodian.architecture.zkclient.ZkClient;
import com.yihaodian.common.yredis.RedisProxy;
import com.yihaodian.common.yredis.client.conf.RedisConfig;
import com.yihaodian.common.yredis.client.conf.RedisPoolConfig;
import com.yihaodian.common.yredis.client.exception.RedisInitException;
import com.yihaodian.configcentre.client.utils.YccGlobalPropertyConfigurer;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.commons.pool.impl.GenericObjectPool.Config;

public class RedisAdmin
{
  protected static Log logger = LogFactory.getLog(RedisAdmin.class);
  private static RedisConfig config;
  private static Map<String, ShardedJedisPool> mcMap;
  private static RedisAdmin instance;
  private static final String REDIS_ADDR = "redis-servers";
  private static Executor executor = Executors.newFixedThreadPool(1);
  private static Map<String, Long> poolFailTs = new HashMap();

  public static RedisAdmin getInstance()
  {
    return instance;
  }

  public static synchronized void init(InputStream paramInputStream)
    throws RedisInitException
  {
    RedisConfig localRedisConfig = RedisConfig.parseXmlConfig(paramInputStream);
    init(localRedisConfig);
  }

  static synchronized void init(RedisConfig paramRedisConfig)
  {
    if (instance != null)
      return;
    synchronized (RedisAdmin.class)
    {
      if (instance == null)
        break label22;
      return;
      label22: instance = new RedisAdmin(paramRedisConfig);
    }
  }

  RedisAdmin(RedisConfig paramRedisConfig)
  {
    config = paramRedisConfig;
    mcMap = new HashMap();
    init();
    executor.execute(new Runnable(this)
    {
      public void run()
      {
        try
        {
          Thread.sleep(30000L);
          RedisAdmin.access$000(this.this$0);
        }
        catch (Exception localException)
        {
          RedisAdmin.logger.error("maintain pool error. " + localException);
        }
      }
    });
  }

  public static void addByConfig(RedisPoolConfig paramRedisPoolConfig)
  {
    String str1 = paramRedisPoolConfig.getPoolName();
    logger.info("    initializing pool " + str1 + "...");
    String[] arrayOfString1 = null;
    String[] arrayOfString2 = null;
    String[] arrayOfString3 = null;
    String str2 = getConfigPath(str1);
    File localFile = new File(str2);
    if (!(localFile.exists()))
      localFile.mkdirs();
    str2 = str2 + "redis_server.properties";
    int i = 0;
    try
    {
      if (paramRedisPoolConfig.zkClient == null)
        paramRedisPoolConfig.zkClient = new ZKRedisProxy(str1, paramRedisPoolConfig.getZkGroup());
      List localList = paramRedisPoolConfig.zkClient.getMCServerConnections(str1);
      if (localList.size() > 0)
        arrayOfString1 = (String[])localList.toArray(new String[localList.size()]);
    }
    catch (Exception localException)
    {
      logger.warn(str1 + " trying to connect zk fail, put local redis config to servers.");
      localObject2 = loadPropertiesFile(str2);
      String str3 = ((Properties)localObject2).getProperty("redis-servers");
      if ((str3 == null) || (str3.equalsIgnoreCase("")))
        logger.error(str2 + ": file is not exist or " + "redis-servers" + " is not exist.");
      else
        arrayOfString1 = str3.split(",");
      logger.warn(str3);
      i = 1;
    }
    if ((arrayOfString1 == null) || (arrayOfString1.length <= 0))
    {
      logger.error(str1 + ": ++++ trying to initialize with no servers");
      throw new IllegalStateException(str1 + ": ++++ trying to initialize with no servers");
    }
    if (i == 0)
    {
      logger.warn(str1 + " initialize successfully, redis server is: ");
      localObject1 = new Properties();
      localObject2 = "";
      for (int j = 0; j < arrayOfString1.length; ++j)
        if (j == 0)
          localObject2 = arrayOfString1[j];
        else
          localObject2 = ((String)localObject2) + "," + arrayOfString1[j];
      logger.warn(str1 + " ip: " + ((String)localObject2));
      localObject3 = null;
      try
      {
        localObject3 = new FileOutputStream(str2);
        ((Properties)localObject1).setProperty("redis-servers", (String)localObject2);
        ((Properties)localObject1).store((OutputStream)localObject3, str1);
      }
      catch (IOException localIOException3)
      {
        localIOException2.printStackTrace();
      }
      finally
      {
        if (localObject3 != null)
          try
          {
            ((OutputStream)localObject3).close();
          }
          catch (IOException localIOException4)
          {
            localIOException4.printStackTrace();
          }
      }
    }
    Object localObject1 = new JedisPoolConfig();
    ((JedisPoolConfig)localObject1).setMaxActive(paramRedisPoolConfig.getMaxActive());
    ((JedisPoolConfig)localObject1).setMaxIdle(paramRedisPoolConfig.getMaxIdle());
    ((JedisPoolConfig)localObject1).setMaxWait(paramRedisPoolConfig.getMaxWait());
    ((JedisPoolConfig)localObject1).setTestOnBorrow(paramRedisPoolConfig.isTestOnBorrow());
    ((JedisPoolConfig)localObject1).setTestOnReturn(paramRedisPoolConfig.isTestOnReturn());
    Object localObject2 = new ArrayList();
    Object localObject3 = paramRedisPoolConfig.zkClient.client.getChildren("/redis/slaveof");
    logger.info(str1 + ": slave servers:" + ((Object)localObject3).toString());
    Iterator localIterator = ((List)localObject3).iterator();
    while (localIterator.hasNext())
    {
      String str4 = (String)localIterator.next();
      if (paramRedisPoolConfig.getServers().get(str4) != null)
        paramRedisPoolConfig.addServers(str4, 2);
    }
    for (int k = 0; k < arrayOfString1.length; ++k)
    {
      arrayOfString2 = arrayOfString1[k].split("=");
      arrayOfString3 = arrayOfString2[1].split(":");
      int l = Integer.parseInt(arrayOfString3[1]);
      if (checkServer(arrayOfString3[0], l))
      {
        if (((List)localObject3).contains(arrayOfString3[0] + ":" + l))
        {
          paramRedisPoolConfig.addServers(arrayOfString3[0], l, 2);
          logger.warn(str1 + ": *slave* server:" + arrayOfString2[1]);
        }
        else
        {
          paramRedisPoolConfig.addServers(arrayOfString3[0], l, 1);
          ((List)localObject2).add(new JedisShardInfo(arrayOfString3[0], l, arrayOfString2[0]));
          logger.warn(str1 + ": has available server:" + arrayOfString2[1]);
        }
      }
      else
      {
        paramRedisPoolConfig.addServers(arrayOfString3[0], l, 3);
        logger.warn(str1 + ": has NOT available server:" + arrayOfString2[1]);
      }
    }
    if (((List)localObject2).size() > 0)
    {
      ShardedJedisPool localShardedJedisPool = new ShardedJedisPool((GenericObjectPool.Config)localObject1, (List)localObject2);
      localShardedJedisPool.setPoolName(str1);
      mcMap.put(str1, localShardedJedisPool);
    }
    else
    {
      logger.warn(" pool " + str1 + " has no available server.");
    }
    if (null == config.getPoolConfig(str1))
      config.addPoolConfig(paramRedisPoolConfig);
    logger.warn("Finished init pool " + paramRedisPoolConfig.getPoolName());
  }

  private void init()
  {
    logger.info("---->>start to init redis pools:");
    Iterator localIterator = config.getPoolConfigs().iterator();
    while (localIterator.hasNext())
    {
      RedisPoolConfig localRedisPoolConfig = (RedisPoolConfig)localIterator.next();
      addByConfig(localRedisPoolConfig);
    }
    logger.info("End to init redis pools<<----");
  }

  static void add(InputStream paramInputStream)
    throws RedisInitException
  {
    RedisConfig localRedisConfig = RedisConfig.parseXmlConfig(paramInputStream);
    logger.info("---->>start to add redis pools:");
    Iterator localIterator = localRedisConfig.getPoolConfigs().iterator();
    while (localIterator.hasNext())
    {
      RedisPoolConfig localRedisPoolConfig = (RedisPoolConfig)localIterator.next();
      addByConfig(localRedisPoolConfig);
    }
    logger.info("End to add redis pools<<----");
  }

  public static void reInitialize(String paramString)
    throws Exception
  {
    logger.info("---->>start to reInitialize redis pools:" + paramString + "...");
    Iterator localIterator = config.getPoolConfigs().iterator();
    while (localIterator.hasNext())
    {
      RedisPoolConfig localRedisPoolConfig = (RedisPoolConfig)localIterator.next();
      String str = localRedisPoolConfig.getPoolName();
      if (paramString.equalsIgnoreCase(str))
      {
        String[] arrayOfString1 = null;
        String[] arrayOfString2 = null;
        String[] arrayOfString3 = null;
        try
        {
          if (localRedisPoolConfig.zkClient == null)
            localRedisPoolConfig.zkClient = new ZKRedisProxy(str, localRedisPoolConfig.getZkGroup());
          List localList1 = localRedisPoolConfig.zkClient.getMCServerConnections(str);
          if (localList1.size() > 0)
            arrayOfString1 = (String[])localList1.toArray(new String[localList1.size()]);
        }
        catch (Exception localException)
        {
          logger.warn(str + " trying to connect zk to reInitialize redis fail.");
        }
        if ((arrayOfString1 == null) || (arrayOfString1.length <= 0))
        {
          logger.error(str + ": ++++ trying to initialize with no servers");
          throw new IllegalStateException(str + ": ++++ trying to initialize with no servers");
        }
        JedisPoolConfig localJedisPoolConfig = new JedisPoolConfig();
        localJedisPoolConfig.setMaxActive(localRedisPoolConfig.getMaxActive());
        localJedisPoolConfig.setMaxIdle(localRedisPoolConfig.getMaxIdle());
        localJedisPoolConfig.setMaxWait(localRedisPoolConfig.getMaxWait());
        localJedisPoolConfig.setTestOnBorrow(localRedisPoolConfig.isTestOnBorrow());
        localJedisPoolConfig.setTestOnReturn(localRedisPoolConfig.isTestOnReturn());
        ArrayList localArrayList = new ArrayList();
        localRedisPoolConfig.getServers().clear();
        List localList2 = localRedisPoolConfig.zkClient.client.getChildren("/redis/slaveof");
        logger.info(str + ": *slave* servers:" + localList2.toString());
        for (int i = 0; i < arrayOfString1.length; ++i)
        {
          arrayOfString2 = arrayOfString1[i].split("=");
          arrayOfString3 = arrayOfString2[1].split(":");
          int j = Integer.parseInt(arrayOfString3[1]);
          if (checkServer(arrayOfString3[0], j))
          {
            if (localList2.contains(arrayOfString3[0] + ":" + j))
            {
              localRedisPoolConfig.addServers(arrayOfString3[0], j, 2);
              logger.warn(str + ": slave server:" + arrayOfString2[1]);
            }
            else
            {
              localRedisPoolConfig.addServers(arrayOfString3[0], j, 1);
              localArrayList.add(new JedisShardInfo(arrayOfString3[0], j, arrayOfString2[0]));
              logger.warn(str + ": has available server:" + arrayOfString2[1]);
            }
          }
          else
          {
            localRedisPoolConfig.addServers(arrayOfString3[0], j, 3);
            logger.warn(str + ": has NOT available server:" + arrayOfString2[1]);
          }
        }
        ShardedJedisPool localShardedJedisPool1 = (ShardedJedisPool)mcMap.get(str);
        if (localShardedJedisPool1 != null)
          localShardedJedisPool1.destroy();
        if (localArrayList.size() > 0)
        {
          ShardedJedisPool localShardedJedisPool2 = new ShardedJedisPool(localJedisPoolConfig, localArrayList);
          localShardedJedisPool2.setPoolName(str);
          mcMap.put(str, localShardedJedisPool2);
        }
        else
        {
          logger.error(" pool " + str + " has no available server!");
        }
        logger.info("    Finished reInitialize pool " + str + "!");
      }
    }
    logger.info("End to reInitialize redis pools<<----");
  }

  protected static String getConfigPath(String paramString)
  {
    String str = System.getProperty("global.config.path") + File.separator + "ycc" + File.separator + "snapshot" + File.separator + paramString + File.separator + "redis" + File.separator;
    if ((str != null) && (!(str.equalsIgnoreCase(""))))
      return str;
    return System.getProperty("user.home") + File.separator;
  }

  protected static Properties loadPropertiesFile(String paramString)
  {
    Properties localProperties = new Properties();
    FileInputStream localFileInputStream = null;
    try
    {
      File localFile = new File(paramString);
      if (localFile.exists())
        localFileInputStream = new FileInputStream(localFile);
      if (localFileInputStream != null)
        localProperties.load(localFileInputStream);
    }
    catch (IOException localIOException3)
    {
      localIOException2.printStackTrace();
    }
    finally
    {
      if (localFileInputStream != null)
        try
        {
          localFileInputStream.close();
        }
        catch (IOException localIOException4)
        {
          localIOException4.printStackTrace();
        }
    }
    return localProperties;
  }

  public void close()
  {
    logger.info("redis connections is going to close....");
    Iterator localIterator = config.getPoolConfigs().iterator();
    while (localIterator.hasNext())
    {
      RedisPoolConfig localRedisPoolConfig = (RedisPoolConfig)localIterator.next();
      ShardedJedisPool localShardedJedisPool = (ShardedJedisPool)mcMap.get(localRedisPoolConfig.getPoolName());
      if (localShardedJedisPool != null)
      {
        logger.info("    redis pool: " + localRedisPoolConfig.getPoolName() + " is going to close...");
        localShardedJedisPool.destroy();
        logger.info("    redis pool: " + localRedisPoolConfig.getPoolName() + " has been closed successfully!");
      }
    }
    logger.info("All redis connections has been colsed successfully!");
  }

  public boolean containPool(String paramString)
  {
    return mcMap.containsKey(paramString);
  }

  protected ShardedJedisPool getBaseCient(String paramString)
  {
    return ((ShardedJedisPool)mcMap.get(paramString));
  }

  public static ShardedJedisPool getBaseProxy(String paramString)
  {
    return instance.getBaseCient(paramString);
  }

  protected RedisConfig getConfig()
  {
    return config;
  }

  public static RedisPoolConfig getPoolConfig(String paramString)
  {
    return getInstance().getConfig().getPoolConfig(paramString);
  }

  public static boolean checkServer(String paramString, int paramInt)
  {
    Jedis localJedis = new Jedis(paramString, paramInt, 1000);
    try
    {
      if (localJedis.ping().equals("PONG"))
      {
        localJedis.quit();
        localJedis.disconnect();
        return true;
      }
    }
    catch (Exception localException1)
    {
      logger.warn(paramString + ":" + paramInt + " check exception.");
    }
    try
    {
      localJedis.quit();
      localJedis.disconnect();
    }
    catch (Exception localException2)
    {
      logger.warn(paramString + ":" + paramInt + " quit after check exception.");
    }
    return false;
  }

  public static synchronized void fastFix(String paramString)
  {
    logger.warn(paramString + ": fastFix  enter!");
    if ((paramString == null) || ((poolFailTs.containsKey(paramString)) && (((Long)poolFailTs.get(paramString)).longValue() + 3000L > System.currentTimeMillis())))
    {
      logger.warn(paramString + ": fastFix  quit for too many caller in 3s!");
      return;
    }
    poolFailTs.put(paramString, Long.valueOf(System.currentTimeMillis()));
    Iterator localIterator = getPoolConfig(paramString).getServers().entrySet().iterator();
    while (localIterator.hasNext())
    {
      Map.Entry localEntry = (Map.Entry)localIterator.next();
      String[] arrayOfString = ((String)localEntry.getKey()).split(":");
      if ((((Integer)localEntry.getValue()).intValue() == 1) && (false == checkServer(arrayOfString[0], Integer.parseInt(arrayOfString[1]))))
      {
        try
        {
          reInitialize(paramString);
        }
        catch (Exception localException)
        {
          logger.warn(paramString + " fastFix  reInitialize fail!");
        }
        logger.warn(paramString + " is reinitialize in fastFix !!!");
        return;
      }
    }
  }

  private synchronized void mainTainPools()
    throws Exception
  {
    Iterator localIterator1 = config.getPoolConfigs().iterator();
    while (localIterator1.hasNext())
    {
      RedisPoolConfig localRedisPoolConfig = (RedisPoolConfig)localIterator1.next();
      String str = localRedisPoolConfig.getPoolName();
      Iterator localIterator2 = localRedisPoolConfig.getServers().entrySet().iterator();
      while (localIterator2.hasNext())
      {
        Map.Entry localEntry = (Map.Entry)localIterator2.next();
        String[] arrayOfString = ((String)localEntry.getKey()).split(":");
        if ((((Integer)localEntry.getValue()).intValue() == 3) && (true == checkServer(arrayOfString[0], Integer.parseInt(arrayOfString[1]))))
        {
          reInitialize(str);
          logger.warn(str + " is reinitialize in maintain task!!!");
          return;
        }
      }
    }
  }

  public static void main(String[] paramArrayOfString)
  {
    RedisProxy localRedisProxy;
    File localFile = YccGlobalPropertyConfigurer.loadConfigFile("yihaodian/common", "redis_test.xml");
    try
    {
      YredisProxyFactory.configure("file:" + localFile.getAbsolutePath());
      label40: localRedisProxy = YredisProxyFactory.getClient("im_chatLog");
    }
    catch (Exception localException1)
    {
      try
      {
        localRedisProxy.set("aaa", "bbb");
        String str = localRedisProxy.get("aaa");
        System.out.println(str);
        Thread.sleep(3000L);
      }
      catch (Exception localException2)
      {
        break label40:
        localException1 = localException1;
      }
    }
  }
}