package com.yihaodian.common.idc;

import com.ycache.danga.MemCached.MemCachedClient;
import com.ycache.redis.clients.jedis.ShardedJedis;
import com.ycache.redis.clients.jedis.ShardedJedisPool;
import com.yihaodian.architecture.hedwig.common.hessian.HedwigHessianInput;
import com.yihaodian.architecture.hedwig.common.hessian.HedwigHessianOutput;
import com.yihaodian.common.idc.cache.CacheAdmin;
import com.yihaodian.common.ycache.memcache.MemcacheAdmin;
import com.yihaodian.common.ycache.memcache.conf.MemcachePoolConfig;
import com.yihaodian.common.ycache.memcache.impl.BaseMemcacheProxy;
import com.yihaodian.common.yredis.client.impl.BaseRedisProxy;
import com.yihaodian.configcentre.client.utils.YccGlobalPropertyConfigurer;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class IDCCommandUtil
{
  protected static Log logger = LogFactory.getLog(IDCCommandUtil.class);
  static String[] OtherIDCPoolNames = null;
  static boolean invalidLocal_slave = false;
  static boolean invalidNoTTL_master = false;
  static Map<String, BlockingQueue<Map<Integer, Object>>> bqMap = new ConcurrentHashMap();
  private static Integer Command_queue_size = Integer.valueOf(10000);
  private static Integer Command_batch_send_size = Integer.valueOf(10);
  private static Integer Command_add_key_timeout = Integer.valueOf(10);
  private static Integer Command_send_key_timeout = Integer.valueOf(100);
  private static Integer Command_process_max_num_each_scheduler = Integer.valueOf(1000);
  private static Integer Command_process_max_time_each_scheduler = Integer.valueOf(500);

  public static void setCommand_queue_size(int paramInt)
  {
    Command_queue_size = Integer.valueOf(paramInt);
  }

  public static void setCommand_batch_send_size(int paramInt)
  {
    Command_batch_send_size = Integer.valueOf(paramInt);
  }

  public static void setCommand_add_key_timeout(int paramInt)
  {
    Command_add_key_timeout = Integer.valueOf(paramInt);
  }

  public static void setCommand_send_key_timeout(int paramInt)
  {
    Command_send_key_timeout = Integer.valueOf(paramInt);
  }

  public static void setCommand_process_max_each_scheduler(int paramInt)
  {
    Command_process_max_num_each_scheduler = Integer.valueOf(paramInt);
  }

  public static boolean AddKey(String paramString1, Object paramObject, String paramString2, String paramString3, String paramString4)
  {
    try
    {
      if (!(bqMap.containsKey(paramString2)))
        synchronized (bqMap)
        {
          if (!(bqMap.containsKey(paramString2)))
            bqMap.put(paramString2, new LinkedBlockingQueue(Command_queue_size.intValue()));
        }
      if ((Command_add_key_timeout.intValue() < 0) && (!(isWritable(paramString2))))
      {
        logger.error("add key to invalid queue fail because invalid queue full. key=" + paramString1);
        return false;
      }
      ??? = (BlockingQueue)bqMap.get(paramString2);
      HashMap localHashMap = new HashMap();
      localHashMap.put(IDCConstants.Command_Map_key_key, paramString1);
      localHashMap.put(IDCConstants.Command_Map_key_action, paramString3);
      if (null != paramObject)
        localHashMap.put(IDCConstants.Command_Map_key_value, paramObject);
      if (null != paramString4)
        localHashMap.put(IDCConstants.Command_Map_key_Invalid_ttlMillisecond, paramString4);
      return ((BlockingQueue)???).offer(localHashMap, Command_add_key_timeout.intValue(), TimeUnit.MILLISECONDS);
    }
    catch (Exception localException)
    {
      logger.error("add key to invalid queue fail. key=" + paramString1 + localException);
    }
    return false;
  }

  public static boolean AddCmd(Map<Integer, Object> paramMap)
  {
    String str;
    try
    {
      str = (String)paramMap.get(IDCConstants.Command_Map_key_poolName);
      if (!(bqMap.containsKey(str)))
        synchronized (bqMap)
        {
          if (!(bqMap.containsKey(str)))
          {
            bqMap.put(str, new LinkedBlockingQueue(Command_queue_size.intValue()));
            IDCExecutorService.getInstance().setWeight(str, CacheAdmin.getWeight(str));
          }
        }
      ??? = (BlockingQueue)bqMap.get(str);
      if (paramMap != null)
        return ((BlockingQueue)???).offer(paramMap, Command_add_key_timeout.intValue(), TimeUnit.MILLISECONDS);
    }
    catch (Exception localException)
    {
      logger.error("add cmd to invalid queue fail." + localException);
      return false;
    }
    return false;
  }

  public static int getKeyNumber()
  {
    int i = 0;
    Iterator localIterator = bqMap.keySet().iterator();
    while (localIterator.hasNext())
    {
      String str = (String)localIterator.next();
      i += ((BlockingQueue)bqMap.get(str)).size();
    }
    return i;
  }

  public static Map<String, Integer> getAllPoolKeyNumber()
  {
    HashMap localHashMap = new HashMap();
    Iterator localIterator = bqMap.keySet().iterator();
    while (localIterator.hasNext())
    {
      String str = (String)localIterator.next();
      localHashMap.put(str, Integer.valueOf(((BlockingQueue)bqMap.get(str)).size()));
    }
    return localHashMap;
  }

  public static int getKeyNumber(String paramString)
  {
    if (bqMap.containsKey(paramString))
      return ((BlockingQueue)bqMap.get(paramString)).size();
    return 0;
  }

  public static boolean isWritable(String paramString)
  {
    return (getKeyNumber(paramString) < Command_queue_size.intValue());
  }

  public static Runnable getInvalidTask(String paramString1, String paramString2)
  {
    1 local1 = new Runnable(paramString2, paramString1)
    {
      public void run()
      {
        if (IDCCommandUtil.getKeyNumber(this.val$poolName) == 0)
          return;
        String[] arrayOfString = IDCCommandUtil.getOtherIDCPoolNames();
        if (this.val$poolName.isEmpty())
        {
          IDCCommandUtil.logger.warn("No IDC pool found. ");
          return;
        }
        boolean bool1 = MemcacheAdmin.getPoolConfig(arrayOfString[0]).isNoreply();
        int i = 0;
        long l = System.currentTimeMillis();
        Random localRandom = new Random();
        BlockingQueue localBlockingQueue = (BlockingQueue)IDCCommandUtil.bqMap.get(this.val$poolName);
        while (true)
        {
          Object localObject2;
          Map localMap = null;
          LinkedList localLinkedList = new LinkedList();
          Object localObject1 = Integer.valueOf(0);
          while (((Integer)localObject1).intValue() < IDCCommandUtil.access$000().intValue())
          {
            try
            {
              localMap = (Map)localBlockingQueue.poll(IDCCommandUtil.access$100().intValue(), TimeUnit.MILLISECONDS);
            }
            catch (InterruptedException localInterruptedException)
            {
            }
            if (localMap == null)
              break;
            localObject2 = new HashMap();
            ((Map)localObject2).put(IDCConstants.Command_Map_key_action, (String)localMap.get(IDCConstants.Command_Map_key_action));
            ((Map)localObject2).put(IDCConstants.Command_Map_key_cacheType, this.val$cacheType);
            ((Map)localObject2).put(IDCConstants.Command_Map_key_poolName, this.val$poolName);
            if (bool1)
              ((Map)localObject2).put(IDCConstants.Command_Map_key_version, "2.0");
            if (null != localMap.get(IDCConstants.Command_Map_key_value))
              ((Map)localObject2).put(IDCConstants.Command_Map_key_value, localMap.get(IDCConstants.Command_Map_key_value));
            if (null != localMap.get(IDCConstants.Command_Map_key_Invalid_ttlMillisecond))
              ((Map)localObject2).put(IDCConstants.Command_Map_key_Invalid_ttlMillisecond, localMap.get(IDCConstants.Command_Map_key_Invalid_ttlMillisecond));
            if ("tm".equalsIgnoreCase(this.val$cacheType))
            {
              ((Map)localObject2).put(IDCConstants.Command_Map_key_key, MemcacheAdmin.getBaseProxy(this.val$poolName).getGoodKey((String)localMap.get(IDCConstants.Command_Map_key_key)));
              if (null != localMap.get(IDCConstants.Command_Map_key_Invalid_ttlMillisecond))
                ((Map)localObject2).put(IDCConstants.Command_Map_key_Invalid_ttl_key, MemcacheAdmin.getBaseProxy(this.val$poolName).getGoodKey(IDCCommandUtil.getInvalidTTLKey((String)localMap.get(IDCConstants.Command_Map_key_key))));
            }
            else
            {
              ((Map)localObject2).put(IDCConstants.Command_Map_key_key, localMap.get(IDCConstants.Command_Map_key_key));
              if (null != localMap.get(IDCConstants.Command_Map_key_Invalid_ttlMillisecond))
                ((Map)localObject2).put(IDCConstants.Command_Map_key_Invalid_ttl_key, IDCCommandUtil.getInvalidTTLKey((String)localMap.get(IDCConstants.Command_Map_key_key)));
            }
            localLinkedList.add(localObject2);
            localObject2 = localObject1;
            Integer localInteger = localObject1 = Integer.valueOf(((Integer)localObject1).intValue() + 1);
          }
          if (localLinkedList.size() == 0)
            return;
          localObject1 = arrayOfString;
          int j = localObject1.length;
          for (int k = 0; k < j; ++k)
          {
            String str = localObject1[k];
            BaseMemcacheProxy localBaseMemcacheProxy = MemcacheAdmin.getBaseProxy(str);
            if (localBaseMemcacheProxy != null)
              try
              {
                boolean bool2 = localBaseMemcacheProxy.put("IDC-" + str + localRandom.nextInt(10000), localLinkedList);
                if (!(bool2))
                  IDCCommandUtil.logger.error("Invalid fail！ no retry for now." + localLinkedList);
                else if (IDCCommandUtil.logger.isInfoEnabled())
                  IDCCommandUtil.logger.info("Invalid success" + localLinkedList);
              }
              catch (Exception localException)
              {
                IDCCommandUtil.logger.error("Invalid exception！" + localLinkedList);
                if (IDCCommandUtil.logger.isErrorEnabled())
                  IDCCommandUtil.logger.error(localException);
              }
            else
              IDCCommandUtil.logger.error("cannot find idc-pool cache, poolname=" + str);
          }
          if ((((++i > IDCCommandUtil.access$200().intValue()) || (System.currentTimeMillis() - l > IDCCommandUtil.access$300().intValue()))) && (localBlockingQueue.size() > 0))
          {
            IDCExecutorService.getInstance().submitTask(this, this.val$poolName);
            return;
          }
        }
      }
    };
    return local1;
  }

  public static Runnable getInvalidLocalTask(String paramString)
  {
    2 local2 = new Runnable(paramString)
    {
      public void run()
      {
        int i = 0;
        if (IDCCommandUtil.getKeyNumber(this.val$poolName) == 0)
          return;
        long l = System.currentTimeMillis();
        Random localRandom = new Random();
        BlockingQueue localBlockingQueue = (BlockingQueue)IDCCommandUtil.bqMap.get(this.val$poolName);
        while (true)
        {
          Map localMap = (Map)localBlockingQueue.poll();
          if (localMap == null)
            return;
          if ("tm".equalsIgnoreCase((String)localMap.get(IDCConstants.Command_Map_key_cacheType)))
            IDCCommandUtil.access$400(localMap);
          else
            IDCCommandUtil.access$500(localMap);
          if ((((++i > IDCCommandUtil.access$200().intValue()) || (System.currentTimeMillis() - l > IDCCommandUtil.access$300().intValue()))) && (localBlockingQueue.size() > 0))
          {
            IDCExecutorService.getInstance().submitTask(this, this.val$poolName);
            return;
          }
        }
      }
    };
    return local2;
  }

  private static void invalidMemcache(Map<Integer, Object> paramMap)
  {
    if (logger.isInfoEnabled())
      logger.info("invalid command =" + paramMap);
    String str1 = (String)paramMap.get(IDCConstants.Command_Map_key_poolName);
    Object localObject = CacheAdmin.getInstance().getMemcacheProxy(str1);
    MemCachedClient localMemCachedClient = ((BaseMemcacheProxy)localObject).getClient();
    if (!(invalidNoTTL_master))
    {
      localObject = (String)paramMap.get(IDCConstants.Command_Map_key_Invalid_ttl_key);
      String str2 = (String)paramMap.get(IDCConstants.Command_Map_key_Invalid_ttlMillisecond);
      int i = 1005;
      if (localObject != null)
      {
        try
        {
          i = Integer.parseInt(str2);
          i = (i < 1005) ? 1005 : i;
        }
        catch (NumberFormatException localNumberFormatException)
        {
          localNumberFormatException.printStackTrace();
        }
        boolean bool2 = localMemCachedClient.set((String)localObject, i + "", new Date(i));
        if ((!(bool2)) && (logger.isInfoEnabled()))
          logger.info("set ttl key result=" + bool2);
      }
      else if (logger.isErrorEnabled())
      {
        logger.error("Command_Map_key_Invalid_ttl_key is null");
      }
    }
    if ((String)paramMap.get(IDCConstants.Command_Map_key_key) != null)
    {
      boolean bool1 = localMemCachedClient.delete((String)paramMap.get(IDCConstants.Command_Map_key_key));
      if (logger.isInfoEnabled())
        logger.info("delete key result=" + bool1);
    }
    else if (logger.isInfoEnabled())
    {
      logger.info("key is null");
    }
  }

  private static void invalidRedis(Map<Integer, Object> paramMap)
  {
    if (logger.isInfoEnabled())
      logger.info("invalid command =" + paramMap);
    ShardedJedisPool localShardedJedisPool = CacheAdmin.getInstance().getRedisProxy((String)paramMap.get(IDCConstants.Command_Map_key_poolName)).getShardedJedisPool();
    ShardedJedis localShardedJedis = null;
    try
    {
      localShardedJedis = (ShardedJedis)localShardedJedisPool.getResource();
      if (!(invalidNoTTL_master))
      {
        String str1 = (String)paramMap.get(IDCConstants.Command_Map_key_Invalid_ttl_key);
        String str2 = (String)paramMap.get(IDCConstants.Command_Map_key_Invalid_ttlMillisecond);
        int i = 1;
        try
        {
          i = Integer.parseInt(str2) / 1000;
          i = (i < 1) ? 1 : i;
        }
        catch (NumberFormatException localNumberFormatException)
        {
          logger.error(localNumberFormatException);
        }
        String str3 = localShardedJedis.setex(str1, i, (i * 1000) + "");
        if (logger.isInfoEnabled())
          logger.info("set ttl key result=" + str3);
      }
      long l = localShardedJedis.del((String)paramMap.get(IDCConstants.Command_Map_key_key)).longValue();
      if (logger.isInfoEnabled())
        logger.info("delete key =" + l);
    }
    catch (Exception localException)
    {
      logger.error(localException);
    }
    finally
    {
      if (localShardedJedis != null)
        localShardedJedisPool.returnResource(localShardedJedis);
    }
  }

  public static void setInvalidNoTTL_master(boolean paramBoolean)
  {
    invalidNoTTL_master = paramBoolean;
  }

  public static boolean getInvalidNoTTL_master()
  {
    return invalidNoTTL_master;
  }

  public static void setInvalidLocal_slave(boolean paramBoolean)
  {
    invalidLocal_slave = paramBoolean;
  }

  public static boolean getInvalidLocal_slave()
  {
    return invalidLocal_slave;
  }

  public static void setOtherIDCPoolNames(String[] paramArrayOfString)
  {
    OtherIDCPoolNames = paramArrayOfString;
  }

  public static String[] getOtherIDCPoolNames()
  {
    if (OtherIDCPoolNames != null)
      return OtherIDCPoolNames;
    String str1 = YccGlobalPropertyConfigurer.loadConfigString("yihaodian/common", "idc_common.properties");
    Hashtable localHashtable = YccGlobalPropertyConfigurer.loadProperties(str1);
    String str2 = (String)localHashtable.get("idc_ycache_poolName_list");
    if ((str2 == null) || (str2.trim().length() == 0))
      logger.error("idc_common.properties 文件缺少值idc_ycache_poolName_list");
    OtherIDCPoolNames = str2.split(",");
    return OtherIDCPoolNames;
  }

  public static byte[] getBytes(Object paramObject)
    throws IOException
  {
    ByteArrayOutputStream localByteArrayOutputStream = null;
    HedwigHessianOutput localHedwigHessianOutput = null;
    try
    {
      localByteArrayOutputStream = new ByteArrayOutputStream();
      localHedwigHessianOutput = new HedwigHessianOutput(localByteArrayOutputStream);
      localHedwigHessianOutput.writeObject(paramObject);
      localHedwigHessianOutput.close();
      byte[] arrayOfByte1 = localByteArrayOutputStream.toByteArray();
      byte[] arrayOfByte2 = arrayOfByte1;
      return arrayOfByte2;
    }
    catch (IOException localIOException1)
    {
    }
    finally
    {
      try
      {
        if (localByteArrayOutputStream != null)
        {
          localByteArrayOutputStream.close();
          localByteArrayOutputStream = null;
        }
        if (localHedwigHessianOutput != null)
        {
          localHedwigHessianOutput.close();
          localHedwigHessianOutput = null;
        }
      }
      catch (IOException localIOException3)
      {
        logger.error(localIOException3);
      }
    }
  }

  public static LinkedList<Map<Integer, Object>> getList(byte[] paramArrayOfByte)
    throws IOException
  {
    ByteArrayInputStream localByteArrayInputStream = null;
    HedwigHessianInput localHedwigHessianInput = null;
    try
    {
      if (logger.isInfoEnabled())
        logger.info("value length:" + paramArrayOfByte.length);
      localByteArrayInputStream = new ByteArrayInputStream(paramArrayOfByte);
      localHedwigHessianInput = new HedwigHessianInput(localByteArrayInputStream);
      LinkedList localLinkedList1 = (LinkedList)localHedwigHessianInput.readObject(LinkedList.class);
      LinkedList localLinkedList2 = localLinkedList1;
      return localLinkedList2;
    }
    catch (IOException localIOException1)
    {
    }
    finally
    {
      try
      {
        if (localByteArrayInputStream != null)
        {
          localByteArrayInputStream.close();
          localByteArrayInputStream = null;
        }
        if (localHedwigHessianInput != null)
        {
          localHedwigHessianInput.close();
          localHedwigHessianInput = null;
        }
      }
      catch (IOException localIOException3)
      {
        logger.error(localIOException3);
      }
    }
  }

  public static String getInvalidTTLKey(String paramString)
  {
    return paramString + "_ai_ttl";
  }

  public static String showStatus()
  {
    String str1 = new String();
    if (OtherIDCPoolNames != null)
    {
      String[] arrayOfString = OtherIDCPoolNames;
      int i = arrayOfString.length;
      for (int j = 0; j < i; ++j)
      {
        String str2 = arrayOfString[j];
        str1 = str1 + str2 + ",";
      }
    }
    return new String("\r\n IDCCommandUtil status:\r\n OtherIDCPoolNames=" + str1.toString() + "\r\n Command_queue_size=" + Command_queue_size + " Command_add_key_timeout=" + Command_add_key_timeout + "\r\n Command_batch_send_size=" + Command_batch_send_size + " Command_add_key_timeout=" + Command_add_key_timeout + "\r\n queue key=" + getAllPoolKeyNumber().toString());
  }
}