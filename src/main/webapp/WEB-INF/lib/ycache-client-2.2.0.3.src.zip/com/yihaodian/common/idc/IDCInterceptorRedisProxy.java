package com.yihaodian.common.idc;

import com.ycache.redis.clients.util.SafeEncoder;
import com.yihaodian.common.yredis.client.RedisAdmin;
import com.yihaodian.common.yredis.client.RedisInterceptor;
import com.yihaodian.common.yredis.client.conf.RedisPoolConfig;
import com.yihaodian.common.yredis.client.impl.InterceptorRedisProxy;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class IDCInterceptorRedisProxy extends InterceptorRedisProxy
  implements IDCRedisProxy
{
  protected Log logger = LogFactory.getLog(getClass());

  public IDCInterceptorRedisProxy(String paramString, RedisInterceptor paramRedisInterceptor)
  {
    super(paramString, paramRedisInterceptor);
  }

  public long del(String paramString)
  {
    if (RedisAdmin.getPoolConfig(this.poolName).isInvalidAuto())
      invalid(paramString);
    return super.del(paramString);
  }

  public long del(byte[] paramArrayOfByte)
  {
    if (RedisAdmin.getPoolConfig(this.poolName).isInvalidAuto())
      invalid(SafeEncoder.encode(paramArrayOfByte));
    return super.del(paramArrayOfByte);
  }

  public String set(String paramString1, String paramString2)
  {
    int i = getTTLSecond(paramString1);
    if (i > 0)
      return super.setex(paramString1, i, paramString2);
    return super.set(paramString1, paramString2);
  }

  public String set(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    int i = getTTLSecond(SafeEncoder.encode(paramArrayOfByte1));
    if (i > 0)
      return super.setex(paramArrayOfByte1, i, paramArrayOfByte2);
    return super.set(paramArrayOfByte1, paramArrayOfByte2);
  }

  public String setex(String paramString1, int paramInt, String paramString2)
  {
    return super.setex(paramString1, getMinInvalidTTL(paramString1, paramInt), paramString2);
  }

  public String setex(byte[] paramArrayOfByte1, int paramInt, byte[] paramArrayOfByte2)
  {
    return super.setex(paramArrayOfByte1, getMinInvalidTTL(SafeEncoder.encode(paramArrayOfByte1), paramInt), paramArrayOfByte2);
  }

  public boolean invalid(String paramString)
  {
    return invalid(paramString, RedisAdmin.getPoolConfig(super.getPoolName()).getInvalidTTLMillisecond());
  }

  public boolean invalid(String paramString, int paramInt)
  {
    IDCCommandUtil.AddKey(paramString, null, this.poolName, "ai", paramInt + "");
    if ((IDCExecutorService.getInstance(10, 2).isAcceptTask(this.poolName)) && (IDCExecutorService.getInstance(10, 2).getTaskNumber(this.poolName) * 100 < IDCCommandUtil.getKeyNumber(this.poolName)))
    {
      Runnable localRunnable = IDCCommandUtil.getInvalidTask("tr", this.poolName);
      IDCExecutorService.getInstance(10, 2).submitTask(localRunnable, this.poolName);
    }
    if (IDCCommandUtil.getInvalidLocal_slave())
    {
      this.logger.info("invalid local cache key:" + paramString);
      super.setex(IDCCommandUtil.getInvalidTTLKey(paramString), paramInt / 1000, paramInt + "");
    }
    return true;
  }

  public int getTTL(String paramString)
  {
    if (IDCCommandUtil.getInvalidNoTTL_master())
      return -1;
    String str = super.get(IDCCommandUtil.getInvalidTTLKey(paramString));
    if ((str == null) || ("".equals(str.trim())))
      return -1;
    int i = 0;
    try
    {
      i = (int)Long.parseLong(str);
      if ((i < 0) || (i > 2 * RedisAdmin.getPoolConfig(this.poolName).getInvalidTTLMillisecond()))
        i = RedisAdmin.getPoolConfig(this.poolName).getInvalidTTLMillisecond();
    }
    catch (NumberFormatException localNumberFormatException)
    {
      localNumberFormatException.printStackTrace();
    }
    return i;
  }

  public boolean deleteTTL(String paramString)
  {
    Long localLong = Long.valueOf(super.del(IDCCommandUtil.getInvalidTTLKey(paramString)));
    return (localLong.longValue() > -6318802138378010624L);
  }

  public int getTTLSecond(String paramString)
  {
    int i = getTTL(paramString);
    return (i / 1000);
  }

  int getMinInvalidTTL(String paramString, int paramInt)
  {
    int i = getTTLSecond(paramString);
    if (i <= 0)
      return paramInt;
    if (paramInt > i)
      return i;
    return paramInt;
  }
}