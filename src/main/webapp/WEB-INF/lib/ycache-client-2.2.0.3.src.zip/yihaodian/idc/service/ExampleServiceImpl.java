package yihaodian.idc.service;

import com.yihaodian.common.idc.IDCInterceptorRedisProxy;
import com.yihaodian.common.idc.IDCMemcacheProxy;
import com.yihaodian.common.idc.IDCRedisProxy;
import com.yihaodian.common.ycache.memcache.IDCMemcacheProxyFactory;
import com.yihaodian.common.ycache.memcache.exception.MemcacheInitException;
import com.yihaodian.common.yredis.client.IDCRedisProxyFactory;
import com.yihaodian.common.yredis.client.exception.RedisInitException;
import com.yihaodian.configcentre.client.utils.YccGlobalPropertyConfigurer;
import java.io.File;
import java.io.PrintStream;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class ExampleServiceImpl
  implements ExampleService
{
  private Log logger = LogFactory.getLog(super.getClass());
  Map<String, IDCMemcacheProxy> memcacheProxyMap = new ConcurrentHashMap();
  Map<String, IDCRedisProxy> redisProxyMap = new ConcurrentHashMap();

  public boolean invalid(int paramInt1, String paramString1, String paramString2, String paramString3, String paramString4, int paramInt2)
  {
    if (paramInt1 == 0)
    {
      initMemcache(paramString1, paramString2, paramString3);
      localObject = (IDCMemcacheProxy)this.memcacheProxyMap.get(paramString3);
      return ((IDCMemcacheProxy)localObject).invalid(paramString4, paramInt2);
    }
    initRedis(paramString1, paramString2, paramString3);
    Object localObject = (IDCInterceptorRedisProxy)this.redisProxyMap.get(paramString3);
    return ((IDCInterceptorRedisProxy)localObject).invalid(paramString4, paramInt2);
  }

  public String get(int paramInt, String paramString1, String paramString2, String paramString3, String paramString4)
  {
    if (paramInt == 0)
    {
      initMemcache(paramString1, paramString2, paramString3);
      str = ((IDCMemcacheProxy)this.memcacheProxyMap.get(paramString3)).get(paramString4) + "";
      return str;
    }
    initRedis(paramString1, paramString2, paramString3);
    String str = ((IDCRedisProxy)this.redisProxyMap.get(paramString3)).get(paramString4);
    return str;
  }

  public int ttl(int paramInt, String paramString1, String paramString2, String paramString3, String paramString4)
  {
    if (paramInt == 0)
    {
      initMemcache(paramString1, paramString2, paramString3);
      i = ((IDCMemcacheProxy)this.memcacheProxyMap.get(paramString3)).getTTL(paramString4);
      return i;
    }
    initRedis(paramString1, paramString2, paramString3);
    int i = ((IDCRedisProxy)this.redisProxyMap.get(paramString3)).getTTL(paramString4);
    return i;
  }

  public boolean deleteTTL(int paramInt, String paramString1, String paramString2, String paramString3, String paramString4)
  {
    if (paramInt == 0)
    {
      initMemcache(paramString1, paramString2, paramString3);
      return ((IDCMemcacheProxy)this.memcacheProxyMap.get(paramString3)).deleteTTL(paramString4);
    }
    return false;
  }

  public boolean set(int paramInt1, String paramString1, String paramString2, String paramString3, String paramString4, int paramInt2, String paramString5)
  {
    if (paramInt1 == 0)
    {
      initMemcache(paramString1, paramString2, paramString3);
      boolean bool = ((IDCMemcacheProxy)this.memcacheProxyMap.get(paramString3)).put(paramString4, paramString5, paramInt2);
      return bool;
    }
    initRedis(paramString1, paramString2, paramString3);
    String str = ((IDCRedisProxy)this.redisProxyMap.get(paramString3)).setex(paramString4, paramInt2 * 60, paramString5);
    return "OK".equalsIgnoreCase(str);
  }

  private void initRedis(String paramString1, String paramString2, String paramString3)
  {
    if (!(this.redisProxyMap.containsKey(paramString3)))
      synchronized (this)
      {
        if (!(this.redisProxyMap.containsKey(paramString3)))
        {
          File localFile = YccGlobalPropertyConfigurer.loadConfigFile(paramString1, paramString2);
          try
          {
            IDCRedisProxyFactory.configure("file:" + localFile.getAbsolutePath());
            IDCRedisProxy localIDCRedisProxy = IDCRedisProxyFactory.getClient(paramString3);
            this.redisProxyMap.put(paramString3, localIDCRedisProxy);
          }
          catch (RedisInitException localRedisInitException)
          {
            localRedisInitException.printStackTrace();
          }
        }
      }
  }

  private void initMemcache(String paramString1, String paramString2, String paramString3)
  {
    if (!(this.memcacheProxyMap.containsKey(paramString3)))
      synchronized (this)
      {
        if (!(this.memcacheProxyMap.containsKey(paramString3)))
        {
          File localFile = YccGlobalPropertyConfigurer.loadConfigFile(paramString1, paramString2);
          try
          {
            IDCMemcacheProxyFactory.configure("file:" + localFile.getAbsolutePath());
            IDCMemcacheProxy localIDCMemcacheProxy = IDCMemcacheProxyFactory.getClient(paramString3);
            this.memcacheProxyMap.put(paramString3, localIDCMemcacheProxy);
          }
          catch (MemcacheInitException localMemcacheInitException)
          {
            this.logger.error(localMemcacheInitException);
          }
        }
      }
  }

  public static void main(String[] paramArrayOfString)
  {
    System.out.println("Hallo!");
    ExampleServiceImpl localExampleServiceImpl = new ExampleServiceImpl();
    for (int i = 0; i < 100000; ++i)
      localExampleServiceImpl.invalid(0, "yihaodian/common", "memcache.xml", "test", "aaa" + i, 100);
  }
}