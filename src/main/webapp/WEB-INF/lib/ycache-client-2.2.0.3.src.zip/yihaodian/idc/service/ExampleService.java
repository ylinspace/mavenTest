package yihaodian.idc.service;

public abstract interface ExampleService
{
  public abstract boolean invalid(int paramInt1, String paramString1, String paramString2, String paramString3, String paramString4, int paramInt2);

  public abstract String get(int paramInt, String paramString1, String paramString2, String paramString3, String paramString4);

  public abstract int ttl(int paramInt, String paramString1, String paramString2, String paramString3, String paramString4);

  public abstract boolean set(int paramInt1, String paramString1, String paramString2, String paramString3, String paramString4, int paramInt2, String paramString5);

  public abstract boolean deleteTTL(int paramInt, String paramString1, String paramString2, String paramString3, String paramString4);
}